import React from "react";
import ReactDOM from "react-dom";
import { Router } from "react-router-dom";
import { Provider } from "react-redux";
import { createStore, applyMiddleware, compose } from "redux";
import thunkMiddleware from "redux-thunk";
import { createBrowserHistory } from "history";
import App from "./App";
import "./index.scss";

export const history = createBrowserHistory();

import "./index.scss";

let middleware: any;

if ((window as any).__REDUX_DEVTOOLS_EXTENSION__) {
    middleware = compose(applyMiddleware(thunkMiddleware), (window as any).__REDUX_DEVTOOLS_EXTENSION__());
} else {
    middleware = applyMiddleware(thunkMiddleware);
}

export const store = createStore(state => state, middleware);

ReactDOM.render(
    <Provider store={store}>
        <Router history={history}>
            <App></App>
        </Router>
    </Provider>,
    document.getElementById("root"),
);
