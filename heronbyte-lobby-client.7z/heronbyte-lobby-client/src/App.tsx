import React, { useEffect, useState } from "react";
import { Switch, Route } from "react-router-dom";
import MainLayout from "./MainLayout";
import { AuthForm } from "./components/AuthForm";
import { getUser, logout, refresh, setAccessToken } from "./api/auth";
import { clearAuth, getAuth, setLocalAuth } from "./localstorage/auth";
import { CustomNavbar } from "./components/CustomNavbar";
import { Alert } from "react-bootstrap";
import { UserBar } from "./components/UserBar";

const App = (props: any) => {
    const [auth, setAuth] = useState(null);
    const [error, setError] = useState("");
    const [user, setUser] = useState(null);

    const setAuthWithLocal = (authObj: any) => {
        setAccessToken(authObj.access_token);
        setLocalAuth(authObj);
        setAuth(authObj);
    };

    const logoutUser = () => {
        logout(
            () => {
                setAuth(null);
                setAccessToken("");
                clearAuth();
            },
            err => {
                setError(err);

                setTimeout(() => {
                    setError("");
                }, 3000);
            },
        );
    };

    useEffect(() => {
        const authObj = getAuth();
        if (authObj !== null) {
            setAccessToken(authObj.access_token);
            setAuth(authObj);
        }
    }, []);

    useEffect(() => {
        setError("");

        if (auth !== null) {
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            const { expired_at, refresh_token } = auth;
            const expireDeadline = new Date();
            expireDeadline.setSeconds(expireDeadline.getSeconds() + 10);


            console.log(expireDeadline, expired_at, new Date(),  expired_at < expireDeadline)
            if (expired_at < expireDeadline) {
                refresh(setAuthWithLocal, setError)(refresh_token);
            }

            if (expired_at > expireDeadline) {
                getUser(setUser, setError);
            }
        }
    }, [auth]);

    useEffect(() => {
        document.title = "HeronByte.com!";
    }, []);

    if (auth === null || user === null) {
        return (
            <div className="App">
                <AuthForm setAuth={setAuthWithLocal} />
            </div>
        );
    }

    if (error !== "") {
        return <Alert variant="danger">{error}</Alert>;
    }

    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    const userBar = <UserBar login={user ? user.login : ""} logout={logoutUser} />;

    return (
        <Switch>
            <Route exact path="*">
                <CustomNavbar>
                    <div className="d-flex justify-content-end w-100">{userBar}</div>
                </CustomNavbar>
                <MainLayout />
            </Route>
        </Switch>
    );
};

export default App;
