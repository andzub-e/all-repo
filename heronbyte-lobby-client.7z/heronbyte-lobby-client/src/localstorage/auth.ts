const authKey = "auth";

const getAuth = () => {
    const localValue = localStorage.getItem(authKey);
    const auth = JSON.parse(localValue || "null");
    if (auth) {
        auth.expired_at = new Date(Date.parse(auth.expired_at));
        auth.created_at = new Date(Date.parse(auth.created_at));
    }
    return auth;
};

const clearAuth = () => {
    localStorage.removeItem(authKey);
};

const setLocalAuth = (auth: any) => {
    localStorage.setItem(authKey, JSON.stringify(auth));
};

export { setLocalAuth, getAuth, clearAuth };
