import { CONFIG } from "../config";
import { IGame } from "../components/Lobby";
import { apiInfo } from "./auth";


const getGames = (onSuccess: (games: IGame[]) => void, onFailure: (reason: any) => void): void => {
    const url = new URL(CONFIG.server_url + "games");
    fetch(url.toString(), {
        method: "GET",
        headers: {
            "X-Auth": apiInfo.accessToken,
        },
    })
        .then(body => body.json())
        .then(result => onSuccess(result.data))
        .catch(onFailure);
};

const getCachedGameIndex = (): number => {
    const item = localStorage.getItem(CONFIG.local_storage_key);
    let index = -1;
    if (item) {
        index = parseInt(item);
    }

    return index;
};

export { getGames, getCachedGameIndex };
