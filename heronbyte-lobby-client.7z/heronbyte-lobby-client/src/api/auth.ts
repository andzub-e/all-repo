import { CONFIG } from "../config";

const apiInfo = {
    accessToken: "",
};

const setAccessToken = (token: string) => {
    apiInfo.accessToken = token;
};

const login = (setSuccess: (res: any) => void, onFailure: (res: any) => void) => (login: string, password: string) => {
    fetch(CONFIG.server_url + "auth/login", {
        method: "POST",
        body: JSON.stringify({ login, password }),
    })
        .then(b => b.json())
        .then(res => {
            if (res.status === 200) {
                const expire = new Date(Date.parse(res.data.expired_at));
                const created = new Date(Date.parse(res.data.created_at));

                setSuccess({
                    expired_at: expire,
                    created_at: created,
                    access_token: res.data.access_token,
                    refresh_token: res.data.refresh_token,
                });
            } else {
                onFailure(res.data);
            }
        })
        .catch(err => onFailure(err.toString()));
};

const refresh = (setSuccess: (res: any) => void, onFailure: (res: any) => void) => (token: string) => {
    fetch(CONFIG.server_url + "auth/refresh", {
        method: "POST",
        headers: {
            "X-Auth": token,
        },
    })
        .then(b => b.json())
        .then(res => {
            if (res.status === 200) {
                const expire = new Date(Date.parse(res.data.expired_at));
                const created = new Date(Date.parse(res.data.created_at));

                setSuccess({
                    expired_at: expire,
                    created_at: created,
                    access_token: res.data.access_token,
                    refresh_token: res.data.refresh_token,
                });
            } else {
                onFailure(res.data);
            }
        })
        .catch(err => onFailure(err.toString()));
};

const logout = (onSuccess: () => void, setError: (res: any) => void) => {
    fetch(CONFIG.server_url + "auth/logout", {
        method: "POST",
        headers: {
            "X-Auth": apiInfo.accessToken,
        },
    })
        .then(b => b.json())
        .then(res => {
            if (res.status === 200) {
                onSuccess();
            } else {
                setError(res.data);
            }
        })
        .catch(err => setError(err.toString()));
};

const getUser = (setUser: (res: any) => void, setError: (res: any) => void) => {
    fetch(CONFIG.server_url + "auth/user", {
        method: "GET",
        headers: {
            "X-Auth": apiInfo.accessToken,
        },
    })
        .then(b => b.json())
        .then(res => {
            if (res.status === 200) {
                setUser(res.data);
            } else {
                setError(res.data);
            }
        })
        .catch(err => setError(err.toString()));
};

export { login, refresh, logout, getUser, setAccessToken, apiInfo };
