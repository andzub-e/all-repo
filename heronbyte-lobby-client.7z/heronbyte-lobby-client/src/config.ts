export const CONFIG = {
    server_url: "https://dev-lobby.heronbyte.com/api/",
    local_storage_key: "heronbyte_lobby_game_id",
};
