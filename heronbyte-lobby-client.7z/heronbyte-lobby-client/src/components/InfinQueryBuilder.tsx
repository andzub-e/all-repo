import { Box, Button, TextField } from "@material-ui/core";
import { CustomCheckbox } from "./Checkbox";
import { CustomSelect } from "./Select";
import { FreeSpinButton } from "./FreeSpinButton";
import React, { useEffect, useState } from "react";

interface Props {
    game: any;
    env: string;

    setSearchParams(s: string): void;
}

const InfinQueryBuilder = (props: Props) => {
    const { game, env, setSearchParams } = props;

    const [userID, setUserID] = useState("");

    const [isCheatsShown, setIsCheatsShown] = useState(false);

    const [userLocale, setUserLocale] = useState(game.user_locale[0]);

    const buildSearchParams = (): string => {
        const sp = new URLSearchParams();

        sp.set("key", userID);
        sp.set("lang", userLocale.split("_")[0]);
        sp.set("integrator", "infingame");
        sp.set("partner", "infingame");
        sp.set("platform", "desk");

        if (isCheatsShown) {
            sp.set("showcheats", "true");
        }

        return sp.toString();
    };

    useEffect(() => {
        setSearchParams(buildSearchParams());
    }, [userID, isCheatsShown, userLocale, env, game.owner]);

    return (
        <div>
            <Box display="flex" pt={2}>
                <form noValidate autoComplete="off">
                    <p className="lobby__group_header">User</p>
                    <input
                        className="user-input"
                        value={userID}
                        style={{ width: "450px" }}
                        placeholder="Get key on integrator's site"
                        onChange={e => setUserID(e.target.value)}
                    />
                </form>
            </Box>

            {/* checkboxes */}

            <div className="checkbox_container">
                <CustomCheckbox name="cheats" onChange={() => setIsCheatsShown(!isCheatsShown)} value={isCheatsShown} />
            </div>

            {/* selects */}

            <div className="d-flex justify-content-between w-50">
                <select
                    name={"userLocale"}
                    value={userLocale}
                    className="select-container__select"
                    onChange={e => setUserLocale(e.target.value)}
                >
                    {game.user_locale?.map(
                        (loc: boolean | React.ReactChild | React.ReactFragment | React.ReactPortal | null | undefined) => {
                            // eslint-disable-next-line react/jsx-key
                            return <option>{loc}</option>;
                        },
                    )}
                </select>
            </div>
        </div>
    );
};

export default InfinQueryBuilder;
