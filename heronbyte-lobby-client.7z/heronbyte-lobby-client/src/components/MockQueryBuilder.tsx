import { Box, Button } from "@material-ui/core";
import { CustomCheckbox } from "./Checkbox";
import { FreeSpinButton } from "./FreeSpinButton";
import React, { useEffect, useState } from "react";
import { ToggleButton, ToggleButtonGroup } from "@material-ui/lab";

interface Props {
    game: any;
    env: string;

    setSearchParams(s: string): void;
}

const MockQueryBuilder = (props: Props) => {
    const { game, env, setSearchParams } = props;

    const [userID, setUserID] = useState(uuid());

    const [isLowBalance, setIsLowBalance] = useState(false);
    const [isCheatsShown, setIsCheatsShown] = useState(false);
    const [isLobbyUrl, setIsLobbyUrl] = useState(false);

    const operators = ["mock", "mock1", "mock2"];

    const [jurisdiction, setJurisdiction] = useState(game.jurisdictions[0]);
    const [currency, setCurrency] = useState(game.currencies[0]);
    const [userLocale, setUserLocale] = useState(game.user_locale[0]);

    const [operator, setOperator] = useState(operators[0]);

    const buildSearchParams = (): string => {
        const sp = new URLSearchParams();

        sp.set("user_id", userID);
        sp.set("jurisdiction", jurisdiction);
        sp.set("currency", currency);
        sp.set("user_locale", userLocale.replace("_", "-"));
        sp.set("integrator", "mock");
        sp.set("operator", operator);

        if (isLowBalance) {
            sp.set("low_balance", "true");
        }

        if (isCheatsShown) {
            sp.set("showcheats", "true");
        }

        if (isLowBalance) {
            sp.set("lobbyurl", window.location.href);
        }

        return sp.toString();
    };

    useEffect(() => {
        setSearchParams(buildSearchParams());
    }, [userID, isLowBalance, isCheatsShown, isLobbyUrl, jurisdiction, currency, userLocale, env, operator, game.owner]);

    const gameSplit = game.dev_url.split("/");
    const gameName = gameSplit[gameSplit.length - 2];

    return (
        <div className="builder">
            <p className="editor__group_header">Operator</p>
            <ToggleButtonGroup
                value={operator}
                exclusive
                onChange={(event: React.MouseEvent<HTMLElement, MouseEvent>, value: string) => {
                    setOperator(value);
                }}
                aria-label="text alignment"
            >
                {operators.map(oper => {
                    return (
                        <ToggleButton
                            className="builder__button"
                            key={oper}
                            value={oper}
                            disabled={operator == oper}
                            aria-label="left aligned"
                        >
                            {oper}
                        </ToggleButton>
                    );
                })}
            </ToggleButtonGroup>
            <Box display="flex" pt={2}>
                <form noValidate autoComplete="off">
                    <p className="lobby__group_header">User</p>
                    <input
                        className="user-input"
                        value={userID}
                        style={{ width: "450px" }}
                        onChange={() => {
                            return null;
                        }}
                    />
                </form>
                <Button onClick={() => setUserID(uuid())} className="user-input-button">
                    generate
                </Button>
            </Box>

            {/* checkboxes */}

            <div className="checkbox_container">
                <CustomCheckbox name="low_balance" onChange={() => setIsLowBalance(!isLowBalance)} value={isLowBalance} />
                <CustomCheckbox name="cheats" onChange={() => setIsCheatsShown(!isCheatsShown)} value={isCheatsShown} />
                <CustomCheckbox name="lobbyurl" onChange={() => setIsLobbyUrl(!isLobbyUrl)} value={isLobbyUrl} />
            </div>

            {/* selects */}

            <div className="select-container">
                <select
                    name={"jurisdiction"}
                    className="select-container__select"
                    value={jurisdiction}
                    onChange={e => setJurisdiction(e.target.value)}
                >
                    {game.jurisdictions?.map(
                        (jur: boolean | React.ReactChild | React.ReactFragment | React.ReactPortal | null | undefined) => {
                            // eslint-disable-next-line react/jsx-key
                            return <option>{jur}</option>;
                        },
                    )}
                </select>
                <select name={"currency"} className="select-container__select" value={currency} onChange={e => setCurrency(e.target.value)}>
                    {game.currencies?.map(
                        (cur: boolean | React.ReactChild | React.ReactFragment | React.ReactPortal | null | undefined) => {
                            // eslint-disable-next-line react/jsx-key
                            return <option>{cur}</option>;
                        },
                    )}
                </select>
                <select
                    name={"userLocale"}
                    value={userLocale}
                    className="select-container__select"
                    onChange={e => setUserLocale(e.target.value)}
                >
                    {game.user_locale?.map(
                        (loc: boolean | React.ReactChild | React.ReactFragment | React.ReactPortal | null | undefined) => {
                            // eslint-disable-next-line react/jsx-key
                            return <option>{loc}</option>;
                        },
                    )}
                </select>
            </div>

            <Box my={5}>
                <FreeSpinButton gameName={gameName} userID={userID} currency={currency} env={env} gameOwner={game.owner}/>
            </Box>
        </div>
    );
};

function uuid() {
    return (`${1e7}` + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c: any) =>
        (c ^ (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))).toString(16),
    );
}

export default MockQueryBuilder;
