import { Box } from "@material-ui/core";
import React from "react";

interface Props {
    history: History[];
}

interface History {
    url: string;
    date: string;
}

const HistoryList = (props: Props) => {
    const { history } = props;

    if (history.length == 0) {
        return <Box my={5} />;
    }

    return (
        <Box className="history" my={5}>
            <h3 className="history__header">History:</h3>
            {history.map((el: any, i: number) => {
                if (i < 3) {
                    return (
                        <div className="history__element" key={i}>
                            <a className="history__link" target="_blank" rel="noreferrer" href={el.url}>
                                {el.url}
                            </a>
                            <br></br>
                            <span> Generated: {el.date}</span>
                            <hr/>
                        </div>
                    );
                }
                return;
            })}
        </Box>
    );
};

export default HistoryList;
