import React from "react";

type Props = {
    login: string;
    logout: () => void;
};

const UserBar = (props: Props) => {
    const { login, logout } = props;

    return (
        <div className="text-light d-flex">
            <div style={{ marginRight: "2rem" }}>{login}</div>
            <div className="userbar__logout" role="button" onClick={logout}>
                Logout
            </div>
        </div>
    );
};

export { UserBar };
