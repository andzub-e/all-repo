import React, { useState } from "react";
import { IGame } from "./Lobby";
import { envLink } from "../helpers";
import URLControl from "./URLControl";
import MockQueryBuilder from "./MockQueryBuilder";
import InfinQueryBuilder from "./InfinQueryBuilder";
import { ToggleButton, ToggleButtonGroup } from "@material-ui/lab";

interface Props {
    key: number;
    game: IGame;
    env: "dev" | "stage" | "demo" | "prod";
}

const Editor = (props: Props) => {
    const { game, env } = props;
    const [url, setURL] = useState("");
    const [integrator, setIntegrator] = useState("mock");

    const queryBuilders = ["mock", "infin"];

    return (
        <div className="editor">
            <p className="editor__group_header">Integrator</p>
            <ToggleButtonGroup
                value={integrator}
                exclusive
                onChange={(event: React.MouseEvent<HTMLElement, MouseEvent>, value: string) => {
                    setIntegrator(value);
                }}
                aria-label="text alignment"
            >
                {queryBuilders.map(intg => {
                    return (
                        <ToggleButton className="editor__button" key={intg} value={intg} disabled={integrator == intg} aria-label="left aligned">
                            {intg}
                        </ToggleButton>
                    );
                })}
            </ToggleButtonGroup>

            {integrator == "mock" ? (
                <MockQueryBuilder game={game} env={env} setSearchParams={sp => setURL(envLink(env, game) + "?" + sp)} />
            ) : null}
            {integrator == "infin" ? (
                <InfinQueryBuilder game={game} env={env} setSearchParams={sp => setURL(envLink(env, game) + "?" + sp)} />
            ) : null}
            <hr></hr>

            <URLControl url={url} />
        </div>
    );
};

export { Editor };
