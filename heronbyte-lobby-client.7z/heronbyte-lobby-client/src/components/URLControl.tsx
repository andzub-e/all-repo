import { Box } from "@material-ui/core";
import { FreeSpinButton } from "./FreeSpinButton";
import { Iframe } from "./Iframe";
import React, { Fragment, useEffect, useState } from "react";
import { getHistory, putHistory } from "../api/history";
import HistoryList from "./HistoryList";

interface Props {
    url: string;
}

interface History {
    url: string;
    date: string;
}

const URLControl = (props: Props) => {
    const [history, setHistory] = useState<History[]>([]);
    const [lastSavedLink, setLastSavedLink] = useState("");

    const updateHistory = () => {
        if (props.url !== lastSavedLink) {
            const date = new Date().toLocaleString();
            saveLinkToServer(props.url, date);

            const newHistory = [...history];

            newHistory.unshift({
                url: props.url,
                date,
            });

            setLastSavedLink(props.url);
            setHistory(newHistory);
        }
    };

    useEffect(() => {
        getHistory((records: never[]) => {
            setHistory(records.reverse());
        }, console.log);
    }, []);

    if (props.url === "") {
        return null;
    }

    return (
        <Fragment>
            <div className="link-container">
                <a className="link-container__link" target="_blank" rel="noreferrer" href={props.url} onClick={updateHistory}>
                    {props.url}
                </a>
            </div>
            <Box my={5}>
                <Iframe stateURL={props.url} updateHistory={updateHistory} />
            </Box>
            <HistoryList history={history} />
        </Fragment>
    );
};

export default URLControl;

const saveLinkToServer = (url: string, date: string) => {
    putHistory(
        JSON.stringify({
            url,
            date,
        }),
    );
};
