import React, { ReactElement } from "react";
import { Navbar, Container } from "react-bootstrap";

type Props = {
    children: ReactElement;
};

const CustomNavbar = (props: Props) => {
    const { children } = props;

    return (
        <Navbar className="custom-navbar">
            <Container>
                <Navbar.Collapse id="basic-navbar-nav">{children}</Navbar.Collapse>
            </Container>
        </Navbar>
    );
};

export { CustomNavbar };
