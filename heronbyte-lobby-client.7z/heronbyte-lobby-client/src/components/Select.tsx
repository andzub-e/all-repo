import { Box, FormControl, InputLabel, Select } from "@material-ui/core";
import React from "react";

interface Props {
    name: string;
    value: string;
    onChange: (e: any) => void;
    options: any[];
}

const CustomSelect = (props: Props) => {
    const { name, value, options, onChange } = props;

    const opts = options.map((el: any, i: number) => (
        <option key={i} value={el}>
            {el}
        </option>
    ));

    return (
        <>
            <Box my={1}>
                <FormControl>
                    <InputLabel htmlFor="age-native-simple">{name}</InputLabel>
                    <Select native name={name} value={value} onChange={onChange}>
                        {opts}
                    </Select>
                </FormControl>
            </Box>
        </>
    );
};

export { CustomSelect };
