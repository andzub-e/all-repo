import {Button, FormControl} from "@material-ui/core";
import React, {useEffect, useState} from "react";
import {putFreeSpins} from "../api/free_spins";

interface FreeSpinButtonProps {
    gameName: string;
    gameOwner: string;
    userID: string;
    currency: string;
    env: string;
}

const FreeSpinButton = (props: FreeSpinButtonProps) => {
    const {gameName, gameOwner, userID, currency, env} = props;
    const [freeSpinURL, setFreeSpinURL] = useState("");
    const [betValue, setBetValue] = useState(1000);

    const handleBetValue = (value: number) => {
        setBetValue(value);
    };

    useEffect(() => {
        const domainName = gameOwner === "game_hub" ? "daplay.io" : "heronbyte.com";

        const url = new URL(`https://${env}-games.${domainName}/pfr/create`);
        setFreeSpinURL(url.toString());
    }, [env]);

    return (
        <div className="d-flex">
            <Button
                className="free-spin-button"
                onClick={() => {
                    putFreeSpins(freeSpinURL, gameName, userID, currency, betValue);
                }}
            >
                Add 2 Free Spins for this user
            </Button>
            <FormControl>
                <select className="free-spin-select" value={betValue}
                        onChange={e => handleBetValue(Number(e.target.value))}>
                    <option value={20}>20</option>
                    <option value={1000}>1000</option>
                    <option value={2000}>2000</option>
                    <option value={5000}>5000</option>
                    <option value={10000}>10000</option>
                </select>
            </FormControl>
        </div>
    );
};

export {FreeSpinButton};
