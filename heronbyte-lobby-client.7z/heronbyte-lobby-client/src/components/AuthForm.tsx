import { Button, Card, Form, Spinner } from "react-bootstrap";
import React, { useState } from "react";
import { login as loginSystem } from "../api/auth";

type Props = {
    setAuth: (res: any) => void;
};

const AuthForm = (props: Props) => {
    const { setAuth } = props;

    const [login, setLogin] = useState("");
    const [password, setPassword] = useState("");
    const [loginError, setLoginError] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [isLoading, setIsLoading] = useState(false);

    const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setIsLoading(true);

        setLoginError(""); // Clear login error
        setPasswordError(""); // Clear password error

        loginSystem(
            auth => {
                setAuth(auth);
                setIsLoading(false);
            },
            err => {
                if (err === "record not found") {
                    setLoginError(err);
                } else {
                    setPasswordError(err);
                }
                setIsLoading(false);
            },
        )(login, password);
    };

    let button = (
        <Button className="auth-form__submit" type="submit">
            Submit
        </Button>
    );
    if (isLoading) {
        button = <Spinner className="auth-form__spinner" animation="border" variant="primary" />;
    }

    return (
        <div className="container-sm d-flex justify-content-center align-items-center" style={{ maxWidth: "475px", minHeight: "100vh" }}>
            <Card body className="auth-form">
                <h3 className="auth-form__header">Heronbyte.com!</h3>
                <p className="auth-form__subheader">Please sign in to continue.</p>
                <Form onSubmit={e => onSubmit(e)}>
                    <Form.Group className="mb-3" controlId="formLogin">
                        <Form.Label className="auth-form__label">Email</Form.Label>
                        <Form.Control
                            className="auth-form__input"
                            type="text"
                            value={login}
                            onChange={e => setLogin(e.target.value)}
                            isInvalid={loginError !== ""}
                            isValid={loginError === ""}
                        />
                        {loginError ? <div className="invalid-feedback">{loginError}</div> : null}
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="formPassword">
                        <Form.Label className="auth-form__label">Password</Form.Label>
                        <Form.Control
                            className="auth-form__input"
                            type="password"
                            value={password}
                            onChange={e => setPassword(e.target.value)}
                            isInvalid={passwordError !== ""}
                            isValid={passwordError === ""}
                        />
                        {passwordError ? <div className="invalid-feedback">{passwordError}</div> : null}
                    </Form.Group>
                    {button}
                </Form>
            </Card>
        </div>
    );
};

export { AuthForm };
