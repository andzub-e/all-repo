import React from "react";
import { Editor } from "./Editor";
import { Box, Container, FormControl, InputLabel, Select } from "@material-ui/core";
import { CONFIG } from "../config";
import { ToggleButton, ToggleButtonGroup } from "@material-ui/lab";
import { getCachedGameIndex, getGames } from "../api/init";
import { envLink } from "../helpers";

export interface IGame {
    currencies: string[];
    dev_url: string;
    stage_url: string;
    demo_url: string;
    prod_url: string;
    id: string;
    jurisdictions: string[];
    langs: string[];
    name: string;
    user_locale: string;
    owner: string;
}

const enum GameEnv {
    dev = "dev",
    stage = "stage",
    demo = "demo",
    prod = "prod",
}

interface State {
    games: IGame[];
    gameIndex: number;
    filteredGames: IGame[];
    isLoading: boolean;
    env: GameEnv;
    selectedOwner: string | null;
}

export class Lobby extends React.Component<any, State> {
    constructor(props: any) {
        super(props);

        this.state = {
            games: [],
            gameIndex: -1,
            filteredGames: [],
            isLoading: true,
            env: GameEnv.dev,
            selectedOwner: null,
        };
    }

    componentDidUpdate(prevProps: Readonly<any>, prevState: Readonly<State>) {
        if (prevState.env !== this.state.env) {
            if (this.state.gameIndex === -1) {
                return;
            }

            const game = this.state.filteredGames[this.state.gameIndex];
            const link = envLink(this.state.env, game);
            if (link === "") {
                this.setState({
                    gameIndex: -1,
                });
            }
        }
    }

    componentDidMount() {
        getGames(
            (games: IGame[]) => {
                const newState = {
                    games: games,
                    isLoading: false,
                    gameIndex: -1,
                    filteredGames: games,
                };

                const index = getCachedGameIndex();
                if (games[index] !== undefined) {
                    newState.gameIndex = index;
                }
                this.setState(newState);
            },
            () => {
                this.setState({
                    isLoading: false,
                });
            },
        );
    }

    getUniqueOwners = (): string[] => {
        const ownersSet = new Set<string>();
        this.state.games.forEach(game => {
            ownersSet.add(game.owner);
        });
        return Array.from(ownersSet);
    };

    updateFilteredGames = () => {
        const { games, selectedOwner } = this.state;
        const filteredGames = selectedOwner ? games.filter(game => game.owner === selectedOwner) : games;

        this.setState({
            filteredGames: filteredGames,
            gameIndex: 0,
        });
    };

    render() {
        let listOfGames;

        if (this.state.filteredGames.length) {
            listOfGames = this.state.filteredGames.map((game: IGame, i: number) => (
                <option key={i} value={i} hidden={envLink(this.state.env, game) == ""}>
                    {game.name}
                </option>
            ));
        }

        const owners = this.getUniqueOwners();
        return (
            <Container className="lobby">
                <h2 className="lobby__header">Welcome to HeronByte lobby!</h2>
                <Box py={3} className="lobby__box">
                    <Box py={3}>
                        <p className="lobby__group_header">Environment</p>
                        <ToggleButtonGroup
                            value={this.state.env}
                            exclusive
                            className="lobby__button_group"
                            onChange={(event: React.MouseEvent<HTMLElement, MouseEvent>, value: GameEnv) => {
                                this.setState({
                                    env: value,
                                });
                            }}
                        >
                            <ToggleButton className="lobby__button" value={GameEnv.dev} disabled={this.state.env == GameEnv.dev}>
                                DEV
                            </ToggleButton>
                            <ToggleButton className="lobby__button" value={GameEnv.stage} disabled={this.state.env == GameEnv.stage}>
                                STAGE
                            </ToggleButton>
                            <ToggleButton className="lobby__button" value={GameEnv.demo} disabled={this.state.env == GameEnv.demo}>
                                DEMO
                            </ToggleButton>
                            <ToggleButton className="lobby__button" value={GameEnv.prod} disabled={this.state.env == GameEnv.prod}>
                                PROD
                            </ToggleButton>
                        </ToggleButtonGroup>
                    </Box>
                    <FormControl>
                        <p className="lobby__group_header">Owner</p>
                        <Select
                            className="lobby__input"
                            native
                            value={this.state.selectedOwner || ""}
                            onChange={(event: React.ChangeEvent<{ value: unknown }>) => {
                                const value = event.target.value as string;
                                this.setState({ selectedOwner: value }, this.updateFilteredGames);
                            }}
                            inputProps={{
                                name: "owner",
                                id: "owner-native-simple",
                            }}
                        >
                            <option value="">All Owners</option>
                            {owners.map((owner, index) => (
                                <option key={index} value={owner}>
                                    {owner}
                                </option>
                            ))}
                        </Select>
                    </FormControl>
                    <FormControl>
                        <p className="lobby__group_header">Game</p>
                        <Select
                            className="lobby__input"
                            native
                            value={this.state.gameIndex}
                            onChange={(event: React.ChangeEvent<{ value: unknown }>) => {
                                const value = event.target.value as string;
                                const index = parseInt(value);
                                localStorage.setItem(CONFIG.local_storage_key, value);
                                this.setState({ gameIndex: index });
                            }}
                            inputProps={{
                                name: "age",
                                id: "age-native-simple",
                            }}
                        >
                            <option aria-label="None" value={-1}>
                                {this.state.isLoading
                                    ? "Loading..."
                                    : this.state.filteredGames.length
                                    ? "Choose game..."
                                    : "AN ERROR HAS OCCURED"}
                            </option>
                            {listOfGames}
                        </Select>
                    </FormControl>
                </Box>
                {this.state.gameIndex !== -1 ? (
                    <Editor key={this.state.gameIndex} game={this.state.filteredGames[this.state.gameIndex]} env={this.state.env} />
                ) : (
                    ""
                )}
            </Container>
        );
    }
}

export default Lobby;
