import { Box, Button } from "@material-ui/core";
import React from "react";

interface Props {
    isVisibleIframe: boolean;
    toggle: () => void;
    reload: () => void;
}

const IframeControl = (props: Props) => {
    const { toggle, reload, isVisibleIframe } = props;

    return (
        <Box display="flex">
            {!isVisibleIframe && (
                <Button className="iframe-button" onClick={toggle}>
                    Run in iframe
                </Button>
            )}
            {isVisibleIframe && (
                <Button className="iframe-button" onClick={toggle}>
                    Hide game
                </Button>
            )}
            {isVisibleIframe && (
                <Box ml={2}>
                    <Button className="iframe-button" onClick={reload}>
                        Reload iframe
                    </Button>
                </Box>
            )}
        </Box>
    );
};

export { IframeControl };
