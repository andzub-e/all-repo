import { IGame } from "./components/Lobby";

const envLink = (env: string, game: IGame): string => {
    switch (env) {
        case "dev":
            return game.dev_url;
        case "stage":
            return game.stage_url;
        case "demo":
            return game.demo_url;
        case "prod":
            return game.prod_url;
        default:
            return "";
    }
};

export { envLink };
