#Installation
Install all dependencies with
    npm ci
For local development use
    npm run local
To build use
    npm run dev
*or* 
    npm run staging
*or*
    npm run prod