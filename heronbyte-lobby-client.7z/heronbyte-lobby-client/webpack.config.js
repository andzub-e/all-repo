const path = require("path");
const { CleanWebpackPlugin } = require("clean-webpack-plugin");
const CopyPlugin = require("copy-webpack-plugin");
const DefinePlugin = require("webpack").DefinePlugin;
const BundleAnalyzerPlugin = require("webpack-bundle-analyzer").BundleAnalyzerPlugin;
const os = require("os");
const HotModuleReplacementPlugin = require("webpack").HotModuleReplacementPlugin;
const HtmlWebpackPlugin = require("html-webpack-plugin");

let chrome_name = "google-chrome";
let platform = os.platform();

if (platform === "win32") {
    chrome_name = "Chrome";
} else if (platform === "darwin") {
    chrome_name = "Google Chrome";
}

const common_config = {
    entry: "./src/index.tsx",
    resolve: {
        extensions: [".ts", ".tsx", ".js", ".jsx"],
    },

    externals: [],
};

const local_config = {
    ...common_config,
    name: "local",
    mode: "development",
    watch: true,
    output: {
        path: path.join(__dirname, "dist"),
        filename: "app.js",
        publicPath: "/dist",
    },
    devServer: {
        contentBase: path.join(__dirname, "/"),
        compress: true,
        port: 8050,
        open: {
            app: [chrome_name],
        },
        historyApiFallback: {
            rewrites: [
                { from: /.*\/dist\/app\.js/, to: "/dist/app.js" },
                { from: /.*/, to: "./index.html" },
            ],
        },
    },
    devtool: "eval-cheap-module-source-map",
    plugins: [
        new DefinePlugin({
            __ENVIRONMENT__: `"DEVELOPMENT"`,
        }),
        /*         new BundleAnalyzerPlugin(), */
        new HotModuleReplacementPlugin({
            // Options...
        }),
    ],
    module: {
        rules: [
            {
                test: /\.tsx?$/,
                use: "ts-loader",
                include: [path.resolve(__dirname, "src"), path.resolve(__dirname, "node_modules/game_engine/src/Models")],
            },
            {
                test: /\.s[ac]ss$/i,
                use: [
                    // Creates `style` nodes from JS strings
                    "style-loader",
                    {
                        loader: "css-loader",
                        options: {
                            sourceMap: true,
                            modules: { auto: true },
                        },
                    },
                    {
                        loader: "sass-loader",
                        options: {
                            sourceMap: true,
                        },
                    },
                ],
            },
            {
                test: /\.css$/i,
                use: [
                    // Creates `style` nodes from JS strings
                    "style-loader",
                    {
                        loader: "css-loader",
                        options: {
                            sourceMap: true,
                            modules: { auto: true },
                        },
                    },
                ],
            },
            {
                test: /\.(png|svg|jpg|gif)$/,
                loader: "file-loader",
                options: {
                    name: "[name].[ext]",
                    outputPath: (url, resourcePath, context) => {
                        let relativePath = resourcePath.replace(context, "").replace(/\\/g, "/");
                        let imagePath = relativePath.replace("/src/", "");

                        // `resourcePath` is original absolute path to asset
                        // `context` is directory where stored asset (`rootContext`) or `context` option

                        // To get relative path you can use
                        // const relativePath = path.relative(context, resourcePath);

                        return `${imagePath}`;
                    },
                },
            },
            {
                test: /\.(svgraw)$/i,
                use: "raw-loader",
            },
            {
                test: /\.(eot|woff|woff2|ttf|gif)$/,
                use: {
                    loader: "url-loader",
                    options: {
                        limit: 10240,
                        name: "[name].[ext]",
                    },
                },
            },
        ],
    },
};

const build_config = {
    ...common_config,

    name: "build",
    mode: "production",

    output: {
        path: path.join(__dirname, "dist"),
        filename: "app.[contenthash].js",
        publicPath: "./",
    },

    plugins: [
        new CleanWebpackPlugin(),
        new HtmlWebpackPlugin({
            template: path.resolve(__dirname, "./prodIndex.html"),
            minify: true,
        }),
        new DefinePlugin({
            __ENVIRONMENT__: `"PRODUCTION"`,
        }),
    ],

    module: {
        rules: [
            {
                test: /\.tsx?$/,
                use: "ts-loader",
                include: [path.resolve(__dirname, "src"), path.resolve(__dirname, "node_modules/game_engine/src/Models")],
            },
            {
                test: /\.s[ac]ss$/i,
                use: [
                    // Creates `style` nodes from JS strings
                    "style-loader",
                    {
                        loader: "css-loader",
                        options: {},
                    },
                    {
                        loader: "sass-loader",
                        options: {},
                    },
                ],
            },
            {
                test: /\.css$/i,
                use: [
                    "style-loader",
                    {
                        loader: "css-loader",
                        options: {
                            sourceMap: false,
                            modules: { auto: true },
                        },
                    },
                ],
            },
            {
                test: /\.(png|svg|jpg|gif)$/,
                loader: "file-loader",
                options: {
                    name: "[name].[ext]",
                    outputPath: (url, resourcePath, context) => {
                        let relativePath = resourcePath.replace(context, "").replace(/\\/g, "/");
                        let imagePath = relativePath.replace("/src/", "");

                        return `${imagePath}`;
                    },
                },
            },
            {
                test: /\.(svgraw)$/i,
                use: "raw-loader",
            },
            {
                test: /\.(eot|woff|woff2|ttf|gif)$/,
                use: {
                    loader: "url-loader",
                    options: {
                        limit: 10240,
                        name: "[name].[ext]",
                    },
                },
            },
        ],
    },
};

module.exports = [local_config, build_config];
