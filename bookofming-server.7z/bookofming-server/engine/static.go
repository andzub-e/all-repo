package engine

import (
	"fmt"
	"github.com/samber/lo"
)

const (
	rtp94 = "94"
	rtp96 = "96"

	needSymbolsToTriggerBonus = 3
	bonusSpinCount            = 10
	windowHeight              = 3
	windowWidth               = 5
	multiplicationDivider     = 10
)

var BookSymbol = "b"

var availableExtraScatters = []string{"t", "j", "q", "k", "a", "v", "d", "g", "s"}
var reels [][]string
var PayLines = [][]int{
	{0, 1, 2, 3, 4},
	{5, 6, 7, 8, 9},
	{10, 11, 12, 13, 14},
	{0, 6, 12, 8, 4},
	{10, 6, 2, 8, 14},

	{0, 1, 7, 13, 14},
	{10, 11, 7, 3, 4},
	{5, 11, 12, 13, 9},
	{5, 1, 2, 3, 9},
	{10, 6, 7, 8, 4},
}

var multipliers = map[string]map[int]int64{
	"t": {3: 5, 4: 25, 5: 100},
	"j": {3: 5, 4: 25, 5: 100},
	"q": {3: 5, 4: 25, 5: 100},

	"k": {3: 5, 4: 40, 5: 150},
	"a": {3: 5, 4: 40, 5: 150},

	"v": {2: 5, 3: 30, 4: 100, 5: 750},
	"d": {2: 5, 3: 30, 4: 100, 5: 750},

	"g":        {2: 5, 3: 40, 4: 400, 5: 2000},
	"s":        {2: 10, 3: 100, 4: 1000, 5: 5000},
	BookSymbol: {3: 20, 4: 200, 5: 2000},
}

var bonusReels = [][]string{
	{"a", "v", "t", "k", "j", "a", "g", "q", "t", "b", "a", "j", "g", "q", "t", "b", "k", "j", "s", "k", "a", "d", "q", "j", "d", "q", "g", "d", "s", "k", "d"},
	{"a", "t", "q", "j", "s", "a", "j", "q", "b", "a", "t", "k", "v", "a", "j", "q", "t", "b", "k", "g", "j", "k", "v", "j", "k", "d", "a", "v", "t", "j", "v", "k"},
	{"k", "j", "a", "t", "q", "d", "t", "q", "v", "t", "k", "d", "q", "a", "s", "q", "a", "k", "g", "q", "a", "j", "t", "g", "b", "t", "k", "j", "g", "t", "q", "v"},
	{"k", "g", "s", "a", "q", "v", "k", "j", "d", "t", "k", "v", "q", "t", "d", "a", "j", "t", "s", "j", "a", "b", "g", "q", "j", "b", "t", "q"},
	{"k", "t", "q", "a", "v", "t", "j", "b", "k", "j", "g", "a", "v", "j", "a", "s", "j", "t", "v", "d", "q", "k", "t", "d", "q", "b", "d", "q"},
}
var bonusTriggerStops = []int{0, 0, 24, 24, 24}

type Window [][]string

func (w *Window) GetSymbol(reelIndex int, payItem int) string {
	return w.symbol(payItem)
}

func (w *Window) GetByIndexes(reelIndex, symbolIndex int) (int, string) {
	return symbolIndex*windowWidth + reelIndex, (*w)[reelIndex][symbolIndex]
}

func (w *Window) GetHeight() int {
	return windowHeight
}

func (w *Window) GetWidth() int {
	return windowWidth
}

func (w *Window) compute(reels [][]string, stops []int) {
	*w = lo.Map(stops, func(stop int, index int) []string {
		reel := reels[index]
		reelLen := len(reel)

		windowLine := make([]string, windowHeight)
		for j := 0; j < windowHeight; j++ {
			windowLine[j] = reel[(stop+j)%reelLen]
		}

		return windowLine
	})
}

func (w Window) symbol(payIndex int) string {
	position, reel := payIndex/windowWidth, payIndex%windowWidth
	return w[reel][position]
}

func reelSerialized(reels [][]string) string {
	return fmt.Sprint(reels)
}

type AwardGetter struct {
	Wager int64
}

func NewAwardGetter(wager int64) (AwardGetter, error) {
	if wager < 0 {
		return AwardGetter{}, fmt.Errorf("negative wager: %v", wager)
	}
	return AwardGetter{Wager: wager}, nil
}

func (a AwardGetter) GetAward(symbol string, size int) int64 {
	mul := multipliers[symbol][size]

	return mul * a.Wager / multiplicationDivider
}
