package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine/utils"
	"github.com/samber/lo"
)

func computeBasicWindow(wager int64, window Window) (award int64, payLinesToShow []PayLine, err error) {
	ag, err := NewAwardGetter(wager)
	if err != nil {
		return 0, nil, err
	}

	pls := utils.CalcBasePayLines[int, string](PayLines, &window, ag, nil, &BookSymbol, utils.LeftToRightDirection)

	lo.ForEach(pls, func(item utils.PayLine[int, string], index int) {
		payLinesToShow = append(payLinesToShow, PayLine{
			Symbol: item.PaySymbol,

			PayLineIndex: item.PayLineIndex,
			Indexes:      item.PayLineItems,
			Award:        item.Award,
		})

		award += item.Award
	})

	return award, payLinesToShow, nil
}

func computeBookAward(wager int64, window Window) (award int64, payLineToShow PayLine, err error) {
	payIndexes := []int{}

	for reelIndex, reel := range window {
		for symbolIndex, symbol := range reel {
			if symbol == BookSymbol {
				payIndexes = append(payIndexes, (symbolIndex*windowWidth)+reelIndex)

				break
			}
		}
	}

	ag, err := NewAwardGetter(wager)
	if err != nil {
		return 0, PayLine{}, err
	}

	if award = ag.GetAward(BookSymbol, len(payIndexes)); award > 0 {
		return award, PayLine{Indexes: payIndexes, Award: award, Symbol: BookSymbol, PayLineIndex: -1}, nil
	}

	return 0, PayLine{}, nil
}

func isTriggersBonus(window Window) (ok bool, bookIndexes []int) {
	counter := 0
	bookIndexes = []int{}

	for reelIndex, reel := range window {
		for symbolIndex, symbol := range reel {
			if symbol == BookSymbol {
				counter++
				bookIndexes = append(bookIndexes, (symbolIndex*windowWidth)+reelIndex)
			}
		}
	}

	if counter >= needSymbolsToTriggerBonus {
		return true, bookIndexes
	}

	return false, bookIndexes
}

func computeBonusWindow(wager int64, extraScatter string, window Window) (award int64, payLinesToShow, payLinesExpand []PayLine, err error) {
	award, payLinesToShow, err = computeBasicWindow(wager, window)
	if err != nil {
		return 0, nil, nil, err
	}

	payLinesExpandMap := map[int]PayLine{}

	reelsWithES := reelsWithExtraScatter(window, extraScatter)

	for payLineIndex, payLine := range PayLines {
		lineCounter := 0
		payLineIndexes := []int{}

		for _, payIndex := range payLine {
			if reelsWithES[payIndex%windowWidth] {
				lineCounter++
				payLineIndexes = append(payLineIndexes, payIndex)
			}
		}

		ag, err := NewAwardGetter(wager)
		if err != nil {
			return 0, nil, nil, err
		}

		if addAward := ag.GetAward(extraScatter, lineCounter); addAward > 0 {
			award += addAward
			payLinesExpandMap[payLineIndex] = PayLine{Indexes: payLineIndexes, Award: addAward, Symbol: extraScatter, PayLineIndex: payLineIndex}
		}
	}

	// remove extraScatter payLines if award is smaller
	for i := 0; i < len(payLinesToShow); i++ {
		payLine := payLinesToShow[i]
		expPayLine, ok := payLinesExpandMap[payLine.PayLineIndex]

		if ok && expPayLine.Symbol == payLine.Symbol {
			if expPayLine.Award > payLine.Award {
				payLinesToShow = append(payLinesToShow[:i], payLinesToShow[i+1:]...)
				award -= payLine.Award

				i--
			} else {
				delete(payLinesExpandMap, expPayLine.PayLineIndex)

				award -= payLine.Award
			}
		}
	}

	return award, payLinesToShow, lo.Values(payLinesExpandMap), nil
}

func reelsWithExtraScatter(window Window, extraScatter string) map[int]bool {
	reelsWithES := map[int]bool{}
	for reelIndex, reel := range window {
		for _, symbol := range reel {
			if symbol == extraScatter {
				reelsWithES[reelIndex] = true

				break
			}
		}
	}

	return reelsWithES
}
