package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"encoding/json"
	"go.uber.org/zap"
)

type RestoringIndexes struct {
	BaseSpinIndex     int  `json:"base_spin_index"`
	BonusSpinIndex    int  `json:"bonus_spin_index"`
	IsGambleCollected bool `json:"gamble_collected"`
}

func (r *RestoringIndexes) IsShown(spin engine.Spin) bool {
	spinTyped, ok := spin.(*Spin)

	if !ok {
		zap.S().Error("can not parse spin")
		return true
	}

	if spinTyped.Bonus == nil {
		return r.BaseSpinIndex == 1
	}

	return r.BaseSpinIndex == 1 && r.BonusSpinIndex == len(spinTyped.Bonus.Spins)
}

func (r *RestoringIndexes) Update(payload interface{}) error {
	bytes, err := json.Marshal(payload)
	if err != nil {
		return err
	}

	return json.Unmarshal(bytes, r)
}
