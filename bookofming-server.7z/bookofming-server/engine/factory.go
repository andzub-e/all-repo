package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/validator"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"encoding/json"
	"fmt"
	"github.com/samber/lo"
	"github.com/sarulabs/di"
)

type EngineInfo struct {
	BaseReels [][]string `json:"base_reels"`
}

func GameBoot(ctn di.Container, config *engine.Config) *engine.Bootstrap {
	switch config.RTP {
	case rtp94:
		reels = reels94
	case rtp96:
		reels = reels96
	default:
		panic("unknown rtp")
	}

	fmt.Printf("current rtp: %v\n", config.RTP)
	rand := ctn.Get(constants.RNGMockName).(rng.Client)
	validatorEngine := ctn.Get(constants.ValidatorName).(*validator.Validator)
	factory := NewSpinFactory(rand, validatorEngine)

	return &engine.Bootstrap{
		SpinFactory: factory,

		HTTPTransport:      true,
		WebsocketTransport: true,

		GambleAnyWinFeature: true,
		FreeSpinsFeature:    true,

		GambleAnyWinMaxTimes: 4,
		GambleAnyWinMaxWager: 125 * 100 * 1000, // 12 500 $

		GameMaxWager: 40000,

		HistoryHandlingType: engine.SequentialRestoring,
		EngineInfo:          EngineInfo{BaseReels: reels},
	}
}

func NewSpinFactory(rand rng.Client, validateEngine *validator.Validator) *SpinFactory {
	factory := &SpinFactory{rand: rand, validateEngine: validateEngine}

	return factory
}

type SpinFactory struct {
	rand           rng.Client
	validateEngine *validator.Validator
}

func (s *SpinFactory) Generate(ctx engine.Context, wager int64, parameters interface{}) (engine.Spin, engine.RestoringIndexes, error) {
	stops, err := s.getStops(&ctx, reels)
	if err != nil {
		return nil, nil, err
	}

	window, payLinesToShow, award, bonus, err := s.compute(ctx, stops, wager)

	if err != nil {
		return nil, nil, err
	}

	if payLinesToShow == nil {
		payLinesToShow = make([]PayLine, 0, 1)
	}

	return &Spin{
			WagerVal:       wager,
			Win:            award,
			Stops:          stops,
			Window:         window,
			PayLinesToShow: payLinesToShow,
			Bonus:          bonus},
		&RestoringIndexes{}, nil
}

func (s *SpinFactory) GambleAnyWin(ctx engine.Context, parameters interface{}) (engine.Spin, error) {
	if ctx.LastSpin.BaseAward() == 0 {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin, ok := ctx.LastSpin.(*Spin)
	if !ok {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin = typedSpin.deepCopy()

	payload, err := parseParams(parameters)

	if payload.Color != GambleRed && payload.Color != GambleBlue {
		return nil, errs.ErrBadDataGiven
	}

	if err != nil {
		return nil, err
	}

	res, err := s.rand.Rand(2)
	if err != nil {
		return nil, err
	}

	suit, err := s.rand.Rand(2)
	if err != nil {
		return nil, err
	}

	g := Gamble{ExpectColor: payload.Color, WagerVal: typedSpin.GambleAward(), Suit: int(suit)}

	c := Cheats{}
	if ctx.Cheats != nil {
		if err := c.Eval(ctx.Cheats); err != nil {
			return nil, err
		}
	}

	if c.GambleColor == GambleRed || c.GambleColor == GambleBlue {
		g.RealColor = c.GambleColor
	} else if res == 1 {
		g.RealColor = GambleRed
	} else {
		g.RealColor = GambleBlue
	}

	g.compute()

	typedSpin.Gambles = append(typedSpin.Gambles, g)

	return typedSpin, nil
}

func (s *SpinFactory) KeepGenerate(ctx engine.Context, parameters interface{}) (engine.Spin, bool, error) {
	return ctx.LastSpin, false, nil
}

func (s SpinFactory) UnmarshalJSONSpin(bytes []byte) (engine.Spin, error) {
	spin := Spin{}
	err := json.Unmarshal(bytes, &spin)

	return &spin, err
}

func (s SpinFactory) UnmarshalJSONRestoringIndexes(bytes []byte) (engine.RestoringIndexes, error) {
	restoringIndexes := RestoringIndexes{}
	err := json.Unmarshal(bytes, &restoringIndexes)

	return &restoringIndexes, err
}

func (s *SpinFactory) compute(ctx engine.Context, stops []int, wager int64) (window Window, payLinesToShow []PayLine, award int64, bonus *Bonus, err error) {
	window.compute(reels, stops)

	award, payLinesToShow, err = computeBasicWindow(wager, window)
	if err != nil {
		return window, nil, 0, nil, err
	}

	bookAward, bookPayLineToShow, err := computeBookAward(wager, window)
	if err != nil {
		return window, nil, 0, nil, err
	}

	if bookAward > 0 {
		award += bookAward
		payLinesToShow = append(payLinesToShow, bookPayLineToShow)
	}

	bonus, err = s.computeBonus(ctx, wager, window)
	if err != nil {
		return window, nil, 0, nil, err
	}

	return window, payLinesToShow, award, bonus, nil
}

func (s *SpinFactory) computeBonus(ctx engine.Context, wager int64, window Window) (*Bonus, error) {
	isTriggers, bookIndexes := isTriggersBonus(window)

	if !isTriggers {
		return nil, nil
	}

	extraScatter, err := s.extraScatter(ctx)
	if err != nil {
		return nil, err
	}

	bonus := &Bonus{
		ExtraScatter: extraScatter,
		BookIndexes:  bookIndexes,
	}

	bonusSpinTriggered := bonusSpinCount

	for count := bonusSpinCount; count > 0; count-- {
		stops, err := s.getStops(&ctx, bonusReels)
		if err != nil {
			return nil, err
		}

		bonusWindow := Window{}
		bonusWindow.compute(bonusReels, stops)

		award, basePayLines, extraPayLines, err := computeBonusWindow(wager, bonus.ExtraScatter, bonusWindow)
		if err != nil {
			return nil, err
		}

		isTriggers, bookIndexes = isTriggersBonus(bonusWindow)

		if isTriggers {
			count += bonusSpinCount
			bonusSpinTriggered += bonusSpinCount
		}

		bookAward, bookBasePayLines, err := computeBookAward(wager, bonusWindow)
		if err != nil {
			return nil, err
		}

		if bookAward > 0 {
			award += bookAward
			basePayLines = append(basePayLines, bookBasePayLines)
		}

		bonus.Spins = append(bonus.Spins,
			BonusSpin{
				Window:               bonusWindow,
				Stops:                stops,
				Award:                award,
				PayLinesToShow:       basePayLines,
				ExtraScatterPayLines: extraPayLines,
				BonusSpinsLeft:       count,
				BookIndexes:          bookIndexes,
				BonusSpinsTriggered:  bonusSpinTriggered})

	}

	return bonus, nil
}

func (s *SpinFactory) getStops(ctx *engine.Context, localReels [][]string) ([]int, error) {
	c := Cheats{}
	if ctx.Cheats != nil {
		if err := c.Eval(ctx.Cheats); err != nil {
			return nil, err
		}
	}

	if c.GambleColor == "" && ctx.Cheats != nil {
		if reelSerialized(localReels) == reelSerialized(bonusReels) {
			if c.FirstStopIfBonus != nil {
				if len(c.FirstStopIfBonus) != len(localReels) {
					return nil, errs.ErrBadDataGiven
				}

				for i := range c.FirstStopIfBonus {
					if c.FirstStopIfBonus[i] > len(localReels[i]) {
						return nil, errs.ErrBadDataGiven
					}
				}

				stops := c.FirstStopIfBonus
				c.FirstStopIfBonus = nil
				ctx.Cheats = c
				return stops, nil
			}

			if c.AdditionalTriggerCount > 0 {
				c.AdditionalTriggerCount--
				ctx.Cheats = c

				stops := make([]int, len(bonusTriggerStops))
				copy(stops, bonusTriggerStops)

				return stops, nil
			}
		} else {
			if len(c.Stops) != len(localReels) {
				return nil, errs.ErrBadDataGiven
			}

			for i := range c.Stops {
				if c.Stops[i] > len(localReels[i]) {
					return nil, errs.ErrBadDataGiven
				}
			}

			return c.Stops, nil
		}
	}

	req := lo.Map(localReels, func(item []string, index int) uint64 {
		return uint64(len(item))
	})

	res, err := s.rand.RandSlice(req)
	if err != nil {
		return nil, err
	}

	return lo.Map(res, func(item uint64, index int) int {
		return int(item)
	}), nil
}

func (s *SpinFactory) extraScatter(ctx engine.Context) (string, error) {
	c := Cheats{}
	if ctx.Cheats != nil {
		if err := c.Eval(ctx.Cheats); err != nil {
			return "", err
		}

		if lo.Contains(availableExtraScatters, c.ExtraScatter) {
			return c.ExtraScatter, nil
		}
	}

	extraScatterIndex, err := s.rand.Rand(uint64(len(availableExtraScatters)))
	if err != nil {
		return "", err
	}

	return availableExtraScatters[extraScatterIndex], nil
}
