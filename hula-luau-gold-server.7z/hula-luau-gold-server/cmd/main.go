package main

import (
	"hula-luau-gold-server/engine"

	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
)

func main() {
	application, err := app.New("config.yml", engine.Bootstrap)

	if err != nil {
		panic(err)
	}

	if err := application.RunOrSimulate(nil); err != nil {
		panic(err)
	}

	//fmt.Println("WheelFromBaseGame: ", engine.WheelFromBaseGame.Load())
	//rate := float64(engine.WheelFromBaseGame.Load()) / float64(engine.Spins.Load())
	//fmt.Printf("WheelFromBaseGame: rate: %0.5f%%\n", rate)
	//fmt.Printf("WheelFromBaseGame: rate ~ 1 per %d spins\n", int(1/rate))
	//
	//fmt.Println("WheelFromReSpin: ", engine.WheelFromReSpin.Load())
	//rate = float64(engine.WheelFromReSpin.Load()) / float64(engine.Spins.Load())
	//fmt.Printf("WheelFromReSpin: rate: %0.5f%%\n", rate)
	//fmt.Printf("WheelFromReSpin: rate ~ 1 per %d re spins\n", int(1/rate))
	//
	//fmt.Printf("ReSpinStarts: %d (%d)\n", engine.ReSpinStarts.Load(), engine.ReSpinCount.Load())
	//rate = float64(engine.ReSpinStarts.Load()) / float64(engine.Spins.Load())
	//fmt.Printf("ReSpinStarts: rate: %0.2f%%\n", rate)
	//fmt.Printf("ReSpinStarts: rate ~ 1 per %d spins\n", int(1/rate))
	//
	//fmt.Println("OneReSpin: ", engine.OneReSpin.Load())
	//fmt.Println("TwoReSpin: ", engine.TwoReSpin.Load())
	//fmt.Println("ThreeReSpin: ", engine.ThreeReSpin.Load())
}
