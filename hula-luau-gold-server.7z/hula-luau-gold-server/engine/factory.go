package engine

import (
	"encoding/json"
	"fmt"
	"hula-luau-gold-server/engine/volatility"
	"hula-luau-gold-server/engine/volatility/high"
	"hula-luau-gold-server/engine/volatility/low"
	"hula-luau-gold-server/engine/volatility/medium"
	"strconv"

	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	kernelUtils "bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine/utils"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"github.com/samber/lo"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
)

type Info struct {
	WheelMultipliers []int `json:"wheel_multipliers"`
}

func Bootstrap(ctn di.Container, config *engine.Config) *engine.Bootstrap {
	rand := kernelUtils.GetRNG(ctn, config)

	rtp, err := strconv.ParseFloat(config.RTP, 64)
	if err != nil {
		return nil
	}

	volMap := volatility.NewVolatilityMap(rand, high.Volatility, medium.Volatility, low.Volatility)

	if !lo.Contains(lo.Keys(volMap), config.Volatility) {
		config.Volatility = medium.Volatility.Name()
	}

	factory := NewSpinFactory(rand, volMap, rtp, config.Volatility)

	return &engine.Bootstrap{
		SpinFactory:        factory,
		HTTPTransport:      true,
		WebsocketTransport: false,

		FreeSpinsFeature:    true,
		GambleAnyWinFeature: false,

		HistoryHandlingType: engine.SequentialRestoring,

		EngineInfo: Info{
			WheelMultipliers: []int{2, 3, 4, 5, 6, 10, 20},
		},
	}
}

type SpinFactory struct {
	rand rng.Client

	volMap map[string]*volatility.Config
	rtp    float64
	vol    string
}

func NewSpinFactory(rand rng.Client, volMap map[string]*volatility.Config, rtp float64, vol string) *SpinFactory {
	return &SpinFactory{
		rand:   rand,
		volMap: volMap,
		rtp:    rtp,
		vol:    vol,
	}
}

func (s *SpinFactory) GetConfig(vol *string) *volatility.Config {
	if vol == nil {
		return s.volMap[s.vol]
	}

	return s.volMap[s.vol]
}

func (s *SpinFactory) Generate(ctx engine.Context, wager int64, _ interface{}) (engine.Spin, engine.RestoringIndexes, error) {
	cheats, err := getCheatsFromCtx(ctx)
	if err != nil {
		return nil, nil, err
	}

	rtp, vol := getUserParams(ctx)
	zap.S().Info("Generating...")
	if rtp != nil {
		zap.S().Info("RTP: ", fmt.Sprintf("%.2f", *rtp))
	}
	if vol != nil {
		zap.S().Info("Volatility: ", *vol)
	}

	config := s.GetConfig(vol)

	reelType, err := s.ChoseReels(rtp, cheats, config)
	if err != nil {
		return nil, nil, err
	}

	ag, err := NewAwardGetter(wager)
	if err != nil {
		return nil, nil, err
	}

	spin, err := s.compute(ag, Window{}, reelType, cheats, Base, Base, config)
	if err != nil {
		return nil, nil, err
	}

	//collectMetrics(spin)

	return spin, &RestoringIndexes{}, nil
}

func (s *SpinFactory) GambleAnyWin(ctx engine.Context, _ interface{}) (engine.Spin, error) {
	return ctx.LastSpin, nil
}

func (s *SpinFactory) KeepGenerate(ctx engine.Context, _ interface{}) (engine.Spin, bool, error) {
	return ctx.LastSpin, false, nil
}

func (s *SpinFactory) UnmarshalJSONSpin(bytes []byte) (engine.Spin, error) {
	spin := SpinBase{}
	err := json.Unmarshal(bytes, &spin)

	return &spin, err
}

func (s *SpinFactory) UnmarshalJSONRestoringIndexes(bytes []byte) (engine.RestoringIndexes, error) {
	restoringIndexes := RestoringIndexes{}
	err := json.Unmarshal(bytes, &restoringIndexes)

	return &restoringIndexes, err
}

func (s *SpinFactory) ChoseReels(rtp *float64, cheats *Cheats, config *volatility.Config) (int, error) {
	if cheats.reelTypeOneOf(reachReelCode, poorReelCode) {
		return cheats.ReelType, nil
	}

	rnd, err := s.rand.RandFloat()
	if err != nil {
		return -1, err
	}

	if rtp != nil {
		if rnd > calcRTP(*rtp, config.PoorRTP, config.ReachRTP) {
			return reachReelCode, nil
		}

		return poorReelCode, nil
	}

	if rnd > calcRTP(s.rtp, config.PoorRTP, config.ReachRTP) {
		return reachReelCode, nil
	}

	return poorReelCode, nil
}

func (s *SpinFactory) getStops(reels [][]int, cheats *Cheats) ([]int, error) {
	if cheats != nil {
		stops, ok := cheats.GetStops()
		if !ok {
			goto Generate
		}

		if len(stops) != len(reels) {
			return nil, errs.ErrBadDataGiven
		}

		for i := range stops {
			if stops[i] > len(reels[i]) {
				return nil, errs.ErrBadDataGiven
			}
		}

		return stops, nil
	}

Generate:
	req := lo.Map(reels, func(item []int, index int) uint64 {
		return uint64(len(item))
	})

	res, err := s.rand.RandSlice(req)
	if err != nil {
		return nil, err
	}

	return lo.Map(res, func(item uint64, index int) int {
		return int(item)
	}), nil
}

func calcRTP(rtp float64, poorRTP, reachRTP float64) float64 {
	return (reachRTP - rtp) / (reachRTP - poorRTP)
}

func getUserParams(ctx engine.Context) (*float64, *string) {
	if ctx.UserParams != nil {
		var rtp *float64

		if ctx.UserParams.RTP != nil {
			tmp := float64(*ctx.UserParams.RTP)
			rtp = &tmp
		}

		return rtp, ctx.UserParams.Volatility
	}

	return nil, nil
}
