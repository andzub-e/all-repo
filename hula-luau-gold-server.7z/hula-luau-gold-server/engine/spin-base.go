package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"github.com/mohae/deepcopy"
)

type PayItem struct {
	Symbol  int   `json:"symbol"`
	PayLine []int `json:"pay_line"`
	Award   int64 `json:"award"`
}

type SpinBase struct {
	Bet             int64      `json:"wager"`
	Win             int64      `json:"award"`
	Stops           []int      `json:"stops"`
	ReelType        int        `json:"reel_type"`
	ReSpinReels     []int      `json:"re_spin_reels"`
	Type            SpinType   `json:"type"`
	Window          Window     `json:"window"`
	PayItems        []*PayItem `json:"pay_items"`
	WheelMultiplier *int64     `json:"wheel_multiplier"`

	ReSpin *SpinBase `json:"re_spin"`
}

func (s *SpinBase) DeepCopy() engine.Spin {
	// TODO: check it
	return deepcopy.Copy(s).(engine.Spin)
}

func (s *SpinBase) GambleAward() int64 {
	return 0
}

func (s *SpinBase) BaseAward() int64 {
	return findLast(s).Win
}

func (s *SpinBase) BonusAward() int64 {
	return 0
}

func (s *SpinBase) Wager() int64 {
	return s.Bet
}

func (s *SpinBase) BonusTriggered() bool {
	return false
}

func (s *SpinBase) GambleQuantity() int {
	return 0
}

func (s *SpinBase) CanGamble(_ engine.RestoringIndexes) bool {
	return false
}

func findLast(spin *SpinBase) *SpinBase {
	last := spin
	for reSpin := spin.ReSpin; reSpin != nil; reSpin = reSpin.ReSpin {
		last = reSpin
	}
	return last
}

func findLastWithCount(spin *SpinBase) (*SpinBase, int64) {
	last := spin
	count := int64(0)
	for reSpin := spin.ReSpin; reSpin != nil; reSpin = reSpin.ReSpin {
		last = reSpin
		count++
	}

	return last, count
}
