package engine

import (
	"hula-luau-gold-server/engine/volatility"

	"bitbucket.org/electronicjaw/base-slot-server/utils"
	"github.com/samber/lo"
)

func (s *SpinFactory) compute(
	ag AwardGetter, window Window, reelType int, cheats *Cheats,
	spinType, prevSpinType SpinType, config *volatility.Config,
) (*SpinBase, error) {
	reels := config.AvailableReels[reelType]

	stops, err := s.getStops(reels, cheats)
	if err != nil {
		return nil, err
	}

	reSpinReels, err := window.compute(stops, reels, spinType, prevSpinType)
	if err != nil {
		return nil, err
	}

	award, payLines := countWin(window, ag)

	spin := &SpinBase{
		Bet:         ag.Wager,
		Win:         award,
		Stops:       stops,
		ReelType:    reelType,
		ReSpinReels: reSpinReels,
		Type:        spinType,
		Window:      utils.DeepCopy2D(window),
		PayItems:    payLines,
	}

	newSpinType := getSpinType(window, spinType)

	if spinType == ReSpinOfFire && newSpinType == ReSpinOfIce {
		reSpin, err := s.wheelAfterIceWildDuringReSpinOfFire(ag, window, reelType, cheats, newSpinType, spinType, config)
		if err != nil {
			return nil, err
		}

		spin.ReSpin = reSpin

		return spin, nil
	}

	if award > 0 {
		if newSpinType == WheelOfFireAndIce {
			if err := s.wheelOfFireAndIce(spin, config); err != nil {
				return nil, err
			}
		}

		return spin, nil
	}

	if spinType == newSpinType {
		return spin, nil
	}

	if newSpinType == ReSpinOfIce || newSpinType == ReSpinOfFire {
		reSpin, err := s.compute(ag, window, reelType, cheats, newSpinType, spinType, config)
		if err != nil {
			return nil, err
		}

		spin.ReSpin = reSpin

		return spin, nil
	}

	return spin, nil
}

type SpinType int

const (
	Base SpinType = iota
	ReSpinOfIce
	ReSpinOfFire
	WheelOfFireAndIce
)

func getSpinType(window Window, prevSpinType SpinType) SpinType {
	stackSymbol := 0
	stackCount := 0
	iceCount := 0

	for i := range window {
		firstSymbol := window[i][0]
		if stackSymbol != 0 {
			firstSymbol = stackSymbol
		}

		sameSymbol := 0
		iceAdded := false
		for j := range window[i] {
			if window[i][j] == firstSymbol || isWild(window[i][j]) {
				if !isWild(window[i][j]) {
					stackSymbol = window[i][j]
				}
				sameSymbol++
			}
			if !iceAdded && window[i][j] == IceWild {
				iceCount++
				iceAdded = true
			}
		}

		if sameSymbol == 3 {
			stackCount++
		}

		// we have 3 IceWilds on the reel
		if sameSymbol == 3 && len(lo.Uniq(window[i])) == 1 && iceAdded {
			iceCount--
		}
	}

	switch {
	case stackCount == 3:
		return WheelOfFireAndIce
	case iceCount > 0 && prevSpinType != ReSpinOfIce:
		return ReSpinOfIce
	case stackCount == 2 && prevSpinType != ReSpinOfFire:
		// check if we have reel with iceWild
		return ReSpinOfFire
	}

	return Base
}

func (s *SpinFactory) wheelAfterIceWildDuringReSpinOfFire(
	ag AwardGetter, window Window, reelType int, cheats *Cheats,
	spinType, prevSpinType SpinType, config *volatility.Config,
) (*SpinBase, error) {
	reels := config.AvailableReels[reelType]

	stops, err := s.getStops(reels, cheats)
	if err != nil {
		return nil, err
	}

	reSpinReels, err := window.compute(stops, reels, spinType, prevSpinType)
	if err != nil {
		return nil, err
	}

	award, payLines := countWin(window, ag)

	spin := &SpinBase{
		Bet:         ag.Wager,
		Win:         award,
		Stops:       stops,
		ReelType:    reelType,
		ReSpinReels: reSpinReels,
		Type:        spinType,
		Window:      utils.DeepCopy2D(window),
		PayItems:    payLines,
	}

	if err := s.wheelOfFireAndIce(spin, config); err != nil {
		return nil, err
	}

	return spin, nil
}

func (s *SpinFactory) wheelOfFireAndIce(spin *SpinBase, config *volatility.Config) error {
	multiplier, err := config.WheelMultipliersChooser.Pick()
	if err != nil {
		return err
	}

	spin.WheelMultiplier = &multiplier
	spin.Win *= multiplier

	return nil
}

func countWin(window Window, ag AwardGetter) (award int64, payItems []*PayItem) {
	for i := range payLines {
		payLine := computePayLine(payLines[i], window, ag)
		if payLine == nil {
			continue
		}

		payItems = append(payItems, payLine)
		award += payLine.Award
	}

	return
}

func computePayLine(line []int, window Window, ag AwardGetter) *PayItem {
	// preprocess the first symbol in the line
	symbol := window.symbol(line[0])

	// capture our initial symbol or wild state
	wildChain := isWild(symbol)
	wildSymbol := lo.Ternary(wildChain, symbol, 0)

	consecutiveWilds := 0

	if wildChain {
		consecutiveWilds++
	}

	// we've already processed the first symbol / wild
	consecutive := 1

	// walk remaining in pay line to find consecutive count (and true pay symbol if we started with a wild)
	for ; consecutive < len(line); consecutive++ {
		// process next symbol in line
		nextSymbol := window.symbol(line[consecutive])

		// check if our next symbol is wild
		if isWild(nextSymbol) && wildChain {
			consecutiveWilds++
		} else if nextSymbol == symbol || isWild(nextSymbol) {
			continue
		} else if wildChain {
			symbol = nextSymbol
			wildChain = false
		} else {
			break
		}
	}

	// get award
	award := ag.GetAward(symbol, consecutive)

	var wildAward int64
	if wildChain {
		wildAward = ag.GetAward(wildSymbol, consecutiveWilds)
	}

	// use the better one
	if wildAward > award {
		award = wildAward
		symbol = wildSymbol
	}

	if award == 0 {
		return nil
	}

	return &PayItem{
		Symbol:  symbol,
		Award:   award,
		PayLine: line,
	}
}

func isWild(symbol int) bool {
	return symbol == IceWild || symbol == FireWild
}
