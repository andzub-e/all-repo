package engine

import (
	"errors"
	"github.com/samber/lo"
)

type Window [][]int

func (w *Window) GetSymbol(_, payItem int) int {
	return w.symbol(payItem)
}

func (w *Window) GetByIndexes(reelIndex, symbolIndex int) (payIndex, symbol int) {
	return symbolIndex*windowSize + reelIndex, (*w)[reelIndex][symbolIndex]
}

func (w *Window) GetSize() int {
	return windowSize
}

func (w *Window) compute(stops []int, reels [][]int, spinType, prevSpinType SpinType) ([]int, error) {
	switch spinType {
	case Base:
		w.computeBase(stops, reels)

		return []int{}, nil
	case ReSpinOfIce:
		return w.computeReSpinOfIce(stops, reels, prevSpinType)
	case ReSpinOfFire:
		return w.computeReSpinOfFire(stops, reels)
	default:
		return nil, errors.New("unknown spin type")
	}
}

func (w *Window) computeBase(stops []int, reels [][]int) {
	*w = lo.Map(stops, func(stop int, index int) []int {
		reel := reels[index]
		reelLen := len(reel)

		windowLine := make([]int, windowSize)
		for j := 0; j < windowSize; j++ {
			windowLine[j] = reel[(stop+j)%reelLen]
		}

		return windowLine
	})
}

// computeReSpinOfIce
// replace all symbols on reel with IceWild if reel contains IceWild
// but for other reels need to get new symbols
func (w *Window) computeReSpinOfIce(stops []int, reels [][]int, prevSpinType SpinType) ([]int, error) {
	reSpinReels := make([]int, 0, windowSize)

	*w = lo.Map(stops, func(stop int, index int) []int {
		reel := reels[index]
		reelLen := len(reel)

		replaceIndex := -1
		if prevSpinType == ReSpinOfFire {
			i, err := findReelForReplace(*w)
			if err != nil {
				return nil
			}

			replaceIndex = i
		}

		windowLine := make([]int, windowSize)
		for j := 0; j < windowSize; j++ {
			if replaceIndex != -1 && index != replaceIndex {
				return (*w)[index]
			}

			if (*w)[index][j] == IceWild {
				for i := 0; i < windowSize; i++ {
					windowLine[i] = IceWild
				}

				return windowLine
			}

			windowLine[j] = reel[(stop+j)%reelLen]
		}

		reSpinReels = append(reSpinReels, index)

		return windowLine
	})

	return reSpinReels, nil
}

// computeReSpinOfFire
// we have two stacked reels and need to change symbols on the third reel
func (w *Window) computeReSpinOfFire(stops []int, reels [][]int) ([]int, error) {
	replaceIndex, err := findReelForReplace(*w)
	if err != nil {
		return []int{}, err
	}

	stop := stops[replaceIndex]
	reel := reels[replaceIndex]
	reelLen := len(reel)

	for sI := 0; sI < windowSize; sI++ {
		(*w)[replaceIndex][sI] = reel[(stop+sI)%reelLen]
	}

	return []int{replaceIndex}, nil
}

func (w *Window) symbol(payIndex int) int {
	position, reel := payIndex/windowSize, payIndex%windowSize
	return (*w)[reel][position]
}

func findReelForReplace(w Window) (int, error) {
	symbolIndexMap := map[int]int{}

	for i := range w {
		symbols, ok := uniq(w[i])
		if !ok {
			return i, nil
		}

		if len(symbols) == 0 {
			continue
		}

		symbolIndexMap[symbols[0]] = i
	}

	keys := lo.Keys(symbolIndexMap)
	if len(symbolIndexMap) <= 2 {
		return symbolIndexMap[lo.Min(keys)], nil
	}

	symbols := lo.FindUniques(keys)

	if len(symbols) == 0 {
		return -1, errors.New("unique symbols not found")
	}

	symbol := symbols[0]
	// if we have more than one reels with the same index,
	// we find min from them (user has a chance to win more than less)
	if len(symbols) > 1 {
		symbol = lo.Min(symbols)
	}

	key, ok := lo.FindKeyBy(symbolIndexMap, func(key int, _ int) bool {
		return symbol == key
	})
	if !ok {
		return -1, errors.New("symbol key not found")
	}

	return symbolIndexMap[key], nil
}

func uniq(reel []int) ([]int, bool) {
	result := make([]int, 0, len(reel))
	seen := make(map[int]struct{}, len(reel))

	for _, item := range reel {
		if _, ok := seen[item]; ok || item == FireWild {
			continue
		}

		seen[item] = struct{}{}
		result = append(result, item)
	}

	return result, len(result) <= 1
}
