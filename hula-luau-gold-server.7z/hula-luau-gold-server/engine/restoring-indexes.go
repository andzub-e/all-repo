package engine

import (
	"encoding/json"

	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
)

type RestoringIndexes struct {
	BaseSpinIndex int `json:"base_spin_index"`
	//ReSpinIndex int `json:"re_spin_index"`
}

func (r *RestoringIndexes) IsShown(_ engine.Spin) bool {
	//baseSpin, ok := spin.(*SpinBase)

	//if !ok {
	//	zap.S().Error("can not parse spin")
	//	return true
	//}

	//i := 0
	//for ; baseSpin.ReSpin != nil; i++ {
	//	baseSpin = baseSpin.ReSpin
	//}

	//return r.BaseSpinIndex == 1 && r.ReSpinIndex == i
	return r.BaseSpinIndex == 1
}

func (r *RestoringIndexes) Update(payload interface{}) error {
	bytes, err := json.Marshal(payload)
	if err != nil {
		return err
	}

	return json.Unmarshal(bytes, r)
}
