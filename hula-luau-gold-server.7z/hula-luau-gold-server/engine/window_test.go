package engine

import (
	"reflect"
	"testing"
)

func TestWindow_computeReSpinOfFire(t *testing.T) {
	type args struct {
		stops []int
		reels [][]int
	}
	tests := []struct {
		name      string
		w         Window
		args      args
		expectedW Window
	}{
		{
			name: "1",
			w: [][]int{
				{1, 1, 1},
				{1, 1, 1},
				{1, 2, 3},
			},
			args: args{
				stops: []int{0, 0, 2},
				reels: [][]int{
					{4, 5, 6},
					{7, 8, 9},
					{10, 11, 12, 13},
				},
			},
			expectedW: [][]int{
				{1, 1, 1},
				{1, 1, 1},
				{12, 13, 10},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, _ = tt.w.computeReSpinOfFire(tt.args.stops, tt.args.reels)
			if !reflect.DeepEqual(tt.w, tt.expectedW) {
				t.Errorf("computeReSpinOfFire() window = %v, want %v", tt.w, tt.expectedW)
			}
		})
	}
}

func Test_myUniq(t *testing.T) {
	type args struct {
		reel []int
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "1",
			args: args{
				reel: []int{1, 1, 1},
			},
			want: true,
		},
		{
			name: "2",
			args: args{
				reel: []int{1, 1, FireWild},
			},
			want: true,
		},
		{
			name: "3",
			args: args{
				reel: []int{FireWild, FireWild, FireWild},
			},
			want: true,
		},
		{
			name: "4",
			args: args{
				reel: []int{IceWild, IceWild, IceWild},
			},
			want: true,
		},
		{
			name: "5",
			args: args{
				reel: []int{1, 2, 3},
			},
			want: false,
		},
		{
			name: "6",
			args: args{
				reel: []int{1, 1, IceWild},
			},
			want: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if _, got := uniq(tt.args.reel); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("myUniq() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_findReelForReplace(t *testing.T) {
	type args struct {
		w Window
	}
	tests := []struct {
		name string
		args args
		want int
	}{
		{
			name: "1",
			args: args{
				w: [][]int{
					{1, 1, 1},
					{1, 1, 1},
					{1, 2, 3},
				},
			},
			want: 2,
		}, {
			name: "2",
			args: args{
				w: [][]int{
					{1, 1, 1},
					{1, 2, 3},
					{1, 1, 1},
				},
			},
			want: 1,
		}, {
			name: "3",
			args: args{
				w: [][]int{
					{1, 2, 3},
					{1, 1, 1},
					{1, 1, 1},
				},
			},
			want: 0,
		}, {
			name: "4",
			args: args{
				w: [][]int{
					{1, 1, 1},
					{FireWild, FireWild, FireWild},
					{2, 2, 2},
				},
			},
			want: 0,
		}, {
			name: "5",
			args: args{
				w: [][]int{
					{1, 1, 1},
					{2, 2, 2},
					{FireWild, FireWild, FireWild},
				},
			},
			want: 0,
		}, {
			name: "6",
			args: args{
				w: [][]int{
					{1, 1, FireWild},
					{2, 2, 2},
					{FireWild, FireWild, FireWild},
				},
			},
			want: 0,
		}, {
			name: "7",
			args: args{
				w: [][]int{
					{5, 5, 5},
					{6, 6, 6},
					{IceWild, IceWild, IceWild},
				},
			},
			want: 0,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got, _ := findReelForReplace(tt.args.w); got != tt.want {
				t.Errorf("findReelForReplace() = %v, want %v", got, tt.want)
			}
		})
	}
}
