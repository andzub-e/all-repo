package engine

import (
	"encoding/json"

	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
)

type Cheats struct {
	Stops    [][]int `json:"stops"`
	ReelType int     `json:"reel_type"`

	i int
}

func (c *Cheats) Eval(payload interface{}) error {
	b, err := json.Marshal(payload)
	if err != nil {
		return err
	}

	return json.Unmarshal(b, c)
}

func (c *Cheats) GetStops() ([]int, bool) {
	defer func() { c.i++ }()

	if c.i >= len(c.Stops) {
		return nil, false
	}

	return c.Stops[c.i], true
}

func (c *Cheats) reelTypeOneOf(types ...int) bool {
	if c == nil {
		return false
	}

	for i := range types {
		if c.ReelType == types[i] {
			return true
		}
	}

	return false
}

func getCheatsFromCtx(ctx engine.Context) (*Cheats, error) {
	var cheats *Cheats

	if ctx.Cheats != nil {
		cheats = new(Cheats)

		if err := cheats.Eval(ctx.Cheats); err != nil {
			return nil, err
		}
	}

	return cheats, nil
}
