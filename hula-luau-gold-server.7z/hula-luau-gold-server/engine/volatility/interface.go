package volatility

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"github.com/samber/lo"
)

type Volatility interface {
	Name() string
	Config(rand rng.Client) *Config
}

func NewVolatilityMap(rand rng.Client, arr ...Volatility) map[string]*Config {
	return lo.SliceToMap(arr, func(item Volatility) (string, *Config) {
		return item.Name(), item.Config(rand)
	})
}
