package volatility

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"bitbucket.org/electronicjaw/base-slot-server/utils"
)

type Config struct {
	PoorRTP, ReachRTP       float64
	AvailableReels          [][][]int
	WheelMultipliersChooser *utils.Chooser[int64, int]
}

func NewConfig(rand rng.Client,
	poorRTP, reachRTP float64,
	availableReels [][][]int,
	wheelMultipliers map[int64]int,
) *Config {
	wheelMultipliersChooser, err := utils.NewChooserFromMap(rand, wheelMultipliers)
	if err != nil {
		panic(err)
	}

	return &Config{
		PoorRTP:                 poorRTP,
		ReachRTP:                reachRTP,
		AvailableReels:          availableReels,
		WheelMultipliersChooser: wheelMultipliersChooser,
	}
}
