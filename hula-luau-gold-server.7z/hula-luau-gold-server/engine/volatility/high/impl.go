package high

import (
	"hula-luau-gold-server/engine/volatility"

	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
)

var Volatility volatility.Volatility = new(high)

type high string

func (m *high) Name() string {
	return "high"
}

func (m *high) Config(rand rng.Client) *volatility.Config {
	return volatility.NewConfig(rand, poorRTP, reachRTP, availableReels, wheelMultipliersMap)
}
