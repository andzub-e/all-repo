package medium

import (
	"hula-luau-gold-server/engine/volatility"

	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
)

var Volatility volatility.Volatility = new(medium)

type medium string

func (m *medium) Name() string {
	return "medium"
}

func (m *medium) Config(rand rng.Client) *volatility.Config {
	return volatility.NewConfig(rand, poorRTP, reachRTP, availableReels, wheelMultipliersMap)
}
