package low

import (
	"hula-luau-gold-server/engine/volatility"

	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
)

var Volatility volatility.Volatility = new(low)

type low string

func (m *low) Name() string {
	return "low"
}

func (m *low) Config(rand rng.Client) *volatility.Config {
	return volatility.NewConfig(rand, poorRTP, reachRTP, availableReels, wheelMultipliersMap)
}
