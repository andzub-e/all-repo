package engine

import (
	"reflect"
	"testing"
)

func Test_countWin(t *testing.T) {
	type args struct {
		window Window
		ag     AwardGetter
	}
	tests := []struct {
		name         string
		args         args
		wantAward    int64
		wantPayItems []*PayItem
	}{
		{
			name: "1",
			args: args{
				window: [][]int{
					{1, 1, 1},
					{1, 1, 1},
					{1, 1, 1},
				},
				ag: AwardGetter{Wager: 20},
			},
			wantAward: 400,
			wantPayItems: []*PayItem{
				{
					Symbol:  1,
					PayLine: []int{0, 1, 2},
					Award:   80,
				},
				{
					Symbol:  1,
					PayLine: []int{3, 4, 5},
					Award:   80,
				},
				{
					Symbol:  1,
					PayLine: []int{6, 7, 8},
					Award:   80,
				},
				{
					Symbol:  1,
					PayLine: []int{0, 4, 8},
					Award:   80,
				},
				{
					Symbol:  1,
					PayLine: []int{6, 4, 2},
					Award:   80,
				},
			},
		},
		{
			name: "2",
			args: args{
				window: [][]int{
					{1, 1, FireWild},
					{1, 1, IceWild},
					{1, 1, FireWild},
				},
				ag: AwardGetter{Wager: 20},
			},
			wantAward: 520,
			wantPayItems: []*PayItem{
				{
					Symbol:  1,
					PayLine: []int{0, 1, 2},
					Award:   80,
				},
				{
					Symbol:  1,
					PayLine: []int{3, 4, 5},
					Award:   80,
				},
				{
					Symbol:  10,
					PayLine: []int{6, 7, 8},
					Award:   200,
				},
				{
					Symbol:  1,
					PayLine: []int{0, 4, 8},
					Award:   80,
				},
				{
					Symbol:  1,
					PayLine: []int{6, 4, 2},
					Award:   80,
				},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotAward, gotPayItems := countWin(tt.args.window, tt.args.ag)
			if gotAward != tt.wantAward {
				t.Errorf("countWin() gotAward = %v, want %v", gotAward, tt.wantAward)
			}
			if !reflect.DeepEqual(gotPayItems, tt.wantPayItems) {
				t.Errorf("countWin() gotPayItems = %v, want %v", gotPayItems, tt.wantPayItems)
			}
		})
	}
}

func Test_getSpinType(t *testing.T) {
	type args struct {
		window       Window
		prevSpinType SpinType
	}
	tests := []struct {
		name string
		args args
		want SpinType
	}{
		{
			name: "1",
			args: args{
				window: [][]int{
					{IceWild, 8, 8},
					{1, 2, 3},
					{4, 5, 6},
				},
				prevSpinType: Base,
			},
			want: ReSpinOfIce,
		}, {
			name: "2",
			args: args{
				window: [][]int{
					{IceWild, IceWild, IceWild},
					{3, 3, 3},
					{4, 5, 6},
				},
				prevSpinType: ReSpinOfIce,
			},
			want: ReSpinOfFire,
		}, {
			name: "3",
			args: args{
				window: [][]int{
					{IceWild, IceWild, IceWild},
					{3, 3, 3},
					{4, 4, 4},
				},
				prevSpinType: ReSpinOfFire,
			},
			want: Base,
		}, {
			name: "4",
			args: args{
				window: [][]int{
					{1, 1, 1},
					{3, 3, 3},
					{4, 4, 4},
				},
				prevSpinType: Base,
			},
			want: Base,
		}, {
			name: "5",
			args: args{
				window: [][]int{
					{1, 1, 1},
					{1, 1, 1},
					{4, 4, 4},
				},
				prevSpinType: Base,
			},
			want: ReSpinOfFire,
		}, {
			name: "6",
			args: args{
				window: [][]int{
					{1, 1, 1},
					{1, 1, 1},
					{4, 4, 9},
				},
				prevSpinType: ReSpinOfFire,
			},
			want: ReSpinOfIce,
		}, {
			name: "7",
			args: args{
				window: [][]int{
					{1, 1, 1},
					{1, 1, 1},
					{9, 9, 9},
				},
				prevSpinType: ReSpinOfIce,
			},
			want: WheelOfFireAndIce,
		}, {
			name: "8",
			args: args{
				window: [][]int{
					{9, 9, 9},
					{1, 1, 1},
					{9, 9, 9},
				},
				prevSpinType: ReSpinOfIce,
			},
			want: WheelOfFireAndIce,
		}, {
			name: "9",
			args: args{
				window: [][]int{
					{5, 5, 5},
					{IceWild, IceWild, IceWild},
					{6, 7, 7},
				},
				prevSpinType: ReSpinOfFire,
			},
			want: Base,
		}, {
			name: "10",
			args: args{
				window: [][]int{
					{6, 6, 6},
					{7, 7, 8},
					{IceWild, 6, 6},
				},
				prevSpinType: Base,
			},
			want: ReSpinOfIce,
		}, {
			name: "11",
			args: args{
				window: [][]int{
					{6, 6, 6},
					{7, 7, 8},
					{6, IceWild, 6},
				},
				prevSpinType: Base,
			},
			want: ReSpinOfIce,
		}, {
			name: "12",
			args: args{
				window: [][]int{
					{6, 6, 6},
					{7, 7, 8},
					{6, 6, IceWild},
				},
				prevSpinType: Base,
			},
			want: ReSpinOfIce,
		}, {
			name: "13",
			args: args{
				window: [][]int{
					{5, 5, 5},
					{7, IceWild, 7},
					{IceWild, IceWild, IceWild},
				},
				prevSpinType: ReSpinOfFire,
			},
			want: ReSpinOfIce,
		}, {
			name: "14",
			args: args{
				window: [][]int{
					{IceWild, IceWild, IceWild},
					{7, IceWild, 7},
					{IceWild, IceWild, IceWild},
				},
				prevSpinType: ReSpinOfIce,
			},
			want: WheelOfFireAndIce,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := getSpinType(tt.args.window, tt.args.prevSpinType); got != tt.want {
				t.Errorf("getSpinType() = %v, want %v", got, tt.want)
			}
		})
	}
}
