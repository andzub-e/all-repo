package engine

const (
	windowSize = 3

	poorReelCode  = 0
	reachReelCode = 1

	multiplierDivider = 10
)

var payLines = [][]int{
	{0, 1, 2},
	{3, 4, 5},
	{6, 7, 8},
	{0, 4, 8},
	{6, 4, 2},
}

var multipliers = map[int]map[int]int64{
	1:        {3: 40},
	2:        {3: 30},
	3:        {3: 20},
	4:        {3: 14},
	5:        {3: 10},
	6:        {3: 8},
	7:        {3: 6},
	8:        {3: 4},
	IceWild:  {3: 100},
	FireWild: {3: 100},
}

const (
	IceWild  = 9
	FireWild = 10
)
