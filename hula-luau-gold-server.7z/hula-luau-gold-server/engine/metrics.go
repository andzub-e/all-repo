package engine

import "sync/atomic"

var (
	WheelFromBaseGame atomic.Int64
	WheelFromReSpin   atomic.Int64
	ReSpinCount       atomic.Int64
	ReSpinStarts      atomic.Int64
	Spins             atomic.Int64

	OneReSpin   atomic.Int64
	TwoReSpin   atomic.Int64
	ThreeReSpin atomic.Int64
)

func collectMetrics(spin *SpinBase) {
	Spins.Add(1)

	if spin.ReSpin != nil {
		ReSpinStarts.Add(1)
	}

	if spin.WheelMultiplier != nil {
		WheelFromBaseGame.Add(1)
	}

	last, count := findLastWithCount(spin)

	switch count {
	case 0:
		break
	case 3:
		ThreeReSpin.Add(1)
		fallthrough
	case 2:
		TwoReSpin.Add(1)
		fallthrough
	case 1:
		OneReSpin.Add(1)
	default:
		panic("unexpected re-spin count")
	}

	ReSpinCount.Add(count)

	if spin.ReSpin != nil && last.WheelMultiplier != nil {
		WheelFromReSpin.Add(1)
	}
}
