package main

import (
	"fmt"
	"rng-service/internal/rand/isaac"
)

func main() {
	str := "This is <i>not</i> the right mytext."
	gen := isaac.NewISAAC(str)

	k := 0

	for i := 0; i < 2560; i++ {
		fmt.Printf("%x ", gen.RandPure())
		k++

		if k%8 == 0 {
			fmt.Print("\n")
		}
	}
}
