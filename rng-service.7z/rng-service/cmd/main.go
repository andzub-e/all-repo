package main

import (
	"context"
	"go.uber.org/zap"
	"rng-service/internal/constants"
	"rng-service/internal/container"
	"rng-service/internal/transport/grpc"
	"rng-service/internal/transport/http"
	"rng-service/utils"
	"sync"
	"time"
)

func main() {
	now := time.Now()
	ctx := context.Background()
	wg := &sync.WaitGroup{}
	app := container.Build(ctx, wg)

	logger := app.Get(constants.LoggerName).(*zap.Logger)
	logger.Info("Starting application...")

	httpServer := app.Get(constants.HTTPServerName).(*http.Server)
	grpcServer := app.Get(constants.GRPCServerName).(*grpc.Server)

	go func() {
		err := grpcServer.Start()
		if err != nil {
			panic(err)
		}
	}()
	go httpServer.Run()

	zap.S().Infof("Up and running (%s)", time.Since(now))
	zap.S().Infof("Got %s signal. Shutting down...", <-utils.WaitTermSignal())

	grpcServer.Shutdown()

	if err := httpServer.Shutdown(); err != nil {
		panic(err)
	}

	zap.S().Info("Service stopped.")
}
