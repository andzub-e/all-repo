package main

import (
	"context"
	"fmt"
	"go.uber.org/zap"
	"rng-service/internal/constants"
	"rng-service/internal/container"
	"rng-service/internal/services"
	"sync"
)

func main() {
	ctx := context.Background()
	wg := &sync.WaitGroup{}
	app := container.Build(ctx, wg)

	logger := app.Get(constants.LoggerName).(*zap.Logger)
	testSrv := app.Get(constants.TestServiceName).(*services.TestService)

	logger.Info("Start Testing")

	// 99.999%
	chiSquareResult := testSrv.ChiSquare(.00001, 25*1000*1000)
	fmt.Println("ChiSquarePassing:", chiSquareResult)
}
