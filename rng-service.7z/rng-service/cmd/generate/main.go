package main

import (
	"context"
	"flag"
	"go.uber.org/zap"
	"os"
	"rng-service/internal/constants"
	"rng-service/internal/container"
	"rng-service/internal/services"
	"sync"
	"time"
)

var (
	out  = flag.String("out", "result.bin", "write result to file")
	size = flag.Int("size", 100*1000*1000, "number of bytes generated")
)

func init() {
	flag.Parse()
}

func main() {
	now := time.Now()
	defer func() {
		zap.S().Infof("application worked for (%s)", time.Since(now))
	}()

	ctx := context.Background()
	wg := &sync.WaitGroup{}
	app := container.Build(ctx, wg)

	logger := app.Get(constants.LoggerName).(*zap.Logger)
	srv := app.Get(constants.ISAACRandServiceName).(services.RandService)

	logger.Info("Start Generating")

	buf := srv.RandomBuffer(*size)
	file, err := os.Create(*out)

	if err != nil {
		zap.S().Infof("can not open file: %v", err)
	}

	if _, err = file.Write(buf); err != nil {
		zap.S().Infof("can not write to file: %v", err)
	}
}
