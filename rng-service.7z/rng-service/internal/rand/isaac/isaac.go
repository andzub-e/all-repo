package isaac

//#cgo CFLAGS: -I${SRCDIR}/clib
//#include "rand.c"
import "C"

type ISAAC struct{}

func NewISAAC(seed string) *ISAAC {
	issac := &ISAAC{}
	issac.Seed(seed)

	return issac
}

func (isaac *ISAAC) Seed(str string) {
	if len(str) > 256 {
		str = str[:256]
	}

	seed := C.CString(str)
	l := C.int(len(str))

	C.seed(seed, l)
}

func (isaac *ISAAC) RandPure() uint {
	return uint(C.gen())
}

func (isaac *ISAAC) Rand() uint32 {
	return uint32(isaac.RandPure())
}
