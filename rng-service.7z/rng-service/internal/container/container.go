package container

import (
	"context"
	"fmt"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
	"rng-service/internal/config"
	"rng-service/internal/constants"
	"rng-service/internal/services"
	"rng-service/internal/transport/grpc"
	"rng-service/internal/transport/http"
	"rng-service/internal/transport/http/handlers"
	"sync"
)

var container di.Container
var once sync.Once

func Build(ctx context.Context, wg *sync.WaitGroup) di.Container {
	once.Do(func() {
		builder, _ := di.NewBuilder()
		defs := []di.Def{
			{
				Name: constants.LoggerName,
				Build: func(ctn di.Container) (interface{}, error) {
					logger, err := zap.NewDevelopment()

					if err != nil {
						return nil, fmt.Errorf("can't initialize zap logger: %v", err)
					}

					zap.ReplaceGlobals(logger)

					return logger, nil
				},
			},
			{
				Name: constants.ConfigName,
				Build: func(ctn di.Container) (interface{}, error) {
					return config.New()
				},
			},
			{
				Name: constants.GRPCHandlerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)
					randSrv := ctn.Get(constants.ISAACRandServiceName).(services.RandService)

					return grpc.NewHandler(cfg.GRPCConfig, randSrv), nil
				},
			},
			{
				Name: constants.GRPCServerName,
				Build: func(ctn di.Container) (interface{}, error) {
					grpcHandler := ctn.Get(constants.GRPCHandlerName).(*grpc.Handler)

					return grpc.NewServer(grpcHandler), nil
				},
			},
			{
				Name: constants.HTTPServerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					var publicHandlers = []http.Handler{
						ctn.Get(constants.HTTPMetaHandlerName).(http.Handler),
					}

					return http.New(ctx, wg, cfg.HTTPConfig, publicHandlers), nil
				},
			},
			{
				Name: constants.HTTPMetaHandlerName,
				Build: func(ctn di.Container) (interface{}, error) {
					return handlers.NewMetaHandler(), nil
				},
			},
		}

		defs = append(defs, BuildServices()...)
		defs = append(defs, BuildRepositories()...)

		if err := builder.Add(defs...); err != nil {
			panic(err)
		}

		container = builder.Build()
	})

	return container
}
