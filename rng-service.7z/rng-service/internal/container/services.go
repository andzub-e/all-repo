package container

import (
	"github.com/sarulabs/di"
	"rng-service/internal/constants"
	"rng-service/internal/services"
)

func BuildServices() []di.Def {
	return []di.Def{
		{
			Name: constants.ISAACRandServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				return services.NewISAACRandService()
			},
		},
		{
			Name: constants.TestServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				randSrv := ctn.Get(constants.ISAACRandServiceName).(services.RandService)

				return services.NewTestService(randSrv), nil
			},
		},
	}
}
