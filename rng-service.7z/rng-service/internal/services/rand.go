package services

type RandService interface {
	Rand(max uint64) uint64
	RandFloat64() float64
	RandomBuffer(size int) []byte
}
