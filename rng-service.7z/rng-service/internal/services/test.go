package services

import (
	"github.com/gonum/stat/distuv"
)

type TestService struct {
	randSrv RandService
}

func NewTestService(randSrv RandService) *TestService {
	return &TestService{randSrv: randSrv}
}

func (s *TestService) ChiSquare(quantile float64, experimentCount int) bool {
	ksi := distuv.ChiSquared{K: float64(experimentCount) - 1}
	expectValue := ksi.Quantile(quantile)

	if experimentCount <= 0 {
		return false
	}

	expectation := float64(experimentCount) / 256
	experimentalValue := 0.0

	counter := map[byte]int{}
	buf := s.randSrv.RandomBuffer(experimentCount)

	for i := 0; i < len(buf); i++ {
		counter[buf[i]]++
	}

	for _, count := range counter {
		tmp := float64(count) - expectation
		tmp *= tmp
		tmp /= expectation
		experimentalValue += tmp
	}

	return experimentalValue < expectValue
}
