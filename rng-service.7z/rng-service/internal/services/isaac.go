package services

import (
	"bytes"
	"crypto/rand"
	"go.uber.org/zap"
	"rng-service/internal/rand/isaac"
	"sync"
	"unsafe"
)

type ISAACRandService struct {
	gen *isaac.ISAAC
	mu  sync.Mutex
}

func NewISAACRandService() (RandService, error) {
	zap.S().Info("ISAACRandService created")

	key := make([]byte, 64)
	_, err := rand.Read(key)

	if err != nil {
		return nil, err
	}

	gen := isaac.NewISAAC(string(key))

	return &ISAACRandService{
		gen: gen,
	}, nil
}

func (r *ISAACRandService) Rand(max uint64) uint64 {
	// remember: if max ~ max uint64 distribution is not uniform
	r.mu.Lock()
	defer r.mu.Unlock()

	u1, u2 := r.gen.Rand(), r.gen.Rand()

	var u3 = uint64(u1)
	u3 += uint64(u2) << 32

	if max == 0 {
		return 0
	}

	return u3 % max
}

func (r *ISAACRandService) RandomBuffer(size int) []byte {
	buf := bytes.Buffer{}

	uintSize := size / 4

	for i := 0; i < uintSize; i++ {
		ui := r.gen.Rand()
		buf.Write((*[4]byte)(unsafe.Pointer(&ui))[:])
	}

	return buf.Bytes()
}

func (r *ISAACRandService) RandFloat64() float64 {
	return float64(r.Rand(1<<53)) / (1 << 53)
}
