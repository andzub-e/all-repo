package grpc

import (
	"fmt"
	"go.uber.org/zap"
	googleGRPC "google.golang.org/grpc"
	"net"
	"rng-service/pkg/rng"
)

type Server struct {
	hdl *Handler
	r   *googleGRPC.Server
}

func NewServer(hdl *Handler) *Server {
	return &Server{
		hdl: hdl,
	}
}

func (s *Server) Start() error {
	address := fmt.Sprintf("%v:%d", s.hdl.cnf.Host, s.hdl.cnf.Port)

	tcpAddr, err := net.ResolveTCPAddr("tcp", address)
	if err != nil {
		return err
	}

	listener, err := net.ListenTCP("tcp", tcpAddr)
	if err != nil {
		return err
	}

	zap.S().Infof("grpc listining: %s", address)

	s.r = googleGRPC.NewServer()
	rng.RegisterRNGServer(s.r, s.hdl)

	if err = s.r.Serve(listener); err != nil {
		return err
	}

	return nil
}

func (s *Server) Shutdown() {
	s.r.Stop()
}
