package grpc

import (
	"context"
	"io"
	"rng-service/internal/services"
	"rng-service/pkg/rng"
	"time"
)

type Handler struct {
	rng.RNGServer
	randSrv services.RandService
	cnf     *Config
}

func NewHandler(cnf *Config, randSrv services.RandService) *Handler {
	if cnf.MaxProcessingTime == 0 {
		cnf.MaxProcessingTime = time.Second * 10
	} else {
		cnf.MaxProcessingTime *= time.Millisecond
	}

	return &Handler{
		cnf:     cnf,
		randSrv: randSrv,
	}
}

func (h *Handler) HealthCheck(stream rng.RNG_HealthCheckServer) error {
	for {
		msg, err := stream.Recv()
		if err != nil {
			if err == io.EOF {
				return nil
			}

			return err
		}

		if err = stream.Send(msg); err != nil {
			if err == io.EOF {
				return nil
			}

			return err
		}
	}
}

func (h *Handler) Rand(ctx context.Context, request *rng.RandRequest) (*rng.RandResponse, error) {
	response := &rng.RandResponse{Result: make([]uint64, len(request.Max))}
	for i := 0; i < len(response.Result); i++ {
		response.Result[i] = h.randSrv.Rand(request.Max[i])
	}

	return response, nil
}

func (h *Handler) RandFloat(ctx context.Context, request *rng.RandRequestFloat) (*rng.RandResponseFloat, error) {
	response := &rng.RandResponseFloat{Result: make([]float64, request.Max)}
	for i := 0; i < len(response.Result); i++ {
		response.Result[i] = h.randSrv.RandFloat64()
	}

	return response, nil
}
