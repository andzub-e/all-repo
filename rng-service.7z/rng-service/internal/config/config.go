package config

import (
	"github.com/spf13/viper"
	"rng-service/internal/transport/grpc"
	"rng-service/internal/transport/http"
	"sync"
)

var config *Config
var once sync.Once

type Config struct {
	GRPCConfig *grpc.Config
	HTTPConfig *http.Config
}

func New() (*Config, error) {
	once.Do(func() {
		config = &Config{}

		viper.AddConfigPath(".")
		viper.SetConfigName("config")

		if err := viper.ReadInConfig(); err != nil {
			panic(err)
		}

		grpcConfig := viper.Sub("grpc")
		httpConfig := viper.Sub("http")

		if err := grpcConfig.Unmarshal(&config.GRPCConfig); err != nil {
			panic(err)
		}

		if err := httpConfig.Unmarshal(&config.HTTPConfig); err != nil {
			panic(err)
		}
	})

	return config, nil
}
