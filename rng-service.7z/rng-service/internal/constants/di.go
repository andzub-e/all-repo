package constants

const (
	ConfigName      = "Config"
	LoggerName      = "Logger"
	GRPCServerName  = "GRPCServer"
	GRPCHandlerName = "GRPCHandler"
	HTTPServerName  = "HTTPServer"

	HTTPMetaHandlerName = "HTTPMetaHandler"

	ISAACRandServiceName = "ISAACRandService"
	TestServiceName      = "TestService"
)
