## Dieharder

* ```docker run -it ubuntu```
* ```sudo apt-get update```
* ```sudo apt-get install dieharder```
* ```docker cp result.bin <container>:result.bin```
* ```dieharder -a -g 201 -f ./result.bin >> report.txt```

```
Manual:
    -a - runs all the tests with standard/default options to create a report
    
    -f filename - generators 201 or 202 permit either raw binary or 
     formatted ASCII numbers to be read in from a file for testing.
     
     -g 201 means raw binary
```
