package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/utils"
	"fmt"
	"github.com/samber/lo"
	"os"
	"strings"
)

func main() {
	fmt.Println(lo.Map(utils.MustSubstituteReels(replaceMap, reel), func(item string, index int) string {
		s := `"` + item + `"`
		if index != len(reel)-1 {
			s += ", "
		}

		return s
	}))
}

var replaceMap = map[string]string{
	"CLOVER":     "w",
	"SEVEN":      "n",
	"BELL":       "c",
	"GRAPES":     "g",
	"WATERMELON": "m",
	"ORANGE":     "o",
	"LEMON":      "l",
	"BLUEBERRY":  "b",
	"PLUM":       "p",
	"POT":        "t",
	"HORSESHOE":  "s",
}

var reel []string

func init() {
	res, err := os.ReadFile("./tmp.txt")
	if err != nil {
		panic(err)
	}

	reel = strings.Split(strings.ReplaceAll(string(res), ",", ""), "\n")
}
