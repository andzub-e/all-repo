package engine

import "encoding/json"

var (
	GambleRed  = "r"
	GambleBlue = "b"
)

type GambleParams struct {
	Color string `json:"color"`
}

type Gamble struct {
	WagerVal               int64 `json:"wager"`
	Win                    int64 `json:"award"`
	ExpectColor, RealColor string
}

func (g *Gamble) compute() {
	if g.ExpectColor == g.RealColor {
		g.Win = g.WagerVal * 2
	} else {
		g.Win = 0
	}
}

func parseParams(parameters interface{}) (gp GambleParams, err error) {
	b, err := json.Marshal(parameters)
	if err != nil {
		return gp, err
	}

	if err := json.Unmarshal(b, &gp); err != nil {
		return gp, err
	}

	return gp, nil
}
