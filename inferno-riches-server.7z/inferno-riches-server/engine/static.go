package engine

import "github.com/samber/lo"

const (
	scatterSymbol = "s"
	windSymbol    = "w"
	potSymbol     = "t"

	windowWidth           = 5
	windowHeight4         = 4
	multiplicationDivider = 100

	highRTPReelCode = 0
	lowRTPReelCode  = 1

	// TODO: run simulation on 1kkk (or more) to make more accurate
	// current results from simulation on 100kk
	lowRTP  = 41.730
	highRTP = 220.600
)

var lowRTPReelRate = 0.0

var availableReels = []*[][]string{&reelsHighRTP, &reelsLowRTP}

type Window [][]string

func (w *Window) compute(stops []int, reels [][]string) {
	*w = lo.Map(stops, func(stop int, index int) []string {
		reel := reels[index]
		reelLen := len(reel)

		windowLine := make([]string, windowHeight4)
		for j := 0; j < windowHeight4; j++ {
			windowLine[j] = reel[(stop+j)%reelLen]
		}

		return windowLine
	})
}

func (w *Window) symbol(payIndex int) string {
	position, reel := payIndex/windowWidth, payIndex%windowWidth

	return (*w)[reel][position]
}

func awardBySymbolAndCount(symbol string, count int, wager int64) int64 {
	mul := multipliers[symbol][count]

	return mul * wager / multiplicationDivider
}

func availableReelTypes(reelType int) bool {
	return reelType == highRTPReelCode || reelType == lowRTPReelCode
}

// 0  1  2  3  4
// 5  6  7  8  9
// 10 11 12 13 14
// 15 16 17 18 19

var payLines = [][]int{
	{5, 6, 7, 8, 9},      //1
	{10, 11, 12, 13, 14}, // 2
	{0, 1, 2, 3, 4},      // 3
	{15, 16, 17, 18, 19}, // 4
	{5, 11, 17, 13, 9},   // 5
	{10, 6, 2, 8, 14},    // 6
	{0, 6, 12, 8, 4},     // 7
	{15, 11, 7, 13, 19},  //8

	{5, 1, 2, 3, 9},      //9
	{10, 16, 17, 18, 14}, // 10
	{0, 6, 7, 8, 4},      // 11
	{15, 11, 12, 13, 14}, // 12

	{5, 1, 7, 13, 9},    // 13
	{10, 16, 12, 8, 14}, // 14
	{5, 11, 7, 3, 9},    // 15
	{10, 6, 12, 18, 14}, //16

	{5, 1, 7, 3, 9},      //17
	{10, 16, 12, 18, 14}, // 18
	{0, 6, 2, 8, 4},      // 19
	{15, 11, 17, 13, 19}, // 20

	{5, 6, 12, 18, 19}, // 21
	{10, 11, 7, 3, 4},  // 22
	{0, 1, 7, 13, 14},  // 23
	{15, 16, 12, 8, 9}, //24

	{5, 6, 2, 8, 9},      //25
	{10, 11, 17, 13, 14}, // 26
	{0, 1, 7, 3, 4},      // 27
	{15, 16, 12, 18, 19}, // 28

	{5, 6, 7, 13, 19},   // 29
	{10, 11, 12, 8, 4},  // 30
	{0, 1, 2, 8, 14},    // 31
	{15, 16, 17, 13, 9}, //32

	{5, 11, 17, 18, 19}, //33
	{10, 6, 2, 3, 4},    // 34
	{0, 6, 12, 13, 14},  // 35
	{15, 11, 7, 8, 9},   // 36

	{0, 1, 7, 13, 19},  // 37
	{15, 16, 12, 8, 4}, // 38
	{0, 6, 12, 18, 19}, // 39
	{15, 11, 7, 3, 4},  //40
}

// 5, 15, 50
var multipliers = map[string]map[int]int64{
	"b": {3: 25, 4: 75, 5: 250}, // blueberry
	"p": {3: 25, 4: 75, 5: 250}, // plum
	"l": {3: 25, 4: 75, 5: 250}, // lemon
	"o": {3: 25, 4: 75, 5: 250}, // orange

	"c": {3: 100, 4: 250, 5: 1250}, // campane (bell)
	"g": {3: 100, 4: 250, 5: 1250}, // grapes
	"m": {3: 50, 4: 125, 5: 500},   // watermelon(melon)

	"n":           {2: 25, 3: 125, 4: 500, 5: 7500}, // 10% number (seven)
	scatterSymbol: {3: 2000},
	potSymbol:     {3: 300, 4: 2000, 5: 10000},
}

var reelsHighRTP = [][]string{
	{"b", "b", "b", "t", "l", "l", "p", "p", "p", "p", "o", "o", "o", "c", "c", "c", "c", "c", "b", "b", "b", "t", "l", "l", "b", "b", "s", "m", "m", "m", "o", "o", "o", "l", "l", "l", "t", "g", "g", "g", "g", "g", "p", "p", "p", "p", "o", "o", "o", "o", "n", "n", "n", "l", "l", "l", "m", "m", "m", "b", "b", "b", "s", "o", "o", "o", "l", "l", "l", "s", "p", "p", "p", "b", "b", "b", "b", "m", "m", "m", "m", "p", "p", "p", "b", "b", "b", "t", "l", "l", "p", "p", "p", "p", "o", "o", "o", "c", "c", "c", "c", "c", "b", "b", "b", "t", "l", "l", "b", "b", "s", "m", "m", "m", "o", "o", "o", "l", "l", "l", "t", "g", "g", "g", "g", "g", "p", "p", "p", "p", "o", "o", "o", "o", "n", "n", "n", "n", "l", "l", "l", "m", "m", "m", "b", "b", "b", "s", "o", "o", "o", "l", "l", "l", "s", "p", "p", "p", "b", "b", "b", "b", "m", "m", "m", "m", "p", "p", "p"},
	{"m", "m", "m", "m", "p", "p", "p", "t", "l", "l", "l", "b", "b", "b", "w", "b", "b", "b", "t", "n", "n", "n", "n", "n", "p", "p", "p", "w", "p", "p", "p", "m", "m", "m", "l", "l", "l", "w", "l", "l", "l", "b", "b", "b", "m", "m", "m", "m", "o", "o", "o", "o", "w", "o", "o", "o", "o", "g", "g", "g", "g", "g", "o", "o", "o", "o", "l", "l", "l", "p", "p", "p", "c", "c", "c", "c", "c", "t", "b", "b", "b"},
	{"g", "g", "g", "g", "b", "b", "b", "b", "l", "l", "l", "c", "c", "c", "t", "p", "p", "p", "w", "p", "p", "p", "p", "o", "o", "o", "o", "b", "b", "b", "w", "b", "b", "b", "c", "c", "c", "m", "m", "m", "m", "m", "c", "c", "c", "s", "n", "n", "n", "g", "g", "g", "g", "o", "o", "o", "o", "l", "l", "l", "l", "w", "l", "l", "l", "s", "c", "c", "c", "t", "p", "p", "p", "g", "g", "g", "g", "o", "o", "o"},
	{"p", "p", "p", "w", "p", "p", "p", "b", "b", "b", "b", "w", "b", "b", "b", "o", "o", "o", "o", "c", "c", "c", "c", "l", "l", "l", "n", "n", "n", "n", "p", "p", "p", "p", "p", "m", "m", "m", "m", "b", "b", "b", "b", "l", "l", "l", "l", "w", "l", "l", "l", "l", "g", "g", "g", "g", "o", "o", "o", "o", "c", "c", "c", "g", "g", "g", "o", "o", "o", "t", "m", "m", "m", "m", "m"},
	{"b", "b", "b", "g", "g", "g", "m", "m", "m", "m", "o", "o", "o", "l", "l", "l", "s", "c", "c", "c", "c", "c", "o", "o", "o", "g", "g", "g", "p", "p", "p", "m", "m", "m", "l", "l", "l", "l", "p", "p", "p", "s", "o", "o", "o", "l", "l", "l", "g", "g", "g", "g", "t", "b", "b", "b", "n", "n", "n", "s", "b", "b", "b", "t", "p", "p", "p", "b", "b", "b", "g", "g", "g", "m", "m", "m", "m", "o", "o", "o", "l", "l", "l", "s", "c", "c", "c", "c", "c", "o", "o", "o", "g", "g", "g", "p", "p", "p", "m", "m", "m", "l", "l", "l", "l", "p", "p", "p", "s", "o", "o", "o", "l", "l", "l", "g", "g", "g", "g", "t", "b", "b", "b", "n", "n", "n", "s", "b", "b", "b", "t", "p", "p", "p", "b", "b", "b", "g", "g", "g", "m", "m", "m", "m", "o", "o", "o", "l", "l", "l", "s", "c", "c", "c", "c", "c", "o", "o", "o", "g", "g", "g", "p", "p", "p", "m", "m", "m", "l", "l", "l", "l", "p", "p", "p", "s", "o", "o", "o", "l", "l", "l", "g", "g", "g", "g", "t", "b", "b", "b", "n", "n", "n", "n", "s", "b", "b", "b", "t", "p", "p", "p"},
}

var reelsLowRTP = [][]string{
	{"b", "b", "b", "t", "l", "l", "p", "p", "p", "p", "o", "o", "o", "c", "c", "c", "c", "c", "b", "b", "b", "t", "l", "l", "b", "b", "s", "m", "m", "m", "o", "o", "o", "l", "l", "l", "t", "g", "g", "g", "g", "g", "p", "p", "p", "p", "o", "o", "o", "o", "n", "n", "n", "l", "l", "l", "m", "m", "m", "b", "b", "b", "s", "o", "o", "o", "l", "l", "l", "s", "p", "p", "p", "b", "b", "b", "b", "m", "m", "m", "m", "p", "p", "p"},
	{"m", "m", "m", "m", "p", "p", "p", "t", "l", "l", "l", "b", "b", "b", "b", "b", "b", "t", "n", "n", "n", "n", "n", "p", "p", "p", "p", "p", "p", "m", "m", "m", "l", "l", "l", "l", "l", "l", "b", "b", "b", "m", "m", "m", "m", "o", "o", "o", "o", "o", "o", "o", "o", "g", "g", "g", "g", "g", "o", "o", "o", "o", "l", "l", "l", "p", "p", "p", "c", "c", "c", "c", "c", "t", "b", "b", "b"},
	{"g", "g", "g", "g", "b", "b", "b", "b", "l", "l", "l", "c", "c", "c", "t", "p", "p", "p", "p", "p", "p", "p", "o", "o", "o", "o", "b", "b", "b", "b", "b", "b", "c", "c", "c", "m", "m", "m", "m", "m", "c", "c", "c", "s", "n", "n", "n", "g", "g", "g", "g", "o", "o", "o", "o", "l", "l", "l", "l", "l", "l", "l", "s", "c", "c", "c", "t", "p", "p", "p", "g", "g", "g", "g", "o", "o", "o"},
	{"p", "p", "p", "p", "p", "p", "b", "b", "b", "b", "b", "b", "b", "o", "o", "o", "o", "c", "c", "c", "c", "l", "l", "l", "n", "n", "n", "n", "p", "p", "p", "p", "p", "m", "m", "m", "m", "b", "b", "b", "b", "l", "l", "l", "l", "l", "l", "l", "l", "g", "g", "g", "g", "o", "o", "o", "o", "c", "c", "c", "g", "g", "g", "o", "o", "o", "t", "m", "m", "m", "m", "m"},
	{"b", "b", "b", "g", "g", "g", "m", "m", "m", "m", "o", "o", "o", "l", "l", "l", "s", "c", "c", "c", "c", "c", "o", "o", "o", "g", "g", "g", "p", "p", "p", "m", "m", "m", "l", "l", "l", "l", "p", "p", "p", "s", "o", "o", "o", "l", "l", "l", "g", "g", "g", "g", "t", "b", "b", "b", "n", "n", "n", "s", "b", "b", "b", "t", "p", "p", "p"},
}
