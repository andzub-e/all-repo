package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
	"inferno-riches-server/engine"
)

func main() {
	application, err := app.New("config.yml", engine.GameBoot)

	if err != nil {
		panic(err)
	}

	if err := application.RunOrSimulate(nil); err != nil {
		panic(err)
	}
}
