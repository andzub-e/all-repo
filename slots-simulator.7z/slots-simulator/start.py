import os
import subprocess
import yaml
import jinja2
import sys

def load_yaml(file_path):
    with open(file_path, 'r') as file:
        return yaml.safe_load(file)

def save_yaml(data, file_path):
    with open(file_path, 'w') as file:
        file.write(data)

def process_game(game, common):
    overrides = game.get('overrides', {})

    registry = overrides.get('registry', common['registry'])
    name_suffix = overrides.get('nameSuffix', common['nameSuffix'])
    image_name = f"{registry}/{game['name']}{name_suffix}:{game['tag']}"

    return {
        'name': game['name'],
        'image': image_name,
        'wager': overrides.get('wager', common['wager']),
        'count': overrides.get('count', common['count']),
        'volatility': overrides.get('volatility', common['volatility']),
        'rtp': overrides.get('rtp', common['rtp']),
        'workers': overrides.get('workers', common['workers']),
        'rng': overrides.get('rng', common['rng']),
    }

def process_games(common, games):
    return {'games': [process_game(game, common) for game in games]}

def generate_config(game, config_template):
    sim_rng_host, sim_rng_port = game['rng'].split(':') if game['rng'] != 'mock' else ('rng', 7100)

    return config_template.render(
        SIM_GAME_NAME=game['name'],
        SIM_RTP=game['rtp'],
        SIM_VOLATILITY=game['volatility'],
        SIM_MOCKED_RNG=str(game['rng'] == 'mock').lower(),
        SIM_RNG_HOST=sim_rng_host,
        SIM_RNG_PORT=sim_rng_port,
        SIM_SPINS=game['count'],
        SIM_WAGER=game['wager'],
        SIM_WORKERS=game['workers']
    )

def main(input_path, config_template_path):
    data = load_yaml(input_path)
    processed_data = process_games(data['common'], data['games'])
    config_dir = './configs'
    os.makedirs(config_dir, exist_ok=True)

    with open(config_template_path) as f:
        config_template = jinja2.Template(f.read())

    for game in processed_data['games']:
        config_data = generate_config(game, config_template)
        output_file = os.path.join(config_dir, f"config_{game['name']}_{game['rtp']}_{game['volatility']}.yml")
        save_yaml(config_data, output_file)

        command = [
            'docker', 'run', '--rm',
            '-v', f"{output_file}:/app/config.yml", 
            '-v', f"{os.getcwd()}/results:/app/results",  
            game['image'] 
        ]
        print(command)
        process = subprocess.Popen(command)
        process.wait()

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 start.py games.yaml config.yml.template")
        sys.exit(1)
    input_file, config_template_file = sys.argv[1], sys.argv[2]
    main(input_file, config_template_file)
