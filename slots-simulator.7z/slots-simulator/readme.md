# Heronbyte slots simulator

This is RTP and other stats semi-automatic simulator script for Heronbyte games.

Targeted platform: linux

## How to use
1. Install dependencies:

- [docker](https://docs.docker.com/engine/install/)
- python
- python3-jinja2
- (optional) screen

2. Copy and fill games.yaml
```bash
cp games.yaml.example games.yaml
vim games.yaml # you can use own liked editor
```
3. Non-required advice: create screen
```bash
screen -S sim
```
4. Run simulator
```bash
python3 start.py games.yaml config.yml.template
```
5. Get reports in `results` folder after finish
