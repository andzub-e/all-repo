package consts

const (
	PayLineCount = 10
	PayLineSize  = 5
	ReelCount    = 5
	ReelSize     = 200
	WindowHeight = 3
)
