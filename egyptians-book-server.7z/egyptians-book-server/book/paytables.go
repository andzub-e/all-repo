package book

func init() {
	var minmult Multiplier

Initial:
	for _, pl := range BasePaytable {
		for _, m := range pl {
			if m > 0 {
				minmult = m
				break Initial
			}
		}
	}

	for _, pl := range BasePaytable {
		for _, m := range pl {
			if m < minmult && m > 0 {
				minmult = m
			}
		}
	}
	for _, pl := range BonusPaytable {
		for _, m := range pl {
			if m < minmult && m > 0 {
				minmult = m
			}
		}
	}

	for i := minmult; i > 0; i-- {
		if i.IsDenominator() {
			return
		}
	}

	panic("no multiplier GCD found")
}

var BasePaytable = Paytable{

	"S": PaytableLine{5: 200, 4: 20, 3: 5},             // Bonus and scatter symbol
	"Z": PaytableLine{5: 5000, 4: 1000, 3: 100, 2: 10}, // High pay 2
	"Y": PaytableLine{5: 2000, 4: 400, 3: 40, 2: 5},    // High pay 1
	"P": PaytableLine{5: 750, 4: 100, 3: 30, 2: 5},     // Medium pay 2
	"O": PaytableLine{5: 750, 4: 100, 3: 30, 2: 5},     // Medium pay 1
	"E": PaytableLine{5: 150, 4: 40, 3: 5},             // Ace
	"D": PaytableLine{5: 150, 4: 40, 3: 5},             // King
	"C": PaytableLine{5: 100, 4: 25, 3: 5},             // Queen
	"B": PaytableLine{5: 100, 4: 25, 3: 5},             // Jack
	"A": PaytableLine{5: 100, 4: 25, 3: 5},             // 10
}

var BonusPaytable = Paytable{

	"S": PaytableLine{5: 200, 4: 20, 3: 5},             // Bonus and scatter symbol
	"Z": PaytableLine{5: 5000, 4: 1000, 3: 100, 2: 10}, // High pay 2
	"Y": PaytableLine{5: 2000, 4: 400, 3: 40, 2: 5},    // High pay 1
	"P": PaytableLine{5: 750, 4: 100, 3: 30, 2: 5},     // Medium pay 2
	"O": PaytableLine{5: 750, 4: 100, 3: 30, 2: 5},     // Medium pay 1
	"E": PaytableLine{5: 150, 4: 40, 3: 5},             // Ace
	"D": PaytableLine{5: 150, 4: 40, 3: 5},             // King
	"C": PaytableLine{5: 100, 4: 25, 3: 5},             // Queen
	"B": PaytableLine{5: 100, 4: 25, 3: 5},             // Jack
	"A": PaytableLine{5: 100, 4: 25, 3: 5},             // 10
}

func (m Multiplier) IsDenominator() bool {
	for _, pl := range BasePaytable {
		for _, t := range pl {
			if t%m != 0 {
				return false
			}
		}
	}
	for _, pl := range BonusPaytable {
		for _, t := range pl {
			if t%m != 0 {
				return false
			}
		}
	}

	return true
}

var WildsBonusSpinCounts = map[int]SpinCount{
	5: 10,
	4: 10,
	3: 10,
	2: 0,
	1: 0,
	0: 0,
}
