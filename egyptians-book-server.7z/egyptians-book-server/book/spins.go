package book

import "bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"

type Spin struct {
	WagerVal int64 `json:"wager"`
	Balance  int64 `json:"balance" swaggertype:"integer"`
	BaseWin  int64 `json:"base_win"`
	BonusWin int64 `json:"bonus_win"`

	Reels   ReelState `json:"reels"`
	Payouts Payouts   `json:"payouts"`

	BonusSpins BonusSpinResults `json:"bonus_spins"`
	BonusReels BonusReelStates  `json:"-"` // not exported - purely internal
	Window     ReelWindow       `json:"window" swaggertype:"array,array,string"`
	Gambles    []Gamble         `json:"gambles"`
}

func (s Spin) GambleAward() int64 {
	var award int64

	if len(s.Gambles) > 0 {
		award = s.Gambles[len(s.Gambles)-1].Win
	}

	return award
}

func (s Spin) DeepCopy() engine.Spin {
	return s.deepCopy()
}

func (s Spin) deepCopy() *Spin {
	spin := Spin{
		WagerVal: s.WagerVal,
		Balance:  s.Balance,
		BaseWin:  s.BaseWin,
		BonusWin: s.BonusWin,

		Reels:   s.Reels,
		Payouts: s.Payouts,

		Window:     ReelWindow{},
		BonusSpins: make(BonusSpinResults, len(s.BonusSpins)),
		BonusReels: make(BonusReelStates, len(s.BonusReels)),
		Gambles:    make([]Gamble, len(s.Gambles)),
	}

	copy(spin.Window[:], s.Window[:])
	copy(spin.BonusSpins, s.BonusSpins)
	copy(spin.BonusReels, s.BonusReels)
	copy(spin.Gambles, s.Gambles)

	return &spin
}

func (s *Spin) BaseAward() int64 {
	return s.BaseWin
}

func (s *Spin) BonusAward() int64 {
	award := s.BonusWin

	if len(s.Gambles) > 0 {
		award = 0
	}

	return award
}

func (s *Spin) Wager() int64 {
	return s.WagerVal
}

func (s *Spin) CanGamble(restoringIndexes engine.RestoringIndexes) bool {
	return len(s.BonusSpins) == 0
}

func (s *Spin) GambleQuantity() int {
	return len(s.Gambles)
}

func (s Spin) BonusTriggered() bool {
	return len(s.BonusSpins) > 0
}
