package book

var SymbolsForExpanding = []ReelSymbol{
	"A",
	"B",
	"C",
	"D",
	"E",
	"O",
	"P",
	"Y",
	"Z",
}

type Weight uint

var BaseReelsOptions = map[int]Weight{
	0: 1,
}

var BaseReelsTotalWeight Weight

func init() {
	for _, w := range BaseReelsOptions {
		BaseReelsTotalWeight += w
	}
}
