package book

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"books/consts"
	"github.com/google/uuid"
	"sort"
)

type ReelState struct {
	Stops                     [consts.ReelCount]ReelStop `json:"stops" example:"11,22,33,44,55"`
	IsCheatStops              bool                       `json:"is_cheat_stops,omitempty"`
	IsAutospin                bool                       `json:"is_autospin"`
	IsTurbospin               bool                       `json:"is_turbospin"`
	BonusSpinsRetriggerAmount uint                       `json:"bonus_spins_retrigger_amount"`
}

type BonusReelState struct {
	ReelState
	ExpandingSymbol          ReelSymbol       `json:"expanding_symbol" example:"A"`
	ExpandingActivated       bool             `json:"expanding_activated" example:"false"`
	ExpandingSymbolPositions []SymbolPosition `json:"expanding_symbol_position"`
	FreeSpinsLeft            SpinCount        `json:"free_spins_left" example:"9"`
	RetriggeredBonusGame     int              `json:"retriggered_bonus_game" example:"0"`
}

type ReelStop uint

type PaylineID uint
type Reel [consts.ReelSize]ReelSymbol
type ReelID uint
type ReelSymbol string
type ReelWindow [consts.ReelCount]ReelWindowColumn
type ReelWindowColumn [consts.WindowHeight]ReelSymbol
type RowID int
type SpinCount uint

type SessionID uuid.UUID
type Username string
type BonusSpinResults []BonusSpinResult
type ReelsSpinTime uint
type MicroMultiplier uint64
type Multiplier uint // @name Multiplier
type PaytableLine map[uint]Multiplier
type Paytable map[ReelSymbol]PaytableLine
type AbsolutePayline [consts.PayLineSize]WindowSlot
type BonusReelStates []BonusReelState
type WindowSlot uint

type CurrencyType string
type FreespinID uuid.UUID
type WagerID uuid.UUID
type ReelSet [consts.ReelCount]Reel

type BonusSpinResult struct {
	Window           ReelWindow     `json:"window"`
	Reels            BonusReelState `json:"reels"`
	PayoutsInfo      Payouts        `json:"payouts_info"`
	AdditionalSpins  SpinCount      `json:"additionalSpins"`
	CurrentWinAmount int64          `json:"current_win_amount" swaggertype:"integer" example:"100"`
	BalanceAfterSpin int64          `json:"balance_after_spin" swaggertype:"integer" example:"100"`
}

const WildSymbol = ReelSymbol("S")

type SymbolPosition struct {
	ReelID ReelID `json:"reel_id" example:"0"`
	RowID  RowID  `json:"row_id" example:"0"`
}

func (s *SpinFactory) randomReelState(ctx engine.Context) (rs ReelState, err error) {
	c := Cheats{}

	if ctx.Cheats != nil {
		if err := c.Eval(ctx.Cheats); err != nil {
			return rs, err
		}
	}

	if c.GambleColor == "" && ctx.Cheats != nil {
		if len(c.Stops) != consts.ReelCount {
			return rs, errs.ErrBadDataGiven
		}

		for i := range c.Stops {
			if c.Stops[i] > consts.ReelSize {
				return rs, errs.ErrBadDataGiven
			}
		}

		for i := range c.Stops {
			rs.Stops[i] = ReelStop(c.Stops[i])
		}

		return
	}

	for i := 0; i < consts.ReelCount; i++ {
		var stop uint64
		stop, err = s.rand.Rand(consts.ReelSize)
		if err != nil {
			return
		}

		rs.Stops[i] = ReelStop(stop)
	}

	return
}

func (s *SpinFactory) executeSpin(ctx engine.Context, wager int64, isAutospin bool, spin *Spin) (err error) {

	// spin base reels
	err = s.spinReels(ctx, wager, isAutospin, spin)
	if err != nil {
		return
	}

	// spin bonus reels (if exists)
	err = s.spinBonusReels(ctx, wager, spin)
	if err != nil {
		return
	}

	return
}

func (s *SpinFactory) spinBonusReels(ctx engine.Context, wager int64, spin *Spin) (err error) {
	spin.BonusSpins = nil

	count := spin.Reels.BonusSpinsFromWilds()

	spin.BonusReels, err = s.spinBonusReels2(ctx, count)
	if err != nil {
		return
	}

	if spin.BonusReels == nil {
		return
	}

	currentWinAmount := spin.Payouts.PayoutForSpin
	balanceAfterSpin := spin.Balance + currentWinAmount

	// build bonus state
	for ind, brs := range spin.BonusReels {
		spin.BonusSpins = append(spin.BonusSpins, brs.Results(wager))

		// we accumulate all wins for showing how the winning amount increases
		currentWinAmount += spin.BonusSpins[ind].PayoutsInfo.PayoutForSpin
		balanceAfterSpin += spin.BonusSpins[ind].PayoutsInfo.PayoutForSpin
		spin.BonusSpins[ind].CurrentWinAmount = currentWinAmount
		spin.BonusSpins[ind].BalanceAfterSpin = balanceAfterSpin
	}

	return
}

func (s *SpinFactory) spinReels(ctx engine.Context, wager int64, isAutospin bool, spin *Spin) (err error) {

	// spin the base reels
	spin.Reels, err = s.randomReelState(ctx)
	if err != nil {
		return
	}

	spin.Reels.IsAutospin = isAutospin

	// update internal state
	spin.Window = spin.Reels.Window()
	spin.Payouts = spin.Reels.Results(wager)

	return
}

func (rs ReelState) Results(totalWager int64) (payouts Payouts) {

	// get line payouts
	return rs.Window().Results(totalWager, BasePaytable, nil)
}

func (brs BonusReelState) Results(totalWager int64) (result BonusSpinResult) {
	// payouts
	result.Window, _, _ = brs.Window()

	// reels
	result.Reels = brs

	// pays for spin
	newpays := result.Window.Results(totalWager, BonusPaytable, &brs)

	result.PayoutsInfo.WildWins = newpays.WildWins

	for _, po := range newpays.SpinPayouts {
		result.PayoutsInfo.SpinPayouts = append(result.PayoutsInfo.SpinPayouts, po)
	}

	// pays for expanded symbols
	for _, esp := range newpays.ExpandedSymbolPayouts {
		result.PayoutsInfo.ExpandedSymbolPayouts = append(result.PayoutsInfo.ExpandedSymbolPayouts, esp)
	}

	// additional spins (from this spin)
	if result.Reels.RetriggeredBonusGame <= 3 {
		result.AdditionalSpins = brs.BonusSpinsFromWilds()
	} else {
		result.AdditionalSpins = 0
	}

	result.PayoutsInfo.PayoutForSpin = newpays.PayoutForSpin

	return
}

type Payouts struct {
	SpinPayouts           []Payout `json:"spin_payouts"`
	ExpandedSymbolPayouts []Payout `json:"expanded_symbol_payouts"`
	PayoutForSpin         int64    `json:"payout_for_spin" swaggertype:"integer" example:"100"`
	WildWins              WildWins `json:"wild_wins"`
}

func (s *SpinFactory) calcWin(spin *Spin) (err error) {

	for _, p := range spin.BonusSpins {
		spin.BonusWin += p.PayoutsInfo.TotalWins()
	}

	spin.BaseWin = spin.Payouts.TotalWins()

	return
}

func (rs ReelState) Window() (window ReelWindow) {

	for reel := ReelID(0); reel < consts.ReelCount; reel++ {
		for row := RowID(0); row < consts.WindowHeight; row++ {
			window[reel][row] = rs.EffectiveSymbol(reel, row, rs.Stops[reel])
		}
	}

	return
}

func (rs ReelState) EffectiveSymbol(reel ReelID, row RowID, stop ReelStop) ReelSymbol {
	return BaseReels.RawSymbol(reel, row, stop)
}

func (r ReelSet) RawSymbol(reel ReelID, row RowID, stop ReelStop) ReelSymbol {
	return r[reel][((int(row)+int(stop))%consts.ReelSize+consts.ReelSize)%consts.ReelSize]
}

// returns all payouts for the specified wager
func (rw ReelWindow) Results(totalWager int64, payTable Paytable, brs *BonusReelState) (payouts Payouts) {
	// here we calculate the results for base window
	for payline := PaylineID(0); payline < consts.PayLineCount; payline++ {
		payout := rw.Result(payline, payTable)
		if payout != nil {
			payout.Amount = payout.Multiplier.ApplyTo(totalWager) / consts.PayLineCount
			payouts.SpinPayouts = append(payouts.SpinPayouts, *payout)
		}
	}

	// calculate payouts for wilds symbols
	payouts.WildWins = rw.payoutForWilds(totalWager)

	// if we have the expanding symbol activated we calculate user's win with new window
	if brs != nil && brs.ExpandingActivated {
		_, _, amount := brs.Window()
		payouts.ExpandedSymbolPayouts = rw.ResultForExpandingSymbols(brs.ExpandingSymbol, totalWager, amount)
	}

	sort.SliceStable(payouts.SpinPayouts, func(i, j int) bool {
		return payouts.SpinPayouts[i].Amount < payouts.SpinPayouts[j].Amount
	})

	// calculate payout for spin
	payouts.PayoutForSpin = payouts.TotalWins()

	return
}

// returns the payout multiplier for one payline
func (rw ReelWindow) Result(lid PaylineID, payTable Paytable) *Payout {

	// the line we're processing
	line := PayLines[lid]

	// preprocess the first symbol in the line
	symbol := rw.SymbolAt(line[0])

	// capture our initial symbol or wild state
	wildChain := symbol == WildSymbol
	consecutiveWilds := uint(0)
	if wildChain {
		consecutiveWilds++
	}

	// we've already processed the first symbol / wild
	consecutive := uint(1)

	// walk remaining in payline to find consecutive count (and true pay symbol if we started with a wild)
	for ; consecutive < consts.PayLineSize; consecutive++ {

		// process next symbol in line
		nextSymbol := rw.SymbolAt(line[consecutive])

		// check if our next symbol is wild
		if nextSymbol == WildSymbol {
			if wildChain {
				consecutiveWilds++
			}
		} else if nextSymbol == symbol {
			// continue
		} else if wildChain {
			symbol = nextSymbol
			wildChain = false
		} else {
			break
		}
	}

	// get multiplier
	mult := payTable.Result(symbol, consecutive)
	wildmult := payTable.Result("Z", consecutiveWilds)

	// use the better one
	if wildmult > mult {
		mult = wildmult
		consecutive = consecutiveWilds
		symbol = "Z"
	}

	// if we ended up without a multiplier, we're done
	if mult == 0 {
		return nil
	}

	return &Payout{
		Symbol:     symbol,
		Count:      consecutive,
		PaylineId:  lid,
		Multiplier: mult,
	}
}

func (rw ReelWindow) SymbolAt(slot WindowSlot) ReelSymbol {
	reel, row := slot.Location()
	return rw[reel][row]
}

func (slot WindowSlot) Location() (reel ReelID, row RowID) {
	return ReelID(slot % consts.ReelCount), RowID(slot / consts.ReelCount)
}

type WildWins struct {
	Amount    int64            `json:"amount" swaggertype:"integer" example:"100"`
	Count     uint             `json:"count" example:"3"`
	Positions []SymbolPosition `json:"positions"`
}

type Payout struct {
	Symbol     ReelSymbol `json:"symbol" example:"A"`
	Count      uint       `json:"count" example:"5"`
	PaylineId  PaylineID  `json:"payline" swaggertype:"string" example:"0"`
	Amount     int64      `json:"amount" swaggertype:"integer" example:"100"`
	Cycle      int        `json:"cycle,omitempty"`
	Multiplier Multiplier `json:"-"` // not exported - purely internal
}

func (s *SpinFactory) spinBonusReels2(ctx engine.Context, count SpinCount) (spins []BonusReelState, err error) {
	// we need this for control of the bonus game activation three times only
	var (
		expandingSymbol    ReelSymbol
		bonusGameTriggered int
	)
	var randomNumber uint64 = 0
	// if we have free spins we get the expanding symbol for the bonus game
	if count != 0 {
		randomNumber, err = s.rand.Rand(uint64(len(SymbolsForExpanding)))
		if err != nil {
			return
		}

		expandingSymbol = SymbolsForExpanding[randomNumber]
	}

	for ; count > 0; count-- {

		// create the reels
		var brs BonusReelState
		brs, err = s.randomBonusReelState(ctx)
		if err != nil {
			return
		}

		brs.ExpandingSymbol = expandingSymbol
		brs.FreeSpinsLeft = count - 1

		// bonus spins would be retriggered three times only
		if bonusGameTriggered == 3 {
			for ; count > 0; count-- {
				brs, err = s.randomBonusReelState(ctx)
				if err != nil {
					return
				}

				// pass table which triggers new spins
				if brs.BonusSpinsFromWilds() > 0 {
					count++
					continue
				}

				brs.RetriggeredBonusGame = bonusGameTriggered
				brs.ExpandingSymbol = expandingSymbol
				brs.FreeSpinsLeft = count - 1
				spins = append(spins, brs)
			}
			return
		}

		// we check if a bonus game exist and stop to spin if we already have three bonus games
		if brs.BonusSpinsFromWilds() > 0 {
			if bonusGameTriggered < 3 {
				bonusGameTriggered++

				// add any additional bonus spins from this spin
				count += brs.BonusSpinsFromWilds()
			}
		}

		brs.RetriggeredBonusGame = bonusGameTriggered

		// add them to our list
		spins = append(spins, brs)
	}

	return
}

func (s *SpinFactory) randomBonusReelState(ctx engine.Context) (brs BonusReelState, err error) {
	if ctx.Cheats != nil {
		c := Cheats{}
		if err := c.Eval(ctx.Cheats); err != nil {
			return brs, err
		}

		if c.AdditionalTriggerCount > 0 {
			c.AdditionalTriggerCount--
			for i := 0; i < consts.ReelCount; i++ {
				brs.Stops[i] = ReelStop(cheatTriggerBonusReelStops[i])
			}

			ctx.Cheats = c

			return
		}
	}

	for i := 0; i < consts.ReelCount; i++ {
		var stop uint64
		stop, err = s.rand.Rand(consts.ReelSize)
		if err != nil {
			return
		}

		brs.Stops[i] = ReelStop(stop)
	}

	return
}

func (rw ReelWindow) CountOf(sym ReelSymbol) (count int) {

	// walk the window
	for _, column := range rw {
		for _, symbol := range column {
			if sym == symbol {
				count++
			}
		}
	}

	return
}

func (rs ReelState) BonusSpinsFromWilds() (retval SpinCount) {
	return rs.Window().BonusSpinsFromWilds()
}

func (brs *BonusReelState) Window() (window ReelWindow, expandedSymbolTrigerred bool, expandedSymbolAmount uint) {
	var expandedSymbolPosition SymbolPosition

	amountForTrigger := BasePaytable.AmountForExpandTrigger(brs.ExpandingSymbol)
	repeatingOnReels := make(map[ReelID]uint)

	// accumulate our effective symbols for the window
	for reel := ReelID(0); reel < consts.ReelCount; reel++ {
		for row := RowID(0); row < consts.WindowHeight; row++ {
			window[reel][row] = brs.EffectiveSymbol(reel, row, brs.Stops[reel])

			// we get the expanded symbol positions at the window
			if window[reel][row] == brs.ExpandingSymbol {
				// here we accumulate the repeating of the expanded symbol on every reel
				_, ok := repeatingOnReels[reel]
				if ok {
					repeatingOnReels[reel] += 1
				} else {
					repeatingOnReels[reel] = 1
				}

				// here we remind the expanded symbol position
				expandedSymbolPosition.ReelID = reel
				expandedSymbolPosition.RowID = row
				brs.ExpandingSymbolPositions = append(brs.ExpandingSymbolPositions, expandedSymbolPosition)
			}
		}
	}

	// if we have expanding symbols win combination, we change a window by replacing all reel symbols
	// that consist an expanded symbol with last one
	if uint(len(repeatingOnReels)) >= amountForTrigger {
		brs.ExpandingActivated = true
		expandedSymbolTrigerred = true
		expandedSymbolAmount = uint(len(repeatingOnReels))
	}

	return
}

func (t Paytable) AmountForExpandTrigger(symbol ReelSymbol) (amount uint) {
	amount = 3
	for sym, payTableLine := range t {
		if symbol == sym {
			for s := range payTableLine {
				if s < amount {
					amount = s
				}
			}
		}
	}

	return
}

func (pays Payouts) TotalWins() (total int64) {
	for _, p := range pays.SpinPayouts {
		total += p.Amount
	}

	total += pays.WildWins.Amount

	// add payout for expanded symbol (if any)
	if len(pays.ExpandedSymbolPayouts) > 0 {
		for _, esp := range pays.ExpandedSymbolPayouts {
			total += esp.Amount
		}
	}

	return
}

func (m Multiplier) ApplyTo(value int64) int64 {
	return int64(m) * value
}

func (rw ReelWindow) payoutForWilds(totalWager int64) (payout WildWins) {

	var counter uint
	for reelID, reel := range rw {
		for rowID, symbol := range reel {
			if symbol == WildSymbol {
				counter++
				payout.Positions = append(payout.Positions, SymbolPosition{
					ReelID: ReelID(reelID),
					RowID:  RowID(rowID),
				})
			}
		}
	}

	if counter < 3 {
		return
	}

	multiplier := BasePaytable[WildSymbol][counter]
	payout.Amount = int64(multiplier) * totalWager / consts.PayLineCount
	payout.Count = counter

	return
}

func (rw ReelWindow) ResultForExpandingSymbols(expandingSymbol ReelSymbol, totalWager int64, amount uint) []Payout {
	var payouts []Payout
	for i := 0; i < consts.PayLineCount; i++ {
		payouts = append(payouts, Payout{
			Symbol:     expandingSymbol,
			Amount:     int64(BasePaytable[expandingSymbol][amount]) * totalWager / consts.PayLineCount,
			Count:      amount,
			PaylineId:  PaylineID(i),
			Multiplier: BasePaytable[expandingSymbol][amount],
		})
	}

	return payouts
}

func (t Paytable) Result(sym ReelSymbol, consecutive uint) Multiplier {
	return t[sym][consecutive]
}
