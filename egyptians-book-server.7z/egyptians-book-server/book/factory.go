package book

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/validator"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"encoding/json"
	"fmt"
	"github.com/sarulabs/di"
)

func GameBoot(ctn di.Container, config *engine.Config) *engine.Bootstrap {
	switch config.RTP {
	case "94":
		BaseReels = BaseReels94
	case "96":
		BaseReels = BaseReels96
	default:
		panic(fmt.Sprintf("can't specify RTP: %v", config.RTP))
	}

	rand := ctn.Get(constants.RNGName).(rng.Client)
	validatorEngine := ctn.Get(constants.ValidatorName).(*validator.Validator)
	factory := NewSpinFactory(rand, validatorEngine)

	return &engine.Bootstrap{
		SpinFactory: factory,

		HTTPTransport:      true,
		WebsocketTransport: true,

		FreeSpinsFeature:    true,
		GambleAnyWinFeature: true,

		GambleAnyWinMaxTimes: 4,
		GambleAnyWinMaxWager: 125 * 1000 * 1000,
		GameMaxWager:         50 * 1000, // 50 $

		HistoryHandlingType: engine.SequentialRestoring,

		EngineInfo: EngineInfo{BaseReels: BaseReels},
	}
}

// returns the number of bonus spins triggered by wilds in this window
func (rw ReelWindow) BonusSpinsFromWilds() SpinCount {
	return WildsBonusSpinCounts[rw.CountOf(WildSymbol)]
}

func NewSpinFactory(rand rng.Client, validateEngine *validator.Validator) *SpinFactory {
	factory := &SpinFactory{rand: rand, validateEngine: validateEngine}

	return factory
}

type SpinFactory struct {
	rand           rng.Client
	validateEngine *validator.Validator
}

func (s *SpinFactory) GambleAnyWin(ctx engine.Context, parameters interface{}) (engine.Spin, error) {
	if ctx.LastSpin.BaseAward() == 0 {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin, ok := ctx.LastSpin.(*Spin)
	if !ok {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin = typedSpin.deepCopy()

	payload, err := parseGambleParams(parameters)

	if payload.Color != GambleRed && payload.Color != GambleBlack {
		return nil, errs.ErrBadDataGiven
	}

	if err != nil {
		return nil, err
	}

	res, err := s.rand.Rand(2)
	if err != nil {
		return nil, err
	}

	award := typedSpin.BaseAward() + typedSpin.BonusAward()
	g := Gamble{ExpectColor: payload.Color, WagerVal: award}

	c := Cheats{}
	if ctx.Cheats != nil {
		if err := c.Eval(ctx.Cheats); err != nil {
			return nil, err
		}
	}

	if c.GambleColor == GambleRed || c.GambleColor == GambleBlack {
		g.RealColor = c.GambleColor
	} else if res == 1 {
		g.RealColor = GambleRed
	} else {
		g.RealColor = GambleBlack
	}

	g.compute()

	typedSpin.Gambles = append(typedSpin.Gambles, g)

	return typedSpin, nil
}

func (s *SpinFactory) KeepGenerate(ctx engine.Context, parameters interface{}) (engine.Spin, bool, error) {
	return ctx.LastSpin, false, nil
}

type WagerParameters struct {
	IsAutospin  bool ` json:"is_autospin"`
	IsTurbospin bool ` json:"is_turbospin"`
}

type EngineInfo struct {
	BaseReels ReelSet `json:"base_reels"`
}

func (s *SpinFactory) Generate(ctx engine.Context, wager int64, parameters interface{}) (engine.Spin, engine.RestoringIndexes, error) {
	var spin = &Spin{WagerVal: wager}

	params, err := s.extractParameters(parameters)
	if err != nil {
		return nil, nil, err
	}

	// execute the spin
	err = s.executeSpin(ctx, wager, params.IsAutospin, spin)
	if err != nil {
		return nil, nil, err
	}

	err = s.calcWin(spin)
	if err != nil {
		panic(err)
	}

	return spin, &RestoringIndexes{}, err
}

func (s *SpinFactory) UnmarshalJSONSpin(bytes []byte) (engine.Spin, error) {
	spin := Spin{}
	err := json.Unmarshal(bytes, &spin)

	return &spin, err
}

func (s *SpinFactory) UnmarshalJSONRestoringIndexes(bytes []byte) (engine.RestoringIndexes, error) {
	restoringIndexes := RestoringIndexes{}
	err := json.Unmarshal(bytes, &restoringIndexes)

	return &restoringIndexes, err
}

func (s *SpinFactory) extractParameters(parameters any) (*WagerParameters, error) {
	bytes, err := json.Marshal(parameters)
	if err != nil {
		return nil, err
	}

	generationParameters := WagerParameters{}
	err = json.Unmarshal(bytes, &generationParameters)

	if err != nil {
		return nil, err
	}

	err = s.validateEngine.ValidateStruct(generationParameters)

	if err != nil {
		return nil, errs.NewInternalValidationError(err)
	}

	return &generationParameters, nil
}
