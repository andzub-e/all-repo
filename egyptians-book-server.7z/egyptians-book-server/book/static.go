package book

import "books/consts"

var (
	cheatTriggerBonusReelStops = []int{9, 41, 0, 0, 127}
)

var PayLines = [consts.PayLineCount]AbsolutePayline{
	{0, 1, 2, 3, 4},      // 0
	{5, 6, 7, 8, 9},      // 1
	{10, 11, 12, 13, 14}, // 2

	{0, 6, 12, 8, 4},  // 3
	{10, 6, 2, 8, 14}, // 4

	{5, 1, 2, 3, 9},    // 5
	{5, 11, 12, 13, 9}, // 6

	{0, 1, 7, 13, 14}, // 7
	{10, 11, 7, 3, 4}, // 8
	{5, 11, 7, 3, 9},  // 9
}

var BaseReels ReelSet
