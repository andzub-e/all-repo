package validator

import (
	"github.com/go-playground/validator/v10"
	"time"
)

const (
	CustomDateTimeRule = "custom_datetime"
)

const TimeLayout = "2006-01-02 15:04:05"

func IsCustomDateTime(fl validator.FieldLevel) bool {
	if fl.Field().String() == "" {
		return true
	}

	if _, err := time.Parse(TimeLayout, fl.Field().String()); err != nil {
		return false
	}

	return true
}
