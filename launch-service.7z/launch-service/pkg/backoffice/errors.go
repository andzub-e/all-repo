package backoffice

import (
	"errors"
)

var (
	ErrCanNotRemoveOrganization    = errors.New("can not remove organization")
	ErrOrganizationIsNotIntegrator = errors.New("selected organization is not integrator")
	ErrDoesNotHavePermission       = errors.New("does not have permissions")

	ErrOrganizationNameMustBeUnique = errors.New("role slug must be unique")
	ErrOrganizationInUse            = errors.New("cannot delete assigned organization")
	ErrOrganizationNotFound         = errors.New("organization not found")
	ErrOrganizationAlreadyAssigned  = errors.New("this organization is already assigned to the user")

	ErrAccountDoesNotExists = errors.New("account does not exists")
	ErrAccountAlreadyExists = errors.New("account with provided credentials already exists")

	ErrPermissionNotFound = errors.New("permission not found")

	ErrRoleSlugMustBeUnique = errors.New("role slug must be unique")
	ErrRoleInUse            = errors.New("cannot delete assigned role")
	ErrRoleAlreadyAssigned  = errors.New("this role is already assigned to the user")
	ErrRoleNotFound         = errors.New("role not found")

	ErrSessionNotFound = errors.New("session not found")

	ErrSpinDoesNotExists = errors.New("spin does not exists")
	ErrNotAuthorized     = errors.New("unauthorized")

	ErrInternal = errors.New("internal error")
)
