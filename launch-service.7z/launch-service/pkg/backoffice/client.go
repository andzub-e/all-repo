package backoffice

import (
	"context"
	"crypto/tls"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials"
	"google.golang.org/grpc/credentials/insecure"
	"google.golang.org/grpc/status"
	"launch-service/pkg/errors"
	"net/http"
)

type Client interface {
	HasAccess(ctx context.Context, apiKey, game string) (*HasAccessOut, error)
	GameList(ctx context.Context, apiKey string) (*GameListOut, error)
	Provider(ctx context.Context, game string) (*GetProviderOut, error)
}

type client struct {
	api BackofficeClient
}

func NewClient(cfg *Config) (Client, error) {
	var (
		conn *grpc.ClientConn
		err  error
	)

	if cfg.IsSecure {
		config := &tls.Config{
			InsecureSkipVerify: false,
		}

		conn, err = grpc.Dial(cfg.getAddress(), grpc.WithTransportCredentials(credentials.NewTLS(config)))
	} else {
		conn, err = grpc.Dial(cfg.getAddress(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	}

	if err != nil {
		return nil, err
	}

	return &client{api: NewBackofficeClient(conn)}, nil
}

func (c *client) HasAccess(ctx context.Context, apiKey, game string) (*HasAccessOut, error) {
	resp, err := c.api.HasAccess(ctx, &HasAccessIn{
		ApiKey: apiKey,
		Game:   game,
	})

	if err != nil {
		return nil, c.handleError(err)
	}

	return resp, nil
}

func (c *client) GameList(ctx context.Context, apiKey string) (*GameListOut, error) {
	resp, err := c.api.GameList(ctx, &GameListIn{
		ApiKey: apiKey,
	})

	if err != nil {
		return nil, c.handleError(err)
	}

	return resp, nil
}

func (c *client) Provider(ctx context.Context, game string) (*GetProviderOut, error) {
	resp, err := c.api.GetProvider(ctx, &GetProviderIn{
		GameName: game,
	})

	if err != nil {
		return nil, c.handleError(err)
	}

	return resp, nil
}

func (c *client) handleError(err error) error {
	switch status.Code(err) {
	case codes.Unauthenticated:
		return errors.NewError(http.StatusUnauthorized, 100000, ErrNotAuthorized, "")
	case codes.PermissionDenied:
		return errors.NewError(http.StatusForbidden, 100000, ErrDoesNotHavePermission, "")
	default:
		return errors.NewError(http.StatusInternalServerError, 100000, ErrInternal, "")
	}
}
