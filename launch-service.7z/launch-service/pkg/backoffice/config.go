package backoffice

type Config struct {
	Host     string
	Port     string
	IsSecure bool
}

func (c *Config) getAddress() string {
	return c.Host + ":" + c.Port
}
