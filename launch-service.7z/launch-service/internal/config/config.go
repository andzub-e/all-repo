package config

import (
	"github.com/spf13/viper"
	"launch-service/internal/http"
	"launch-service/internal/services"
	"launch-service/pkg/backoffice"
	"launch-service/pkg/tracer"
	"sync"
)

var config *Config
var once sync.Once

type Config struct {
	ServerConfig     *http.Config
	LaunchConfig     *services.LaunchConfig
	BFConfig         *services.BFConfig
	LemonConfig      *services.Account
	BackofficeConfig *backoffice.Config
	TracerConfig     *tracer.Config
}

func New() (*Config, error) {
	once.Do(func() {
		config = &Config{}

		viper.AddConfigPath(".")
		viper.SetConfigName("config")

		if err := viper.ReadInConfig(); err != nil {
			panic(err)
		}

		serverConfig := viper.Sub("server")
		launchConfig := viper.Sub("launch")
		lemonConfig := viper.Sub("lemon")
		bfConfig := viper.Sub("bf")
		tracerConfig := viper.Sub("tracer")
		backofficeConfig := viper.Sub("backoffice")

		if err := serverConfig.Unmarshal(&config.ServerConfig); err != nil {
			panic(err)
		}

		if err := launchConfig.Unmarshal(&config.LaunchConfig); err != nil {
			panic(err)
		}

		if err := lemonConfig.Unmarshal(&config.LemonConfig); err != nil {
			panic(err)
		}

		if err := bfConfig.Unmarshal(&config.BFConfig); err != nil {
			panic(err)
		}

		if err := tracerConfig.Unmarshal(&config.TracerConfig); err != nil {
			return
		}

		if err := backofficeConfig.Unmarshal(&config.BackofficeConfig); err != nil {
			panic(err)
		}
	})

	return config, nil
}
