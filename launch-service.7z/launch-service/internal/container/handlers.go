package container

import (
	"github.com/sarulabs/di"
	"launch-service/internal/constants"
	"launch-service/internal/http/handlers"
	"launch-service/internal/services"
)

func BuildHandlers() []di.Def {
	return []di.Def{
		{
			Name: constants.LemonHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				lemonService := ctn.Get(constants.LemonServiceName).(*services.LemonService)

				return handlers.NewLemonHandler(lemonService), nil
			},
		},
		{
			Name: constants.BFHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				bfService := ctn.Get(constants.BFServiceName).(*services.BFService)

				return handlers.NewBFHandler(bfService), nil
			},
		},
		{
			Name: constants.InfinGameHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				launchService := ctn.Get(constants.LaunchServiceName).(*services.LaunchService)

				return handlers.NewInfinGameHandler(launchService), nil
			},
		},
		{
			Name: constants.DirectGamesHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				launchService := ctn.Get(constants.LaunchServiceName).(*services.LaunchService)

				return handlers.NewDirectHandler(launchService), nil
			},
		},
		{
			Name: constants.MetaHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				return handlers.NewMetaHandler(), nil
			},
		},
		{
			Name: constants.UPlatformHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				launchService := ctn.Get(constants.LaunchServiceName).(*services.LaunchService)

				return handlers.NewUPlatformHandler(launchService), nil
			},
		},
	}
}
