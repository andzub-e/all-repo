package container

import (
	"context"
	"fmt"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
	"launch-service/internal/config"
	"launch-service/internal/constants"
	"launch-service/internal/http"
	"launch-service/pkg/backoffice"
	"launch-service/pkg/tracer"
	"launch-service/pkg/validator"
	"sync"
)

var container di.Container
var once sync.Once

func Build(ctx context.Context, wg *sync.WaitGroup) di.Container {
	once.Do(func() {
		builder, _ := di.NewBuilder()
		defs := []di.Def{
			{
				Name: constants.LoggerName,
				Build: func(ctn di.Container) (interface{}, error) {
					logger, err := zap.NewDevelopment()

					if err != nil {
						return nil, fmt.Errorf("can't initialize zap logger: %v", err)
					}

					zap.ReplaceGlobals(logger)
					return logger, nil
				},
			},
			{
				Name: constants.ConfigName,
				Build: func(ctn di.Container) (interface{}, error) {
					return config.New()
				},
			},
			{
				Name: constants.ServerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)
					var privateHandlers []http.Handler
					var publicHandlers = []http.Handler{
						ctn.Get(constants.LemonHandlerName).(http.Handler),
						ctn.Get(constants.BFHandlerName).(http.Handler),
						ctn.Get(constants.InfinGameHandlerName).(http.Handler),
						ctn.Get(constants.DirectGamesHandlerName).(http.Handler),
						ctn.Get(constants.MetaHandlerName).(http.Handler),
						ctn.Get(constants.UPlatformHandlerName).(http.Handler),
					}
					tr := ctn.Get(constants.TracerName).(*tracer.JaegerTracer)

					return http.New(ctx, wg, cfg.ServerConfig, tr, publicHandlers, privateHandlers), nil
				},
			},
			{
				Name: constants.ValidatorName,
				Build: func(ctn di.Container) (interface{}, error) {
					return validator.New()
				},
			},
			{
				Name: constants.BackofficeClientName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return backoffice.NewClient(cfg.BackofficeConfig)
				},
			},
			{
				Name: constants.TracerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return tracer.NewTracer(cfg.TracerConfig)
				},
			},
		}

		defs = append(defs, BuildServices()...)
		defs = append(defs, BuildRepositories()...)
		defs = append(defs, BuildHandlers()...)

		if err := builder.Add(defs...); err != nil {
			panic(err)
		}

		container = builder.Build()
	})

	return container
}
