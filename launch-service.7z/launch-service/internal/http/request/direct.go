package request

type BaseDirectRequest struct {
	ApiKey string `json:"api_key" validate:"required"`
}

type DirectLaunchGameRequest struct {
	BaseDirectRequest
	Game      string  `json:"game" validate:"required"`
	UserID    string  `json:"user_id" validate:"required"`
	Currency  string  `json:"currency" validate:"required"`
	Language  string  `json:"language" validate:"required"`
	Platform  *string `json:"platform"`
	ReturnUrl *string `json:"return_url"`
}
