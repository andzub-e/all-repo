package request

type UPlatformDemoRequest struct {
	GameID string `json:"gameId" validate:"required,max=255"`
	Lang   string `json:"lang" validate:"required,max=2"`
}

type UPlatformLaunchRequest struct {
	GameID      string `json:"gameId" validate:"required,max=255"`
	UserID      string `json:"userId" validate:"required,max=255"`
	Currency    string `json:"currency" validate:"required,max=3"`
	Lang        string `json:"lang" validate:"required,max=2"`
	SessionUUID string `json:"sessionUuid" validate:"required,max=36"`
}
