package handlers

import (
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"launch-service/internal/http/request"
	"launch-service/internal/http/response"
	"launch-service/internal/services"
	"launch-service/pkg/validator"
	"net/http"
	"strings"
)

type uPlatformHandler struct {
	launchService *services.LaunchService
}

func NewUPlatformHandler(launchService *services.LaunchService) *uPlatformHandler {
	return &uPlatformHandler{
		launchService: launchService,
	}
}

func (h *uPlatformHandler) Register(router *gin.RouterGroup) {
	group := router.Group("uplatform")
	group.POST("/demo", h.demo)
	group.POST("/launch", h.launch)
}

// @Summary Get demo url.
// @Tags UPlatform
// @Consume application/json
// @Description Check service health.
// @Accept  json
// @Produce  json
// @Param request body request.UPlatformDemoRequest true "Demo request"
// @Success 200  {object} response.UPlatformSuccessResponse
// @Failure 422 {object} response.UPlatformErrorResponse
// @Router /demo [post].
func (h *uPlatformHandler) demo(ctx *gin.Context) {
	req := request.UPlatformDemoRequest{}
	if err := ctx.ShouldBind(&req); err != nil {

		data := response.UPlatformErrorResponse{
			Message: handleValidationError(err),
		}

		response.Code(ctx, http.StatusUnprocessableEntity, data, nil)

		return
	}

	zap.S().Infof("%+v", req)

	link := h.launchService.UPlatform(req.GameID, req.Lang, "", "", "", true)

	zap.S().Info(link)

	response.OK(ctx, response.UPlatformSuccessResponse{GameUrl: link}, nil)
}

// @Summary Get launch url.
// @Tags UPlatform
// @Consume application/json
// @Description Check service health.
// @Accept  json
// @Produce  json
// @Param request body request.UPlatformLaunchRequest true "Launch request"
// @Success 200  {object} response.UPlatformSuccessResponse
// @Failure 422 {object} response.UPlatformErrorResponse
// @Router /launch [post].
func (h *uPlatformHandler) launch(ctx *gin.Context) {
	req := request.UPlatformLaunchRequest{}
	if err := ctx.ShouldBind(&req); err != nil {

		data := response.UPlatformErrorResponse{
			Message: handleValidationError(err),
		}

		response.Code(ctx, http.StatusUnprocessableEntity, data, nil)

		return
	}

	zap.S().Infof("%+v", req)

	link := h.launchService.UPlatform(req.GameID, req.Lang, req.UserID, req.Currency, req.SessionUUID, false)

	zap.S().Info(link)

	response.OK(ctx, response.UPlatformSuccessResponse{GameUrl: link}, nil)
}

func handleValidationError(err error) string {
	data := make([]string, 0)

	for _, taggedError := range validator.CheckValidationErrors(err) {
		e := taggedError.Err
		data = append(data, e.Error())
	}

	return strings.Join(data, ", ")
}
