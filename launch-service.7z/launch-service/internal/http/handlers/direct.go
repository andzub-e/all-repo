package handlers

import (
	"github.com/gin-gonic/gin"
	"launch-service/internal/http/request"
	"launch-service/internal/http/response"
	"launch-service/internal/services"
	"launch-service/pkg/errors"
)

type directHandler struct {
	launchService *services.LaunchService
}

func NewDirectHandler(launchService *services.LaunchService) *directHandler {
	return &directHandler{launchService: launchService}
}

func (h *directHandler) Register(router *gin.RouterGroup) {
	games := router.Group("games")
	games.POST("launch", h.launch)
	games.POST("list", h.discoverGames)
}

func (h *directHandler) launch(ctx *gin.Context) {
	req := request.DirectLaunchGameRequest{}
	if err := ctx.ShouldBind(&req); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	url, err := h.launchService.Generate(ctx, req.ApiKey, req.Game, req.UserID, req.Currency, req.Language, req.Platform, req.ReturnUrl)
	if err != nil {
		if e, ok := err.(errors.Error); ok {
			response.Code(ctx, e.StatusCode, e.Error(), nil)

			return
		}

		response.ServerError(ctx, err, nil)

		return
	}

	response.OK(ctx, response.DirectLaunchGameResponse{URL: url}, nil)
}

func (h *directHandler) discoverGames(ctx *gin.Context) {
	req := request.BaseDirectRequest{}
	if err := ctx.ShouldBind(&req); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	games, err := h.launchService.Games(ctx, req.ApiKey)
	if err != nil {
		if e, ok := err.(errors.Error); ok {
			response.Code(ctx, e.StatusCode, e.Error(), nil)

			return
		}

		response.ServerError(ctx, err, nil)

		return
	}

	response.OK(ctx, games, nil)
}
