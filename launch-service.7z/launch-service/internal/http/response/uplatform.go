package response

type UPlatformSuccessResponse struct {
	GameUrl string `json:"gameUrl"`
}

type UPlatformErrorResponse struct {
	Message string `json:"message"`
}
