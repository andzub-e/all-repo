package response

type DirectLaunchGameResponse struct {
	URL string `json:"url"`
}
