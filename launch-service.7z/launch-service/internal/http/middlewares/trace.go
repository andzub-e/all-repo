package middlewares

import (
	"github.com/gin-gonic/gin"
	"launch-service/pkg/tracer"
)

func Trace(tr *tracer.JaegerTracer) func(ctx *gin.Context) {
	return func(ctx *gin.Context) {
		trCtx, span := tr.Start(ctx.Request.Context(), "launch", ctx.Request.RequestURI,
			tracer.CtxWithTraceValue|tracer.CtxWithGRPCMetadata)

		ctx.Request = ctx.Request.WithContext(trCtx)

		ctx.Next()
		span.End()
	}
}
