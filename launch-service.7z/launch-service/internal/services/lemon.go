package services

import (
	"errors"
	"fmt"
	"github.com/google/uuid"
)

var ErrLemonUnauthorized = errors.New("wrong credentials")

type Account struct {
	Username string
	Password string
}

type LemonService struct {
	cfg          *LaunchConfig
	lemonAccount *Account
}

func NewLemonService(cfg *LaunchConfig, lemonAccount *Account) *LemonService {
	return &LemonService{cfg: cfg, lemonAccount: lemonAccount}
}

func (s *LemonService) LemonDemo(GameCode, CurrencyCode, LanguageCode, HomeURL string, account Account, platformType int) string {
	if platformType == 0 {
		platformType = 1
	}

	return fmt.Sprintf("%v%v/?token=%v&integrator=lemon&currency=%v&userlocale=%v&platform_type=%v&is_demo=true",
		s.cfg.BaseURL, GameCode, uuid.NewString(), CurrencyCode, LanguageCode, platformType)
}

func (s *LemonService) Lemon(GameCode, CurrencyCode, LanguageCode, HomeURL, PlayerID string, account Account, platformType int) (string, string, error) {
	if account.Username != s.lemonAccount.Username || account.Password != s.lemonAccount.Password {
		return "", "", ErrLemonUnauthorized
	}

	userID := uuid.NewString()

	if platformType == 0 {
		platformType = 1
	}

	return fmt.Sprintf("%v%v/?token=%v&integrator=lemon&currency=%v&userlocale=%v&user_id=%v&platform_type=%v",
		s.cfg.BaseURL, GameCode, userID, CurrencyCode, LanguageCode, PlayerID, platformType), userID, nil
}
