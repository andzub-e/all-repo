package services

import (
	"context"
	"fmt"
	"github.com/google/uuid"
	"github.com/samber/lo"
	"launch-service/internal/entities"
	"launch-service/pkg/backoffice"
)

type BFConfig struct {
	BFBaseURL string
	BaseURL   string
	Format    string
}

var integratorMap = map[string]string{
	"BFG": "61dac939-a3e6-4b67-91e1-a2e17671541b",
	"HB":  "85c42cda-9d6a-4ad6-bceb-b316b40d508c",
}

var tmpEjawAvailable = []string{
	"stonesofmagic",
	"asgardparty",
	"ego-draconis",
	"cyber-town",
	"plinko",
	"secrettotems",
	"preciousbugs",
}

type BFService struct {
	config *BFConfig
	client backoffice.Client
}

func NewBFService(config *BFConfig, client backoffice.Client) *BFService {
	return &BFService{config: config, client: client}
}

func (s *BFService) BF(ctx context.Context, gameId, gameMode, sessionToken, currency, language string) (link, version string, err error) {
	if sessionToken == "" {
		sessionToken = uuid.NewString()
	}

	res, err := s.client.Provider(ctx, gameId)
	if err != nil {
		return "", "", err
	}

	baseUrl := ""

	switch res.Provider {
	case "ejaw":
		baseUrl = s.config.BaseURL
	case "bf":
		baseUrl = s.config.BFBaseURL
	default:
		return "", "", fmt.Errorf("wrong provider: %v", res.Provider)
	}

	link = fmt.Sprintf("%v%v/?user_id=%v&integrator=bf&jurisdiction=UA&currency=%v&userlocale=%v",
		baseUrl, gameId, sessionToken, currency, language)

	if gameMode == "demo" {
		link += "&is_demo=true"
	}

	return link, "v1.0.0", nil
}

func (s *BFService) BFGames(ctx context.Context, provider string) ([]entities.BFGame, error) {
	apiKey, ok := integratorMap[provider]
	if !ok {
		return nil, fmt.Errorf("wrong provider: %v", provider)
	}

	res, err := s.client.GameList(ctx, apiKey)
	if err != nil {
		return nil, err
	}

	if provider == "HB" {
		res.Games = lo.Filter(res.Games, func(item string, index int) bool {
			return lo.Contains(tmpEjawAvailable, item)
		})
	}

	return lo.Map(res.Games, func(item string, index int) entities.BFGame {
		return entities.BFGame{Name: item, GameID: item}
	}), nil
}
