package entities

type BFGame struct {
	GameID string `json:"gameId"`
	Name   string `json:"name"`
}
