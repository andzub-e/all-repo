package stunninghot_test

import (
	"math"
	"stunning-hot-server/engine"
	"testing"
)

func TestGambleImmutability(t *testing.T) {
	spin, err := factory.GambleAnyWin(spinWithAward, gambleBody(engine.GambleRed))
	if err != nil {
		panic(err)
	}

	if spin.Award() == spinWithAward.Award() || spin.Wager() == spinWithAward.Wager() {
		t.Errorf("Gamble func are mutable: %v, %v", spin, spinWithoutAward)
	}
}

func TestGambleStat(t *testing.T) {
	win, lose := 0.0, 0.0
	for i := 0; i < 1000; i++ {
		spin, err := factory.GambleAnyWin(spinWithAward, gambleBody(engine.GambleRed))

		if err != nil {
			panic(err)
		}

		if spin.Award() > 0 {
			win++
		} else {
			lose++
		}
	}

	if math.Abs(win-lose) > 50 {
		t.Errorf("gamble is not equaly distibuted, win: %v, lose: %v", win, lose)
	}
}

func TestGambleWrongColor(t *testing.T) {
	_, err := factory.GambleAnyWin(spinWithAward, gambleBody("pink"))
	if err == nil {
		t.Errorf("No validation on wrong color")
	}
}

func TestGambleWrongSpin(t *testing.T) {
	_, err := factory.GambleAnyWin(spinWithoutAward, gambleBody(engine.GambleBlue))
	if err == nil {
		t.Errorf("No validation on wrong spin")
	}
}

func TestGambleInvariant(t *testing.T) {
	spin, err := factory.GambleAnyWin(spinWithAward, gambleBody(engine.GambleRed))
	if err != nil {
		panic(err)
	}

	if spin.Wager() != spinWithAward.Award() {
		t.Errorf("old award != new wager: %v != %v", spin.Wager(), spinWithAward.Award())
	}
}
