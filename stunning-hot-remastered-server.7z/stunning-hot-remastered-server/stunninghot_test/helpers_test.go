package stunninghot_test

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/container"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"context"
	"os"
	"stunning-hot-server/engine"
	"sync"
)

var (
	factory engine.SpinFactory
	wager   int64 = 1000

	spinWithAward    engine.Spin
	spinWithoutAward engine.Spin
)

func init() {
	ctn := container.Build(context.Background(),
		&sync.WaitGroup{}, "config.yml", "TEST", true, true)
	os.Chdir("..")
	factory = engine.GameBoot(ctn).SpinFactory

	for {
		spin, _, err := factory.Generate(wager, nil)
		if err != nil {
			panic(err)
		}

		if spin.Award() > 0 {
			spinWithAward = spin
		} else {
			spinWithoutAward = spin
		}

		if spinWithAward != nil && spinWithoutAward != nil {
			break
		}
	}
}

func gambleBody(color string) interface{} {
	return engine.GambleParams{Color: color}
}
