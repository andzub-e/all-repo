package stunninghot_test

import (
	"stunning-hot-server/engine"
	"testing"
)

var (
	PayLinesTestCases = 10000
)

func TestPayLines(t *testing.T) {
	payLineCounts := make([]int, len(engine.PayLines))
	for i := 0; i < PayLinesTestCases; i++ {
		spin, _, err := factory.Generate(wager, nil)
		if err != nil {
			panic(err)
		}

		typedSpin := spin.(*engine.SpinBase)

		for _, payLine := range typedSpin.PayLinesToShow {
			if payLine.Symbol != engine.ScatterSymbol {
				payLineCounts[payLine.PayLineIndex]++
			}

		}
	}

	for i, payLineCount := range payLineCounts {
		if payLineCount == 0 {
			t.Errorf("pay line %v, is never happened", engine.PayLines[i])
		}
	}
}
