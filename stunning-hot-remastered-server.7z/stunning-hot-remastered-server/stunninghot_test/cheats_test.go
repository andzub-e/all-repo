package stunninghot_test

import (
	"stunning-hot-server/engine"
	"testing"
)

func TestGenerateWithCheats(t *testing.T) {
	stops := []int{1, 1, 1, 1, 1}
	f := factory.WithCheat(engine.Cheats{Stops: stops})

	spin, _, err := f.Generate(wager, nil)
	if err != nil {
		panic(err)
	}

	typedSpin := spin.(*engine.SpinBase)

	for i := range typedSpin.Stops {
		if typedSpin.Stops[i] != stops[i] {
			t.Errorf("cheat stops are wrong %v, %v.", stops, typedSpin.Stops)

			break
		}
	}
}

func TestGenerateCheatsWrongStopsSize(t *testing.T) {
	stops := []int{1, 1, 1, 1}
	f := factory.WithCheat(engine.Cheats{Stops: stops})
	_, _, err := f.Generate(wager, nil)
	if err == nil {
		t.Errorf("No stops size validation")
	}
}

func TestGenerateCheatsWrongStopsValue(t *testing.T) {
	stops := []int{1, 1, 1, 1, 1000}
	f := factory.WithCheat(engine.Cheats{Stops: stops})
	_, _, err := f.Generate(wager, nil)
	if err == nil {
		t.Errorf("No stops value validation")
	}
}
