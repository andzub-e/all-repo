package stunninghot_test

import (
	"math"
	"stunning-hot-server/engine"
	"testing"
)

var (
	UniformityTestCases = 10000
)

func TestReelsUniformity(t *testing.T) {
	buf := make([]map[int]int, 5)
	for i := 0; i < UniformityTestCases; i++ {
		spin, _, err := factory.Generate(wager, nil)
		if err != nil {
			panic(err)
		}

		typedSpin := spin.(*engine.SpinBase)

		for j := 0; j < len(typedSpin.Stops); j++ {
			if buf[j] == nil {
				buf[j] = map[int]int{}
			}

			buf[j][typedSpin.Stops[j]]++
		}
	}

	for i := 0; i < len(buf); i++ {
		min, max := math.MaxInt, math.MinInt
		for _, val := range buf[i] {
			if val < min {
				min = val
			}

			if val > max {
				max = val
			}
		}

		if max-min > UniformityTestCases/(len(buf[i])*3) {
			t.Errorf("reels distributed not uniformity")
		}
	}
}
