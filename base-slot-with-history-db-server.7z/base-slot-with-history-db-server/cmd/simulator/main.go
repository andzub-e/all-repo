package main

import (
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/buildvar"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/internal/roulette"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/app"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/services"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/utils"
	"fmt"
	"os"
	"path/filepath"
	"time"
)

func main() {
	now := time.Now()

	application, err := app.NewApp("config.yml", buildvar.Tag, buildvar.Debug, buildvar.IsCheatsAvailable, roulette.GameBoot)
	if err != nil {
		panic(err)
	}

	simulator := application.GetSimulatorService()

	result, err := simulator.WithProgressListener(func(percent float64) {
		fmt.Printf("Processing: %2.0f%%\n", percent*100)
	}).
		WithWagerParameters(nil).
		Simulate("roulette", 30000, 1000)

	reportPages := []utils.Page{
		{
			Name:  "Report",
			Table: utils.Transpose(utils.ExtractTable([]*services.SimulationView{result.View()}, "xlsx")),
		}}

	saveReport(reportPages)

	fmt.Printf("The program ran for %s\n", time.Since(now))
}

func saveReport(reportPages []utils.Page) {
	excel, err := utils.ExportMultiPageXLSX(reportPages)
	if err != nil {
		fmt.Printf("simulate: %v\n", err)
	}

	abs, err := filepath.Abs("simresults")
	if err != nil {
		panic(err)
	}

	file, err := os.Create(filepath.Join(abs, fmt.Sprintf("report-%v.xlsx", time.Now().UnixNano())))
	if err != nil {
		fmt.Printf("simulate: %v\n", err)
	}

	if err = excel.Write(file); err != nil {
		fmt.Printf("simulate: %v\n", err)
	}
}
