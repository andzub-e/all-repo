package main

import (
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/internal/roulette"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/app"
)

func main() {
	// application, err := app.NewApp("config.yml", buildvar.Tag, buildvar.Debug, buildvar.IsCheatsAvailable, roulette.GameBoot)
	application, err := app.New("config.yml", roulette.GameBoot)

	if err != nil {
		panic(err)
	}

	if err := application.Run(); err != nil {
		panic(err)
	}
}
