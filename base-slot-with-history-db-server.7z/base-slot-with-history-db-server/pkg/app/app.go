package app

import (
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/config"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/container"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/errs"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/services"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/transport/http"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/validator"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/utils"
	"context"
	"github.com/gin-gonic/gin/binding"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
	"sync"
	"time"
)

type App struct {
	ctn di.Container
	ctx context.Context
	wg  *sync.WaitGroup
}

type GameBootstrap func(ctn di.Container, config *engine.Config) *engine.Bootstrap

func New(configPath string, fn GameBootstrap) (*App, error) {
	app := &App{
		ctx: context.Background(),
		wg:  &sync.WaitGroup{},
	}

	app.ctn = container.NewBuild(app.ctx, app.wg, configPath)

	logger := app.ctn.Get(constants.LoggerName).(*zap.Logger)
	logger.Info("Building application...")

	cfg := app.ctn.Get(constants.ConfigName).(*config.Config)

	var boot = fn(app.ctn, cfg.EngineConfig)
	if boot.HistoryHandlingType != engine.SequentialRestoring && boot.GambleAnyWinFeature {
		return nil, errs.ErrInitImpossibleBootConfig
	}

	engine.PutInContainer(boot)

	return app, nil
}

// NewApp DEPRECATED use New
func NewApp(configPath string, buildTag string, isDebug, isCheatsAvailable bool, fn GameBootstrap) (*App, error) {
	app := &App{
		ctx: context.Background(),
		wg:  &sync.WaitGroup{},
	}

	app.ctn = container.Build(app.ctx, app.wg, configPath, buildTag, isDebug, isCheatsAvailable)

	logger := app.ctn.Get(constants.LoggerName).(*zap.Logger)
	logger.Info("Building application...")

	cfg := app.ctn.Get(constants.ConfigName).(*config.Config)

	var boot = fn(app.ctn, cfg.EngineConfig)
	if boot.HistoryHandlingType != engine.SequentialRestoring && boot.GambleAnyWinFeature {
		return nil, errs.ErrInitImpossibleBootConfig
	}

	engine.PutInContainer(boot)

	return app, nil
}

func (app *App) GetSimulatorService() *services.SimulatorService {
	return app.ctn.Get(constants.SimulatorServiceName).(*services.SimulatorService)
}

func (app *App) Ctn() di.Container {
	return app.ctn
}

func (app *App) Run() error {
	now := time.Now()

	logger := app.ctn.Get(constants.LoggerName).(*zap.Logger)
	logger.Info("Building application...")

	server := app.ctn.Get(constants.ServerName).(*http.Server)
	binding.Validator = app.ctn.Get(constants.ValidatorName).(*validator.Validator)

	go server.Run()

	zap.S().Infof("Up and running (%s)", time.Since(now))
	zap.S().Infof("Got %s signal. Shutting down...", <-utils.WaitTermSignal())

	if err := server.Shutdown(context.Background()); err != nil {
		zap.S().Errorf("Error stopping server: %s", err)
	}

	app.wg.Wait()
	zap.S().Info("Service stopped.")

	return nil
}
