package engine

import "context"

type Context struct {
	context.Context
	Cheats   interface{}
	LastSpin Spin
	RTP      *int64
}

type SpinFactory interface {
	/*
	*	Generate method serves the purpose of generating a single request for a spin
	*   This method can modify the wager that passes into it
	*	For example: the game presents a possibility to buy a bonus, but the price for this bonus can be different
	* 	for each game, so we can modify the wager in this method depending on the game rules.
	 */
	Generate(ctx Context, wager int64, parameters interface{}) (Spin, RestoringIndexes, error)

	GambleAnyWin(ctx Context, parameters interface{}) (Spin, error)
	/*
	*	KeepGenerate method serves the purpose of generating multiple requests for spins
	*   For example: in the game user has won a bonus game and must decide which type of bonus he wishes to play
	* 	In DB it will be stored as the same spin overlord will receive transaction: {wager = 0; award = newAward - oldAward}
	*   Spin - new spin, you may mutate existing spin or create another one, anyway base slot will use DeepCopy() of spin.
	* 	bool - false if according to the game rules spin generation con not be continued.
	*  	error - for technical error like serialization, rng etc.
	 */
	KeepGenerate(ctx Context, parameters interface{}) (Spin, bool, error)

	UnmarshalJSONSpin(bytes []byte) (Spin, error)
	UnmarshalJSONRestoringIndexes(bytes []byte) (RestoringIndexes, error)
}

type Generate func(wager int64, parameters interface{}) (Spin, RestoringIndexes, error)

type Spin interface {
	BaseAward() int64
	BonusAward() int64
	/*
	*	GambleAward method that returns gamble award if in game there is not wager must return 0
	 */
	GambleAward() int64
	Wager() int64

	DeepCopy() Spin

	BonusTriggered() bool
	GambleQuantity() int
	CanGamble(restoringIndexes RestoringIndexes) bool // only logical issues for example: no gamble in bonus game or gamble is collected
}

type RestoringIndexes interface {
	IsShown(spin Spin) bool
	Update(payload interface{}) error
}

func TotalAwardWithGambling(spin Spin) int64 {
	award := spin.GambleAward()

	if award == 0 && spin.GambleQuantity() == 0 {
		award = spin.BaseAward() + spin.BonusAward()
	}

	return award
}

func TotalAward(spin Spin) int64 {
	return spin.BaseAward() + spin.BonusAward()
}
