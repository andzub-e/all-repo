package constants

type Config struct {
	AvailableGames []string
}
