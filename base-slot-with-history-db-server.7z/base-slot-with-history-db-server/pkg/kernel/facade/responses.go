package facade

import (
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/entities"
)

type GetFreeSpinsResponse struct {
	FreeSpins []*entities.FreeSpin `json:"freespins"`
}
