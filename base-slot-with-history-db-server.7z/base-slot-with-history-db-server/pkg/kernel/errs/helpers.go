package errs

import (
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/history"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/overlord"
)

var translateOverlordMap = map[error]error{
	overlord.ErrMarshaling:                ErrBadDataGiven,
	overlord.ErrBalanceTooLow:             ErrNotEnoughMoney,
	overlord.ErrWrongSessionToken:         ErrWrongSessionToken,
	overlord.ErrWrongFreeSpinID:           ErrWrongFreeSpinID,
	overlord.ErrSessionTokenExpired:       ErrSessionTokenExpired,
	overlord.ErrUserHasDifferentCurrency:  ErrUserHasDifferentCurrency,
	overlord.ErrUserIsBlocked:             ErrUserIsBlocked,
	overlord.ErrIntegratorCriticalFailure: ErrIntegratorCriticalFailure,
}

var translateHistoryMap = map[error]error{
	history.ErrSpinNotFound: ErrHistoryRecordNotFound,
}

func TranslateOverlordErr(err error) error {
	validationErr, ok := err.(overlord.ValidationError)
	if ok {
		return InternalValidationError{Err: validationErr}
	}

	res, ok := translateOverlordMap[err]
	if !ok {
		return err
	}

	return res
}

func TranslateHistoryErr(err error) error {
	validationErr, ok := err.(overlord.ValidationError)
	if ok {
		return InternalValidationError{Err: validationErr}
	}

	res, ok := translateHistoryMap[err]
	if !ok {
		return err
	}

	return res
}
