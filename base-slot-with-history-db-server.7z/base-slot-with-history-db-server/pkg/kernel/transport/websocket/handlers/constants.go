package handlers

const (
	ActionState             = "core/state"
	ActionWager             = "core/wager"
	ActionGambleAnyWin      = "core/gamble_any_win"
	ActionKeepGenerating    = "core/keep_generating"
	ActionSpinsHistory      = "core/spins_history"
	ActionUpdateSpinIndexes = "spin_indexes/update"
	ActionGetFreeSpins      = "core/free_spins/get"
	ActionCancelFreeSpins   = "core/free_spins/cancel"

	ActionAddCheats = "cheats"
)
