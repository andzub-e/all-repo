package container

import (
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/config"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/facade"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/transport/http/handlers"
	"bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/transport/websocket"
	wsHandlers "bitbucket.org/electronicjaw/base-slot-with-history-db-server/pkg/kernel/transport/websocket/handlers"
	"github.com/sarulabs/di"
)

func BuildHandlers(buildTag string, isCheatsAvailable bool) []di.Def {

	defs := append(buildHandlers(),
		[]di.Def{
			{
				Name: constants.HTTPMetaHandlerName,
				Build: func(ctn di.Container) (interface{}, error) {
					return handlers.NewMetaHandler(buildTag), nil
				},
			},
			{
				Name: constants.HTTPCheatsHandlerName,
				Build: func(ctn di.Container) (interface{}, error) {
					fcd := ctn.Get(constants.FacadeName).(*facade.Facade)
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return handlers.NewCheatsHandler(fcd, isCheatsAvailable || cfg.EngineConfig.IsCheatsAvailable), nil
				},
			},
			{
				Name: constants.WSCheatsHandlerName,
				Build: func(ctn di.Container) (interface{}, error) {
					fcd := ctn.Get(constants.FacadeName).(*facade.Facade)
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return wsHandlers.NewCheatsHandler(fcd, isCheatsAvailable || cfg.EngineConfig.IsCheatsAvailable), nil
				},
			},
		}...,
	)

	return defs
}

func NewBuildHandlers() []di.Def {
	defs := append(buildHandlers(),
		[]di.Def{
			{
				Name: constants.HTTPMetaHandlerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return handlers.NewMetaHandler(cfg.EngineConfig.BuildVersion), nil
				},
			},
			{
				Name: constants.HTTPCheatsHandlerName,
				Build: func(ctn di.Container) (interface{}, error) {
					fcd := ctn.Get(constants.FacadeName).(*facade.Facade)
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return handlers.NewCheatsHandler(fcd, cfg.EngineConfig.IsCheatsAvailable), nil
				},
			},
			{
				Name: constants.WSCheatsHandlerName,
				Build: func(ctn di.Container) (interface{}, error) {
					fcd := ctn.Get(constants.FacadeName).(*facade.Facade)
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return wsHandlers.NewCheatsHandler(fcd, cfg.EngineConfig.IsCheatsAvailable), nil
				},
			},
		}...,
	)

	return defs
}

func buildHandlers() []di.Def {
	return []di.Def{
		{
			Name: constants.HTTPGameFlowHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				fcd := ctn.Get(constants.FacadeName).(*facade.Facade)

				return handlers.NewGameFlowHandler(fcd), nil
			},
		},

		{
			Name: constants.HTTPMetricsHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				return handlers.NewMetricsHandler(), nil
			},
		},
		{
			Name: constants.HTTPWSHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				websocketServer := ctn.Get(constants.WebsocketServerName).(*websocket.Server)

				return handlers.NewWebsocketHandler(websocketServer), nil
			},
		},

		{
			Name: constants.WSGameFlowHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				fcd := ctn.Get(constants.FacadeName).(*facade.Facade)

				return wsHandlers.NewGameFlowHandler(fcd), nil
			},
		},
	}
}
