package app

import (
	"context"
	"cyber-town-simulator/pkg/kernel/config"
	"cyber-town-simulator/pkg/kernel/constants"
	"cyber-town-simulator/pkg/kernel/container"
	"cyber-town-simulator/pkg/kernel/engine"
	"cyber-town-simulator/pkg/kernel/errs"
	"cyber-town-simulator/pkg/kernel/services"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
	"sync"
)

type App struct {
	ctn di.Container
	ctx context.Context
	wg  *sync.WaitGroup
}

type GameBootstrap func(ctn di.Container, config *engine.Config) *engine.Bootstrap

func NewApp(configPath string, isDebug bool, fn GameBootstrap) (*App, error) {
	app := &App{
		ctx: context.Background(),
		wg:  &sync.WaitGroup{},
	}

	app.ctn = container.Build(configPath, isDebug)

	logger := app.ctn.Get(constants.LoggerName).(*zap.Logger)
	logger.Info("Building application...")

	cfg := app.ctn.Get(constants.ConfigName).(*config.Config)

	var boot = fn(app.ctn, cfg.EngineConfig)
	if boot.HistoryHandlingType != engine.SequentialRestoring && boot.NeedLastSpin {
		return nil, errs.ErrInitImpossibleBootConfig
	}

	if boot.HistoryHandlingType != engine.SequentialRestoring && boot.GambleAnyWinFeature {
		return nil, errs.ErrInitImpossibleBootConfig
	}

	engine.PutInContainer(boot)

	return app, nil
}

func (app *App) GetSimulatorService() *services.SimulatorService {
	return app.ctn.Get(constants.SimulatorServiceName).(*services.SimulatorService)
}
