package constants

const (
	ConfigName  = "Config"
	LoggerName  = "Logger"
	RNGMockName = "RNGMock"

	SimulatorServiceName = "SimulatorService"
)
