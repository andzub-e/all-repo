package errs

import (
	"errors"
)

var (
	ErrBadDataGiven             = errors.New("bad data given")
	ErrInitImpossibleBootConfig = errors.New("impossible boot config")
)
