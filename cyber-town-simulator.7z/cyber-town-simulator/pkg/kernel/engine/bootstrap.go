package engine

import (
	"github.com/mitchellh/mapstructure"
	"go.uber.org/zap"
)

type Bootstrap struct {
	SpinFactory SpinFactory `mapstructure:"-"`

	HTTPTransport      bool `mapstructure:"-"`
	WebsocketTransport bool `mapstructure:"-"`

	FreeSpinsFeature    bool `mapstructure:"free_spins_feature"`
	GambleAnyWinFeature bool `mapstructure:"gamble_any_win_feature"`
	NeedLastSpin        bool `mapstructure:"-"`

	GambleAnyWinMaxTimes int   `mapstructure:"gamble_any_win_max_times"`
	GambleAnyWinMaxWager int64 `mapstructure:"gamble_any_win_max_wager"`
	GameMaxWager         int64 `mapstructure:"game_max_wager"`

	HistoryHandlingType HistoryType `mapstructure:"-"`

	EngineInfo interface{} `mapstructure:"-"`
}

func (b *Bootstrap) GetEngineInfo() interface{} {
	return b.EngineInfo
}

func (b *Bootstrap) GetBootInfo() interface{} {
	view := map[string]interface{}{}

	// bad decoding rebuild on simple map
	if err := mapstructure.Decode(b, &view); err != nil {
		zap.S().Warn(err)
	}

	return view
}

type Config struct {
	RTP                      string
	BuildVersion             string // any build info
	TurnOnGambleIfAdmissible bool
}

type HistoryType int

const (
	NoHistory HistoryType = iota
	JustSaveHistory
	SequentialRestoring
	ParallelRestoring
)
