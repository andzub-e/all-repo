package engine

type SpinFactory interface {
	Generate(wager int64, parameters interface{}) (Spin, RestoringIndexes, error)
	GambleAnyWin(spin Spin, parameters interface{}) (Spin, error)
	WithBoundLastSpin(spin Spin) SpinFactory
	WithCheat(cheat interface{}) SpinFactory

	UnmarshalJSONSpin(bytes []byte) (Spin, error)
	UnmarshalJSONRestoringIndexes(bytes []byte) (RestoringIndexes, error)
}

type Generate func(wager int64, parameters interface{}) (Spin, RestoringIndexes, error)

type Spin interface {
	Award() int64
	BonusAward() int64
	Wager() int64

	BonusTriggered() bool
	WagerNoGambles() int64
	GambleQuantity() int
	CanGamble(restoringIndexes RestoringIndexes) bool // only logical issues for example: no gamble in bonus game or gamble is collected
}

type RestoringIndexes interface {
	IsShown(spin Spin) bool
	Update(payload interface{}) error
}
