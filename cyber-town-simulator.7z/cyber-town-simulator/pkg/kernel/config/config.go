package config

import (
	"cyber-town-simulator/pkg/kernel/engine"
	"fmt"
	"github.com/spf13/viper"
	"path/filepath"
)

var (
	config *Config
)

type Config struct {
	EngineConfig *engine.Config
}

func New(path string) (*Config, error) {
	viper.Reset()

	abs, err := filepath.Abs(path)
	if err != nil {
		return nil, err
	}

	viper.AddConfigPath(filepath.Dir(abs))
	viper.SetConfigFile(filepath.Base(abs))

	return build()
}

func build() (*Config, error) {
	config = &Config{}

	if err := viper.ReadInConfig(); err != nil {
		return nil, err
	}
	
	engineConfig := viper.Sub("engine")

	if err := parseSubConfig(engineConfig, &config.EngineConfig); err != nil {
		return nil, err
	}

	return config, nil
}

func parseSubConfig[T any](subConfig *viper.Viper, parseTo *T) error {
	if subConfig == nil {
		return fmt.Errorf("can not read %T config: subconfig is nil", parseTo)
	}

	if err := subConfig.Unmarshal(parseTo); err != nil {
		return err
	}

	return nil
}
