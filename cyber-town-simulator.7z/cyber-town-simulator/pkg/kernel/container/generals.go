package container

import (
	"cyber-town-simulator/pkg/kernel/config"
	"cyber-town-simulator/pkg/kernel/constants"
	"fmt"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
)

func BuildGenerals(configPath string, isDebug bool) []di.Def {
	return []di.Def{
		{
			Name: constants.LoggerName,
			Build: func(ctn di.Container) (interface{}, error) {
				logger, err := zap.NewProduction()
				if isDebug {
					logger, err = zap.NewDevelopment()
				}

				if err != nil {
					return nil, fmt.Errorf("can't initialize zap logger: %v", err)
				}

				zap.ReplaceGlobals(logger)

				return logger, nil
			},
		},
		{
			Name: constants.ConfigName,
			Build: func(ctn di.Container) (interface{}, error) {
				return config.New(configPath)
			},
		},
	}
}
