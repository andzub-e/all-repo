package container

import (
	"cyber-town-simulator/pkg/kernel/constants"
	"cyber-town-simulator/pkg/rng"
	"github.com/sarulabs/di"
)

func BuildPkg() []di.Def {
	return []di.Def{
		{
			Name: constants.RNGMockName,
			Build: func(ctn di.Container) (interface{}, error) {
				return rng.NewMockClient()
			},
		},
	}
}
