package container

import (
	"cyber-town-simulator/pkg/kernel/constants"
	"cyber-town-simulator/pkg/kernel/services"
	"github.com/sarulabs/di"
)

func BuildServices() []di.Def {
	return []di.Def{
		{
			Name: constants.SimulatorServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				return services.NewSimulatorService(), nil
			},
		},
	}
}
