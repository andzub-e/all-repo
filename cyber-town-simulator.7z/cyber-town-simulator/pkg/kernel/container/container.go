package container

import (
	"sync"

	"github.com/sarulabs/di"
)

var (
	container di.Container
	once      sync.Once
)

func Build(configPath string, isDebug bool) di.Container {
	once.Do(func() {
		builder, _ := di.NewBuilder()
		defs := []di.Def{}

		defs = append(defs, BuildServices()...)
		defs = append(defs, BuildGenerals(configPath, isDebug)...)
		defs = append(defs, BuildPkg()...)

		if err := builder.Add(defs...); err != nil {
			panic(err)
		}

		container = builder.Build()
	})

	return container
}
