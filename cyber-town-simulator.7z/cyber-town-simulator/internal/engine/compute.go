package engine

func computeBasicWindow(window Window, ag AwardGetter) (award int64, payouts Payouts) {
	for payLineIndex := range payLines {
		payout := computePayLine(payLineIndex, window, ag)
		if payout == nil {
			continue
		}

		if currentAward := ag.GetAward(payout.Symbol, int(payout.Count)); currentAward > 0 {
			payout.Amount = currentAward
			payouts.SpinPayouts = append(payouts.SpinPayouts, *payout)
			payouts.PayoutForSpin += currentAward

			award += payout.Amount
		}
	}

	return
}

func computeBonusWindow(window Window, spinType SpinType, ag AwardGetter) BonusSpinsTriggered {
	paylineIndependent := map[string]struct{}{
		ScatterSymbol: {},
	}

	var availableBonusSymbols map[string]struct{}

	switch spinType {
	case SpinTypeBase:
		availableBonusSymbols = sliceToMap(BaseSpinBonusSymbols)
	case SpinTypeBonus:
		availableBonusSymbols = sliceToMap(BonusSpinBonusSymbols)
	}

	var result BonusSpinsTriggered

	// collect bonus spins for payline independent symbols
	for symb := range paylineIndependent {
		_, ok := availableBonusSymbols[symb]
		if !ok {
			continue
		}

		ctn := getBonusSymbolCount(window, symb)
		if ctn != 0 {
			result.TotalSpins += ctn
			result.BonusSpinsTriggeredInfo = append(result.BonusSpinsTriggeredInfo, BonusSpinTriggered{
				Symbol:             symb,
				PayLine:            0,
				PayLineIndependent: true,
				SpinsAmount:        ctn,
			})
		}
	}

	// collect bonus spins for payline dependent symbols
	for lineID := range payLines {
		symb, amount := getBonusSymbolCountByPayLine(lineID, window, ag)

		// is symbol available for input spin type
		_, isAvailable := availableBonusSymbols[symb]
		// wheather this symbol already calculated in collect independent paylines block or not
		_, isAlreadyCalculated := paylineIndependent[symb]

		if !isAvailable || isAlreadyCalculated {
			continue
		}

		if amount != 0 {
			result.TotalSpins += amount
			result.BonusSpinsTriggeredInfo = append(result.BonusSpinsTriggeredInfo, BonusSpinTriggered{
				Symbol:             symb,
				PayLine:            uint(lineID),
				PayLineIndependent: false,
				SpinsAmount:        amount,
			})
		}
	}

	return result
}

func computePayLine(payLineID int, window Window, ag AwardGetter) *Payout {
	line := payLines[payLineID]

	// preprocess the first symbol in the line
	symbol := window.symbol(line[0])

	// capture our initial symbol or wild state
	wildChain := symbolIsWild(symbol)
	consecutiveWilds := uint(0)

	if wildChain {
		consecutiveWilds++
	}

	// we've already processed the first symbol / wild
	consecutive := uint(1)

	// walk remaining in payline to find consecutive count (and true pay symbol if we started with a wild)
	for ; consecutive < uint(len(line)); consecutive++ {
		// process next symbol in line
		nextSymbol := window.symbol(line[consecutive])

		// check if our next symbol is wild
		if symbolIsWild(nextSymbol) && wildChain {
			consecutiveWilds++
		} else if nextSymbol == symbol || symbolIsWild(nextSymbol) {
			continue
		} else if wildChain {
			symbol = nextSymbol
			wildChain = false
		} else {
			break
		}
	}

	// get multiplier
	mult := ag.GetAward(symbol, int(consecutive))
	wildmult := ag.GetAward(WildSymbol, int(consecutiveWilds))

	// use the better one
	if wildmult > mult {
		mult = wildmult
		consecutive = consecutiveWilds
		symbol = WildSymbol
	}

	if mult == 0 {
		return nil
	}

	return &Payout{
		Symbol:    symbol,
		Count:     consecutive,
		PayLineID: uint(payLineID),
	}
}

func getBonusSymbolCountByPayLine(payLineID int, window Window, ag AwardGetter) (string, uint) {
	result := computePayLine(payLineID, window, ag)
	if result == nil {
		return "", 0
	}

	resSpins, ok := BonusFreeSpins[result.Symbol][result.Count]
	if !ok {
		return "", 0
	}

	return result.Symbol, resSpins
}

func sliceToMap(symbols []string) map[string]struct{} {
	res := make(map[string]struct{})
	for _, v := range symbols {
		res[v] = struct{}{}
	}

	return res
}
