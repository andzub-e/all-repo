package engine

import "cyber-town-simulator/pkg/kernel/engine"

type Spin struct {
	LastWager int64     `json:"last_wager"`
	TotalWin  int64     `json:"total_win"`
	Window    Window    `json:"window"`
	Payouts   Payouts   `json:"payouts"`
	ReelState ReelState `json:"reels"`

	Bonus *Bonus `json:"bonus,omitempty"`
}

type ReelState struct {
	Stops        []int `json:"stops"`
	IsCheatStops bool  `json:"is_cheat_stops"`
	IsAutoSpin   bool  `json:"is_autospin"`
	IsTurboSpin  bool  `json:"is_turbospin"`
}

type Payouts struct {
	SpinPayouts   []Payout `json:"spin_payouts"`
	PayoutForSpin int64    `json:"payout_for_spin" swaggertype:"integer" example:"100"`
}

type Payout struct {
	Symbol         string `json:"symbol" example:"A"`
	Count          uint   `json:"count" example:"5"`
	PayLineID      uint   `json:"payline" swaggertype:"integer" example:"0"`
	Amount         int64  `json:"amount" swaggertype:"integer" example:"100"`
	Cycle          int    `json:"cycle,omitempty"`
	StartReelIndex uint   `json:"start_reel_index"`
}

func (s Spin) Award() int64 {
	return s.Payouts.PayoutForSpin
}

func (s Spin) BonusAward() int64 {
	return s.Bonus.Award()
}

func (s Spin) BonusTriggered() bool {
	return s.Bonus != nil
}

func (s Spin) Wager() int64 {
	return s.LastWager
}

func (s Spin) WagerNoGambles() int64 {
	return s.LastWager
}

func (s Spin) GambleQuantity() int {
	return 0
}

func (s Spin) CanGamble(restoringIndexes engine.RestoringIndexes) bool {
	return false
}
