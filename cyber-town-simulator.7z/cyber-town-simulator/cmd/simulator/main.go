package main

import (
	"cyber-town-simulator/internal/engine"
	"cyber-town-simulator/pkg/app"
	"cyber-town-simulator/pkg/kernel/services"
	"cyber-town-simulator/utils"
	"fmt"
	"os"
	"path/filepath"
	"time"
)

const SpinCount = 1000 * 1000

func main() {

	now := time.Now()

	application, err := app.NewApp("config.yml", true, engine.Bootstrap)
	if err != nil {
		panic(err)
	}

	simulator := application.GetSimulatorService()

	result, err := simulator.WithProgressListener(func(percent float64) {
		fmt.Printf("Processing: %2.0f%%\n", percent*100)
	}).
		WithWagerParameters(nil).
		Simulate("cyber-town", SpinCount, 1000)

	reportPages := []utils.Page{
		{
			Name:  "Report",
			Table: utils.Transpose(utils.ExtractTable([]*services.SimulationView{result.View()}, "xlsx")),
		}}

	saveReport(reportPages)

	fmt.Printf("The program ran for %s\n", time.Since(now))
}

func saveReport(reportPages []utils.Page) {
	excel, err := utils.ExportMultiPageXLSX(reportPages)
	if err != nil {
		fmt.Printf("simulate: %v\n", err)
	}

	abs, err := filepath.Abs("simresults")
	if err != nil {
		panic(err)
	}

	file, err := os.Create(filepath.Join(abs, fmt.Sprintf("report-%v.xlsx", time.Now().UnixNano())))
	if err != nil {
		fmt.Printf("simulate: %v\n", err)
	}

	if err = excel.Write(file); err != nil {
		fmt.Printf("simulate: %v\n", err)
	}
}
