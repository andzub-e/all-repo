//go:build !prod
// +build !prod

package cache

func init() {
	Cache.storage = make(map[string]interface{})
}
