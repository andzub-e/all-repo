package core

import "github.com/sirupsen/logrus"

type Core struct {
	log *logrus.Entry
}

func NewCore(log *logrus.Entry) *Core {
	return &Core{
		log: log,
	}
}
