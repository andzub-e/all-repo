package core

import (
	"PR_BUGS/game"
	"PR_BUGS/game/constants"
	"PR_BUGS/internal/models"
)

func (c *Core) ExecSpin(u *models.User, isAutospin bool) error {
	var err error

	c.log.Info("exec spin: spinBase")
	err = c.spinBase(u, isAutospin)
	if err != nil {
		return err
	}

	// reality check
	if !u.State.Window.Equals(u.State.Reels.Window()) {
		c.log.Error("!u.Window.Equals(u.Reels.Window())")
	}

	c.log.Info("exec spin: spinBonus")
	err = c.spinBonus(u, isAutospin)
	if err != nil {
		return err
	}

	if len(u.State.BonusStates.BonusReelStates) != len(u.State.BonusStates.BonusSpinResults) {
		c.log.Errorf("len(u.BonusReels) %d != %d len(u.BonusSpins)",
			len(u.State.BonusStates.BonusReelStates), len(u.State.BonusStates.BonusSpinResults))
	}

	return nil
}

func (c *Core) spinBase(u *models.User, isAutospin bool) error {
	u.State.Reels = nextRandomReelState(u, game.BaseReelsSize)
	u.State.Reels.IsAutospin = isAutospin
	u.State.Window = u.State.Reels.Window()
	u.State.Payouts = u.State.Reels.Window().Results(u.State.LastWagerAmount, game.BasePaytable)
	u.State.TotalWins += u.State.Payouts.PayoutForSpin
	u.State.Balance += u.State.Payouts.PayoutForSpin

	return nil
}

func (c *Core) spinBonus(u *models.User, isAutospin bool) error {
	baseSpinBonusTriggered := u.State.Window.BonusSpins(game.SpinTypeBase)
	if baseSpinBonusTriggered.TotalSpins != 0 {
		u.State.BaseSpinBonusTriggered = baseSpinBonusTriggered

		u.State.BonusStates.BonusReelStates = make(game.BonusReelStates, 0, baseSpinBonusTriggered.TotalSpins)
		u.State.BonusStates.BonusSpinResults = make(game.BonusSpinResults, 0, baseSpinBonusTriggered.TotalSpins)

		balanceAfterSpin := u.State.Balance
		currentWinAmount := game.CurrencyAmount(u.State.TotalWins)
		u.State.BonusStates.Win = currentWinAmount

		for ctn := baseSpinBonusTriggered.TotalSpins; ctn != 0; ctn-- {
			bonusState, bonusResult := c.spinBonusSingle(isAutospin, u.State.LastWagerAmount)

			additionalSpins := bonusResult.Window.BonusSpins(game.SpinTypeBonus)
			bonusSpinsLeft := ctn + additionalSpins.TotalSpins - 1
			currentWinAmount += bonusResult.PayoutsInfo.PayoutForSpin
			balanceAfterSpin += bonusResult.PayoutsInfo.PayoutForSpin

			bonusResult.AdditionalSpins = additionalSpins
			bonusResult.CurrentWinAmount = currentWinAmount
			bonusResult.BonusSpinsLeft = bonusSpinsLeft
			bonusResult.BalanceAfterSpin = balanceAfterSpin

			u.State.BonusStates.Win = currentWinAmount
			u.State.BonusStates.BonusReelStates = append(u.State.BonusStates.BonusReelStates, bonusState)
			u.State.BonusStates.BonusSpinResults = append(u.State.BonusStates.BonusSpinResults, bonusResult)

			ctn += additionalSpins.TotalSpins

			c.log.Infof("ctn = %d, add spins = %d\n", ctn, additionalSpins.TotalSpins)
		}

		u.State.BonusStates.FortuneMultiplierIndex, u.State.BonusStates.FortuneMultiplier = c.wheelOfFortuneMultiplier()
		u.State.BonusStates.WinAfterMultiplier = u.State.BonusStates.FortuneMultiplier.ApplyToWithoutDivision(u.State.BonusStates.Win)
		u.State.TotalWins += u.State.BonusStates.WinAfterMultiplier
		u.State.Balance += u.State.BonusStates.WinAfterMultiplier
	}

	return nil
}

func (c *Core) spinBonusSingle(isAutospin bool, lastWager game.CurrencyAmount) (game.BonusReelState, game.BonusSpinResult) {
	bonusSpinResult := game.BonusSpinResult{}
	bonusReelState := game.BonusReelState{}

	bonusReelState = nextRandomBonusReelState(game.BonusReelsSize)
	bonusReelState.IsAutospin = isAutospin

	bonusSpinResult.Window = bonusReelState.Window()
	bonusSpinResult.PayoutsInfo = bonusReelState.Window().Results(lastWager, game.BasePaytable)
	bonusSpinResult.Reels = bonusReelState

	return bonusReelState, bonusSpinResult
}

func (c *Core) wheelOfFortuneMultiplier() (game.RowID, game.Multiplier) {
	return nextRandomWheelOfFortune()
}

func (c *Core) StopsNoWin() [constants.ReelCount]game.ReelStop {
	var cheatState game.ReelState
	payout := game.Payouts{PayoutForSpin: 1}
	bonusSpins := game.SpinCount(1)

	for payout.PayoutForSpin != 0 || bonusSpins != 0 {
		cheatState = randomReelState(game.BaseReelsSize)
		payout = cheatState.Results(1)
		bonusSpins = cheatState.Window().BonusSpins(game.SpinTypeBase).TotalSpins
	}

	return cheatState.Stops
}
