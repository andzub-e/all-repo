//go:build !prod
// +build !prod

package core

import (
	"PR_BUGS/cache"
	"PR_BUGS/game"
	"PR_BUGS/internal/models"
)

func nextRandomReelState(u *models.User, reelsSize game.ReelsSize) game.ReelState {
	val, ok := cache.Cache.Get(string(u.State.SessionToken))
	if !ok {
		return randomReelState(reelsSize)
	}

	cache.Cache.Delete(string(u.State.SessionToken))

	return val.(game.ReelState)
}
