//go:build !prod
// +build !prod

package core

import (
	"testing"

	"PR_BUGS/game"
	"PR_BUGS/game/constants"
	"github.com/sirupsen/logrus"
	"github.com/stretchr/testify/assert"
)

func TestValidateStops(t *testing.T) {
	var (
		stops [constants.ReelCount]game.ReelStop
		err   error
	)

	core := &Core{log: &logrus.Entry{}}

	stops = [constants.ReelCount]game.ReelStop{0, 0, 0, 0, 0}
	err = core.ValidateStops(&ValidateStopsParams{
		Stops: stops,
		Reels: game.BaseReels,
	})
	assert.Equal(t, nil, err)

	stops = [constants.ReelCount]game.ReelStop{15, 15, 15, 34, 45}
	err = core.ValidateStops(&ValidateStopsParams{
		Stops: stops,
		Reels: game.BaseReels,
	})
	assert.NotEqual(t, nil, err)

	stops = [constants.ReelCount]game.ReelStop{37, 0, 0, 31, 10}
	err = core.ValidateStops(&ValidateStopsParams{
		Stops: stops,
		Reels: game.BaseReels,
	})
	assert.NotEqual(t, nil, err)
}

func TestCheatNoWinStops(t *testing.T) {
	core := &Core{log: &logrus.Entry{}}
	state := game.ReelState{}

	for i := 0; i < 10; i++ {
		state.Stops, _ = core.CheatNoWinStops(&CheatNoWinStops{})
		assert.Equal(t, 0, int(state.Results(1).PayoutForSpin))
		t.Log()
	}
}

func TestCheatBonusStops(t *testing.T) {
	var (
		err error
	)

	core := &Core{log: &logrus.Entry{}}
	state := game.ReelState{}

	for i := 0; i < 10; i++ {
		state.Stops, err = core.CheatBonusStops(game.SpinTypeBase, game.Scatter)
		assert.Equal(t, nil, err)
		assert.Equal(t, 15, int(state.Window().BonusSpins(game.SpinTypeBase).TotalSpins))
	}
}
