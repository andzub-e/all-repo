package core

import (
	"fmt"

	"PR_BUGS/game"
	"PR_BUGS/game/constants"
)

func nextMock3ScattersReelState() game.ReelState {
	res := game.ReelState{}

	scatterAmount := 0
	for reel := game.ReelID(0); reel < constants.ReelCount; reel++ {
		reelSize := game.RowID(len(game.BaseReels[reel]))
		for row := game.RowID(0); row < reelSize; row++ {
			if game.BaseReels[reel][row] == game.Scatter {
				res.Stops[reel] = game.ReelStop(row)
				fmt.Printf("reel %d, scatter stop = %d\n", reel, row)
				scatterAmount++
				break
			}
		}
		if scatterAmount == 3 {
			break
		}
	}

	return res
}
