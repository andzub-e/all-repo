//go:build !prod
// +build !prod

package core

import (
	"fmt"

	"PR_BUGS/game"
	"PR_BUGS/game/constants"
	"PR_BUGS/utils"
)

type ValidateStopsParams struct {
	Stops [constants.ReelCount]game.ReelStop
	Reels game.ReelSet
}

// check stops to be valid for input reels
func (c *Core) ValidateStops(params *ValidateStopsParams) error {
	if len(params.Reels) != len(params.Stops) {
		return fmt.Errorf("len(params.Reels) %d != %d len(params.Stops)", len(params.Reels), len(params.Stops))
	}

	for i, v := range params.Stops {
		if len(params.Reels[i]) <= int(v) {
			return fmt.Errorf("reel stop in out of range: reel %d, input stop %d, max stop %d", i, v, len(params.Reels[i]))
		}
	}

	return nil
}

type CheatWinStopsParams struct {
	IsBonus bool
}

// cheat stops with random win
func (c *Core) CheatWinStops(params *CheatWinStopsParams) ([constants.ReelCount]game.ReelStop, error) {
	var stops [constants.ReelCount]game.ReelStop

	return stops, nil
}

type CheatNoWinStops struct {
}

// cheat stops with no win
func (c *Core) CheatNoWinStops(params *CheatNoWinStops) ([constants.ReelCount]game.ReelStop, error) {
	var cheatState game.ReelState
	payout := game.Payouts{PayoutForSpin: 1}
	bonusSpins := game.SpinCount(1)

	for payout.PayoutForSpin != 0 || bonusSpins != 0 {
		cheatState = randomReelState(game.BaseReelsSize)
		payout = cheatState.Results(1)
		bonusSpins = cheatState.Window().BonusSpins(game.SpinTypeBase).TotalSpins
	}

	return cheatState.Stops, nil
}

type CheatWinTypeStops struct {
	WinType game.WinType
}

// cheat stops with defined win type
func (c *Core) CheatWinTypeStops(params *CheatWinTypeStops) ([constants.ReelCount]game.ReelStop, error) {
	var stops [constants.ReelCount]game.ReelStop

	return stops, nil
}

// cheat stops with bonus game
func (c *Core) CheatBonusStops(spinType game.SpinType, bonusTriggerSymbol game.ReelSymbol) ([constants.ReelCount]game.ReelStop, error) {
	var (
		stops       [constants.ReelCount]game.ReelStop
		reels       game.ReelSet
		bonusSymbol game.ReelSymbol
	)

	bonusSymbol = bonusTriggerSymbol

	switch spinType {
	case game.SpinTypeBase:
		reels = game.BaseReels
		if bonusSymbol == "" {
			bonusSymbol = game.BaseSpinBonusSymbols[utils.RandInt(0, len(game.BaseSpinBonusSymbols))]
		}
	case game.SpinTypeBonus:
		reels = game.BonusReels
		if bonusSymbol == "" {
			bonusSymbol = game.BonusSpinBonusSymbols[utils.RandInt(0, len(game.BonusSpinBonusSymbols))]
		}
	default:
		return stops, fmt.Errorf("no such spin type. input type: %s", spinType)
	}

	allStops, isPossible := isPossibleTriggerBonus(reels, bonusSymbol)
	if !isPossible {
		return stops, fmt.Errorf("no possible ways to trigger bonus game by %s symbol", bonusSymbol)
	}

	for reel, v := range allStops {
		stops[reel] = v[utils.RandInt(0, len(v))]
	}

	return stops, nil
}

func isPossibleTriggerBonus(reels game.ReelSet, symbol game.ReelSymbol) ([constants.ReelCount][]game.ReelStop, bool) {
	var stops [constants.ReelCount][]game.ReelStop

	minRequiredSymbols := len(reels) + 1
	symbolsRow := game.BonusFreeSpins[symbol]
	for symbolsAmount, bonusSpins := range symbolsRow {
		if bonusSpins != 0 && minRequiredSymbols > int(symbolsAmount) {
			minRequiredSymbols = int(symbolsAmount)
		}
	}

	if minRequiredSymbols > len(reels) {
		return stops, false
	}

	for reel, v := range reels {
		for stop, symb := range v {
			if symb == symbol {
				stops[reel] = append(stops[reel], game.ReelStop(stop))
			}
		}
	}

	symbolByRows := 0
	for i, v := range stops {
		if len(v) > 0 {
			symbolByRows++
		} else {
			stops[i] = append(stops[i], 0)
		}
	}

	return stops, symbolByRows >= minRequiredSymbols
}
