//go:build prod
// +build prod

package core

import (
	"PR_BUGS/game"
	"PR_BUGS/internal/models"
)

func nextRandomReelState(u *models.User, reelsSize game.ReelsSize) game.ReelState {
	return randomReelState(reelsSize)
}
