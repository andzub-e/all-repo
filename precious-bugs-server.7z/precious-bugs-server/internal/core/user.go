package core

import (
	"PR_BUGS/api"
	"PR_BUGS/game"
	"PR_BUGS/internal/betoverlord"
	"PR_BUGS/internal/models"
)

type LookUpOrCreateUserParams struct {
	SessionID string
	Operator  string
	Game      string
	Params    []byte
}

func (c *Core) LookUpOrCreateUser(client *betoverlord.OverlordClient, params *LookUpOrCreateUserParams) (*betoverlord.UserState, error) {
	var u *betoverlord.UserState
	var err error

	if params.SessionID != "" {
		u, err = client.GetStateBySessionToken(params.SessionID)
	} else {
		u, err = client.GetState(params.Operator, params.Game, params.Params)
	}

	if err != nil {
		c.log.WithError(err).Error("failed to get user state from betlord")
		return nil, err
	}

	return u, nil
}

func (c *Core) BaseUser() *models.User {
	return &models.User{
		State: api.SessionState{
			Username:        "",
			Balance:         0,
			Currency:        "",
			LastWagerID:     "some id",
			LastWagerAmount: 0,
			FreespinID:      "",
			SessionToken:    "",
			WagerLevels:     []int64{},
			DefaultWager:    0,
			Game:            "",

			Reels:       game.ReelState{},
			BonusStates: game.BonusStates{},

			StartBalance:  0,
			UserID:        "",
			Operator:      "",
			OperatorToken: "",
			TransactionID: "",
			RoundID:       "",
		},
	}
}

func (c *Core) LookUpOrCreateUserMock(client *betoverlord.OverlordClient, params *LookUpOrCreateUserParams) (*betoverlord.UserState, error) {
	u, err := client.GetState(params.Operator, params.Game, params.Params)
	if err != nil {
		c.log.WithError(err).Error("failed to get user state from betlord")
		return nil, err
	}

	return u, nil
}
