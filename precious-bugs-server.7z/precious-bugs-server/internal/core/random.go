package core

import (
	"PR_BUGS/game"
	"PR_BUGS/game/constants"
	"PR_BUGS/utils"
)

func randomReelState(reelsSize game.ReelsSize) game.ReelState {
	rs := game.ReelState{}

	var stop game.ReelStop
	for i := 0; i < constants.ReelCount; i++ {
		stop = game.ReelStop(utils.RandInt(0, int(reelsSize[i])))
		rs.Stops[i] = stop
	}
	return rs
}

func RandomWindowForFirstStartGame() game.ReelWindow {
	return randomReelState(game.BaseReelsSize).Window()
}

func nextRandomBonusReelState(reelsSize game.ReelsSize) game.BonusReelState {
	brs := game.BonusReelState{}

	var stop game.ReelStop
	for i := 0; i < constants.ReelCount; i++ {
		stop = game.ReelStop(utils.RandInt(0, int(reelsSize[i])))
		brs.Stops[i] = stop
	}
	return brs
}

func nextRandomWheelOfFortune() (game.RowID, game.Multiplier) {
	// fmt.Printf("Wheel of fortune reel size = %d\n", len(game.WheelOfFortuneReel))
	index := utils.RandInt(0, len(game.WheelOfFortuneReel))
	return game.RowID(index), game.WheelOfFortuneReel[index]
}
