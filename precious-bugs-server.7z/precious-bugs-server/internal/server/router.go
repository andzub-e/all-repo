package server

import (
	"time"

	"PR_BUGS/internal/server/handlers"
	"PR_BUGS/internal/services"

	_ "PR_BUGS/docs"
	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
	"github.com/sirupsen/logrus"
	echoSwagger "github.com/swaggo/echo-swagger"
)

const durationThreshold = time.Second * 10

func NewRouter(log *logrus.Entry, services *services.Service) *echo.Echo {
	router := echo.New()

	cors := middleware.CORSWithConfig(middleware.CORSConfig{
		AllowOrigins:     []string{"*"},
		AllowMethods:     []string{"*", "GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"},
		AllowHeaders:     []string{"*", "Accept", "Authorization", "Content-Type", "X-CSRF-Token", "x-auth", "Access-Control-Allow-Origin", "Access-Control-Allow-Methods", "Access-Control-Allow-Credentials"},
		ExposeHeaders:    []string{"*", "Link"},
		AllowCredentials: true,
		MaxAge:           300,
	})

	// provider := NewProvider(cfg)
	router.Use(cors)
	router.Use(middleware.LoggerWithConfig(middleware.LoggerConfig{
		Format:           "[REQUEST] [URI]=${uri}, [METHOD]=${method}, [STATUS]=${status}, [TIME]=${time_rfc3339_nano}\n",
		CustomTimeFormat: "2006-01-02 15:04:05",
	}))
	router.Use(middleware.Recover())

	handlers := handlers.New(log, services)

	// Swagger endpoint
	router.GET("/swagger/*", echoSwagger.WrapHandler)

	// Static data endpoints
	router.GET("/static/reels", handlers.GetReels)
	router.GET("/static/bonus_reels", handlers.GetBonusReels)
	router.GET("/static/paylines", handlers.GetPaylines)
	router.GET("/static/paytable", handlers.GetPaytable)
	router.GET("/static/wheel_of_fortune", handlers.GetWheelOfFortune)

	// Core endpoints
	// router.GET("/core/state", handlers.State)
	router.GET("/core/free_spins/get", handlers.GetFreeSpins)
	router.GET("/core/free_spins", handlers.GetFreeSpins) // TODO DEPRECATED ENDPOINT
	router.GET("/core/spins_history", handlers.GetSpinsHistory)
	router.POST("/core/state", handlers.State)
	router.POST("/core/wager", handlers.PlaceWager)
	router.POST("/core/increment_bonus_index", handlers.IncrementBonusIndex)

	// add routes depending on build tag
	AddRoutes(router, handlers)

	return router
}
