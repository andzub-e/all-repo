//go:build !prod
// +build !prod

package server

import (
	_ "PR_BUGS/docs"
	"PR_BUGS/internal/server/handlers"
	"github.com/labstack/echo/v4"
)

func AddRoutes(r *echo.Echo, handlers *handlers.Handler) {
	r.POST("/cheat/no_win", handlers.CheatNoWin)
	r.POST("/cheat/bonus_game", handlers.CheatBonusGame)
	r.POST("/cheat/custom_stops", handlers.CheatCustomStops)
}
