package handlers

import (
	"net/http"

	"PR_BUGS/api"
	"PR_BUGS/internal/errs"
	"PR_BUGS/utils"
	"github.com/labstack/echo/v4"
)

// @Summary Get free spins
// @Tags core
// @Consume application/json
// @Description Retrieves user's available free spins
// @Param session_token query string true "session token"
// @Produce  json
// @Success 200 {object} api.GetFreeSpinsResponse
// @Failure 400 {object} errs.ErrResp
// @Failure 500 {object} errs.ErrResp
// @Router /core/free_spins [get]
func (h *Handler) GetFreeSpins(c echo.Context) error {
	sessionToken := c.QueryParam("session_token")
	if utils.Empty(sessionToken) {
		h.log.Error("input session_token is empty")
		return c.JSON(http.StatusBadRequest, errs.BadParamInBodyErr)
	}

	req := &api.GetFreeSpinsRequest{
		SessionToken: api.Token(sessionToken),
	}

	resp, err := h.services.UserService.GetFreeSpins(req)
	if err != nil {
		h.log.WithError(err).Error("failed to get free spins")
		return c.JSON(int(err.(errs.ErrResp).Code), err)
	}

	return c.JSON(http.StatusOK, resp)
}
