package handlers

import (
	"net/http"

	"PR_BUGS/api"
	"PR_BUGS/internal/errs"
	"github.com/labstack/echo/v4"
)

// @Summary Place a bet
// @Tags core
// @Consume application/json
// @Param JSON body api.PlaceWagerRequest true "body for a making bet(spin)"
// @Description Make a bet (spin).
// @Accept  json
// @Produce  json
// @Success 200 {object} api.SessionState
// @Failure 400 {object} errs.ErrResp
// @Failure 500 {object} errs.ErrResp
// @Router /core/wager [post]
func (h *Handler) PlaceWager(c echo.Context) error {
	var (
		req api.PlaceWagerRequest
		err error
	)

	// parse request
	err = c.Bind(&req)
	if err != nil {
		h.log.WithError(err).Error("failed to parse place wager request")
		return c.JSON(http.StatusBadRequest, errs.BadParamInBodyErr)
	}

	// call service method
	h.log.Info("calling wager core")
	resp, err := h.services.UserService.Wager(&req)
	if err != nil {
		h.log.WithError(err).Error("failed to place wager")
		myErr := errs.GetMyErr(err)
		return c.JSON(myErr.Code, err)
	}

	return c.JSON(http.StatusOK, resp)
}
