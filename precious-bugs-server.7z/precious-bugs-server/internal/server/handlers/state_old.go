package handlers

// @Summary State
// @Tags core
// @Consume application/json
// @Param session_id query string true "session id from game client"
// @Param operator query string true "operator name"
// @Param game query string true "game id"
// @Param params query string true "special operator parameters"
// @Description Retrieves an initial state of the game from the bet-overlord service.
// @Description For every new session you need to send /state request. /br In response you'll get a session token for a bets placing.
// @Description Mock data: operator - MOCK, game - TEST, params example - { "user": "58e361be-2edc-4b4e-bf24-5a348a5eff3c", "token": "04e717e7-e5af-42eb-8c67-08aa647b5c7b", "game": "test", "operator": "MOCK" }
// @Accept  json
// @Produce  json
// @Success 200 {object} api.StateResponse
// @Failure 400 {object} errs.ErrResp
// @Failure 500 {object} errs.ErrResp
// @Router /core/state [get]
// func (h *Handler) State(c echo.Context) error {
// 	var (
// 		err error
// 	)

// 	req := api.StateRequest{
// 		SessionID: api.SessionID(c.QueryParam("session_id")),
// 		Operator:  c.QueryParam("operator"),
// 		Game:      c.QueryParam("game"),
// 		Params:    c.QueryParam("params"),
// 	}

// 	// init user state on lord
// 	resp, err := h.services.UserService.GetUserState(&req)
// 	if err != nil {
// 		h.log.WithError(err).Error("failed to get user state from db")
// 		return c.JSON(int(err.(errs.ErrResp).Code), err)
// 	}

// 	return c.JSON(http.StatusOK, resp)
// }
