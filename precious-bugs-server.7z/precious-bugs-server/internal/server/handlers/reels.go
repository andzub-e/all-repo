package handlers

import (
	"net/http"

	"PR_BUGS/api"
	"PR_BUGS/game"
	"github.com/labstack/echo/v4"
)

// @Summary Get reels
// @Tags static
// @Consume application/json
// @Description Retrieves base reels.
// @Produce  json
// @Success 200 {object} api.ReelsResponse
// @Failure 400 {object} errs.ErrResp
// @Failure 500 {object} errs.ErrResp
// @Router /static/reels [get]
func (h *Handler) GetReels(c echo.Context) error {
	return c.JSON(http.StatusOK, api.ReelsResponse{Reels: game.BaseReels})
}
