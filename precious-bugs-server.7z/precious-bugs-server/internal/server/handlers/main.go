package handlers

import (
	// "PR_BUGS/internal/server/service"
	"PR_BUGS/internal/services"
	"github.com/sirupsen/logrus"
)

type Handler struct {
	log      *logrus.Entry
	services *services.Service
}

func New(log *logrus.Entry, services *services.Service) *Handler {
	return &Handler{
		log:      log,
		services: services,
	}
}
