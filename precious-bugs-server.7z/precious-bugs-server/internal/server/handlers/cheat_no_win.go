//go:build !prod
// +build !prod

package handlers

import (
	"net/http"

	"PR_BUGS/api"
	"PR_BUGS/internal/errs"
	"PR_BUGS/utils"
	"github.com/labstack/echo/v4"
)

// @Summary Cheat no win
// @Tags cheat
// @Consume application/json
// @Description Set next spin to be with 0 win
// @Param JSON body api.CheatsNoWinRequest true "body for exec cheat"
// @Accept  json
// @Produce  json
// @Success 200
// @Failure 400 {object} errs.ErrResp
// @Failure 500 {object} errs.ErrResp
// @Router /cheat/no_win [post]
func (h *Handler) CheatNoWin(c echo.Context) error {
	var req api.CheatsNoWinRequest

	err := c.Bind(&req)
	if err != nil {
		h.log.WithError(err).Error("failed to decode request json")
		return c.JSON(http.StatusBadRequest, errs.BadParamInBodyErr)
	}

	if utils.Empty(string(req.SessionToken)) {
		h.log.Error("input session_token is empty")
		return c.JSON(http.StatusBadRequest, errs.BadParamInBodyErr)
	}

	err = h.services.CheatsService.NoWin(&req)
	if err != nil {
		h.log.WithError(err).Error("failed to exec cheat no win")
		return c.JSON(http.StatusInternalServerError, errs.InternalServerErr)

	}

	return c.NoContent(http.StatusOK)
}
