package handlers

import (
	"net/http"

	"PR_BUGS/api"
	"PR_BUGS/internal/errs"
	"PR_BUGS/utils"
	"github.com/labstack/echo/v4"
)

// @Summary Increment bonus index
// @Tags core
// @Consume application/json
// @Description Increment viewed bonus spins index
// @Param session_token query string true "session token"
// @Produce  json
// @Success 200
// @Failure 400 {object} errs.ErrResp
// @Failure 500 {object} errs.ErrResp
// @Router /core/increment_bonus_index [post]
func (h *Handler) IncrementBonusIndex(c echo.Context) error {
	sessionToken := c.QueryParam("session_token")
	if utils.Empty(sessionToken) {
		h.log.Error("input session_token is empty")
		return c.JSON(http.StatusBadRequest, errs.BadParamInBodyErr)
	}

	req := &api.IncrementBonusIndexRequest{
		SessionToken: api.Token(sessionToken),
	}

	err := h.services.UserService.IncrementBonusIndex(req)
	if err != nil {
		h.log.WithError(err).Error("failed increment bonus index")
		return c.JSON(int(err.(errs.ErrResp).Code), err)
	}

	return c.NoContent(http.StatusOK)
}
