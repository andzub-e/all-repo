package handlers

import (
	"net/http"

	"PR_BUGS/api"
	"PR_BUGS/game"
	"github.com/labstack/echo/v4"
)

// @Summary Get wheel of fortune
// @Tags static
// @Consume application/json
// @Description Retrieves base wheel of fortune reel
// @Produce  json
// @Success 200 {object} api.WheelOfFortuneResponse
// @Failure 400 {object} errs.ErrResp
// @Failure 500 {object} errs.ErrResp
// @Router /static/wheel_of_fortune [get]
func (h *Handler) GetWheelOfFortune(c echo.Context) error {
	return c.JSON(http.StatusOK, api.WheelOfFortuneResponse{WheelOfFortune: game.WheelOfFortuneReel})
}
