package handlers

import (
	"net/http"

	"PR_BUGS/api"
	"PR_BUGS/internal/errs"
	"PR_BUGS/internal/services/user"
	"PR_BUGS/utils"
	"github.com/labstack/echo/v4"
)

// @Summary State
// @Tags core
// @Consume application/json
// @Param JSON body api.StateRequest true "body for get state"
// @Accept  json
// @Produce  json
// @Success 200 {object} api.StateResponse
// @Failure 400 {object} errs.ErrResp
// @Failure 500 {object} errs.ErrResp
// @Router /core/state [post]
func (h *Handler) State(c echo.Context) error {
	var (
		req api.StateRequest
		err error
	)

	err = c.Bind(&req)
	if err != nil {
		h.log.WithError(err).Error("failed to parse state request")
		return c.JSON(http.StatusBadRequest, errs.BadParamInBodyErr)
	}

	paramsBytes, err := utils.JSONToBytes(req.Params)
	if err != nil {
		h.log.WithError(err).Error("failed to parse params json to string")
		return c.JSON(http.StatusBadRequest, errs.BadParamInBodyErr)
	}
	h.log.Infof("Params string: %s", string(paramsBytes))
	userStateParams := user.GetUserStateParams{
		Operator: req.Operator,
		Game:     req.Game,
		Params:   paramsBytes,
	}

	// init user state on lord
	resp, err := h.services.UserService.GetUserState(&userStateParams)
	if err != nil {
		h.log.WithError(err).Error("failed to get user state from db")
		return c.JSON(errs.GetMyErr(err).Code, err)
	}

	return c.JSON(http.StatusOK, resp)
}
