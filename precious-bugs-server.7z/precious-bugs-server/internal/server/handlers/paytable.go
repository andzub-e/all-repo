package handlers

import (
	"net/http"

	"PR_BUGS/api"
	"PR_BUGS/game"
	"github.com/labstack/echo/v4"
)

// @Summary Get paytable
// @Tags static
// @Consume application/json
// @Description Retrieves base paytable.
// @Produce  json
// @Success 200 {object} api.ReelsResponse
// @Failure 400 {object} errs.ErrResp
// @Failure 500 {object} errs.ErrResp
// @Router /static/paytable [get]
func (h *Handler) GetPaytable(c echo.Context) error {
	return c.JSON(http.StatusOK, api.PaytableResponse{Paytable: game.BasePaytable})
}
