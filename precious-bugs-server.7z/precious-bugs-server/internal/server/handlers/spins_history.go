package handlers

import (
	"net/http"

	"PR_BUGS/api"
	"PR_BUGS/internal/errs"
	"PR_BUGS/utils"
	"github.com/labstack/echo/v4"
)

// @Summary Get free spins
// @Tags core
// @Consume application/json
// @Description Retrieves user's available free spins
// @Param session_token query string true "session token"
// @Param game query string true "game name"
// @Produce  json
// @Success 200 {object} api.HistoryResponse
// @Failure 400 {object} errs.ErrResp
// @Failure 500 {object} errs.ErrResp
// @Router /core/spins_history [get]
func (h *Handler) GetSpinsHistory(c echo.Context) error {
	sessionToken := c.QueryParam("session_token")
	if utils.Empty(sessionToken) {
		h.log.Error("input session_token is empty")
		return c.JSON(http.StatusBadRequest, errs.BadParamInBodyErr)
	}

	req := &api.HistoryRequest{
		SessionToken: api.Token(sessionToken),
	}

	history, err := h.services.UserService.SpinsHistory(req)
	if err != nil {
		h.log.WithError(err).Error("failed to get spins history from user service")
		myErr := errs.GetMyErr(err)
		return c.JSON(int(myErr.Code), myErr)
	}

	return c.JSON(http.StatusOK, history)
}
