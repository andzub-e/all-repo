package server

// HTTP is store all info about http server connection
type Config struct {
	Host           string `env:"PR_BUGS_HOST,required"`
	Port           string `env:"PR_BUGS_PORT,required"`
	SSL            bool   `env:"PR_BUGS_SSL,required"`
	ServerCertPath string `env:"PR_BUGS_CERT_PATH" envDefault:""`
	ServerKeyPath  string `env:"PR_BUGS_CERT_KEY" envDefault:""`
}
