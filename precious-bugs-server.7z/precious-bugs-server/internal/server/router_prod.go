//go:build prod
// +build prod

package server

import (
	"PR_BUGS/internal/server/handlers"
	"github.com/labstack/echo/v4"
)

func AddRoutes(r *echo.Echo, handlers *handlers.Handler) {}
