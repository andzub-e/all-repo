package betoverlordmock

import (
	"fmt"

	types "PR_BUGS/api"
	"PR_BUGS/internal/models"
)

var (
	BaseWagerLevels = types.WagerLevels{20, 30, 40, 50, 60, 100, 500, 1000, 2000, 2500}
	BaseCurrency    = "XTS"
	BaseBalance     = 10000
	BaseWager       = 100
)

const idPrefix = "id_for_"

var betlordMockDB map[string]*models.User

func init() {
	betlordMockDB = make(map[string]*models.User)
}

func GetState(sessionid string) (models.User, error) {
	userID := idPrefix + sessionid

	user, ok := betlordMockDB[userID]
	if !ok {
		user = &models.User{
			State: types.SessionState{
				Username:        types.Username("username_" + sessionid),
				Balance:         types.CurrencyAmount(BaseBalance),
				Currency:        types.CurrencyType(BaseCurrency),
				LastWagerID:     types.WagerID("no id"),
				LastWagerAmount: types.CurrencyAmount(0),
				TotalWins:       types.CurrencyAmount(0),
				SessionToken:    types.Token("some token"),
				DefaultWager:    types.DefaultWager(BaseWager),
				Window:          types.ReelWindow{},
				Reels:           types.ReelState{},
				Payouts:         types.Payouts{},
				BonusStates:     types.BonusStates{},
				WagerLevels:     BaseWagerLevels,
				UserID:          userID,
				Operator:        "some operator",
				OperatorToken:   "some operator token",
				FreespinID:      "",
			},
		}

		betlordMockDB[userID] = user
	}

	user.State.TotalWins = 0

	return *user, nil
}

func PlaceBet(u *models.User, sessionID string, wager types.CurrencyAmount) error {
	// request to pitlord to open bet

	userID := idPrefix + sessionID
	userState, ok := betlordMockDB[userID]
	if !ok {
		return fmt.Errorf("no such user in betlord db, id: %s", userID)
	}

	userState.State.Balance -= wager
	u.State.Balance -= wager
	u.State.LastWagerAmount = wager

	return nil
}

func CloseBet(u *models.User, sessionID string, wager types.CurrencyAmount) error {
	// request to pitlord to close bet

	userID := idPrefix + sessionID
	userState, ok := betlordMockDB[userID]
	if !ok {
		return fmt.Errorf("no such user in betlord db, id: %s", userID)
	}

	userState.State.Balance += wager

	return nil
}

func SaveSpin(u *models.User, sessionID string) error {
	//request to overlord to save spin info

	userID := idPrefix + sessionID
	userState, ok := betlordMockDB[userID]
	if !ok {
		return fmt.Errorf("no such user in betlord db, id: %s", userID)
	}

	userState.State.BonusStates = u.State.BonusStates
	userState.State.Reels = u.State.Reels
	userState.State.TotalWins = u.State.TotalWins
	userState.State.Window = u.State.Window
	userState.State.Payouts = u.State.Payouts

	return nil
}
