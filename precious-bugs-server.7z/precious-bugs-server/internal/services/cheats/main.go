//go:build !prod
// +build !prod

package cheats

import (
	"PR_BUGS/api"
	"PR_BUGS/internal/core"
	"PR_BUGS/repository"
	"github.com/sirupsen/logrus"
)

type CheatsService interface {
	NoWin(req *api.CheatsNoWinRequest) error
	Bonus(req *api.CheatBonusRequest) error
	CustomStops(req *api.CheatCustomStopsRequest) error
}

type Service struct {
	log  *logrus.Entry
	core *core.Core
	repo *repository.Repository
}

func NewService(logger *logrus.Entry, core *core.Core, repo *repository.Repository) CheatsService {
	return &Service{
		log:  logger,
		core: core,
		repo: repo,
	}
}
