//go:build !prod
// +build !prod

package cheats

import (
	"PR_BUGS/api"
	"PR_BUGS/cache"
	"PR_BUGS/game"
	"PR_BUGS/internal/core"
)

func (s *Service) CustomStops(req *api.CheatCustomStopsRequest) error {
	err := s.core.ValidateStops(&core.ValidateStopsParams{
		Stops: req.Stops,
		Reels: game.BaseReels,
	})
	if err != nil {
		s.log.WithError(err).Error("stops validation failed")
		return err
	}

	state := game.ReelState{
		Stops:        req.Stops,
		IsCheatStops: true,
	}

	err = cache.Cache.Set(string(req.SessionToken), state)
	if err != nil {
		s.log.WithError(err).Error("failed to add state to cache")
		return err
	}

	return nil
}
