//go:build !prod
// +build !prod

package cheats

import (
	"PR_BUGS/api"
	"PR_BUGS/cache"
	"PR_BUGS/game"
	"PR_BUGS/internal/core"
)

func (s *Service) NoWin(req *api.CheatsNoWinRequest) error {
	stops, err := s.core.CheatNoWinStops(&core.CheatNoWinStops{})
	if err != nil {
		s.log.WithError(err).Error("failed to cheat no win stops")
		return err
	}

	state := game.ReelState{
		Stops:        stops,
		IsCheatStops: true,
	}

	err = cache.Cache.Set(string(req.SessionToken), state)
	if err != nil {
		s.log.WithError(err).Error("failed to add state to cache")
		return err
	}

	return nil
}
