package user

import (
	"net/http"
	"time"

	"PR_BUGS/api"
	"PR_BUGS/internal/betoverlord"
	"PR_BUGS/internal/errs"
	"PR_BUGS/utils"
)

func (s *Service) Wager(req *api.PlaceWagerRequest) (api.PlaceWagerResponse, error) {
	var resp api.PlaceWagerResponse

	cli, err := betoverlord.NewClient()
	if err != nil {
		s.log.WithError(err).Error("failed to create betlord grpc client")
		return resp, errs.InternalServerErr
	}
	defer cli.CloseConn()

	state, err := s.GetUserState(&GetUserStateParams{SessionID: string(req.SessionToken)})
	if err != nil {
		return api.PlaceWagerResponse{}, err
	}

	user := s.core.BaseUser()
	user.State.UserID = state.UserID

	user.State.SpinTime.Start = time.Now().UTC()

	if !utils.Empty(string(req.FreeSpinID)) {
		s.log.Info("stage: OPEN FREE BET")
		err = cli.OpenFreeBet(user, &betoverlord.OpenFreeBetParams{
			SessinToken: string(req.SessionToken),
			FreeBetID:   string(req.FreeSpinID),
			Value:       int64(req.Wager),
		})
		if err != nil {
			s.log.WithError(err).Error("failed to open free bet")
			return resp, err
		}

	} else {
		s.log.Info("stage: OPEN BET")
		err = cli.OpenBet(user, &betoverlord.OpenBetParams{
			SessionToken: string(req.SessionToken),
			Currency:     string(req.Currency),
			Value:        int64(req.Wager),
		})
		if err != nil {
			httpErr := errs.GetMyErr(err)

			switch httpErr.Code {
			case http.StatusPaymentRequired:
				s.log.Warn("insufficient user balance. generate no win stops")
				user.State.Reels.Stops = s.core.StopsNoWin()
				return user.State, errs.BalanceTooLowErr
			default:
				s.log.WithError(err).Error("failed to open bet")
				return resp, err
			}
		}
	}

	s.log.Infof("balance after bet opened: %d", user.State.Balance)

	s.log.Info("stage: EXEC SPIN")
	err = s.core.ExecSpin(user, false)
	if err != nil {
		s.log.WithError(err).Error("failed to exec spin")
		return resp, errs.InternalServerErr
	}

	s.log.Info("stage: CLOSE BET")
	err = cli.CloseBet(user, user.State.TotalWins)
	if err != nil {
		s.log.WithError(err).Error("failed to close bet")
		return resp, err
	}

	user.State.SpinTime.Finish = time.Now().UTC()

	s.log.Info("stage: SAVE SPIN")
	err = s.repo.SaveHistory(user)
	if err != nil {
		s.log.WithError(err).Error("failed to save spin")
		return resp, err
	}

	return user.State, nil
}
