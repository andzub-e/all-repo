package user

import (
	"PR_BUGS/api"
	"PR_BUGS/internal/betoverlord"
	"PR_BUGS/internal/core"
	"PR_BUGS/internal/errs"
)

type MockParams struct {
	Game      string `json:"game"`
	UserID    string `json:"user"`
	Token     string `json:"token"`
	Lang      string `json:"lang"`
	PlayMode  string `json:"playMode"`
	Device    string `json:"device"`
	Currency  string `json:"currency"`
	Operator  string `json:"operator"`
	ReturnURL string `json:"return_url"`
}

type GetUserStateParams struct {
	SessionID string `json:"session_id" swaggertype:"string"`
	Operator  string `json:"operator"`
	Game      string `json:"game"`
	Params    []byte `json:"params"`
}

func (s *Service) GetUserState(req *GetUserStateParams) (api.StateResponse, error) {
	var resp api.StateResponse

	cli, err := betoverlord.NewClient()
	if err != nil {
		s.log.WithError(err).Error("failed to create betlord grpc client")
		return resp, errs.InternalServerErr
	}
	defer cli.CloseConn()

	s.log.Infof("GetUserState req: %s, %s, %s", req.Game, req.Operator, req.Params)

	user, err := s.core.LookUpOrCreateUser(cli, &core.LookUpOrCreateUserParams{
		SessionID: req.SessionID,
		Operator:  req.Operator,
		Game:      req.Game,
		Params:    req.Params,
	})
	if err != nil {
		s.log.WithError(err).Error("failed to init betlord user state")
		return resp, err
	}

	resp.SessionState, err = s.repo.GetState(user)

	return resp, err
}
