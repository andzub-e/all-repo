package user

import (
	"PR_BUGS/api"
	"PR_BUGS/config"
	"PR_BUGS/internal/core"
	"PR_BUGS/repository"
	"github.com/sirupsen/logrus"
)

type UserService interface {
	GetUserState(req *GetUserStateParams) (api.StateResponse, error)
	Wager(req *api.PlaceWagerRequest) (api.PlaceWagerResponse, error)
	GetFreeSpins(req *api.GetFreeSpinsRequest) (api.GetFreeSpinsResponse, error)
	IncrementBonusIndex(req *api.IncrementBonusIndexRequest) error
	SpinsHistory(req *api.HistoryRequest) (api.HistoryResponse, error)
}

type Service struct {
	cfg  config.Config
	log  *logrus.Entry
	core *core.Core
	repo *repository.Repository
}

func NewService(cfg config.Config, core *core.Core, repo *repository.Repository) UserService {
	return &Service{
		cfg:  cfg,
		log:  cfg.Log(),
		core: core,
		repo: repo,
	}
}
