package user

import (
	"PR_BUGS/api"
	"PR_BUGS/internal/betoverlord"
	"PR_BUGS/internal/errs"
)

func (s *Service) GetFreeSpins(req *api.GetFreeSpinsRequest) (api.GetFreeSpinsResponse, error) {
	var resp api.GetFreeSpinsResponse

	cli, err := betoverlord.NewClient()
	if err != nil {
		s.log.WithError(err).Error("failed to create betlord grpc client")
		return resp, errs.InternalServerErr
	}

	user := s.core.BaseUser()

	resp.FreeSpins, err = cli.GetAvailableFreeBets(user, string(req.SessionToken))
	if err != nil {
		s.log.WithError(err).Error("lord cli: failed to get user free spins")
		return resp, err
	}

	return resp, nil
}
