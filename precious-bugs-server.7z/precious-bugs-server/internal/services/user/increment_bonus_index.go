package user

import (
	"PR_BUGS/api"
)

func (s *Service) IncrementBonusIndex(req *api.IncrementBonusIndexRequest) error {
	// TODO check to req this method
	//cli, err := betoverlord.NewClient()
	//if err != nil {
	//	s.log.WithError(err).Error("failed to create betlord grpc client")
	//	return errs.InternalServerErr
	//}
	//defer cli.CloseConn()

	//user := s.core.BaseUser()
	//
	//err = cli.IncrementBonusIndex(user, string(req.SessionToken))
	//if err != nil {
	//	s.log.WithError(err).Error("failed to increment bonus spins viewed index")
	//	return err
	//}

	return nil
}
