package user

import (
	"PR_BUGS/api"
	"PR_BUGS/internal/betoverlord"
)

//func (s *Service) SpinsHistory(req *api.HistoryRequest) (api.HistoryResponse, error) {
//	var resp api.HistoryResponse
//
//	cli, err := betoverlord.NewClient()
//	if err != nil {
//		s.log.WithError(err).Error("failed to create betlord grpc client")
//		return resp, errs.InternalServerErr
//	}
//	defer cli.CloseConn()
//
//	resp.Spins, err = cli.GetSpinHistory(string(req.SessionToken))
//	if err != nil {
//		s.log.WithError(err).Error("failed to get spins history")
//		return resp, err
//	}
//
//	for i := range resp.Spins {
//		sp := resp.Spins[i]
//		sp.Window = sp.ReelsState.Window()
//		sp.Payouts = sp.Window.Results(game.CurrencyAmount(sp.Bet), game.BasePaytable)
//	}
//
//	return resp, nil
//}

func (s *Service) SpinsHistory(req *api.HistoryRequest) (api.HistoryResponse, error) {
	client, err := betoverlord.NewClient()
	if err != nil {
		return api.HistoryResponse{}, err
	}

	state, err := client.GetStateBySessionToken(string(req.SessionToken))
	if err != nil {
		return api.HistoryResponse{}, err
	}
	return s.repo.GetHistory(state.UserId, 0)
}
