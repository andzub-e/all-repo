//go:build !prod
// +build !prod

package services

import (
	"PR_BUGS/config"
	"PR_BUGS/internal/core"
	"PR_BUGS/internal/services/cheats"
	"PR_BUGS/internal/services/user"
	"PR_BUGS/repository"
)

type Service struct {
	UserService   user.UserService
	CheatsService cheats.CheatsService
}

func NewService(cfg config.Config, core *core.Core, repo *repository.Repository) *Service {
	return &Service{
		UserService:   user.NewService(cfg, core, repo),
		CheatsService: cheats.NewService(cfg.Log(), core, repo),
	}
}
