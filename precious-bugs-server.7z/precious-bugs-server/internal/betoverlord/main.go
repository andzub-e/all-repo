package betoverlord

import (
	"crypto/tls"

	"PR_BUGS/config"
	"PR_BUGS/internal/proto/api"
	"github.com/sirupsen/logrus"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
)

const (
// overlordHost = "games.heronbyte.com/overlord"
// overlordHost = "51.15.117.238"
// overlordPort = "7000"

// packagename = "betoverlord"
)

type jsonUnmarshalPair struct {
	src       []byte
	baseValue []byte
	dest      interface{}
	info      string
}

type jsonMarshalPair struct {
	src  interface{}
	dest *[]byte
	info string
}

type OverlordClient struct {
	log    *logrus.Entry
	client api.OverlordClient
	conn   *grpc.ClientConn
}

type Config struct {
	dialOpts []grpc.DialOption
	addr     string
	log      *logrus.Entry
}

var lordConfig *Config

func InitRPCConfig(cfg config.Config) error {
	if lordConfig == nil {
		lordConfig = &Config{}
	}

	lordConfig.addr = cfg.RPC().Addr()
	lordConfig.log = cfg.Log()
	if cfg.RPC().SSL {
		// crds, err := credentials.NewClientTLSFromFile(cfg.RPC().CertPath, "")
		// if err != nil {
		// 	return err
		// }
		tlsCfg := &tls.Config{
			InsecureSkipVerify: true,
		}
		lordConfig.dialOpts = append(lordConfig.dialOpts, grpc.WithTransportCredentials(credentials.NewTLS(tlsCfg)))
	} else {
		lordConfig.dialOpts = append(lordConfig.dialOpts, grpc.WithInsecure())
	}

	return nil
}

func NewClient() (*OverlordClient, error) {
	conn, err := grpc.Dial(lordConfig.addr, lordConfig.dialOpts...)
	if err != nil {
		return nil, err
	}

	return &OverlordClient{
		log:    lordConfig.log,
		conn:   conn,
		client: api.NewOverlordClient(conn),
	}, nil
}

func (oc *OverlordClient) CloseConn() error {
	return oc.conn.Close()
}
