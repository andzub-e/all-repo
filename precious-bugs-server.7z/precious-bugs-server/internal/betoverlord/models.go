package betoverlord

type UserState struct {
	UserId        string  `json:"user_id" example:"some_id1"`
	Operator      string  `json:"operator,omitempty" example:"mock"`
	Game          string  `json:"THE_EJAW_SLOT" example:"test"`
	Username      string  `json:"username" example:"mock_state"`
	OperatorToken string  `json:"operator_token" example:""`
	SessionToken  string  `json:"session_token" example:"9eedb051-32f6-4e24-9caa-93fa63685a95"`
	Balance       int64   `json:"balance" example:"9997170"`
	Currency      string  `json:"currency" example:"XTS"`
	IsOpened      bool    `json:"is_opened" example:"false"`
	DefaultWager  int64   `json:"default_wager" example:"2000"`
	WagerLevels   []int64 `json:"wager_levels" example:"100,200,500,700,1000,1500,2000,2500,5000,10000,25000,50000,100000,150000,250000,500000"`
}
