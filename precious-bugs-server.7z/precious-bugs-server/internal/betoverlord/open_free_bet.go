package betoverlord

import (
	"context"

	types "PR_BUGS/api"
	"PR_BUGS/internal/errs"
	"PR_BUGS/internal/models"
	"PR_BUGS/internal/proto/api"
	"github.com/google/uuid"
)

type OpenFreeBetParams struct {
	SessinToken string
	FreeBetID   string
	Value       int64
}

func (oc *OverlordClient) OpenFreeBet(u *models.User, params *OpenFreeBetParams) error {
	u.State.RoundID = uuid.New().String()

	betout, err := oc.client.OpenFreeBet(context.Background(), &api.OpenFreeBetIn{
		SessionToken: params.SessinToken,
		FreeBetId:    params.FreeBetID,
		RoundId:      u.State.RoundID,
	})
	if err != nil {
		oc.log.WithError(err).Error("lord cli: failed to open free bet")
		return errs.InternalServerErr
	}

	u.State.StartBalance = types.CurrencyAmount(betout.Balance)
	u.State.Balance = types.CurrencyAmount(betout.Balance)
	u.State.Currency = types.CurrencyType(betout.Currency)
	u.State.FreespinID = types.FreespinID(params.FreeBetID)
	u.State.LastWagerAmount = types.CurrencyAmount(params.Value)
	u.State.SessionToken = types.Token(params.SessinToken)
	u.State.TransactionID = betout.TransactionId

	return nil
}
