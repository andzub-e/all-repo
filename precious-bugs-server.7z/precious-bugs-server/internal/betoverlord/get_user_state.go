package betoverlord

import (
	"PR_BUGS/internal/proto/api"
	"context"
)

func (o *OverlordClient) GetStateBySessionToken(token string) (*UserState, error) {
	o.log.Info("lord: GetStateBySessionToken starting...")

	in := &api.GetStateBySessionTokenIn{SessionToken: token}

	overlordState, err := o.client.GetStateBySessionToken(context.Background(), in)
	if err != nil {
		return nil, err
	}

	state := &UserState{
		UserId:        overlordState.UserId,
		Operator:      overlordState.Operator,
		Game:          overlordState.Game,
		Username:      overlordState.Username,
		OperatorToken: overlordState.OperatorToken,
		SessionToken:  overlordState.SessionToken,
		Balance:       overlordState.Balance,
		Currency:      overlordState.Currency,
		IsOpened:      overlordState.IsOpened,
		DefaultWager:  overlordState.DefaultWager,
		WagerLevels:   overlordState.WagerLevels,
	}

	return state, nil

}

func (oc *OverlordClient) GetState(operator, game string, params []byte) (*UserState, error) {
	in := &api.InitUserStateIn{
		Operator: operator,
		Game:     game,
		Params:   params,
	}

	oc.log.Infof("lord state request in: opeartor - %s, game - %s, params - %s", in.Operator, in.Game, in.Params)
	overlordState, err := oc.client.InitUserState(context.Background(), in)
	if err != nil {
		oc.log.WithError(err).Error("lord cli: failed to get state")
		return nil, err
	}

	return oc.GetStateBySessionToken(overlordState.SessionToken)
}
