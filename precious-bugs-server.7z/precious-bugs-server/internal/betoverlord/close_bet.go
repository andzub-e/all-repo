package betoverlord

import (
	"context"

	types "PR_BUGS/api"
	"PR_BUGS/internal/errs"
	"PR_BUGS/internal/models"
	"PR_BUGS/internal/proto/api"
)

func (oc *OverlordClient) CloseBet(u *models.User, total types.CurrencyAmount) error {
	oc.log.Infof("session token on close bet: %s", u.State.SessionToken)

	betout, err := oc.client.CloseBet(context.Background(), &api.CloseBetIn{
		TransactionId: u.State.TransactionID,
		SessionToken:  string(u.State.SessionToken),
		Currency:      string(u.State.Currency),
		Value:         int64(total),
	})
	if err != nil {
		oc.log.WithError(err).Error("lord cli: failed to close bet")
		return errs.InternalServerErr
	}

	u.State.Balance = types.CurrencyAmount(betout.Balance)
	u.State.Currency = types.CurrencyType(betout.Currency)

	return nil
}
