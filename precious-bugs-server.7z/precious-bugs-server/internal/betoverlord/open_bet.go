package betoverlord

import (
	"context"

	types "PR_BUGS/api"
	"PR_BUGS/internal/errs"
	"PR_BUGS/internal/models"
	"PR_BUGS/internal/proto/api"
	"github.com/google/uuid"
	"google.golang.org/grpc/status"
)

type OpenBetParams struct {
	SessionToken string
	Currency     string
	Value        int64
}

func (oc *OverlordClient) OpenBet(u *models.User, params *OpenBetParams) error {
	u.State.RoundID = uuid.New().String()

	openBetIn := api.OpenBetIn{
		SessionToken: params.SessionToken,
		Currency:     params.Currency,
		Value:        params.Value,
		RoundId:      u.State.RoundID,
	}

	oc.log.Infof("open bet in struct: operatorToken=%s, roundID=%s, currency=%s, value=%d",
		openBetIn.SessionToken,
		openBetIn.RoundId,
		openBetIn.Currency,
		openBetIn.Value,
	)

	betout, err := oc.client.OpenBet(context.Background(), &openBetIn)
	if err != nil {
		oc.log.WithError(err).Error("lord cli: failed to open bet")

		code, _ := status.FromError(err)
		switch code.Code() {
		case LowBalance:
			u.State.Error = errs.BalanceTooLowErr.Message
			return errs.BalanceTooLowErr
		default:
			return errs.InternalServerErr
		}
	}

	u.State.StartBalance = types.CurrencyAmount(betout.Balance + params.Value)
	u.State.Balance = types.CurrencyAmount(betout.Balance)
	u.State.Currency = types.CurrencyType(betout.Currency)
	u.State.LastWagerAmount = types.CurrencyAmount(params.Value)
	u.State.SessionToken = types.Token(params.SessionToken)
	u.State.TransactionID = betout.TransactionId

	return nil
}
