package betoverlord

import (
	"context"

	types "PR_BUGS/api"
	"PR_BUGS/internal/errs"
	"PR_BUGS/internal/models"
	"PR_BUGS/internal/proto/api"
)

func (oc *OverlordClient) GetAvailableFreeBets(u *models.User, sessionToken string) ([]*types.FreeSpin, error) {
	betsout, err := oc.client.GetAvailableFreeBets(context.Background(), &api.GetAvailableFreeBetsIn{
		SessionToken: sessionToken,
	})
	if err != nil {
		oc.log.WithError(err).Error("lord cli: failed to get available free bets")
		return nil, errs.InternalServerErr
	}

	oc.log.Infof("lord response: free spins amount = %d", len(betsout.FreeBets))

	res := make([]*types.FreeSpin, 0, len(betsout.FreeBets))

	for _, v := range betsout.FreeBets {
		res = append(res, &types.FreeSpin{
			ID:        v.Id,
			Currency:  v.Currency,
			Game:      v.Game,
			Value:     int(v.Value),
			SpinCount: int(v.SpinCount),
		})
	}

	return res, nil
}
