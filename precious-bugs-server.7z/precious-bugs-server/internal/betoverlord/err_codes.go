package betoverlord

import "google.golang.org/grpc/codes"

const (
	LowBalance codes.Code = 100
)
