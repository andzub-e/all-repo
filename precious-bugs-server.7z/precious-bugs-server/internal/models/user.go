package models

import (
	types "PR_BUGS/api"
)

type User struct {
	State types.SessionState
}
