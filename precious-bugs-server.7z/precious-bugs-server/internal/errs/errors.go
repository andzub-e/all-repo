package errs

import (
	"errors"
	"net/http"
)

type ErrResp struct {
	Message string `json:"message" example:"INTERNAL_SERVER_ERROR"`
	Code    int    `json:"code" example:"500"`
} //@name ErrResp

func (e ErrResp) ToError() error {
	return errors.New(e.Message)
}

func (e ErrResp) Error() string {
	return e.Message
}

var (
	InternalServerErr = ErrResp{"INTERNAL_SERVER_ERROR", http.StatusInternalServerError}
	BadParamInBodyErr = ErrResp{"BAD_PARAM_IN_BODY", http.StatusBadRequest}
	BalanceTooLowErr  = ErrResp{"INSUFFICIENT_FUNDS", http.StatusPaymentRequired}
)

func GetMyErr(e interface{}) ErrResp {
	if o, ok := e.(ErrResp); ok {
		return o
	}
	return InternalServerErr
}
