## Dicey Hustle Game Engine

Dicey Hustle Game Engine is a REST API for slot game. This service interacts with bet-overlord service for integrations with different casino operators.

------

#### Requirements

- Golang 1.12+
- Docker (optional)

------

#### Environments

| Name                   | Default               | Description                         |
| ---------------------- | --------------------- | ----------------------------------- |
| DICEY_HUSTLE_HOST      | 0.0.0.0               | server host                         |
| DICEY_HUSTLE_PORT      | 8086                  | server port                         |
| DICEY_HUSTLE_SSL       | false                 | If you use https, it must be 'true' |
| DICEY_HUSTLE_CERT_PATH | ./ssl/diceyhustle.crt | Path to ssl certificate             |
| DICEY_HUSTLE_CERT_KEY  | ./ssl/diceyhustle.key | Path to ssl certificate key         |

------

#### Now to run

Setup all required environments from table and run commands for build and run:

```bash
go build -tags prod -o PR_BUGS-town ./cmd/main.go
./PR_BUGS-town
```

For Docker run command:

```bash
docker-compose up -d
```

------

#### Game flow

Every game begins from request to **/core/state** endpoint. In response you get **session_token** for next requests. 

------

### Endpoints descriptions

**State**

Returns user state from bet-overlord service.

Endpoint: */core/state*

Method: *GET*

*Request query parameters:*

| Parameter name | Type   | Description                                  | Required |
| -------------- | ------ | -------------------------------------------- | -------- |
| session_id     | string | session id from game client                  | required |
| operator       | string | operator name                                | required |
| game           | string | game id                                      | required |
| params         | string | special operator parameters from game client | required |

*Response example:*

status 200

```json
{
  "THE_EJAW_SLOT": "string",
  "balance": 0,
  "base_spins_bonus_triggered": {
    "total_spins": 0,
    "triggered_spins_info": [
      {
        "payline": 0,
        "payline_independent": true,
        "spins_amount": 0,
        "symbol": "string"
      }
    ]
  },
  "bonus_games": {
    "fortune_multiplier_index": 0,
    "spins_results": [
      {
        "additionalSpins": {
          "total_spins": 0,
          "triggered_spins_info": [
            {
              "payline": 0,
              "payline_independent": true,
              "spins_amount": 0,
              "symbol": "string"
            }
          ]
        },
        "bonus_spins_left": 100,
        "current_win_amount": 100,
        "payouts": {
          "payout_for_spin": 100,
          "spin_payouts": [
            {
              "amount": 100,
              "count": 5,
              "cycle": 0,
              "payline": 0,
              "start_reel_index": 0,
              "symbol": "A"
            }
          ]
        },
        "reels": {
          "is_autospin": true,
          "is_cheat_stops": true,
          "is_turbospin": true,
          "stops": [
            11,
            22,
            33,
            44,
            55
          ]
        },
        "window": [
          [
            "A"
          ]
        ]
      }
    ],
    "total_win": 0,
    "win": 0
  },
  "bonus_index": 0,
  "currency": 0,
  "default_wager": 0,
  "error": "string",
  "freespinid": 0,
  "last_wager": 0,
  "payouts": {
    "payout_for_spin": 100,
    "spin_payouts": [
      {
        "amount": 100,
        "count": 5,
        "cycle": 0,
        "payline": 0,
        "start_reel_index": 0,
        "symbol": "A"
      }
    ]
  },
  "reels": {
    "is_autospin": true,
    "is_cheat_stops": true,
    "is_turbospin": true,
    "stops": [
      11,
      22,
      33,
      44,
      55
    ]
  },
  "session_token": "string",
  "total_wins": 0,
  "username": "string",
  "wager_levels": [
    0
  ],
  "wallet_play_id": "string",
  "window": [
    [
      "string"
    ]
  ]
}
```

status 400

```json
{ 
    "error":"BAD_PARAM_IN_BODY", 
    "code": 400
}
```

status 500

```json
{ 
    "error":"INTERNAL_SERVER_ERROR", 
    "code": 500
}
```

------

**Wager**

Make a bet (spin)

Endpoint: */core/wager*

Method: *POST*

*Request body parameters:*

| Parameter name | Type    | Description                   | Required |
| -------------- | ------- | ----------------------------- | -------- |
| session_token  | string  | token for current session     | required |
| wager          | integer | amount of money for bet       | required |
| currency       | string  | current currency              | required |
| freespin_id    | string  | id of a free spin from casino | optional |

*Response example:*

status 200

```json
{
  "THE_EJAW_SLOT": "string",
  "balance": 0,
  "base_spins_bonus_triggered": {
    "total_spins": 0,
    "triggered_spins_info": [
      {
        "payline": 0,
        "payline_independent": true,
        "spins_amount": 0,
        "symbol": "string"
      }
    ]
  },
  "bonus_games": {
    "fortune_multiplier_index": 0,
    "spins_results": [
      {
        "additionalSpins": {
          "total_spins": 0,
          "triggered_spins_info": [
            {
              "payline": 0,
              "payline_independent": true,
              "spins_amount": 0,
              "symbol": "string"
            }
          ]
        },
        "bonus_spins_left": 100,
        "current_win_amount": 100,
        "payouts": {
          "payout_for_spin": 100,
          "spin_payouts": [
            {
              "amount": 100,
              "count": 5,
              "cycle": 0,
              "payline": 0,
              "start_reel_index": 0,
              "symbol": "A"
            }
          ]
        },
        "reels": {
          "is_autospin": true,
          "is_cheat_stops": true,
          "is_turbospin": true,
          "stops": [
            11,
            22,
            33,
            44,
            55
          ]
        },
        "window": [
          [
            "A"
          ]
        ]
      }
    ],
    "total_win": 0,
    "win": 0
  },
  "bonus_index": 0,
  "currency": 0,
  "default_wager": 0,
  "error": "string",
  "freespinid": 0,
  "last_wager": 0,
  "payouts": {
    "payout_for_spin": 100,
    "spin_payouts": [
      {
        "amount": 100,
        "count": 5,
        "cycle": 0,
        "payline": 0,
        "start_reel_index": 0,
        "symbol": "A"
      }
    ]
  },
  "reels": {
    "is_autospin": true,
    "is_cheat_stops": true,
    "is_turbospin": true,
    "stops": [
      11,
      22,
      33,
      44,
      55
    ]
  },
  "session_token": "string",
  "total_wins": 0,
  "username": "string",
  "wager_levels": [
    0
  ],
  "wallet_play_id": "string",
  "window": [
    [
      "string"
    ]
  ]
}
```
status 400

```json
{
  "code": 400,
  "message": "BAD_PARAM_IN_BODY"
}
```

status 500

```json
{ 
    "error":"INTERNAL_SERVER_ERROR", 
    "code": 500
}
```

------

**History**

Retrieves user's spins history. Last 50 items.

Endpoint: */core/spins_history*

Method: *GET*

*Request query parameters:*

| Parameter name | Type   | Description               | Required |
| -------------- | ------ | ------------------------- | -------- |
| session_token  | string | token for current session | true     |

Response example:

status 200

```json
{
  "spins_history": [
    {
      "balance": 0,
      "base_pay": 0,
      "bet": 0,
      "bonus_index": 0,
      "bonus_pay": 0,
      "bonus_reels": {
        "fortune_multiplier_index": 0,
        "spins_results": [
          {
            "additionalSpins": {
              "total_spins": 0,
              "triggered_spins_info": [
                {
                  "payline": 0,
                  "payline_independent": true,
                  "spins_amount": 0,
                  "symbol": "string"
                }
              ]
            },
            "bonus_spins_left": 100,
            "current_win_amount": 100,
            "payouts": {
              "payout_for_spin": 100,
              "spin_payouts": [
                {
                  "amount": 100,
                  "count": 5,
                  "cycle": 0,
                  "payline": 0,
                  "start_reel_index": 0,
                  "symbol": "A"
                }
              ]
            },
            "reels": {
              "is_autospin": true,
              "is_cheat_stops": true,
              "is_turbospin": true,
              "stops": [
                11,
                22,
                33,
                44,
                55
              ]
            },
            "window": [
              [
                "A"
              ]
            ]
          }
        ],
        "total_win": 0,
        "win": 0
      },
      "currency": "string",
      "final_balance": 0,
      "finish_time": 0,
      "freespin_id": "string",
      "game": "string",
      "id": "string",
      "payouts": {
        "payout_for_spin": 100,
        "spin_payouts": [
          {
            "amount": 100,
            "count": 5,
            "cycle": 0,
            "payline": 0,
            "start_reel_index": 0,
            "symbol": "A"
          }
        ]
      },
      "reels": {
        "is_autospin": true,
        "is_cheat_stops": true,
        "is_turbospin": true,
        "stops": [
          11,
          22,
          33,
          44,
          55
        ]
      },
      "round_id": "string",
      "start_time": 0,
      "transaction_id": "string",
      "window": [
        [
          "A"
        ]
      ]
    }
  ]
}
```

status 400

```json
{ 
    "error":"BAD_PARAM_IN_BODY", 
    "code": 400
}
```

status 500

```json
{ 
    "error":"INTERNAL_SERVER_ERROR", 
    "code": 500
}
```

------

**Free spins**

Retrieves user's available free spins

Endpoint: */core/free_spins*

Method: *GET*

*Request query parameters:*

| Parameter name | Type   | Description               | Required |
| -------------- | ------ | ------------------------- | -------- |
| session_token  | string | token for current session | true     |

*Response example:*

status 200

```json
{
  "freespins": [
    {
      "currency": "UAH",
      "expire_date": "string",
      "game": "test",
      "id": "some_id",
      "spin_count": 2,
      "value": 10
    }
  ]
}
```

status 400

```json
{ 
    "error":"BAD_PARAM_IN_BODY", 
    "code": 400
}
```

status 500

```json
{ 
    "error":"INTERNAL_SERVER_ERROR", 
    "code": 500
}
```

------

**Increment a bonus spins index**

Increment viewed bonus spins index. This index uses for a bonus spins demonstration for a user if a user saw a part of them and closes a browser.

Endpoint: */core/increment_bonus_index*

Method: *POST*

*Request body parameters:*

| Parameter name | Type   | Description               | Required |
| -------------- | ------ | ------------------------- | -------- |
| session_token  | string | token for current session | required |

*Response example:*

status 200

```json
no content
```

status 400

```json
{ 
    "error":"BAD_PARAM_IN_BODY", 
    "code": 400
}
```

status 500

```json
{ 
    "error":"INTERNAL_SERVER_ERROR", 
    "code": 500
}
```

