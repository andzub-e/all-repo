package bot

import (
	"PR_BUGS/game"
	"PR_BUGS/game/constants"
	"PR_BUGS/utils"
)

type TotalResult struct {
	Uid                          string // just to be sure all results are unique
	BaseSpinsAmount              int
	BonusSpinsAmount             int
	BaseWin                      int
	BonusWin                     int
	TotalWin                     int
	TotalSpent                   int
	TotalGamesWithBonus          int
	AverageBonusTrigger          float32
	AverageBonusSpinsAmount      float32
	MaxTriggeredBonusSpinsAmount int
	MaxWin                       int
	Rtp                          float32
	Wager                        int
	Spec                         specificTotalResult
}

type specificTotalResult struct {
	TotalMultipiers                 int
	AverageWheelOfFortuneMultiplier float32
}

type result struct {
	uid              string // same as total results
	payouts          game.Payouts
	baseWin          int
	bonusWin         int
	bonusSpinsAmount int
	totalWin         int
	wager            int
	stops            [constants.ReelCount]game.ReelStop
	window           game.ReelWindow
	bonusGames       game.BonusSpinResults
	spec             specificResult
}

type specificResult struct {
	wheelOfFortuneMultiplier int
}

func (tr *TotalResult) addResult(r result) {
	tr.BaseSpinsAmount++
	tr.BonusSpinsAmount += r.bonusSpinsAmount
	tr.TotalWin += r.totalWin
	tr.TotalSpent += r.wager
	tr.BaseWin += r.baseWin
	tr.BonusWin += r.bonusWin
	if r.bonusSpinsAmount != 0 {
		tr.TotalGamesWithBonus++
	}
	if r.bonusSpinsAmount > tr.MaxTriggeredBonusSpinsAmount {
		tr.MaxTriggeredBonusSpinsAmount = r.bonusSpinsAmount
	}
	if r.totalWin > tr.MaxWin {
		tr.MaxWin = r.totalWin
	}

	tr.Spec.TotalMultipiers += r.spec.wheelOfFortuneMultiplier
}

func (tr *TotalResult) finalizeResults() {
	tr.Rtp = float32(tr.TotalWin) / float32(tr.TotalSpent) * 100 // rtp shows in %
	if tr.BaseSpinsAmount != 0 {
		tr.AverageBonusSpinsAmount = float32(tr.BonusSpinsAmount) / float32(tr.BaseSpinsAmount)
		tr.AverageBonusTrigger = float32(tr.TotalGamesWithBonus) / float32(tr.BaseSpinsAmount)
	}

	if tr.Spec.TotalMultipiers != 0 {
		tr.Spec.AverageWheelOfFortuneMultiplier = float32(tr.TotalGamesWithBonus) / float32(tr.Spec.TotalMultipiers)
	}
}

func (tr *TotalResult) addTotalResult(tre TotalResult) {
	tr.BaseSpinsAmount += tre.BaseSpinsAmount
	tr.BonusSpinsAmount += tre.BonusSpinsAmount
	tr.TotalWin += tre.TotalWin
	tr.TotalSpent += tre.TotalSpent
	tr.TotalGamesWithBonus += tre.TotalGamesWithBonus
	tr.BaseWin += tre.BaseWin
	tr.BonusWin += tre.BonusWin
	tr.MaxWin = utils.Max(tr.MaxWin, tre.MaxWin)
	tr.MaxTriggeredBonusSpinsAmount = utils.Max(tr.MaxTriggeredBonusSpinsAmount, tre.MaxTriggeredBonusSpinsAmount)

	tr.Spec.TotalMultipiers += tre.Spec.TotalMultipiers

	tr.finalizeResults()
}
