package bot

type BotsConfig struct {
	ResultsFilePath            string
	Rounds                     int
	Wager                      int
	WithFileOutputSpinsResult  bool
	WithFileOutputTotalResults bool
	WithPlots                  bool
	WithCSV                    bool
}
