package bot

import (
	"fmt"

	"PR_BUGS/game"
	"PR_BUGS/internal/core"
	"github.com/google/uuid"
	"github.com/sirupsen/logrus"
)

type bot struct {
	botName           string
	log               *logrus.Entry
	core              *core.Core
	writeResult       chan result
	writeTotalResults chan TotalResult
	rounds            int
	wager             int
}

func (b *bot) run() error {
	fmt.Printf("running bot %s with %d rounds...\n", b.botName, b.rounds)

	var err error

	totalResult := TotalResult{
		Uid: uuid.New().String(),
	}

	for i := 0; i < b.rounds; i++ {
		// fmt.Printf("bot %s, round %d\n", b.botName, i+1)

		u := b.core.BaseUser()
		u.State.LastWagerAmount = game.CurrencyAmount(b.wager)
		u.State.StartBalance = 0
		u.State.Balance = 0

		err = b.core.ExecSpin(u, false)
		if err != nil {
			return err
		}

		result := result{
			uid:              uuid.New().String(),
			payouts:          u.State.Payouts,
			baseWin:          int(u.State.Payouts.PayoutForSpin),
			bonusWin:         int(u.State.BonusStates.WinAfterMultiplier),
			bonusSpinsAmount: len(u.State.BonusStates.BonusSpinResults),
			totalWin:         int(u.State.TotalWins),
			wager:            int(u.State.LastWagerAmount),
			stops:            u.State.Reels.Stops,
			window:           u.State.Window,
			bonusGames:       u.State.BonusStates.BonusSpinResults,
			spec: specificResult{
				wheelOfFortuneMultiplier: int(u.State.BonusStates.FortuneMultiplier),
			},
		}

		b.writeResult <- result

		totalResult.addResult(result)
	}

	fmt.Printf("[BOT FINISH] bot %s finished %d rounds\n", b.botName, b.rounds)

	b.writeTotalResults <- totalResult

	return nil
}
