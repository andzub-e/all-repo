package bot

import (
	"fmt"
	"sync"

	"PR_BUGS/config"
	"PR_BUGS/internal/core"
	"github.com/google/uuid"
	"github.com/sirupsen/logrus"
)

type bots struct {
	log              *logrus.Entry
	bots             []bot
	fileWriter       fileWriter
	resultsChan      chan result
	totalResultsChan chan TotalResult
	wager            int
}

func NewBots(cfg *BotsConfig) *bots {
	logbase := config.Log{}
	log := logbase.GetLogEntry()
	fmt.Println("creating bots")
	core := core.NewCore(log)
	var pdf fileWriter = NewDoc(cfg)

	// botsAmount := runtime.NumCPU()
	botsAmount := 1
	roundsPerBot := cfg.Rounds / botsAmount
	if roundsPerBot == 0 {
		roundsPerBot = 1
	}
	resultsChan := make(chan result, cfg.Rounds)
	totalResultsChan := make(chan TotalResult, botsAmount)

	roundsAdded := 0
	b := make([]bot, 0, botsAmount)
	checkTotalRounds := 0 // just to check rounds distribution by bots
	for i := 0; i < botsAmount; i++ {
		if roundsAdded >= cfg.Rounds {
			fmt.Println("exit creation loop")
			break
		}

		tmp := roundsAdded + roundsPerBot
		rounds := roundsPerBot
		if tmp > cfg.Rounds {
			rounds = cfg.Rounds - roundsAdded
		}
		roundsAdded += roundsPerBot

		b = append(b, bot{
			log:               log,
			core:              core,
			writeResult:       resultsChan,
			writeTotalResults: totalResultsChan,
			rounds:            rounds,
			botName:           uuid.New().String(),
			wager:             cfg.Wager,
		})

		checkTotalRounds += rounds
	}

	fmt.Printf("bots rounds: bots amount %d, expected %d, actual %d\n", len(b), cfg.Rounds, checkTotalRounds)

	return &bots{
		log:              log,
		bots:             b,
		fileWriter:       pdf,
		totalResultsChan: totalResultsChan,
		resultsChan:      resultsChan,
		wager:            cfg.Wager,
	}
}

func (bs *bots) Run() error {
	bs.ExportState()
	wg := sync.WaitGroup{}
	wg.Add(len(bs.bots))

	exit := make(chan struct{}, 1)
	wg1 := &sync.WaitGroup{}
	wg1.Add(1)

	go func(wg *sync.WaitGroup) {
		defer wg.Done()
		bs.fileWriter.runWriteResultWorker(bs.resultsChan, exit)
	}(wg1)

	for _, v := range bs.bots {
		go func(b bot, wg *sync.WaitGroup) {
			defer wg.Done()
			err := b.run()
			if err != nil {
				fmt.Println("error: bot execution error")
			}
		}(v, &wg)
	}

	wg.Wait()
	close(bs.totalResultsChan)
	exit <- struct{}{}
	wg1.Wait()

	totalResult := TotalResult{
		Uid: uuid.New().String(),
	}
	for v := range bs.totalResultsChan {
		fmt.Printf("adding total result with id %s\n", v.Uid)
		totalResult.addTotalResult(v)
	}

	fmt.Println("writing total")
	totalResult.Wager = bs.wager
	bs.fileWriter.writeTotalResult(totalResult)
	fmt.Println("total wrote")

	fmt.Println("saving pdf")
	err := bs.fileWriter.saveData()
	if err != nil {
		logrus.WithError(err).Error("failed to save data")
		return err
	}
	fmt.Println("pdf saved")

	bs.fileWriter.exportTerminalData(totalResult)

	return nil
}

// temp func
func (bs *bots) ExportState() {
	fmt.Printf("bots size = %d\n", len(bs.bots))
}
