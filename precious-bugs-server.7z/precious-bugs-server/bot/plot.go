package bot

import (
	"fmt"
	"image/color"

	"gonum.org/v1/plot"
	"gonum.org/v1/plot/plotter"
	"gonum.org/v1/plot/vg"
	"gonum.org/v1/plot/vg/draw"
)

type Plot struct {
	plotValues plotter.XYs
	plotCanv   *plot.Plot
}

func NewPlot(plotSizeExpect int) *Plot {
	return &Plot{
		plotCanv:   plot.New(),
		plotValues: make(plotter.XYs, 0, plotSizeExpect),
	}
}

func (pt *Plot) buildPlot() error {
	pt.plotCanv.Add(plotter.NewGrid())

	pt.plotCanv.Title.Text = "Payouts by spins"
	pt.plotCanv.X.Label.Text = "X"
	pt.plotCanv.Y.Label.Text = "Y"

	// l, err := plotter.NewLine(pt.plotValues)
	// if err != nil {
	// 	return err
	// }

	// l.LineStyle.Width = vg.Points(1)
	// l.LineStyle.Dashes = []vg.Length{vg.Points(5), vg.Points(5)}
	// l.LineStyle.Color = color.RGBA{B: 255, A: 255}

	lpLine, lpPoints, err := plotter.NewLinePoints(pt.plotValues)
	if err != nil {
		return err
	}

	lpLine.Color = color.RGBA{B: 255, A: 255}
	lpPoints.Shape = draw.PyramidGlyph{}
	lpPoints.Color = color.RGBA{R: 255, A: 255}

	fmt.Printf("plot values size = %d\n", len(pt.plotValues))

	pt.plotCanv.Add(lpLine, lpPoints)
	pt.plotCanv.Legend.Add("line points", lpLine, lpPoints)

	return nil
}

func (pt *Plot) savePlot(name string) error {
	return pt.plotCanv.Save(20*vg.Inch, 20*vg.Inch, name)
}

func (pt *Plot) appendPoint(x, y float64) {
	pt.plotValues = append(pt.plotValues, plotter.XY{
		X: x,
		Y: y,
	})
}
