package bot

import (
	"fmt"
	"sync"

	"PR_BUGS/game"
	"github.com/jung-kurt/gofpdf"
	"github.com/sirupsen/logrus"
)

const (
	dateCellSize     = 90
	newLineLeftPoint = 10
	windowCell       = 50
	stopsCell        = 70
	reelCellSize     = 14
	totalsCellSize   = 18
	ordinate         = 15.0
	pageHeight       = 297
)

type fileWriter interface {
	runWriteResultWorker(resultsChan chan result, exitChan <-chan struct{})
	writeTotalResult(tr TotalResult)
	exportTerminalData(tr TotalResult)
	saveData() error
}

type pdfManager struct {
	log *logrus.Entry

	resultMutex      sync.Mutex
	totalResultMutex sync.Mutex
	resultPath       string

	pdf               *gofpdf.Fpdf
	currentSpin       int
	percentage        int
	isFileOutputSpins bool
	isFileOutputTotal bool
	lineHt            float64

	// remove if not need
	plotPayouts  *Plot
	plotTotal    *Plot
	totalPay     int64
	isPlotNeeded bool

	csv         *CSV
	isCSVOutput bool
}

func NewDoc(cfg *BotsConfig) *pdfManager {
	percentage := cfg.Rounds / 100
	if percentage == 0 {
		percentage = 1
	}

	pdf := &pdfManager{
		pdf:               gofpdf.New("P", "mm", "A4", ""),
		log:               &logrus.Entry{},
		resultMutex:       sync.Mutex{},
		totalResultMutex:  sync.Mutex{},
		resultPath:        cfg.ResultsFilePath,
		isFileOutputSpins: cfg.WithFileOutputSpinsResult,
		isFileOutputTotal: cfg.WithFileOutputTotalResults,
		percentage:        percentage,
		plotPayouts:       NewPlot(cfg.Rounds),
		plotTotal:         NewPlot(cfg.Rounds),
		isPlotNeeded:      cfg.WithPlots,
		csv:               NewCSV(),
		isCSVOutput:       cfg.WithCSV,
	}

	pdf.pdf.AddPage()
	pdf.pdf.SetFont("times", "", 10)
	pdf.pdf.SetDrawColor(0, 102, 102)
	pdf.pdf.SetFillColor(0, 102, 102)
	pdf.pdf.SetTopMargin(20)
	_, pdf.lineHt = pdf.pdf.GetFontSize()

	return pdf
}

func (pdf *pdfManager) runWriteResultWorker(resultsChan chan result, exitChan <-chan struct{}) {
	var flag bool

	for {
		if flag {
			break
		}

		select {
		case r := <-resultsChan:
			pdf.writeResult(r)
		case <-exitChan:
			flag = true
		}
	}

	close(resultsChan)
	for v := range resultsChan {
		pdf.writeResult(v)
	}
	fmt.Println("exiting write result worker")
}

func (pdf *pdfManager) writeResult(r result) {
	pdf.currentSpin++

	if pdf.currentSpin%pdf.percentage == 0 {
		fmt.Printf("percent completed: %d\n", pdf.currentSpin/pdf.percentage)
	}

	// remove if not need
	if pdf.isPlotNeeded {
		pdf.totalPay += int64(r.totalWin)
		pdf.plotPayouts.appendPoint(float64(pdf.currentSpin), float64(r.totalWin))
		pdf.plotTotal.appendPoint(float64(pdf.currentSpin), float64(pdf.totalPay))
	}

	if pdf.isCSVOutput {
		pdf.csv.appendRecord(&r)
	}

	if !pdf.isFileOutputSpins {
		return
	}

	pdf.resultMutex.Lock()
	defer pdf.resultMutex.Unlock()

	_, lineHt := pdf.pdf.GetFontSize()
	// Current spin
	//pdf.pdf.SetXY(pdf.pdf.GetX(), pdf.pdf.GetY())

	pdf.pdf.SetTextColor(255, 255, 255)
	pdf.pdf.SetFont("times", "", 10)
	if pdf.pdf.GetY()+lineHt*25 > pageHeight {
		pdf.pdf.AddPage()
		pdf.pdf.SetXY(newLineLeftPoint, ordinate)
	}
	pdf.pdf.CellFormat(dateCellSize, lineHt*2, fmt.Sprintf("Spin %d", pdf.currentSpin), "1", 2, "L", true, 0, "")
	pdf.pdf.SetTextColor(204, 0, 102)

	// Left side table header
	pdf.pdf.CellFormat(windowCell, lineHt*4, "Window", "1", 0, "L", false, 0, "")
	x, y := pdf.pdf.GetXY()

	// Stops info
	pdf.pdf.CellFormat(stopsCell, lineHt*2, "Stops", "1", 2, "C", false, 0, "")
	pdf.pdf.CellFormat(reelCellSize, lineHt*2, "Reel 1", "1", 0, "C", false, 0, "")
	pdf.pdf.CellFormat(reelCellSize, lineHt*2, "Reel 2", "1", 0, "C", false, 0, "")
	pdf.pdf.CellFormat(reelCellSize, lineHt*2, "Reel 3", "1", 0, "C", false, 0, "")
	pdf.pdf.CellFormat(reelCellSize, lineHt*2, "Reel 4", "1", 0, "C", false, 0, "")
	pdf.pdf.CellFormat(reelCellSize, lineHt*2, "Reel 5", "1", 1, "C", false, 0, "")

	y = pdf.pdf.GetY()

	// Write the data
	pdf.pdf.SetXY(newLineLeftPoint, y)
	pdf.pdf.SetFont("times", "B", 8)

	// First reel
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[0][0]), "1", 2, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[0][1]), "1", 2, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[0][2]), "1", 0, "C", false, 0, "")

	// Second reel
	x = pdf.pdf.GetX()
	pdf.pdf.SetXY(x, y)
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[1][0]), "1", 2, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[1][1]), "1", 2, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[1][2]), "1", 0, "C", false, 0, "")

	// third reel
	x = pdf.pdf.GetX()
	pdf.pdf.SetXY(x, y)
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[2][0]), "1", 2, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[2][1]), "1", 2, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[2][2]), "1", 0, "C", false, 0, "")

	// fourth reel
	x = pdf.pdf.GetX()
	pdf.pdf.SetXY(x, y)
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[3][0]), "1", 2, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[3][1]), "1", 2, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[3][2]), "1", 0, "C", false, 0, "")

	// fifth reel
	x = pdf.pdf.GetX()
	pdf.pdf.SetXY(x, y)
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[4][0]), "1", 2, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[4][1]), "1", 2, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(r.window[4][2]), "1", 0, "C", false, 0, "")

	// Stops info
	x = pdf.pdf.GetX()
	pdf.pdf.SetXY(x, y)
	pdf.pdf.CellFormat(reelCellSize, lineHt*2*3, fmt.Sprintf("%d", r.stops[0]), "1", 0, "C", false, 0, "")
	pdf.pdf.CellFormat(reelCellSize, lineHt*2*3, fmt.Sprintf("%d", r.stops[1]), "1", 0, "C", false, 0, "")
	pdf.pdf.CellFormat(reelCellSize, lineHt*2*3, fmt.Sprintf("%d", r.stops[2]), "1", 0, "C", false, 0, "")
	pdf.pdf.CellFormat(reelCellSize, lineHt*2*3, fmt.Sprintf("%d", r.stops[3]), "1", 0, "C", false, 0, "")
	pdf.pdf.CellFormat(reelCellSize, lineHt*2*3, fmt.Sprintf("%d", r.stops[4]), "1", 1, "C", false, 0, "")

	paylines, counts, symbols, payout := getWinlineInfo(r.payouts)
	pdf.pdf.CellFormat(windowCell, lineHt*2, "Win lines", "1", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(reelCellSize*5, lineHt*2, paylines, "1", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, lineHt*2, "Multipliers", "1", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(reelCellSize*5, lineHt*2, counts, "1", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, lineHt*2, "Symbols", "1", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(reelCellSize*5, lineHt*2, symbols, "1", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, lineHt*2, "Payouts", "1", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(reelCellSize*5, lineHt*2, payout, "1", 1, "C", false, 0, "")

	// Add bonus games data
	// g := false
	if r.bonusSpinsAmount > 0 {

		pdf.pdf.SetFillColor(0, 102, 51)
		pdf.pdf.SetTextColor(255, 255, 255)
		pdf.pdf.CellFormat(windowCell, lineHt*2, "Bonus spins info", "1", 0, "L", true, 0, "")
		pdf.pdf.CellFormat(reelCellSize*2, lineHt*2, fmt.Sprintf("Expanded symbol: %s", "S"), "1", 1, "L", true, 0, "")
		pdf.pdf.CellFormat(reelCellSize*2, lineHt*2, fmt.Sprintf("Spins count: %d", 15), "1", 1, "L", true, 0, "")
		pdf.pdf.SetTextColor(204, 0, 102)
		pdf.pdf.SetFillColor(0, 102, 102)
		// Left side table header
		pdf.pdf.CellFormat(windowCell, lineHt*4, "Window", "1", 0, "L", false, 0, "")
		bonusX, bonusY := pdf.pdf.GetXY()

		// Stops info
		pdf.pdf.CellFormat(stopsCell, lineHt*2, "Stops", "1", 2, "C", false, 0, "")
		pdf.pdf.CellFormat(reelCellSize, lineHt*2, "Reel 1", "1", 0, "C", false, 0, "")
		pdf.pdf.CellFormat(reelCellSize, lineHt*2, "Reel 2", "1", 0, "C", false, 0, "")
		pdf.pdf.CellFormat(reelCellSize, lineHt*2, "Reel 3", "1", 0, "C", false, 0, "")
		pdf.pdf.CellFormat(reelCellSize, lineHt*2, "Reel 4", "1", 0, "C", false, 0, "")
		pdf.pdf.CellFormat(reelCellSize, lineHt*2, "Reel 5", "1", 1, "C", false, 0, "")

		for _, v := range r.bonusGames {
			if pdf.pdf.GetY()+lineHt*16 > pageHeight {
				pdf.pdf.AddPage()
				pdf.pdf.SetXY(newLineLeftPoint, ordinate)
			}
			pdf.pdf.SetTextColor(255, 255, 255)
			pdf.pdf.SetFillColor(0, 51, 102)
			pdf.pdf.CellFormat(windowCell, lineHt*2, fmt.Sprintf("Free spins left %d", v.BonusSpinsLeft), "1", 1, "L", true, 0, "")
			pdf.pdf.SetFillColor(0, 102, 102)
			pdf.pdf.SetTextColor(204, 0, 102)
			bonusY = pdf.pdf.GetY()

			// Write the data
			pdf.pdf.SetXY(newLineLeftPoint, bonusY)
			pdf.pdf.SetFont("times", "B", 8)

			// First reel
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[0][0]), "1", 2, "C", false, 0, "")
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[0][1]), "1", 2, "C", false, 0, "")
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[0][2]), "1", 0, "C", false, 0, "")

			// Second reel
			bonusX = pdf.pdf.GetX()
			pdf.pdf.SetXY(bonusX, bonusY)
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[1][0]), "1", 2, "C", false, 0, "")
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[1][1]), "1", 2, "C", false, 0, "")
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[1][2]), "1", 0, "C", false, 0, "")

			// third reel
			bonusX = pdf.pdf.GetX()
			pdf.pdf.SetXY(bonusX, bonusY)
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[2][0]), "1", 2, "C", false, 0, "")
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[2][1]), "1", 2, "C", false, 0, "")
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[2][2]), "1", 0, "C", false, 0, "")

			// fourth reel
			bonusX = pdf.pdf.GetX()
			pdf.pdf.SetXY(bonusX, bonusY)
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[3][0]), "1", 2, "C", false, 0, "")
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[3][1]), "1", 2, "C", false, 0, "")
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[3][2]), "1", 0, "C", false, 0, "")

			// fifth reel
			bonusX = pdf.pdf.GetX()
			pdf.pdf.SetXY(bonusX, bonusY)
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[4][0]), "1", 2, "C", false, 0, "")
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[4][1]), "1", 2, "C", false, 0, "")
			pdf.pdf.CellFormat(windowCell/5, lineHt*2, string(v.Window[4][2]), "1", 0, "C", false, 0, "")

			// Stops info
			bonusX = pdf.pdf.GetX()
			pdf.pdf.SetXY(bonusX, bonusY)
			pdf.pdf.CellFormat(reelCellSize, lineHt*2*3, fmt.Sprintf("%d", v.Reels.Stops[0]), "1", 0, "C", false, 0, "")
			pdf.pdf.CellFormat(reelCellSize, lineHt*2*3, fmt.Sprintf("%d", v.Reels.Stops[1]), "1", 0, "C", false, 0, "")
			pdf.pdf.CellFormat(reelCellSize, lineHt*2*3, fmt.Sprintf("%d", v.Reels.Stops[2]), "1", 0, "C", false, 0, "")
			pdf.pdf.CellFormat(reelCellSize, lineHt*2*3, fmt.Sprintf("%d", v.Reels.Stops[3]), "1", 0, "C", false, 0, "")
			pdf.pdf.CellFormat(reelCellSize, lineHt*2*3, fmt.Sprintf("%d", v.Reels.Stops[4]), "1", 1, "C", false, 0, "")

			//// Right part of table header
			//bonusX = pdf.pdf.GetX()
			//pdf.pdf.SetXY(bonusX, bonusY)

			paylines, counts, symbols, payout := getWinlineInfo(v.PayoutsInfo)
			pdf.pdf.CellFormat(windowCell, lineHt*2, "Win lines", "1", 0, "L", false, 0, "")
			pdf.pdf.CellFormat(reelCellSize*5, lineHt*2, paylines, "1", 1, "C", false, 0, "")
			pdf.pdf.CellFormat(windowCell, lineHt*2, "Multipliers", "1", 0, "L", false, 0, "")
			pdf.pdf.CellFormat(reelCellSize*5, lineHt*2, counts, "1", 1, "C", false, 0, "")
			pdf.pdf.CellFormat(windowCell, lineHt*2, "Symbols", "1", 0, "L", false, 0, "")
			pdf.pdf.CellFormat(reelCellSize*5, lineHt*2, symbols, "1", 1, "C", false, 0, "")
			pdf.pdf.CellFormat(windowCell, lineHt*2, "Payouts", "1", 0, "L", false, 0, "")
			pdf.pdf.CellFormat(reelCellSize*5, lineHt*2, payout, "1", 1, "C", false, 0, "")
			for _, info := range v.AdditionalSpins.BonusSpinsTriggeredInfo {
				str := fmt.Sprintf("symb - %s, line - %d, spins - %d", info.Symbol, info.PayLine, info.SpinsAmount)
				pdf.pdf.CellFormat(windowCell, lineHt*2, "Additional spins", "1", 0, "L", false, 0, "")
				pdf.pdf.CellFormat(reelCellSize*5, lineHt*2, str, "1", 1, "C", false, 0, "")
			}
		}
	}

	// Totals info
	pdf.pdf.SetFillColor(224, 224, 224)
	pdf.pdf.CellFormat(windowCell, lineHt*2, "Total win", "1", 0, "L", true, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, lineHt*2, fmt.Sprintf("%d", r.totalWin), "1", 1, "C", true, 0, "")
	pdf.pdf.CellFormat(windowCell, lineHt*2, "Base spin payouts", "1", 0, "L", true, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, lineHt*2, fmt.Sprintf("%d", r.baseWin), "1", 1, "C", true, 0, "")
	pdf.pdf.CellFormat(windowCell, lineHt*2, "Bonus spin payouts", "1", 0, "L", true, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, lineHt*2, fmt.Sprintf("%d", r.bonusWin), "1", 1, "C", true, 0, "")
	pdf.pdf.CellFormat(windowCell, lineHt*2, "Bonus spins amount", "1", 0, "L", true, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, lineHt*2, fmt.Sprintf("%d", r.bonusSpinsAmount), "1", 1, "C", true, 0, "")
	pdf.pdf.CellFormat(windowCell, lineHt*2, "Wheel of fortune mult", "1", 0, "L", true, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, lineHt*2, fmt.Sprintf("%d", r.spec.wheelOfFortuneMultiplier), "1", 1, "C", true, 0, "")
	pdf.pdf.SetFillColor(0, 102, 102)

	// Line break for next data
	pdf.pdf.Ln(-lineHt * 2)
}

func (pdf *pdfManager) writeTotalResult(tr TotalResult) {
	if !pdf.isFileOutputTotal {
		return
	}

	pdf.totalResultMutex.Lock()
	defer pdf.totalResultMutex.Unlock()

	fmt.Printf("writing total result with id %s\n", tr.Uid)
	// pdf.exportData(tr)

	pdf.pdf.SetFont("times", "BU", 10)
	pdf.pdf.SetTextColor(0, 0, 0)
	pdf.pdf.CellFormat(windowCell, pdf.lineHt*2, "Total base spins amount", "0", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, pdf.lineHt*2, fmt.Sprintf("%d", tr.BaseSpinsAmount), "0", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, pdf.lineHt*2, "Total bonus spins amount", "0", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, pdf.lineHt*2, fmt.Sprintf("%d", tr.BonusSpinsAmount), "0", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, pdf.lineHt*2, "Max win", "0", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, pdf.lineHt*2, fmt.Sprintf("%d", tr.MaxWin), "0", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, pdf.lineHt*2, "RTP", "0", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, pdf.lineHt*2, fmt.Sprintf("%f", tr.Rtp), "0", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, pdf.lineHt*2, "Avg wheel of fortune", "0", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, pdf.lineHt*2, fmt.Sprintf("%f", tr.Spec.AverageWheelOfFortuneMultiplier), "0", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, pdf.lineHt*2, "Total games with bonus", "0", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, pdf.lineHt*2, fmt.Sprintf("%d", tr.TotalGamesWithBonus), "0", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, pdf.lineHt*2, "Max triggered bonus in game", "0", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, pdf.lineHt*2, fmt.Sprintf("%d", tr.MaxTriggeredBonusSpinsAmount), "0", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, pdf.lineHt*2, "Wager", "0", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, pdf.lineHt*2, fmt.Sprintf("%d", tr.Wager), "0", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, pdf.lineHt*2, "Total win", "0", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, pdf.lineHt*2, fmt.Sprintf("%d", tr.TotalWin), "0", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, pdf.lineHt*2, "Total spent", "0", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, pdf.lineHt*2, fmt.Sprintf("%d", tr.TotalSpent), "0", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, pdf.lineHt*2, "Total base win", "0", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, pdf.lineHt*2, fmt.Sprintf("%d", tr.BaseWin), "0", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, pdf.lineHt*2, "Total bonus win", "0", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, pdf.lineHt*2, fmt.Sprintf("%d", tr.BonusWin), "0", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, pdf.lineHt*2, "Avg bonus spins per game", "0", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, pdf.lineHt*2, fmt.Sprintf("%f", tr.AverageBonusSpinsAmount), "0", 1, "C", false, 0, "")
	pdf.pdf.CellFormat(windowCell, pdf.lineHt*2, "Avg bonus trigger per game", "0", 0, "L", false, 0, "")
	pdf.pdf.CellFormat(totalsCellSize, pdf.lineHt*2, fmt.Sprintf("%f", tr.AverageBonusTrigger), "0", 1, "C", false, 0, "")
}

func getWinlineInfo(payouts game.Payouts) (payline string, count string, symbol string, payout string) {
	if len(payouts.SpinPayouts) > 0 {
		for _, pay := range payouts.SpinPayouts {
			payline = payline + fmt.Sprintf("%d", pay.PaylineId) + ", "
			count = count + fmt.Sprintf("%d", pay.Count) + ", "
			symbol = symbol + fmt.Sprintf("%s", pay.Symbol) + ", "
			payout = payout + fmt.Sprintf("%d", pay.Amount) + ", "
		}

		payline = payline[:len(payline)-2]
		count = count[:len(count)-2]
		symbol = symbol[:len(symbol)-2]
		payout = payout[:len(payout)-2]

		return
	}

	return "no_paylines", "0", "no_symbols", "0"
}

func (pdf *pdfManager) saveData() error {
	if !pdf.isFileOutputSpins && !pdf.isFileOutputTotal {
		return nil
	}
	err := pdf.pdf.OutputFileAndClose(pdf.resultPath)
	if err != nil {
		return err
	}
	if pdf.isPlotNeeded {
		err = pdf.plotPayouts.buildPlot()
		if err != nil {
			return err
		}
		err = pdf.plotPayouts.savePlot("payouts.png")
		if err != nil {
			return err
		}

		err = pdf.plotTotal.buildPlot()
		if err != nil {
			return err
		}
		err = pdf.plotTotal.savePlot("total.png")
		if err != nil {
			return err
		}
	}
	if pdf.isCSVOutput {
		err = pdf.csv.save("spins.csv")
		if err != nil {
			return err
		}
	}
	return nil
}

// temp func
func (pdf *pdfManager) exportTerminalData(tr TotalResult) {
	fmt.Println("-------Total results-------")
	fmt.Printf("\n")
	fmt.Printf("\tBase spins amount: %d\n", tr.BaseSpinsAmount)
	fmt.Printf("\tBonus spins amount: %d\n", tr.BonusSpinsAmount)
	fmt.Printf("\tMax win: %d\n", tr.MaxWin)
	fmt.Printf("\tRTP: %f\n", tr.Rtp)
	fmt.Printf("\tAverage wheel of fortune multiplier: %f\n", tr.Spec.AverageWheelOfFortuneMultiplier)
	fmt.Printf("\tTotal games with bonus: %d\n", tr.TotalGamesWithBonus)
	fmt.Printf("\tMax triggered bonus spins in game: %d\n", tr.MaxTriggeredBonusSpinsAmount)
	fmt.Printf("\tWager: %d\n", tr.Wager)
	fmt.Printf("\tTotal win: %d\n", tr.TotalWin)
	fmt.Printf("\tTotal spent: %d\n", tr.TotalSpent)
	fmt.Printf("\tTotal base win: %d\n", tr.BaseWin)
	fmt.Printf("\tTotal bonus win: %d\n", tr.BonusWin)
	fmt.Printf("\tAverage bonus spins per game: %f\n", tr.AverageBonusSpinsAmount)
	fmt.Printf("\tAverage bonus triggered per game: %f\n", tr.AverageBonusTrigger)
	fmt.Printf("\n")
}
