package bot

import (
	"fmt"
	"os"
	"strconv"

	"PR_BUGS/game"
)

type CSV struct {
	records []string
}

func NewCSV() *CSV {
	return &CSV{
		records: make([]string, 0),
	}
}

func (c *CSV) save(path string) error {
	out, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0666)
	if err != nil {
		return err
	}
	defer out.Close()

	for _, v := range c.records {
		_, err = fmt.Fprintf(out, "%s\n", v)
		if err != nil {
			return err
		}
	}

	return nil
}

func (c *CSV) appendRecord(r *result) {
	idx := len(c.records)
	base := prepareBase(r, idx)

	c.records = append(c.records, base)

	for _, v := range r.bonusGames {
		bonus := prepareBonus(&v, r.spec.wheelOfFortuneMultiplier, idx)
		c.records = append(c.records, bonus)
	}
}

func prepareBase(r *result, curIdx int) string {
	str := ""

	trNum := strconv.Itoa(curIdx)
	bet := strconv.Itoa(r.wager)
	win := strconv.Itoa(r.baseWin)

	stops := make([][]string, 3)
	for i, v := range r.stops {
		stops[0] = append(stops[0], strconv.Itoa(int(v)))
		stops[1] = append(stops[1], strconv.Itoa(getStopWithOffset(game.BaseReels[i], int(v), 1)))
		stops[2] = append(stops[2], strconv.Itoa(getStopWithOffset(game.BaseReels[i], int(v), 2)))
	}

	symbols := make([][]string, 3)
	for _, v := range r.window {
		symbols[0] = append(symbols[0], string(v[0]))
		symbols[1] = append(symbols[1], string(v[1]))
		symbols[2] = append(symbols[2], string(v[2]))
	}

	freespinsWin := "0"

	str += fmt.Sprintf("%s;%s;%s;", trNum, bet, win)
	for _, v := range stops {
		tmp := ""
		for _, stop := range v {
			tmp += stop + ","
		}
		str += tmp + ";"
	}

	for _, v := range symbols {
		tmp := ""
		for _, symb := range v {
			tmp += symb + ","
		}
		str += tmp + ";"
	}
	str += freespinsWin

	return str
}

func prepareBonus(r *game.BonusSpinResult, mult, curIdx int) string {
	str := ""

	trNum := strconv.Itoa(curIdx)
	bet := "0"
	win := "0"

	stops := make([][]string, 3)
	for i, v := range r.Reels.Stops {
		stops[0] = append(stops[0], strconv.Itoa(int(v)))
		stops[1] = append(stops[1], strconv.Itoa(getStopWithOffset(game.BonusReels[i], int(v), 1)))
		stops[2] = append(stops[2], strconv.Itoa(getStopWithOffset(game.BonusReels[i], int(v), 2)))
	}

	symbols := make([][]string, 3)
	for _, v := range r.Window {
		symbols[0] = append(symbols[0], string(v[0]))
		symbols[1] = append(symbols[1], string(v[1]))
		symbols[2] = append(symbols[2], string(v[2]))
	}

	freespinsWin := strconv.Itoa(int(r.PayoutsInfo.PayoutForSpin) * mult)

	str += fmt.Sprintf("%s;%s;%s;", trNum, bet, win)
	for _, v := range stops {
		tmp := ""
		for _, stop := range v {
			tmp += stop + ","
		}
		str += tmp + ";"
	}

	for _, v := range symbols {
		tmp := ""
		for _, symb := range v {
			tmp += symb + ","
		}
		str += tmp + ";"
	}
	str += freespinsWin

	return str
}

func getStopWithOffset(reel game.Reel, stop, offset int) int {
	res := stop + offset
	if stop >= len(reel) {
		res = stop - len(reel)
	}
	return res
}

//TransactionNumber;Bet;Win;
//Reel1PositionStops;Reel2PositionStops;Reel3PositionStops;
//Reel1SymbolStops;Reel2SymbolStops;Reel3SymbolStops;
//FreeSpinsWin
