package utils

import (
	"encoding/json"
	"io/ioutil"
	"net/http"
)

// func getParamFromUrl(r *http.Request, param string) (string, error) {
// 	u, err := r.URL.Parse(r.URL.String())
// 	if err != nil {
// 		log.Println("failed to parse url")
// 		return "", err
// 	}

// 	param, err := url.ParseQuery(u.RawQuery)

// 	if err != nil {
// 		h.log.WithError(err).WithField("url", u.RawQuery).Error("failed to parse query with food ID")
// 		errs.InternalError(w)
// 		bugsnag.Notify(errs.CreateBugSnagNotification(r, u.RawQuery, err, "failed to parse query with food ID", http.StatusInternalServerError))
// 		return
// 	}

// 	foodID := param.Get("food_id")
// }

type ParseOpts struct {
	Body   interface{}
	Header *map[string]string
}

type ParseOpt func(*ParseOpts) error

func ParseRequest(r *http.Request, targetBody interface{}, targetHeader map[string]string) {

}

func parseWithBody(r *http.Request, distValue interface{}) error {
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		return err
	}

	return json.Unmarshal(body, distValue)
}
