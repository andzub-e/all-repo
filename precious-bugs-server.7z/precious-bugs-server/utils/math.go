package utils

func Max(a, b int) int {
	if a < b {
		return b
	}

	return a
}

func Min(a, b int) int {
	if a < b {
		return a
	}

	return b
}

func MinNonNeg(a, b int) int {
	if a <= 0 {
		return b
	}
	if b <= 0 {
		return a
	}
	return Min(a, b)
}
