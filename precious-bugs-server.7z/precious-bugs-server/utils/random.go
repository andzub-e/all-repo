package utils

import (
	"math/rand"
	"time"
)

// bounds are [left:right)
func RandInt(leftBound, rightBound int) int {
	if leftBound == rightBound {
		return 0
	}

	rand.Seed(time.Now().UnixNano())
	return rand.Intn(rightBound-leftBound) + leftBound
}
