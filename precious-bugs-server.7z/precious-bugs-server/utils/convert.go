package utils

import "encoding/json"

func JSONToBytes(j interface{}) ([]byte, error) {
	bts, err := json.Marshal(j)
	if err != nil {
		return nil, err
	}

	return bts, err
}
