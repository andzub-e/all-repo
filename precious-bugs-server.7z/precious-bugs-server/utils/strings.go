package utils

import "strings"

func Empty(s string) bool {
	s = strings.Trim(s, " ")
	return s == ""
}

func ShieldAllSymbol(str string, symb rune) string {
	return strings.ReplaceAll(str, string(symb), "\\"+string(symb))
}
