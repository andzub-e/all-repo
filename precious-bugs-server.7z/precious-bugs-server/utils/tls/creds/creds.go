package creds

// func LoadTLSCredentials(certPath, keyPath string) (credentials.TransportCredentials, error) {
// 	// Load certificate of the CA who signed server's certificate
// 	certificate, err := tls.LoadX509KeyPair(certPath, keyPath)
// 	if err != nil {
// 		return nil, err
// 	}

// 	certPool := x509.NewCertPool()

// 	config := &tls.Config{}

// 	return credentials.NewTLS(config), nil
// }
