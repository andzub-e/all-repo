package api

import (
	"time"

	"PR_BUGS/game"
	"PR_BUGS/game/constants"
)

type Token string
type CurrencyAmount = game.CurrencyAmount
type CurrencyType string
type FreespinID string
type WagerID string
type SessionID string
type Username string
type Multiplier = game.Multiplier
type ReelSet = game.ReelSet
type ReelWindow = game.ReelWindow
type ReelState = game.ReelState
type ReelSymbol = game.ReelSymbol
type PaylineID = game.PaylineID
type BonusSpinResults = game.BonusSpinResults
type BonusReelStates = game.BonusReelStates
type WagerLevels = game.WagerLevels
type DefaultWager = game.DefaultWager
type BonusStates = game.BonusStates
type Paytable = game.Paytable
type Paylines = game.Paylines
type ReelStop = game.ReelStop
type AbsolutePayline = game.AbsolutePayline
type SpinTime = game.SpinTime
type BonusSpinsTriggered = game.BonusSpinsTriggered

////////////////////////////////////////////////////////////////////////////
// Static Endpoints

// type ReelsRequest struct{}
type ReelsResponse struct {
	Reels ReelSet `json:"reels"`
}

// type PaytableRequest struct{}
type PaytableResponse struct {
	Paytable Paytable `json:"paytable"`
}

// type PaylinesRequest struct{}
type PaylinesResponse struct {
	Paylines [constants.PayLineCount]AbsolutePayline `json:"paylines"`
}

type WheelOfFortuneResponse struct {
	WheelOfFortune []Multiplier `json:"wheel_of_fortune"`
}

////////////////////////////////////////////////////////////////////////////
// Core Game Flow

// type StateRequest struct {
// 	SessionID SessionID `json:"session_id"`
// 	Operator  string    `json:"operator"`
// 	Game      string    `json:"game"`
// 	Params    []byte    `json:"params"`
// }

type StateRequest struct {
	SessionID string      `json:"session_id" swaggertype:"string"`
	Operator  string      `json:"operator"`
	Game      string      `json:"game"`
	Params    interface{} `json:"params"`
}

type StateResponse struct {
	SessionState
}

type SessionState struct {
	Username               Username            `json:"username,omitempty"`
	Balance                CurrencyAmount      `json:"balance"`
	Currency               CurrencyType        `json:"currency,omitempty"`
	LastWagerID            WagerID             `json:"wallet_play_id,omitempty"`
	LastWagerAmount        CurrencyAmount      `json:"last_wager,omitempty"`
	FreespinID             FreespinID          `json:"freespinid,omitempty"`
	Window                 ReelWindow          `json:"window"`
	Reels                  ReelState           `json:"reels"`
	BaseSpinBonusTriggered BonusSpinsTriggered `json:"base_spins_bonus_triggered"`
	BonusStates            BonusStates         `json:"bonus_games"`
	BonusIndex             int                 `json:"bonus_index"`
	Payouts                Payouts             `json:"payouts"`
	TotalWins              CurrencyAmount      `json:"total_wins"`
	SessionToken           Token               `json:"session_token"`
	WagerLevels            WagerLevels         `json:"wager_levels,omitempty"`
	DefaultWager           DefaultWager        `json:"default_wager,omitempty"`
	Game                   string              `json:"THE_EJAW_SLOT,omitempty"`

	StartBalance  CurrencyAmount `json:"-"`
	UserID        string         `json:"-"`
	Operator      string         `json:"-"`
	OperatorToken Token          `json:"-"`
	TransactionID string         `json:"-"`
	RoundID       string         `json:"-"`
	SpinTime      SpinTime       `json:"-"`

	Error string `json:"error,omitempty"`
}

type Payouts = game.Payouts

type ReelID uint
type RowID int

type Payout struct {
	Symbol         ReelSymbol     `json:"symbol" example:"A"`
	Count          uint           `json:"count" example:"5"`
	PaylineId      PaylineID      `json:"payline" swaggertype:"string" example:"0"`
	Amount         CurrencyAmount `json:"amount" swaggertype:"integer" example:"100"`
	Cycle          int            `json:"cycle,omitempty"`
	StartReelIndex ReelIndex      `json:"start_reel_index"`
	Multiplier     Multiplier     `json:"-"` // not exported - purely internal
}

type ReelIndex uint

type PlaceWagerRequest struct {
	SessionToken Token          `json:"session_token"`
	Currency     CurrencyType   `json:"currency"`
	Wager        CurrencyAmount `json:"wager"`
	FreeSpinID   FreespinID     `json:"freespin_id"`
}

type PlaceWagerResponse = SessionState

type FreeSpin struct {
	ID         string    `json:"id"`
	Currency   string    `json:"currency"`
	ExpireDate time.Time `json:"expire_date"`
	Value      int       `json:"value"`
	Game       string    `json:"game"`
	SpinCount  int       `json:"spin_count"`
}

type GetFreeSpinsRequest struct {
	SessionToken Token `json:"session_token"`
}

type GetFreeSpinsResponse struct {
	FreeSpins []*FreeSpin `json:"freespins"`
}

type IncrementBonusIndexRequest struct {
	SessionToken Token `json:"session_token"`
}

// ////////////////////////////////////////////////////////////////////////////
// History
type SpinHistory struct {
	ID            string      `json:"id"`
	TransactionID string      `json:"transaction_id"`
	Game          string      `json:"game"`
	Currency      string      `json:"currency"`
	Balance       int64       `json:"balance"`
	Bet           int64       `json:"bet"`
	FinalBalance  int64       `json:"final_balance"`
	RoundId       string      `json:"round_id"`
	BasePay       int64       `json:"base_pay"`
	BonusPay      int64       `json:"bonus_pay"`
	Window        ReelWindow  `json:"window"`
	Payouts       Payouts     `json:"payouts"`
	ReelsState    ReelState   `json:"reels"`
	BonusState    BonusStates `json:"bonus_reels"`
	BonusIndex    int32       `json:"bonus_index"`
	FreeSpinID    string      `json:"freespin_id"`
	StartTime     int64       `json:"start_time"`
	FinishTime    int64       `json:"finish_time"`
}

type HistoryRequest struct {
	SessionToken Token `json:"session_token" swaggertype:"string"`
	// Game         string `json:"game" swaggertype:"string"`
}

type HistoryResponse struct {
	Spins []*SpinHistory `json:"spins_history"`
}

// type HistoryRecord struct {
// 	WagerID      WagerID        `json:"wagerid"`
// 	StartTime    string         `json:"time"`
// 	StartDate    string         `json:"date"`
// 	EndTime      string         `json:"end_time"`
// 	EndDate      string         `json:"end_date"`
// 	Wager        CurrencyAmount `json:"wager"`
// 	TotalWin     CurrencyAmount `json:"total_win"`
// 	StartBalance CurrencyAmount `json:"start_balance"`
// 	EndBalance   CurrencyAmount `json:"end_balance"`
// 	Currency     CurrencyType   `json:"currency"`
// 	FreespinID   *FreespinID    `json:"freespinid,omitempty"`
// 	HistoryCoreV1
// }

// // this is JUST the core data that the wallet system cannot know about - without the context - which it does already know
// type HistoryCoreV1 struct {
// 	Reels game.ReelState `json:"reels"`
// }
