//go:build !prod
// +build !prod

package api

import "PR_BUGS/game/constants"

type CommonRequired struct {
	SessionToken Token `json:"session_token"`
}

type CheatsNoWinRequest struct {
	CommonRequired
}

type CheatBonusRequest struct {
	CommonRequired
}

type CheatCustomStopsRequest struct {
	CommonRequired
	Stops [constants.ReelCount]ReelStop
}
