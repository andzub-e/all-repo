package config

import (
	"sync"

	"github.com/sirupsen/logrus"
)

type Config interface {
	Log() *logrus.Entry
	RPC() *RPC
}

// ConfigImpl is implementation of config interface
type ConfigImpl struct {
	sync.Mutex
	rpc *RPC
	log *logrus.Entry
}

// New config creating
func New() Config {
	return &ConfigImpl{
		Mutex: sync.Mutex{},
	}
}
