package config

import (
	"github.com/caarlos0/env"
)

type RPC struct {
	Host     string `env:"BET_OVERLORD_RPC_HOST" envDefault:"0.0.0.0"`
	Port     string `env:"BET_OVERLORD_RPC_PORT" envDefault:"7000"`
	SSL      bool   `env:"BET_OVERLORD_SSL" envDefault:"false"`
	CertPath string `env:"BET_OVERLORD_CERT_PATH" envDefault:"cert.crt"`
}

func (rpc *RPC) Addr() string {
	return rpc.Host + ":" + rpc.Port
}

func (c *ConfigImpl) RPC() *RPC {
	if c.rpc != nil {
		return c.rpc
	}

	c.Lock()
	defer c.Unlock()

	rpc := &RPC{}
	if err := env.Parse(rpc); err != nil {
		panic(err)
	}

	c.rpc = rpc

	return c.rpc
}
