package repository

import (
	"PR_BUGS/api"
	"PR_BUGS/internal/betoverlord"
	"PR_BUGS/internal/core"
	"PR_BUGS/internal/models"
	"encoding/json"
	"github.com/sirupsen/logrus"
	"gorm.io/gorm"
	"time"
)

type Repository struct {
	log  *logrus.Entry
	conn *gorm.DB
}

func New(log *logrus.Entry, conn *gorm.DB) *Repository {
	return &Repository{log: log, conn: conn}
}

func (r *Repository) GetHistory(userName string, limit int) (a api.HistoryResponse, err error) {
	a.Spins = make([]*api.SpinHistory, 0) // no nil is len zero

	var y = make([]HistoryDB, 0)
	b := r.conn.Order("start_time desc")
	if limit > 0 {
		b = b.Limit(limit)
	}
	err = b.Find(&y, "user_id = ?", userName).Error
	if err != nil {
		return
	}

	for _, hs := range y {
		var rs api.ReelState
		var rw api.ReelWindow
		if err = json.Unmarshal(hs.ReelsState, &rs); err != nil {
			return
		}
		if err = json.Unmarshal(hs.Window, &rw); err != nil {
			return
		}

		a.Spins = append(a.Spins, &api.SpinHistory{
			ID:            hs.RoundId,
			TransactionID: hs.TransactionId,
			Window:        rw,
			Currency:      hs.Currency,
			Balance:       hs.Balance,
			Bet:           hs.Bet,
			FinalBalance:  hs.FinalBalance,
			RoundId:       hs.RoundId,
			BasePay:       hs.BasePay,
			BonusPay:      hs.BonusPay,
			ReelsState:    rs,
			FreeSpinID:    hs.FreeSpinId,
			StartTime:     hs.StartTime,
			FinishTime:    hs.FinishTime,
		})

	}
	return
}

func (r *Repository) SaveHistory(u *models.User) error {

	saveSpinIn := &HistoryDB{
		UserId:        u.State.UserID,
		Currency:      string(u.State.Currency),
		Balance:       int64(u.State.StartBalance),
		Bet:           int64(u.State.LastWagerAmount),
		TransactionId: u.State.TransactionID,
		FinalBalance:  int64(u.State.Balance),
		RoundId:       u.State.RoundID,
		StartTime:     time.Now().Unix(),
		FinishTime:    time.Now().Unix(),
		BasePay:       int64(u.State.Payouts.TotalWins()),
	}

	saveSpinIn.ReelsState, _ = json.Marshal(u.State.Reels)
	saveSpinIn.Window, _ = json.Marshal(u.State.Window)

	return r.conn.Create(saveSpinIn).Error

}

func (r *Repository) GetState(user *betoverlord.UserState) (state api.SessionState, err error) {
	history, err := r.GetHistory(user.UserId, 1)
	if err != nil {
		return api.SessionState{}, err
	}

	state = api.SessionState{
		Username:      api.Username(user.Username),
		Balance:       api.CurrencyAmount(user.Balance),
		Currency:      api.CurrencyType(user.Currency),
		WagerLevels:   user.WagerLevels,
		DefaultWager:  api.DefaultWager(user.DefaultWager),
		UserID:        user.UserId,
		Operator:      user.Operator,
		OperatorToken: api.Token(user.OperatorToken),
		SessionToken:  api.Token(user.SessionToken),
	}

	if len(history.Spins) > 0 {
		state.Reels = history.Spins[0].ReelsState
		state.Window = history.Spins[0].Window
	} else {
		state.Window = core.RandomWindowForFirstStartGame()
	}

	return
}
