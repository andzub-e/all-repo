package repository

import (
	"github.com/caarlos0/env"
	log "github.com/sirupsen/logrus"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func InitConnection() (*gorm.DB, error) {

	conf := &DBConfig{}

	err := env.Parse(conf)
	if err != nil {
		log.Fatalf("failed to get db data from env - %v", err)
	}

	conn, err := gorm.Open(postgres.Open(conf.GetDSN()), &gorm.Config{})

	if err != nil {
		log.WithError(err).Fatal("Failed to connect to DB")
	}

	err = uploadMigrations(conn)

	if err != nil {
		log.WithError(err).Fatal("Failed to upload migrations")
	}

	return conn, err
}

func uploadMigrations(c *gorm.DB) error {
	return c.AutoMigrate(&HistoryDB{})
}
