package repository

type HistoryDB struct {
	Id            uint64
	UserId        string `gorm:"size:100"`
	TransactionId string `gorm:"size:40"`
	Currency      string `gorm:"size:10"`
	Balance       int64
	Bet           int64
	FinalBalance  int64
	RoundId       string `gorm:"size:40"`
	BasePay       int64
	BonusPay      int64
	ReelsState    []byte
	Window        []byte
	FreeSpinId    string `gorm:"size:40"`
	StartTime     int64
	FinishTime    int64
}
