package repository

import "fmt"

type DBConfig struct {
	Host     string `env:"PR_BUGS_DB_HOST,required"`
	Port     string `env:"PR_BUGS_DB_PORT,required"`
	User     string `env:"PR_BUGS_DB_USER,required"`
	Password string `env:"PR_BUGS_DB_PASS,required"`
	Database string `env:"PR_BUGS_DB_BASE,required"`
	SSL      string `env:"PR_BUGS_DB_SSL,required"`
}

func (r DBConfig) GetDSN() string {
	return fmt.Sprintf("user=%s password=%s sslmode=%s host=%s port=%s database=%s",
		r.User, r.Password, r.SSL, r.Host, r.Port, r.Database)
}
