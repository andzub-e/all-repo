package main

import (
	"PR_BUGS/config"
	"PR_BUGS/internal/betoverlord"
	"PR_BUGS/internal/core"
	"PR_BUGS/internal/server"
	"PR_BUGS/internal/services"
	"PR_BUGS/repository"
	"PR_BUGS/utils"
	log "github.com/sirupsen/logrus"
)

const pathToConfigFile = "envs.yaml"

// @title Dicey Hustle Server
// @version 1.0.1
// @description REST API for Dicey Hustle Slot.
// @host 0.0.0.0:8086
// @host games.heronbyte.com/diceyhustle/dev/api
// @BasePath /
func main() {

	utils.UploadEnvironmentVariables(pathToConfigFile)

	conn, err := repository.InitConnection()
	if err != nil {
		log.Fatal("unable connect to DB", err)
	}

	conf := config.New()
	cr := core.NewCore(conf.Log())
	repo := repository.New(conf.Log(), conn)
	serv := services.NewService(conf, cr, repo)

	err = betoverlord.InitRPCConfig(conf)
	if err != nil {
		conf.Log().Fatal(err)
	}

	server.Start(conf.Log(), serv)
}
