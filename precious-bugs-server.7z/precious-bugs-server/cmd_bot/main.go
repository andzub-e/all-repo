package main

import (
	"fmt"
	"log"

	"PR_BUGS/bot"
)

func main() {
	cfg := &bot.BotsConfig{
		ResultsFilePath:            "./bot_report.pdf",
		Rounds:                     3000000,
		Wager:                      100,
		WithFileOutputSpinsResult:  false,
		WithFileOutputTotalResults: true,
		WithPlots:                  false,
		WithCSV:                    true,
	}

	bots := bot.NewBots(cfg)
	err := bots.Run()
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("Calculation finihed")
}
