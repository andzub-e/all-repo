package game

const (
	Ace     ReelSymbol = "A"
	King    ReelSymbol = "K"
	Queen   ReelSymbol = "Q"
	Jack    ReelSymbol = "J"
	Jester1 ReelSymbol = "U"
	Jester2 ReelSymbol = "I"
	Jester3 ReelSymbol = "O"
	Jester4 ReelSymbol = "P"
	Wild    ReelSymbol = "W"
	Scatter ReelSymbol = "S"
)
