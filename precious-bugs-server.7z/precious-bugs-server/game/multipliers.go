package game

import "PR_BUGS/game/constants"

type Multiplier uint

type Payouts struct {
	SpinPayouts   []Payout       `json:"spin_payouts"`
	PayoutForSpin CurrencyAmount `json:"payout_for_spin" swaggertype:"integer" example:"100"`
}

type SymbolPosition struct {
	ReelID ReelID `json:"reel_id"`
	RowID  RowID  `json:"row_id"`
}

type Payout struct {
	Symbol         ReelSymbol     `json:"symbol" example:"A"`
	Count          uint           `json:"count" example:"5"`
	PaylineId      PaylineID      `json:"payline" swaggertype:"integer" example:"0"`
	Amount         CurrencyAmount `json:"amount" swaggertype:"integer" example:"100"`
	Cycle          int            `json:"cycle,omitempty"`
	StartReelIndex ReelIndex      `json:"start_reel_index"`
	Multiplier     Multiplier     `json:"-"` // not exported - purely internal
}

func (m Multiplier) IsDenominator() bool {
	for _, pl := range BasePaytable {
		for _, t := range pl {
			if t%m != 0 {
				return false
			}
		}
	}

	return true
}

func (m Multiplier) ApplyToWithoutDivision(value CurrencyAmount) CurrencyAmount {
	return CurrencyAmount(m) * value
}

func (m Multiplier) ApplyTo(value CurrencyAmount) CurrencyAmount {
	return CurrencyAmount(m) * value / constants.PayLineCount
}

func (pays Payouts) TotalWins() (total CurrencyAmount) {
	for _, p := range pays.SpinPayouts {
		total += p.Amount
	}

	return
}

func (t Paytable) Result(sym ReelSymbol, consecutive uint) Multiplier {
	return t[sym][consecutive]
}
