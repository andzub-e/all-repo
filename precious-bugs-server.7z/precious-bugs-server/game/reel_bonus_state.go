package game

import "PR_BUGS/game/constants"

type BonusStates struct {
	Win                    CurrencyAmount   `json:"win"`
	FortuneMultiplierIndex RowID            `json:"fortune_multiplier_index,omitempty"`
	FortuneMultiplier      Multiplier       `json:"-"`
	WinAfterMultiplier     CurrencyAmount   `json:"total_win"`
	BonusReelStates        BonusReelStates  `json:"-"`
	BonusSpinResults       BonusSpinResults `json:"spins_results"`
}

// type BonusReelState struct {
// 	Stops        [constants.ReelCount]ReelStop `json:"stops" example:"11,22,33,44,55"`
// 	IsCheatStops bool                          `json:"is_cheat_stops"`
// 	IsTurbospin  bool                          `json:"is_turbospin"`
// }

type BonusReelState struct {
	ReelState
}

type BonusSpinResult struct {
	Window      ReelWindow     `json:"window"`
	Reels       BonusReelState `json:"reels"`
	PayoutsInfo Payouts        `json:"payouts"`
	// AdditionalSpins  SpinCount      `json:"additionalSpins" swaggertype:"integer" example:"100"`
	AdditionalSpins  BonusSpinsTriggered `json:"additionalSpins"`
	BonusSpinsLeft   SpinCount           `json:"bonus_spins_left" swaggertype:"integer" example:"100"`
	CurrentWinAmount CurrencyAmount      `json:"current_win_amount" swaggertype:"integer" example:"100"`
	BalanceAfterSpin CurrencyAmount      `json:"-"`
}

type BonusSpinResults []BonusSpinResult
type BonusReelStates []BonusReelState

func (brs BonusReelState) Reels() (reels ReelSet) {
	return BonusReels
}

func (brs BonusReelState) Window() (window ReelWindow) {

	for reel := ReelID(0); reel < constants.ReelCount; reel++ {
		for row := RowID(0); row < constants.WindowHeight; row++ {
			reelSize := ReelSize(len(BonusReels[reel]))
			window[reel][row] = brs.EffectiveSymbol(reel, row, brs.Stops[reel], reelSize)
		}
	}

	return
}

func (brs BonusReelState) Results(totalWager CurrencyAmount) Payouts {
	return brs.Window().Results(totalWager, BasePaytable)
}

// returns the effective symbol given reel, row, and stop accounting for the overlay
func (brs BonusReelState) EffectiveSymbol(reel ReelID, row RowID, stop ReelStop, reelSize ReelSize) ReelSymbol {
	return brs.Reels().RawSymbol(reel, row, stop, reelSize)
}

// func (value *BonusReelStates) Scan(v interface{}) (err error) {

// 	// null is fine
// 	if v == nil {
// 		return
// 	}

// 	// decode from JSONB
// 	if bv, ok := v.([]byte); ok {
// 		err = json.Unmarshal(bv, value)
// 		return
// 	}

// 	// decode from TEXT
// 	if sv, ok := v.(string); ok {
// 		err = json.Unmarshal([]byte(sv), value)
// 		return
// 	}

// 	err = fmt.Errorf("Invalid data format for a bonusReelStateList")
// 	return
// }

// func (value BonusReelStates) Value() (v driver.Value, err error) {

// 	// null is fine
// 	if len(value) == 0 {
// 		return
// 	}

// 	// encode as JSONB
// 	v, err = json.Marshal(value)

// 	return
// }
