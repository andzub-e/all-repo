package constants

const (
	HistoryMaxCount = 50
	HistoryVersion  = 1
	PayLineCount    = 10
	PayLineSize     = 5

	ReelCount = 5
	// ReelSize     = 120
	WindowHeight = 3
	WindowSize   = ReelCount * WindowHeight

	// basic wager levels multiplier
	WLM = 100
)
