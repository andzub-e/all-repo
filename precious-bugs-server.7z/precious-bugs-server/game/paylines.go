package game

import (
	"PR_BUGS/game/constants"
)

type AbsolutePayline [constants.PayLineSize]WindowSlot

type Paylines [constants.PayLineCount]AbsolutePayline

var PayLines = Paylines{
	{5, 6, 7, 8, 9},      //0
	{0, 1, 2, 3, 4},      //1
	{10, 11, 12, 13, 14}, //2
	{0, 6, 12, 8, 4},     //3
	{10, 6, 2, 8, 14},    //4
	{5, 1, 2, 3, 9},      //5
	{5, 11, 12, 13, 9},   //6
	{10, 11, 7, 13, 14},  //7
	{0, 1, 7, 3, 4},      //8
	{5, 1, 7, 3, 9},      //9
}
