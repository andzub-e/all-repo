package game

import "PR_BUGS/game/constants"

type WindowSlot uint

// returns the expanded reel & row for a given slot location
func (slot WindowSlot) Location() (reel ReelID, row RowID) {
	return ReelID(slot % constants.ReelCount), RowID(slot / constants.ReelCount)
}

// returns true if this slot is a member of given collection of slots
func (slot WindowSlot) MemberOf(slots []WindowSlot) bool {
	for _, test := range slots {
		if slot == test {
			return true
		}
	}
	return false
}
