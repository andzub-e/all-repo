package game

type WinBounds struct {
	Lower CurrencyAmount
	Upper CurrencyAmount
}

type WinType string

const (
	NiceWin    WinType = "nice"
	BigWin     WinType = "big"
	HugeWin    WinType = "huge"
	MonsterWin WinType = "monster"
	MegaWin    WinType = "mega"
)

var WinTypeTable = map[WinType]WinBounds{
	NiceWin:    {Lower: 5, Upper: 10},
	BigWin:     {Lower: 10, Upper: 20},
	HugeWin:    {Lower: 20, Upper: 50},
	MonsterWin: {Lower: 50, Upper: 100},
	MegaWin:    {Lower: 100, Upper: 999999},
}
