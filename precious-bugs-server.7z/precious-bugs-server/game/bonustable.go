package game

type BonusTable map[ReelSymbol]BonusTableLine
type BonusTableLine map[uint]SpinCount

type BonusSpinTriggered struct {
	Symbol             ReelSymbol `json:"symbol" swaggertype:"string"`
	PayLine            PaylineID  `json:"payline" swaggertype:"integer"`
	PaylineIndependent bool       `json:"payline_independent"` // set swaggertype bool
	SpinsAmount        SpinCount  `json:"spins_amount" swaggertype:"integer"`
}

type BonusSpinsTriggered struct {
	TotalSpins              SpinCount            `json:"total_spins" swaggertype:"integer"`
	BonusSpinsTriggeredInfo []BonusSpinTriggered `json:"triggered_spins_info"`
}

var BonusFreeSpins = BonusTable{
	"A": BonusTableLine{5: 0, 4: 0, 3: 0},
	"K": BonusTableLine{5: 0, 4: 0, 3: 0},
	"Q": BonusTableLine{5: 0, 4: 0, 3: 0},
	"J": BonusTableLine{5: 0, 4: 0, 3: 0},
	"U": BonusTableLine{5: 3, 4: 2, 3: 1},
	"I": BonusTableLine{5: 3, 4: 2, 3: 1},
	"O": BonusTableLine{5: 3, 4: 2, 3: 1},
	"P": BonusTableLine{5: 3, 4: 2, 3: 1},

	"W": BonusTableLine{5: 0, 4: 0, 3: 0},  // Wild
	"S": BonusTableLine{5: 0, 4: 0, 3: 15}, // Scatter
}

var BaseSpinBonusSymbols = []ReelSymbol{
	Scatter,
}

var BonusSpinBonusSymbols = []ReelSymbol{
	Ace,
	King,
	Queen,
	Jack,
	Jester1,
	Jester2,
	Jester3,
	Jester4,
	Wild,
	Scatter,
}

func sliceToMap(symbols []ReelSymbol) map[ReelSymbol]struct{} {
	res := make(map[ReelSymbol]struct{})
	for _, v := range symbols {
		res[v] = struct{}{}
	}
	return res
}

// func copyBonusSymbolsExcept(exceptSymbols ...ReelSymbol) map[ReelSymbol]struct{} {
// 	res := make(map[ReelSymbol]struct{})
// 	for symbol := range BonusFreeSpins {
// 		contains := false
// 		for _, exceptSymbol := range exceptSymbols {
// 			if exceptSymbol == symbol {
// 				contains = true
// 			}
// 		}
// 		if !contains {
// 			res[symbol] = struct{}{}
// 		}
// 	}

// 	return res
// }
