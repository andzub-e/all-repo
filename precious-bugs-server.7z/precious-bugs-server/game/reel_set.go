package game

import "PR_BUGS/game/constants"

type ReelSet [constants.ReelCount]Reel

func (r ReelSet) RawSymbol(reel ReelID, row RowID, stop ReelStop, reelSize ReelSize) ReelSymbol {
	return r[reel][((int(row)+int(stop))%int(reelSize+reelSize))%int(reelSize)]
}
