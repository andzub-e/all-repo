package game

import (
	"sort"
	"time"

	"PR_BUGS/game/constants"
)

type CurrencyAmount int32
type SpinType string

const (
	SpinTypeBase  SpinType = "base_spin"
	SpinTypeBonus SpinType = "bonus_spin"
)

type SpinTime struct {
	Start  time.Time
	Finish time.Time
}

func (rw ReelWindow) Equals(rhs ReelWindow) bool {
	for c, column := range rw {
		for r, symbol := range column {
			if symbol != rhs[c][r] {
				return false
			}
		}
	}
	return true
}

// returns the symbol at the given absolute slot position
func (rw ReelWindow) SymbolAt(slot WindowSlot) ReelSymbol {
	reel, row := slot.Location()
	return rw[reel][row]
}

// CountOf returns the number of occurences of teh given symbol anywhere in this window
func (rw ReelWindow) CountOf(sym ReelSymbol) (count int) {

	// walk the window
	for _, column := range rw {
		for _, symbol := range column {
			if sym == symbol {
				count++
			}
		}
	}

	return
}

// returns all payouts for the specified wager
func (rw ReelWindow) Results(totalWager CurrencyAmount, payTable Paytable) (payouts Payouts) {

	// here we calculate the results for window with applied mystery symbol feature
	for payline := PaylineID(0); payline < constants.PayLineCount; payline++ {
		payout := rw.Result(payline, payTable)
		if payout != nil {
			payout.Amount = payout.Multiplier.ApplyTo(totalWager)
			payouts.SpinPayouts = append(payouts.SpinPayouts, *payout)
		}
	}

	sort.SliceStable(payouts.SpinPayouts, func(i, j int) bool {
		return payouts.SpinPayouts[i].Amount < payouts.SpinPayouts[j].Amount
	})

	// calculate payout for spin
	payouts.PayoutForSpin = payouts.TotalWins()

	return
}

// returns the payout multiplier for one payline
func (rw ReelWindow) Result(lid PaylineID, payTable Paytable) *Payout {

	// the line we're processing
	line := PayLines[lid]

	// preprocess the first symbol in the line
	symbol := rw.SymbolAt(line[0])

	// capture our initial symbol or wild state
	wildChain := symbol.IsWild()
	consecutiveWilds := uint(0)
	if wildChain {
		consecutiveWilds++
	}

	// we've already processed the first symbol / wild
	consecutive := uint(1)

	// walk remaining in payline to find consecutive count (and true pay symbol if we started with a wild)
	for ; consecutive < constants.PayLineSize; consecutive++ {

		// process next symbol in line
		nextSymbol := rw.SymbolAt(line[consecutive])

		// check if our next symbol is wild
		if nextSymbol.IsWild() {
			if wildChain {
				consecutiveWilds++
			}
		} else if nextSymbol == symbol {
			// continue
		} else if wildChain {
			symbol = nextSymbol
			wildChain = false
		} else {
			break
		}
	}

	// get multiplier
	mult := payTable.Result(symbol, consecutive)
	wildmult := payTable.Result("P", consecutiveWilds)

	// use the better one
	if wildmult > mult {
		mult = wildmult
		consecutive = consecutiveWilds
		symbol = "P"
	}

	// if we ended up without a multiplier, we're done
	if mult == 0 {
		return nil
	}

	return &Payout{
		Symbol:     symbol,
		Count:      consecutive,
		PaylineId:  lid,
		Multiplier: mult,
	}
}

func (rw ReelWindow) BonusSpins(spinType SpinType) BonusSpinsTriggered {
	paylineIndependent := map[ReelSymbol]struct{}{
		Scatter: {},
	}
	// paylineDependent := copyBonusSymbolsExcept(Scatter)

	var availableBonusSymbols map[ReelSymbol]struct{}
	switch spinType {
	case SpinTypeBase:
		availableBonusSymbols = sliceToMap(BaseSpinBonusSymbols)
	case SpinTypeBonus:
		availableBonusSymbols = sliceToMap(BonusSpinBonusSymbols)
	}

	result := BonusSpinsTriggered{}

	// collect bonus spins for payline independent symbols
	for symb := range paylineIndependent {
		_, ok := availableBonusSymbols[symb]
		if !ok {
			continue
		}

		ctn := rw.getBonusSymbolCount(symb)
		if ctn != 0 {
			result.TotalSpins += ctn
			result.BonusSpinsTriggeredInfo = append(result.BonusSpinsTriggeredInfo, BonusSpinTriggered{
				Symbol:             symb,
				PayLine:            0,
				PaylineIndependent: true,
				SpinsAmount:        ctn,
			})
		}
	}

	// collect bonus spins for payline dependent symbols
	for lineID := range PayLines {
		symb, amount := rw.getBonusSymbolCountByPayline(PaylineID(lineID))

		// is symbol available for input spin type
		_, isAvailable := availableBonusSymbols[symb]
		// wheather this symbol already calculated in collect independent paylines block or not
		_, isAlreadyCalculated := paylineIndependent[symb]

		if !isAvailable || isAlreadyCalculated {
			continue
		}

		if amount != 0 {
			result.TotalSpins += amount
			result.BonusSpinsTriggeredInfo = append(result.BonusSpinsTriggeredInfo, BonusSpinTriggered{
				Symbol:             symb,
				PayLine:            PaylineID(lineID),
				PaylineIndependent: false,
				SpinsAmount:        amount,
			})
		}
	}

	return result
}

func (rw ReelWindow) getBonusSymbolCount(symbol ReelSymbol) SpinCount {
	totalSymbols := SpinCount(0)
	for reel := ReelID(0); reel < constants.ReelCount; reel++ {
		for row := RowID(0); row < constants.WindowHeight; row++ {
			if rw[reel][row] == symbol {
				totalSymbols++
			}
		}
	}

	spinsCount, ok := BonusFreeSpins[symbol][uint(totalSymbols)]
	if !ok {
		return 0
	}

	return spinsCount
}

func (rw ReelWindow) getBonusSymbolCountByPayline(lid PaylineID) (ReelSymbol, SpinCount) {
	result := rw.Result(lid, BasePaytable)
	if result == nil {
		return "", 0
	}

	resSpins, ok := BonusFreeSpins[result.Symbol][result.Count]
	if !ok {
		return "", 0
	}

	return result.Symbol, resSpins
}
