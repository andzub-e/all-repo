package game

import "fmt"

var PayTableGCD Multiplier

type Paytable map[ReelSymbol]PaytableLine
type PaytableLine map[uint]Multiplier

func init() {
	var minmult Multiplier

Initial:
	for _, pl := range BasePaytable {
		for _, m := range pl {
			if m > 0 {
				minmult = m
				break Initial
			}
		}
	}

	for _, pl := range BasePaytable {
		for _, m := range pl {
			if m < minmult && m > 0 {
				minmult = m
			}
		}
	}

	for i := minmult; i > 0; i-- {
		if i.IsDenominator() {
			PayTableGCD = i
			return
		}
	}

	panic(fmt.Errorf("no multiplier GCD found"))
}

var BasePaytable = Paytable{
	// "A": PaytableLine{5: 50, 4: 15, 3: 5}, // low 1
	// "B": PaytableLine{5: 50, 4: 15, 3: 5}, // low 2
	// "C": PaytableLine{5: 25, 4: 10, 3: 3}, // low 3
	// "X": PaytableLine{5: 250, 4: 50, 3: 10},   // high 1
	// "Y": PaytableLine{5: 500, 4: 100, 3: 15},  // high 2
	// "Z": PaytableLine{5: 1000, 4: 150, 3: 20}, // high 3
	// "W": PaytableLine{5: 0, 4: 0, 3: 0},       // Wild
	// "S": PaytableLine{5: 0, 4: 0, 3: 0},       // Scatter

	"A": PaytableLine{5: 50, 4: 15, 3: 5},
	"K": PaytableLine{5: 50, 4: 15, 3: 5},
	"Q": PaytableLine{5: 25, 4: 10, 3: 3},
	"J": PaytableLine{5: 25, 4: 10, 3: 3},
	"U": PaytableLine{5: 100, 4: 25, 3: 5},
	"I": PaytableLine{5: 250, 4: 50, 3: 10},
	"O": PaytableLine{5: 500, 4: 100, 3: 15},
	"P": PaytableLine{5: 1000, 4: 150, 3: 20},

	"W": PaytableLine{5: 0, 4: 0, 3: 0}, // Wild
	"S": PaytableLine{5: 0, 4: 0, 3: 0}, // Scatter
}
