package game

var WheelOfFortuneReel = []Multiplier{
	10,
	1,
	3,
	2,
	1,
	3,
	5,
	2,
	1,
	2,
}
