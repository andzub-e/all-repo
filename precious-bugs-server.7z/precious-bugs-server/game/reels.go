package game

import "PR_BUGS/game/constants"

// const (
// 	MYSTERY_SYMBOL = ReelSymbol("M")
// )

type PaylineID uint
type WagerLevels []int64
type DefaultWager uint
type Reel []ReelSymbol
type ReelID uint
type ReelSymbol string
type ReelWindow [constants.ReelCount]ReelWindowColumn
type ReelWindowColumn [constants.WindowHeight]ReelSymbol
type RowID int
type SpinCount uint
type ReelStop uint
type ReelIndex uint

type ReelsSpinTime uint

type ReelSize int
type ReelsSize [constants.ReelCount]ReelSize

var (
	BaseReelsSize  = ReelsSize{36, 42, 42, 39, 42}
	BonusReelsSize = ReelsSize{40, 52, 44, 30, 30}
)

func init() {
	for reel, set := range BaseReels {
		BaseReelsSize[reel] = ReelSize(len(set))
	}

	for reel, set := range BonusReels {
		BonusReelsSize[reel] = ReelSize(len(set))
	}
}

func (r ReelSymbol) IsWild() bool {
	return r == "W"
}

// type PaytableLine map[uint]Multiplier
// type Paytable map[ReelSymbol]PaytableLine

// returns true if the given symbol is a mystery symbol
// func (symbol ReelSymbol) IsMisterySymbol() bool {
// 	return symbol == MYSTERY_SYMBOL
// }
