package game

import (
	"encoding/json"
	"fmt"

	"PR_BUGS/game/constants"
)

type ReelState struct {
	Stops        [constants.ReelCount]ReelStop `json:"stops" example:"11,22,33,44,55"`
	IsCheatStops bool                          `json:"is_cheat_stops"`
	IsAutospin   bool                          `json:"is_autospin"`
	IsTurbospin  bool                          `json:"is_turbospin"`
}

func (rs ReelState) ReelSet() (reels ReelSet) {
	return BaseReels
}

// returns the Window with the overlay accounted for
func (rs ReelState) Window() (window ReelWindow) {

	// accumulate our effective symbols for the window
	for reel := ReelID(0); reel < constants.ReelCount; reel++ {
		for row := RowID(0); row < constants.WindowHeight; row++ {
			reelSize := ReelSize(len(BaseReels[reel]))
			window[reel][row] = rs.EffectiveSymbol(reel, row, rs.Stops[reel], reelSize)
		}
	}

	return
}

func (rs ReelState) Results(totalWager CurrencyAmount) Payouts {
	return rs.Window().Results(totalWager, BasePaytable)
}

// returns the effective symbol given reel, row, and stop accounting for the overlay
func (rs ReelState) EffectiveSymbol(reel ReelID, row RowID, stop ReelStop, reelSize ReelSize) ReelSymbol {
	return rs.ReelSet().RawSymbol(reel, row, stop, reelSize)
}

////////////////////////////////////////////////////////////////////////////
// DB Serialization

func (value *ReelState) Scan(v interface{}) (err error) {

	// decode from JSONB
	if bv, ok := v.([]byte); ok {
		err = json.Unmarshal(bv, value)
		return
	}

	// decode from TEXT
	if sv, ok := v.(string); ok {
		err = json.Unmarshal([]byte(sv), value)
		return
	}

	err = fmt.Errorf("Invalid data format for a ReelState")
	return
}

func (value ReelState) Value() (string, error) {

	// encode as JSONB
	v, err := json.Marshal(value)
	if err != nil {
		return "", err
	}

	return string(v[:]), nil
}

////////////////////////////////////////////////////////////////////////////
// RequestParser Decoding

// URI decoding (for cheats)
// func (rs *ReelState) ParseParameter(value string, tag reflect.StructTag) (err error) {
// 	var retval ReelState
// 	err = json.Unmarshal([]byte(value), &retval)
// 	if err != nil {
// 		return
// 	}

// 	*rs = ReelState(retval)
// 	return
// }
