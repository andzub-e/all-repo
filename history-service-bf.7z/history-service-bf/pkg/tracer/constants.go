package tracer

type CtxKey string

const CtxTraceIDKey CtxKey = "x-trace-id"
const CtxTraceIDStr = "x-trace-id"
