package clickhouse

import (
	"context"
	"github.com/ClickHouse/clickhouse-go/v2"
	"sync"
)

var (
	conn clickhouse.Conn
	once sync.Once
	err  error
)

func NewConnection(cfg *Config) (clickhouse.Conn, error) {
	once.Do(func() {
		conn, err = clickhouse.Open(&clickhouse.Options{
			Addr: cfg.Addr,
			Auth: clickhouse.Auth{
				Database: cfg.Database,
				Username: cfg.Username,
				Password: cfg.Password,
			},
			Debug: cfg.Debug,
			Settings: clickhouse.Settings{
				"max_execution_time": cfg.MaxExecutionTime,
			},
			DialTimeout:      cfg.DialTimeout,
			MaxOpenConns:     cfg.MaxOpenConns,
			MaxIdleConns:     cfg.MaxIdleConns,
			ConnMaxLifetime:  cfg.ConnMaxLifetime,
			ConnOpenStrategy: clickhouse.ConnOpenInOrder,
			Compression: &clickhouse.Compression{
				Method: clickhouse.CompressionLZ4,
			},
			BlockBufferSize: cfg.BlockBufferSize,
		})

		if err != nil {
			return
		}

		if err = conn.Ping(context.Background()); err != nil {
			return
		}
	})

	return conn, nil
}
