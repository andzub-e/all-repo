-- +goose Up
-- +goose StatementBegin
alter table spins add column is_demo boolean default true;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
alter table spins drop column is_demo;
-- +goose StatementEnd
