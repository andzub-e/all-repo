package constants

const (
	ConfigName     = "Config"
	LoggerName     = "Logger"
	HTTPServerName = "HTTPServer"
	RPCServerName  = "RPCServer"
	TracerName     = "Tracer"
	IP2CountryName = "IP2Country"
	ValidatorName  = "Validator"
	RedisName      = "Redis"
	ExchangeName   = "Exchange"

	ClickhouseConnectionName = "Clickhouse"
	PgSQLConnectionName      = "PgSQL"

	MetaHTTPHandlerName = "MetaHTTPHandler"

	SpinRepositoryName  = "SpinRepository"
	SlotRepositoryName  = "SlotRepository"
	DebugRepositoryName = "DebugRepository"

	SpinServiceName     = "SpinService"
	SlotServiceName     = "SlotService"
	ExchangeServiceName = "ExchangeService"
	DebugServiceName    = "DebugService"
)
