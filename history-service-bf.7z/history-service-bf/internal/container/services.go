package container

import (
	"github.com/sarulabs/di"
	"history/internal/constants"
	"history/internal/repositories"
	"history/internal/services"
	"history/pkg/exchange"
	"history/pkg/ip2country"
	"history/pkg/validator"
)

func BuildServices() []di.Def {
	return []di.Def{
		{
			Name: constants.SpinServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				spinRepo := ctn.Get(constants.SpinRepositoryName).(repositories.SpinRepository)
				exchangeService := ctn.Get(constants.ExchangeServiceName).(*services.ExchangeService)

				return services.NewSpinService(spinRepo, exchangeService), nil
			},
		},
		{
			Name: constants.SlotServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				slotRepo := ctn.Get(constants.SlotRepositoryName).(repositories.SlotRepository)
				ip2c := ctn.Get(constants.IP2CountryName).(*ip2country.ClientWithCache)
				valid := ctn.Get(constants.ValidatorName).(*validator.Validator)

				return services.NewSlotService(slotRepo, ip2c, valid), nil
			},
		},
		{
			Name: constants.ExchangeServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				exchangeClient := ctn.Get(constants.ExchangeName).(exchange.Client)

				return services.NewExchangeService(exchangeClient), nil
			},
		},
		{
			Name: constants.DebugServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				debugRepo := ctn.Get(constants.DebugRepositoryName).(repositories.DebugRepository)

				return services.NewDebugService(debugRepo), nil
			},
		},
	}
}
