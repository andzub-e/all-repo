package container

import (
	"context"
	"fmt"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
	"history/internal/config"
	"history/internal/constants"
	"history/internal/services"
	"history/internal/transport/http"
	"history/internal/transport/rpc"
	"history/pkg/exchange"
	"history/pkg/ip2country"
	"history/pkg/pgsql"
	"history/pkg/tracer"
	"history/pkg/validator"
	"strings"
	"sync"
	"time"
)

var container di.Container
var once sync.Once

func Build(ctx context.Context) di.Container {
	once.Do(func() {
		builder, _ := di.NewBuilder()
		defs := []di.Def{
			{
				Name: constants.LoggerName,
				Build: func(ctn di.Container) (interface{}, error) {
					logger, err := zap.NewProduction()
					if err != nil {
						return nil, fmt.Errorf("can't initialize zap logger: %v", err)
					}

					zap.ReplaceGlobals(logger)

					return logger, nil
				},
			},
			{
				Name: constants.ConfigName,
				Build: func(ctn di.Container) (interface{}, error) {
					return config.New()
				},
			},
			{
				Name: constants.PgSQLConnectionName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)
					tr := ctn.Get(constants.TracerName).(*tracer.JaegerTracer)

					return pgsql.NewPgsqlConnection(cfg.PgSQLConfig, tr)
				},
			},
			{
				Name: constants.TracerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return tracer.NewTracer(cfg.TracerConfig)
				},
			},
			{
				Name: constants.ValidatorName,
				Build: func(ctn di.Container) (interface{}, error) {
					return validator.New()
				},
			},
			{
				Name: constants.IP2CountryName,
				Build: func(ctn di.Container) (interface{}, error) {
					c := ip2country.NewClientWithCache(time.Hour*2, strings.ToLower)

					go c.Start()

					return c, nil
				},
				Close: func(obj interface{}) error {
					c, ok := obj.(*ip2country.ClientWithCache)

					if !ok {
						return fmt.Errorf("can not convert %T to *ip2country.ClientWithCache", obj)
					}

					c.Stop()

					return nil
				},
			},
			{
				Name: constants.ExchangeName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return exchange.NewClient(cfg.ExchangeConfig)
				},
			},
			{
				Name: constants.HTTPServerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)
					handlers := []http.Handler{
						ctn.Get(constants.MetaHTTPHandlerName).(http.Handler),
					}

					return http.New(ctx, cfg.HTTPConfig, handlers), nil
				},
				Close: func(obj interface{}) error {
					if err := obj.(*http.Server).Shutdown(); err != nil {
						zap.S().Errorf("Error stopping server: %s", err)

						return err
					}

					return nil
				},
			},
			{
				Name: constants.RPCServerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)
					spinService := ctn.Get(constants.SpinServiceName).(*services.SpinService)
					slotService := ctn.Get(constants.SlotServiceName).(*services.SlotService)

					return rpc.NewHandler(cfg.RPCConfig, spinService, slotService), nil
				},
			},
		}

		defs = append(defs, BuildRepositories()...)
		defs = append(defs, BuildServices()...)
		defs = append(defs, BuildHandlers()...)

		if err := builder.Add(defs...); err != nil {
			panic(err)
		}

		container = builder.Build()
	})

	return container
}
