package pgsql

import (
	"context"
	"errors"
	"github.com/google/uuid"
	"gorm.io/gorm"
	"history/internal/entities"
	"history/internal/errs"
)

type slotRepository struct {
	conn *gorm.DB
}

func NewSlotRepository(conn *gorm.DB) *slotRepository {
	return &slotRepository{conn: conn}
}

func (r slotRepository) Create(ctx context.Context, record *entities.Spin) error {
	return r.conn.WithContext(ctx).Create(record).Error
}

func (r slotRepository) Update(ctx context.Context, record *entities.Spin) error {
	return r.conn.WithContext(ctx).Updates(record).Error
}

func (r slotRepository) Pagination(ctx context.Context, internalUserID uuid.UUID, game string, limit, page uint64) (*entities.Pagination[entities.Spin], error) {
	p := &entities.Pagination[entities.Spin]{}

	tx := r.conn.WithContext(ctx).
		Order("created_at desc").
		Where("internal_user_id = ? and game = ?", internalUserID, game).
		Where("is_shown = true").
		Model(&entities.Spin{})

	var counter int64

	if err := tx.Count(&counter).Error; err != nil {
		return p, err
	}

	l, pg := int(limit), int(page)

	err := tx.Limit(l).
		Offset(l * (pg - 1)).
		Find(&p.Items).Error

	if err != nil {
		return p, err
	}

	p.Total = uint64(counter)
	p.Limit = limit
	p.CurrentPage = page

	return p, nil
}

func (r slotRepository) GetByID(ctx context.Context, id uuid.UUID) (*entities.Spin, error) {
	record := &entities.Spin{}

	err := r.conn.WithContext(ctx).
		Where("id = ?", id).
		First(record).
		Error

	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, errs.ErrSpinNotFound
	}

	if err != nil {
		return nil, err
	}

	return record, nil
}

func (r slotRepository) LastRecord(ctx context.Context, internalUserID uuid.UUID, game string) (*entities.Spin, error) {
	record := &entities.Spin{}
	err := r.conn.WithContext(ctx).
		Order("created_at desc").
		Where("internal_user_id = ? and game = ?", internalUserID, game).
		First(record).
		Error

	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, errs.ErrSpinNotFound
	}

	if err != nil {
		return nil, err
	}

	return record, nil
}

func (r slotRepository) LastRecords(ctx context.Context, internalUserID uuid.UUID, game string) ([]*entities.Spin, error) {
	records := []*entities.Spin{}
	err := r.conn.WithContext(ctx).
		Model(&entities.Spin{}).
		Order("created_at desc").
		Where("internal_user_id = ? and game = ?", internalUserID, game).
		Where("is_shown = false").
		Find(&records).
		Error

	if err != nil {
		return nil, err
	}

	return records, nil
}

func (r slotRepository) LastRecordByWager(ctx context.Context, internalUserID uuid.UUID, game string, wager uint64) (*entities.Spin, error) {
	record := &entities.Spin{}
	err := r.conn.WithContext(ctx).
		Order("created_at desc").
		Where("internal_user_id = ? and game = ? and wager = ?", internalUserID, game, wager).
		First(record).
		Error

	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, errs.ErrSpinNotFound
	}

	if err != nil {
		return nil, err
	}

	return record, nil
}
