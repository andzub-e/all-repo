package pgsql

import (
	"context"
	"errors"
	"fmt"
	"history/internal/entities"
	"history/internal/errs"
	"strings"

	"github.com/google/uuid"
	"github.com/samber/lo"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

var (
	AggregationTypes = map[int]string{
		entities.MaxAggregateType: "max(%[1]s) as %[2]s",
		entities.MinAggregateType: "min(%[1]s) as %[2]s",
		entities.BoolAggregateType: `case
                    when every(%[1]s) = true then true
                    when every(not %[1]s) = true then false
                    end as %[2]s`,
		entities.StringAggregateType: `case
                    when min(%[1]s::text) = max(%[1]s::text) then max(%[1]s::text)
                    end as %[2]s`,
		entities.SumAggregateType: "sum(%[1]s) as %[2]s",
	}
)

type spinRepository struct {
	conn *gorm.DB
}

func NewSpinRepository(conn *gorm.DB) *spinRepository {
	return &spinRepository{
		conn: conn,
	}
}

func (r *spinRepository) FindBy(ctx context.Context, games []string, params map[string]interface{}) (spin *entities.Spin, err error) {
	conn := r.withGames(r.conn.WithContext(ctx), games)

	if err = conn.Where(params).First(&spin).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, errs.ErrSpinNotFound
		}

		return
	}

	return
}

func (r *spinRepository) Upsert(ctx context.Context, spin entities.Spin) error {
	return r.conn.WithContext(ctx).Clauses(clause.OnConflict{
		// Update all columns, except primary keys, to new value on conflict
		UpdateAll: true,
	}).Create(&spin).Error
}

func (r *spinRepository) AwardAndWager(ctx context.Context, games []string, filters map[string]interface{}) (rep map[entities.FinancialReportKey]*entities.RawFinancialReport, err error) {
	conn := r.applyFilters(r.conn.WithContext(ctx), filters, entities.SpinFiltersNameMap)
	conn = r.withGames(conn, games)

	res1 := make([]*entities.RawFinancialReport, 0)
	res2 := make([]*entities.RawFinancialReport, 0)

	err = conn.
		Model(entities.Spin{}).
		Select("sum(wager) as wager, sum(base_award + bonus_award) as award, currency, integrator").
		Group("currency, integrator").
		Scan(&res1).Error

	if err != nil {
		return nil, err
	}

	err = conn.
		Model(entities.Spin{}).
		Select("sum(wager) as wager_without_pfr, sum(base_award + bonus_award) as award_without_pfr, currency, integrator").
		Where("is_pfr = false").
		Group("currency, integrator").
		Scan(&res2).Error

	if err != nil {
		return nil, err
	}

	rep = lo.SliceToMap(res1, func(item *entities.RawFinancialReport) (entities.FinancialReportKey, *entities.RawFinancialReport) {
		return entities.FinancialReportKey{Currency: item.Currency, Integrator: item.Integrator}, item
	})

	lo.ForEach(res2, func(item *entities.RawFinancialReport, index int) {
		_, ok := rep[entities.FinancialReportKey{Currency: item.Currency, Integrator: item.Integrator}]
		if !ok {
			rep[entities.FinancialReportKey{Currency: item.Currency, Integrator: item.Integrator}] = item
		}

		rep[entities.FinancialReportKey{Currency: item.Currency, Integrator: item.Integrator}].WagerWithoutPFR = item.WagerWithoutPFR
		rep[entities.FinancialReportKey{Currency: item.Currency, Integrator: item.Integrator}].AwardWithoutPFR = item.AwardWithoutPFR
	})

	return rep, err
}

func (r *spinRepository) SpinAndUserCount(ctx context.Context, games []string, filters map[string]interface{}) (rep map[entities.FinancialReportKey]*entities.RawUserStatReport, err error) {
	res := make([]*entities.RawUserStatReport, 0)

	conn := r.applyFilters(r.conn.WithContext(ctx), filters, entities.SpinFiltersNameMap)
	conn = r.withGames(conn, games)

	err = conn.
		Model(entities.Spin{}).
		Select("count(spins.id) as spin_quantity, count(distinct internal_user_id) as user_quantity, currency, integrator").
		Group("currency, integrator").
		Scan(&res).Error

	if err != nil {
		return nil, err
	}

	rep = lo.SliceToMap(res, func(item *entities.RawUserStatReport) (entities.FinancialReportKey, *entities.RawUserStatReport) {
		return entities.FinancialReportKey{Currency: item.Currency, Integrator: item.Integrator}, item
	})

	return rep, err
}

func (r *spinRepository) applyFilters(conn *gorm.DB, filters map[string]interface{}, filtersNameMap map[string]string) *gorm.DB {
	for key, val := range filters {
		_, isMultipleSearchColumn := entities.MultipleSearchColumnNames[key]
		realVal := filters[key]
		if strVal, ok := realVal.(string); ok && isMultipleSearchColumn {
			realVal = strings.Split(strings.Trim(strVal, " "), ",")
		}

		realKey, ok := filtersNameMap[key]
		if ok && val != nil {
			conn = conn.Where(realKey, realVal)
		}
	}

	return conn
}

func (r *spinRepository) AggregatedReportByGame(ctx context.Context, games []string, filters map[string]interface{}) ([]*entities.SimpleAggregatedReportByGame, error) {
	selectQuery := []string{
		"spins.game, spins.game_id", "spins.currency", "spins.integrator",
		"count(distinct spins.internal_user_id) as user_count", "count(distinct spins.id) as round_count",
		"sum(spins.base_award + spins.bonus_award) as award", "sum(spins.wager) as wager",
	}

	conn := r.conn.WithContext(ctx)
	conn = r.withGames(conn, games)
	conn = r.applyFilters(conn, filters, entities.SpinFiltersNameMap)

	allReps := []*entities.SimpleAggregatedReportByGame{}
	conn = conn.Select(selectQuery).Group("game_id, game, currency, integrator").Model(&entities.Spin{})

	if err := conn.Find(&allReps).Error; err != nil {
		return nil, err
	}

	return allReps, nil
}

func (r *spinRepository) AggregatedReportByCountry(ctx context.Context, games []string, filters map[string]interface{}) ([]*entities.SimpleAggregatedReportByCountry, error) {
	selectQuery := []string{
		"spins.country", "spins.currency", "spins.integrator",
		"count(distinct spins.internal_user_id) as user_count", "count(distinct spins.id) as round_count",
		"sum(spins.base_award + spins.bonus_award) as award", "sum(spins.wager) as wager",
	}

	conn := r.conn.WithContext(ctx)
	conn = r.withGames(conn, games)
	conn = r.applyFilters(conn, filters, entities.SpinFiltersNameMap)

	allReps := []*entities.SimpleAggregatedReportByCountry{}
	conn = conn.Select(selectQuery).Group("country, currency, integrator").Model(&entities.Spin{})

	if err := conn.Find(&allReps).Error; err != nil {
		return nil, err
	}

	return allReps, nil
}

func (r *spinRepository) All(ctx context.Context, games []string, filters map[string]interface{}) ([]*entities.Spin, error) {
	spins := make([]*entities.Spin, 0)
	conn := r.applyFilters(r.conn.WithContext(ctx), filters, entities.SpinFiltersNameMap)
	conn = r.withGames(conn, games)

	return spins, conn.Find(&spins).Error
}

func (r *spinRepository) withGames(conn *gorm.DB, games []string) *gorm.DB {
	if len(games) > 0 {
		conn = conn.Where("game_id in (?)", games)
	}

	return conn
}

func (r *spinRepository) AllGameSession(ctx context.Context, games []string, filters map[string]interface{}) ([]*entities.GameSession, error) {
	sessions := make([]*entities.GameSession, 0)
	subQuery := r.gameSessionQuery()

	conn := r.conn.WithContext(ctx).Table("(?) as spins", subQuery)
	conn = r.applyFilters(conn, filters, entities.GameSessionFiltersNameMap)
	conn = r.withGames(conn, games)

	err := conn.Find(&sessions).Error
	if err != nil {
		return sessions, err
	}

	lo.ForEach(sessions, func(item *entities.GameSession, index int) {
		item.Compute()
	})

	return sessions, nil
}

func (r *spinRepository) GetSession(ctx context.Context, games []string, id uuid.UUID) (session *entities.GameSession, err error) {
	subQuery := r.gameSessionQuery()

	if err = r.conn.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		conn := tx.Table("(?) as spins", subQuery)
		conn = r.withGames(conn, games)
		conn = conn.Where("session_token = ?", id)

		if err = conn.First(&session).Error; err != nil {
			return err
		}

		if err = tx.Where("session_token = ?", id).Order("created_at asc").Find(&session.Spins).Error; err != nil {
			return err
		}

		return nil
	}); err != nil {
		return nil, err
	}

	return session, nil
}

func (r *spinRepository) gameSessionQuery() *gorm.DB {
	// we need `calc.game_name as game_name` for session filtering
	return r.conn.Raw(`select distinct on(session_token) created_at, session_token, internal_user_id, external_user_id, host, calc.wager, calc.wager_without_pfr, calc.award_without_pfr, calc.award, currency, integrator, operator, game_id, is_demo, calc.game_name as game from spins join (
    	select st, wager, coalesce(wager_without_pfr, 0) as wager_without_pfr, coalesce(award_without_pfr, 0) as award_without_pfr,award, game_name  from
        (select session_token as st, sum(wager) as wager, sum(base_award + bonus_award) as award, game as game_name from spins group by session_token, game_name) as sessions
            left join
            (select session_token as st2, sum(wager) as wager_without_pfr, sum(base_award + bonus_award) as award_without_pfr
             from spins where is_pfr = false group by session_token) as sessions_without_pfr
                on sessions.st = sessions_without_pfr.st2
	) as calc on spins.session_token = calc.st order by session_token, created_at`)
}

func (r *spinRepository) PaginateGrouped(ctx context.Context, games []string, filters map[string]interface{}, order string, limit, page uint64, groupBy []string) (
	pagination entities.Pagination[entities.GroupedSpin], err error) {
	spins := make([]*entities.GroupedSpin, 0)
	conn := r.applyFilters(r.conn.WithContext(ctx), filters, entities.SpinFiltersNameMap)
	conn = r.withGames(conn, games)

	keys := lo.Keys(entities.GroupAggregateTypes)
	keys = lo.Filter(keys, func(item string, index int) bool {
		return !lo.Contains(groupBy, item)
	})

	for _, g := range groupBy {
		conn = conn.Group(g)
	}
	var total int64

	if err = conn.Model(entities.GroupedSpin{}).Count(&total).Error; err != nil {
		return pagination, err
	}

	var l, p = int(limit), int(page)

	conn = conn.
		Order(order).
		Limit(l).
		Offset(l * (p - 1)).
		Select(fmt.Sprintf("%v, ", strings.Join(groupBy, ", ")) + strings.Join(lo.Map(keys, func(key string, index int) string {
			aggType := entities.GroupAggregateTypes[key]
			aggFunc := AggregationTypes[aggType]

			tableKey := (&entities.GroupedSpin{}).TableName() + "." + key
			return fmt.Sprintf(aggFunc, tableKey, key)
		}), ", "))

	if err = conn.Find(&spins).Error; err != nil {
		return
	}

	pagination.Total = uint64(total)
	pagination.Limit = uint64(limit)
	pagination.CurrentPage = uint64(page)
	pagination.Items = spins

	return
}

func (r *spinRepository) PaginateGameSession(ctx context.Context, games []string, filters map[string]interface{}, order string, limit, page uint64) (
	pagination entities.Pagination[entities.GameSession], err error) {

	sessions := make([]*entities.GameSession, 0)
	subQuery := r.gameSessionQuery()

	conn := r.conn.WithContext(ctx).Table("(?) as spins", subQuery).Model(&entities.GameSession{})
	conn = r.applyFilters(conn, filters, entities.GameSessionFiltersNameMap)
	conn = r.withGames(conn, games)

	var total int64

	if err := conn.Count(&total).Error; err != nil {
		return pagination, err
	}

	var l, p = int(limit), int(page)

	conn = conn.Order(order)
	if err = conn.Limit(l).Offset(l * (p - 1)).Find(&sessions).Error; err != nil {
		return
	}

	lo.ForEach(sessions, func(item *entities.GameSession, index int) {
		item.Compute()
	})

	pagination.Total = uint64(total)
	pagination.Limit = limit
	pagination.CurrentPage = page
	pagination.Items = sessions

	return
}

func (r *spinRepository) Paginate(ctx context.Context, games []string, filters map[string]interface{}, order string, limit, page uint64) (
	pagination entities.Pagination[entities.Spin], err error) {
	spins := make([]*entities.Spin, 0)
	conn := r.applyFilters(r.conn.WithContext(ctx), filters, entities.SpinFiltersNameMap)
	conn = r.withGames(conn, games)

	var total int64

	if err = conn.Model(entities.Spin{}).Count(&total).Error; err != nil {
		return pagination, err
	}

	var l, p = int(limit), int(page)

	conn = conn.
		Order(order).
		Limit(l).
		Offset(l * (p - 1))

	if err = conn.Find(&spins).Error; err != nil {
		return
	}

	pagination.Total = uint64(total)
	pagination.Limit = limit
	pagination.CurrentPage = page
	pagination.Items = spins

	return
}

func (r *spinRepository) Currencies(ctx context.Context, filters map[string]interface{}) ([]string, error) {
	currencies := make([]string, 0)

	conn := r.applyFilters(r.conn, filters, entities.SpinFiltersNameMap)

	return currencies, conn.WithContext(ctx).Model(&entities.Spin{}).Distinct().Pluck("currency", &currencies).Error
}

func (r *spinRepository) Hosts(ctx context.Context, games []string) ([]string, error) {
	hosts := make([]string, 0)

	conn := r.conn.WithContext(ctx).Model(&entities.Spin{}).Distinct()

	conn = r.withGames(conn, games)
	err := conn.Pluck("host", &hosts).Error

	return hosts, err
}

func (r *spinRepository) IntegratorOperatorsMap(ctx context.Context, games []string) (map[string][]string, error) {
	var resPure []struct {
		Integrator string
		Operator   string
	}

	conn := r.conn.WithContext(ctx).Model(&entities.Spin{})
	conn = r.withGames(conn, games)
	err := conn.Distinct("integrator, operator").Find(&resPure).Error

	if err != nil {
		return nil, err
	}

	res := map[string][]string{}

	for _, item := range resPure {
		res[item.Integrator] = append(res[item.Integrator], item.Operator)
	}

	return res, nil
}
