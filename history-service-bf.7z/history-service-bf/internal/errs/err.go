package errs

import "errors"

var (
	ErrSpinNotFound             = errors.New("spin not found")
	ErrCanNotFindCurrencyConfig = errors.New("can not find currency config")
	ErrIsDemoRequiredField      = errors.New("is demo required field")
)
