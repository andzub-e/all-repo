package entities

import (
	"history/pkg/history"
	"time"

	"github.com/google/uuid"
	"github.com/samber/lo"
	"google.golang.org/protobuf/types/known/timestamppb"
)

type GameSession struct {
	CreatedAt time.Time `json:"created_at" csv:"created_at" xlsx:"Created At"`

	SessionToken   uuid.UUID `json:"session_token" csv:"session_token" xlsx:"Session Token"`
	UserID         uuid.UUID `json:"user_id" csv:"user_id" xlsx:"User ID" gorm:"column:internal_user_id"`
	ExternalUserID string    `json:"external_user_id" csv:"external_user_id" xlsx:"External User ID"`

	Wager           float64 `json:"wager" csv:"wager" xlsx:"Wager"`
	WagerWithoutPFR float64 `json:"wager_without_pfr" csv:"wager_without_pfr" xlsx:"Wager without PFR"`
	Award           float64 `json:"award" csv:"award" xlsx:"Award"`
	AwardWithoutPFR float64 `json:"award_without_pfr" csv:"award_without_pfr" xlsx:"Award without PFR"`

	Currency   string    `json:"currency" xlsx:"Currency"`
	Integrator string    `json:"integrator" csv:"integrator" xlsx:"Integrator"`
	Operator   string    `json:"operator" csv:"operator" xlsx:"Operator"`
	GameID     uuid.UUID `json:"game_id" gorm:"primaryKey" csv:"game_id" xlsx:"-"`
	Game       string    `json:"game"`

	Spins []*Spin `json:"spins" gorm:"many2many:spin_spins" xlsx:"-"`

	// computed
	WagerWithPFR float64 `json:"wager_with_pfr" csv:"wager_with_pfr" xlsx:"Wager with PFR" gorm:"-"`
	AwardWithPFR float64 `json:"award_with_pfr" csv:"award_with_pfr" xlsx:"Award with PFR" gorm:"-"`

	RTP             float64 `json:"rtp" csv:"rtp" xlsx:"RTP" gorm:"-"`
	RTPWithTurnover float64 `json:"rtp_with_turnover" csv:"rtp_with_turnover" xlsx:"RTP With Turnover" gorm:"-"`
	Margin          float64 `json:"margin" gorm:"-"`
	Revenue         float64 `json:"revenue" csv:"revenue" xlsx:"Revenue" gorm:"-"`

	// spins aggregations
	StartBalance *float64 `json:"start_balance,omitempty" csv:"-" xlsx:"-" gorm:"-"`
	EndBalance   *float64 `json:"end_balance,omitempty" csv:"-" xlsx:"-" gorm:"-"`
	BaseAward    *float64 `json:"base_award,omitempty" csv:"-" xlsx:"-" gorm:"-"`
	BonusAward   *float64 `json:"bonus_award,omitempty" csv:"-" xlsx:"-" gorm:"-"`
}

func (gs *GameSession) TableName() string {
	return "spins"
}

func (gs *GameSession) Compute() {
	if gs.Wager != 0 {
		gs.RTP = gs.Award / gs.Wager
	}

	if gs.WagerWithoutPFR != 0 {
		gs.RTPWithTurnover = gs.Award / gs.WagerWithoutPFR
	}

	gs.AwardWithPFR = gs.Award - gs.AwardWithoutPFR
	gs.WagerWithPFR = gs.Wager - gs.WagerWithoutPFR

	gs.Margin = 1 - gs.RTPWithTurnover
	gs.Revenue = gs.Wager - gs.Award

	if len(gs.Spins) != 0 {
		sb := gs.Spins[0].StartBalance
		eb := gs.Spins[len(gs.Spins)-1].EndBalance
		baseAward := lo.Reduce(gs.Spins, func(agg float64, item *Spin, index int) float64 {
			return agg + item.BaseAward
		}, 0)
		bonusAward := lo.Reduce(gs.Spins, func(agg float64, item *Spin, index int) float64 {
			return agg + item.BonusAward
		}, 0)

		gs.StartBalance = &sb
		gs.EndBalance = &eb
		gs.BaseAward = &baseAward
		gs.BonusAward = &bonusAward
	}
}

func (gs *GameSession) Prettify() *GameSession {
	gs.Compute()

	return gs
}

func (gs *GameSession) GetCurrency() string {
	return gs.Currency
}

func (gs *GameSession) ExchangeCurrencyMut(toCurrency string, multiplier float64) {
	gs.Currency = toCurrency
	gs.Wager = gs.Wager * multiplier
	gs.WagerWithoutPFR = gs.WagerWithoutPFR * multiplier
	gs.Award = gs.Award * multiplier
	gs.AwardWithoutPFR = gs.AwardWithoutPFR * multiplier

	lo.ForEach(gs.Spins, func(item *Spin, index int) {
		item.ExchangeCurrencyMut(toCurrency, multiplier)
	})

	gs.Compute()
}

func (gs *GameSession) ToAPIResponse() *history.GameSessionOut {
	spins := lo.Map(gs.Spins, func(item *Spin, index int) *history.SpinOut {
		return item.ToAPIResponse()
	})

	var sb, eb, baseAward, bonusAward uint64

	if gs.StartBalance != nil {
		sb = uint64(*gs.StartBalance)
	}

	if gs.EndBalance != nil {
		eb = uint64(*gs.EndBalance)
	}

	if gs.BaseAward != nil {
		baseAward = uint64(*gs.BaseAward)
	}

	if gs.BonusAward != nil {
		bonusAward = uint64(*gs.BonusAward)
	}

	return &history.GameSessionOut{
		CreatedAt:       timestamppb.New(gs.CreatedAt),
		SessionToken:    gs.SessionToken.String(),
		UserId:          gs.UserID.String(),
		ExternalUserId:  gs.ExternalUserID,
		Wager:           uint64(gs.Wager),
		WagerWithoutPfr: uint64(gs.WagerWithoutPFR),
		Award:           uint64(gs.Award),
		AwardWithoutPfr: uint64(gs.AwardWithoutPFR),
		Currency:        gs.Currency,
		Integrator:      gs.Integrator,
		Operator:        gs.Operator,
		GameId:          gs.GameID.String(),
		Game:            gs.Game,
		Spins:           spins,
		WagerWithPfr:    uint64(gs.WagerWithPFR),
		AwardWithPfr:    uint64(gs.AwardWithPFR),
		Rtp:             uint64(gs.RTP),
		RtpWithTurnover: uint64(gs.RTPWithTurnover),
		Margin:          uint64(gs.Margin),
		Revenue:         uint64(gs.Revenue),
		StartBalance:    sb,
		EndBalance:      eb,
		BaseAward:       baseAward,
		BonusAward:      bonusAward,
	}
}

var GameSessionFiltersNameMap = map[string]string{
	"integrator":       "integrator",
	"operator":         "operator",
	"game":             "game",
	"starting_from":    "spins.created_at >= ?",
	"ending_at":        "spins.created_at <= ?",
	"host":             "spins.host",
	"external_user_id": "spins.external_user_id",
	"user_id":          "spins.user_id",
	"session_token":    "spins.session_token",
	"is_demo":          "spins.is_demo",
}
