package entities

type Pagination[T any] struct {
	Items       []*T   `json:"items"`
	CurrentPage uint64 `json:"current_page"`
	Limit       uint64 `json:"limit"`
	Total       uint64 `json:"total"`
}

func PaginationSubstituteItems[O, N any](p Pagination[O], items []*N) Pagination[N] {
	return Pagination[N]{
		Items:       items,
		CurrentPage: p.CurrentPage,
		Limit:       p.Limit,
		Total:       p.Total,
	}
}
