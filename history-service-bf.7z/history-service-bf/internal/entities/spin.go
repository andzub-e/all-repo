package entities

import (
	"encoding/json"
	"github.com/google/uuid"
	"google.golang.org/protobuf/types/known/timestamppb"
	"history/pkg/history"
	"time"
)

type Spin struct {
	CreatedAt time.Time `json:"created_at" csv:"created_at" xlsx:"Created At"`
	UpdatedAt time.Time `json:"updated_at" csv:"updated_at" xlsx:"Updated At"`

	Country   *string         `json:"country" gorm:"<-:create"`
	Host      string          `json:"host" csv:"host" xlsx:"Host" gorm:"<-:create" validate:"required,url"`
	ClientIP  string          `json:"client_ip" csv:"client_ip" gorm:"<-:create" validate:"required,ip4_addr"`
	UserAgent string          `json:"user_agent" csv:"user_agent" gorm:"<-:create" validate:"required"`
	Request   json.RawMessage `json:"request" csv:"request" gorm:"<-:create" validate:"required"`

	ID            uuid.UUID `json:"id" gorm:"primaryKey" csv:"id" xlsx:"ID"`
	GameID        uuid.UUID `json:"game_id" gorm:"primaryKey" csv:"game_id" xlsx:"-"`
	Game          string    `json:"game" csv:"game" xlsx:"Game;Name" validate:"required"`
	SessionToken  uuid.UUID `json:"session_token" csv:"session_token" xlsx:"Session Token"`
	TransactionID uuid.UUID `json:"transaction_id" csv:"transaction_id" xlsx:"Transaction ID"`

	Integrator string `json:"integrator" csv:"integrator" xlsx:"Integrator" validate:"required"`
	Operator   string `json:"operator" csv:"operator" xlsx:"Operator" validate:"required"`
	Provider   string `json:"provider" csv:"provider" xlsx:"Provider" validate:"required"`

	InternalUserID uuid.UUID `json:"internal_user_id" csv:"internal_user_id" xlsx:"Internal User ID"`
	ExternalUserID string    `json:"external_user_id" csv:"external_user_id" xlsx:"External User ID" validate:"required"`
	Currency       string    `json:"currency" csv:"currency" xlsx:"Currency" validate:"required"`

	StartBalance float64 `json:"start_balance" csv:"start_balance" xlsx:"Start Balance"`
	EndBalance   float64 `json:"end_balance" csv:"end_balance" xlsx:"End Balance"`
	Wager        float64 `json:"wager" csv:"wager" xlsx:"Wager"`
	BaseAward    float64 `json:"base_award" csv:"base_award" xlsx:"Base Award"`
	BonusAward   float64 `json:"bonus_award" csv:"bonus_award" xlsx:"Bonus Award"`

	Details          json.RawMessage `json:"details" gorm:"serializer:json" csv:"-" swaggertype:"string" xlsx:"-" validate:"required"`
	RestoringIndexes json.RawMessage `json:"restoring_indexes" gorm:"serializer:json" csv:"-" swaggertype:"string" xlsx:"-" validate:"required"`

	IsShown bool `json:"is_shown" csv:"-" xlsx:"isShown"`
	IsPFR   bool `json:"is_pfr" csv:"is_pfr" xlsx:"isPFR"`
	IsDemo  bool `json:"is_demo" csv:"is_demo" xlsx:"isDemo"`
}

type GameParser struct {
	Game string `json:"game"`
}

func (s *Spin) GetIntegrator() string {
	return s.Integrator
}

func (s *Spin) GetCurrency() string {
	return s.Currency
}

func (s *Spin) ExchangeCurrencyMut(toCurrency string, multiplier float64) {
	s.Currency = toCurrency

	s.Wager = float64(s.Wager * multiplier)
	s.BaseAward = float64(s.BaseAward * multiplier)
	s.BonusAward = float64(s.BonusAward * multiplier)
	s.StartBalance = float64(s.StartBalance * multiplier)
	s.EndBalance = float64(s.EndBalance * multiplier)
}

type GroupedSpin struct {
	CreatedAt time.Time `json:"created_at" csv:"created_at" xlsx:"Created At" mapstructure:"created_at"`
	UpdatedAt time.Time `json:"updated_at" csv:"updated_at" xlsx:"Updated At" mapstructure:"updated_at"`

	GameID *uuid.UUID `json:"game_id" gorm:"primaryKey" csv:"game_id" xlsx:"-" mapstructure:"game_id"`
	Game   string     `json:"game"`

	SessionToken   *uuid.UUID `json:"session_token" csv:"session_token" xlsx:"Session Token" mapstructure:"session_token"`
	Integrator     string     `json:"integrator" csv:"integrator" xlsx:"Integrator" mapstructure:"integrator"`
	Operator       string     `json:"operator" csv:"operator" xlsx:"Operator" mapstructure:"operator"`
	Host           *string    `json:"host" csv:"host" xlsx:"Host" mapstructure:"host"`
	UserID         *string    `json:"user_id" csv:"user_id" xlsx:"User ID" mapstructure:"user_id" gorm:"column:internal_user_id"`
	ExternalUserID *string    `json:"external_user_id" csv:"external_user_id" xlsx:"External User ID" mapstructure:"external_user_id"`
	Currency       string     `json:"currency" csv:"currency" xlsx:"Currency" mapstructure:"currency"`

	Wager      float64 `json:"wager" csv:"wager" xlsx:"Wager" mapstructure:"wager"`
	BaseAward  float64 `json:"base_award" csv:"base_award" xlsx:"Base Award" mapstructure:"base_award"`
	BonusAward float64 `json:"bonus_award" csv:"bonus_award" xlsx:"Bonus Award" mapstructure:"bonus_award"`

	IsShown *bool `json:"is_shown" csv:"-" xlsx:"isShown" mapstructure:"is_shown"`
	IsPFR   *bool `json:"is_pfr" csv:"is_pfr" xlsx:"isPFR"  mapstructure:"is_pfr"`
	IsDemo  *bool `json:"is_demo" csv:"is_demo" xlsx:"isDemo"`
}

func (s *GroupedSpin) GetIntegrator() string {
	return s.Integrator
}

func (s *GroupedSpin) GetCurrency() string {
	return s.Currency
}

func (s *GroupedSpin) ExchangeCurrencyMut(toCurrency string, multiplier float64) {
	s.Currency = toCurrency

	s.Wager = float64(s.Wager * multiplier)
	s.BaseAward = float64(s.BaseAward * multiplier)
	s.BonusAward = float64(s.BonusAward * multiplier)
}

func (*GroupedSpin) TableName() string {
	return "spins"
}

const (
	MaxAggregateType = iota
	MinAggregateType
	BoolAggregateType
	StringAggregateType
	SumAggregateType
)

var AvailableColumnToGroup = map[string]string{
	"session_token":    "session_token",
	"integrator":       "integrator",
	"host":             "host",
	"user_id":          "internal_user_id",
	"external_user_id": "external_user_id",
	"currency":         "currency",
	"game_id":          "game_id",
	"game":             "game_id",
}

var GroupAggregateTypes = map[string]int{
	"created_at":       MinAggregateType,
	"updated_at":       MaxAggregateType,
	"game_id":          StringAggregateType,
	"game":             StringAggregateType,
	"session_token":    StringAggregateType,
	"host":             StringAggregateType,
	"internal_user_id": StringAggregateType,
	"external_user_id": StringAggregateType,
	"operator":         StringAggregateType,
	"wager":            SumAggregateType,
	"base_award":       SumAggregateType,
	"bonus_award":      SumAggregateType,
	"is_shown":         BoolAggregateType,
	"is_pfr":           BoolAggregateType,
}

var MultipleSearchColumnNames = map[string]struct{}{
	"integrator":       {},
	"game":             {},
	"session_token":    {},
	"round_id":         {},
	"host":             {},
	"user_id":          {},
	"external_user_id": {},
}

var SpinFiltersNameMap = map[string]string{
	"integrator":       "integrator",
	"operator":         "operator",
	"game":             "game",
	"starting_from":    "spins.created_at >= ?",
	"ending_at":        "spins.created_at <= ?",
	"session_token":    "session_token",
	"round_id":         "spins.id",
	"host":             "spins.host",
	"external_user_id": "spins.external_user_id",
	"user_id":          "spins.internal_user_id",
	"is_pfr":           "spins.is_pfr",
	"is_demo":          "spins.is_demo",
}

func (s *Spin) ToAPIResponse() *history.SpinOut {
	country := ""

	if s.Country != nil {
		country = *s.Country
	}

	return &history.SpinOut{
		CreatedAt: timestamppb.New(s.CreatedAt),
		UpdatedAt: timestamppb.New(s.UpdatedAt),

		Country:   country,
		Host:      s.Host,
		ClientIp:  s.ClientIP,
		UserAgent: s.UserAgent,
		Request:   s.Request,

		Id:             s.ID.String(),
		GameId:         s.GameID.String(),
		Game:           s.Game,
		SessionToken:   s.SessionToken.String(),
		TransactionId:  s.TransactionID.String(),
		Integrator:     s.Integrator,
		Operator:       s.Operator,
		Provider:       s.Provider,
		InternalUserId: s.InternalUserID.String(),
		ExternalUserId: s.ExternalUserID,

		Currency:     s.Currency,
		StartBalance: uint64(s.StartBalance),
		EndBalance:   uint64(s.EndBalance),
		Wager:        uint64(s.Wager),
		BaseAward:    uint64(s.BaseAward),
		BonusAward:   uint64(s.BonusAward),

		RestoringIndexes: s.RestoringIndexes,
		Details:          s.Details,
		IsPfr:            &s.IsPFR,
		IsShown:          &s.IsShown,
		IsDemo:           &s.IsDemo,
	}
}

func (s *GroupedSpin) ToAPIResponse() *history.SpinOut {
	country := ""

	gs := &history.SpinOut{
		CreatedAt: timestamppb.New(s.CreatedAt),
		UpdatedAt: timestamppb.New(s.UpdatedAt),

		Country: country,

		Game:       s.Game,
		Integrator: s.Integrator,
		Operator:   s.Operator,

		Currency:   s.Currency,
		Wager:      uint64(s.Wager),
		BaseAward:  uint64(s.BaseAward),
		BonusAward: uint64(s.BonusAward),

		IsPfr:   s.IsPFR,
		IsShown: s.IsShown,
		IsDemo:  s.IsDemo,
	}

	if s.GameID != nil {
		gs.GameId = s.GameID.String()
	}

	if s.SessionToken != nil {
		gs.SessionToken = s.SessionToken.String()
	}

	if s.Host != nil {
		gs.Host = *s.Host
	}

	if s.UserID != nil {
		gs.InternalUserId = *s.UserID
	}

	if s.ExternalUserID != nil {
		gs.ExternalUserId = *s.ExternalUserID
	}

	return gs
}
