package entities

import "github.com/google/uuid"

type AggregatedReport struct {
	Currency string `json:"currency"`

	UserCount  int `json:"user_count"`
	RoundCount int `json:"round_count"`

	Wager float64 `json:"wager"`
	Award float64 `json:"award"`
}

func (a *AggregatedReport) ExchangeCurrencyMut(toCurrency string, multiplier float64) {
	a.Currency = toCurrency
	a.Wager *= multiplier
	a.Award *= multiplier
}

func (a AggregatedReport) GetCurrency() string {
	return a.Currency
}

type SimpleAggregatedReportByCountry struct {
	Country string `json:"country"`

	AggregatedReport
}

type SimpleAggregatedReportByGame struct {
	Game   string    `json:"game"`
	GameID uuid.UUID `json:"game_id"`

	AggregatedReport
}
