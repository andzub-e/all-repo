package rpc

import (
	"context"
	"errors"
	"github.com/google/uuid"
	"github.com/samber/lo"
	"history/internal/entities"
	"history/internal/errs"
	"history/pkg/history"
)

func (h *Handler) CreateSpin(ctx context.Context, in *history.SpinIn) (*history.Status, error) {
	en, err := api2Entity(in)
	if err != nil {
		return nil, err
	}

	if err := h.slotService.CreateSpin(ctx, en); err != nil {
		return nil, err
	}

	return &history.Status{Status: "ok"}, nil
}

func (h *Handler) UpdateSpin(ctx context.Context, in *history.SpinIn) (*history.Status, error) {
	en, err := api2Entity(in)
	if err != nil {
		return nil, err
	}

	if err := h.slotService.UpdateSpin(ctx, en); err != nil {
		return nil, err
	}

	return &history.Status{Status: "ok"}, nil
}

func (h *Handler) GetSpin(ctx context.Context, in *history.GetSpinIn) (*history.GetSpinOut, error) {
	roundID, err := uuid.Parse(in.RoundId)
	if err != nil {
		return nil, err
	}

	spin, err := h.slotService.GetSpin(ctx, roundID)
	if errors.Is(err, errs.ErrSpinNotFound) {
		return &history.GetSpinOut{IsFound: false, Item: nil}, nil
	}

	if err != nil {
		return nil, err
	}

	return &history.GetSpinOut{IsFound: true, Item: spin.ToAPIResponse()}, nil
}

func (h *Handler) GetLastSpin(ctx context.Context, in *history.GetLastSpinIn) (*history.GetSpinOut, error) {
	internalUserID, err := uuid.Parse(in.InternalUserId)
	if err != nil {
		return nil, err
	}

	spin, err := h.slotService.GetLastSpin(ctx, internalUserID, in.Game)
	if errors.Is(err, errs.ErrSpinNotFound) {
		return &history.GetSpinOut{IsFound: false, Item: nil}, nil
	}

	if err != nil {
		return nil, err
	}

	return &history.GetSpinOut{IsFound: true, Item: spin.ToAPIResponse()}, nil
}

func (h *Handler) GetLastNotShownSpins(ctx context.Context, in *history.GetLastSpinIn) (*history.GetLastSpinsOut, error) {
	internalUserID, err := uuid.Parse(in.InternalUserId)
	if err != nil {
		return nil, err
	}

	spins, err := h.slotService.GetLastNotShownSpins(ctx, internalUserID, in.Game)
	if err != nil {
		return nil, err
	}

	return &history.GetLastSpinsOut{Items: lo.Map(spins, func(item *entities.Spin, index int) *history.SpinOut {
		return item.ToAPIResponse()
	})}, nil
}

func (h *Handler) GetLastSpinByWager(ctx context.Context, in *history.GetLastSpinByWagerIn) (*history.GetSpinOut, error) {
	internalUserID, err := uuid.Parse(in.InternalUserId)
	if err != nil {
		return nil, err
	}

	spin, err := h.slotService.GetLastSpinByWager(ctx, internalUserID, in.Game, in.Wager)
	if errors.Is(err, errs.ErrSpinNotFound) {
		return &history.GetSpinOut{IsFound: false, Item: nil}, nil
	}

	if err != nil {
		return nil, err
	}

	return &history.GetSpinOut{IsFound: true, Item: spin.ToAPIResponse()}, nil
}

func (h *Handler) GetSpinsPagination(
	ctx context.Context, in *history.GetSpinPaginationIn,
) (*history.GetSpinPaginationOut, error) {
	internalUserID, err := uuid.Parse(in.Filter.InternalUserId)
	if err != nil {
		return nil, err
	}

	pagenation, err := h.slotService.GetSpinsPagination(ctx, internalUserID, in.Filter.Game, in.Limit, in.Page)
	if err != nil {
		return nil, err
	}

	return &history.GetSpinPaginationOut{
		Items: lo.Map(pagenation.Items, func(item *entities.Spin, index int) *history.SpinOut {
			return item.ToAPIResponse()
		}),
		Page:  pagenation.CurrentPage,
		Limit: pagenation.Limit,
		Total: pagenation.Total,
	}, nil
}

func api2Entity(in *history.SpinIn) (*entities.Spin, error) {
	id, err := uuid.Parse(in.Id)
	if err != nil {
		return nil, err
	}

	gameID, err := uuid.Parse(in.GameId)
	if err != nil {
		return nil, err
	}

	sessionToken, err := uuid.Parse(in.SessionToken)
	if err != nil {
		return nil, err
	}

	internalUserID, err := uuid.Parse(in.InternalUserId)
	if err != nil {
		return nil, err
	}

	transactionID, err := uuid.Parse(in.TransactionId)
	if err != nil {
		return nil, err
	}

	if in.IsDemo == nil {
		return nil, errs.ErrIsDemoRequiredField
	}

	return &entities.Spin{
		CreatedAt: in.CreatedAt.AsTime(),
		UpdatedAt: in.UpdatedAt.AsTime(),

		Host:      in.Host,
		ClientIP:  in.ClientIp,
		UserAgent: in.UserAgent,
		Request:   in.Request,

		ID:             id,
		GameID:         gameID,
		Game:           in.Game,
		SessionToken:   sessionToken,
		TransactionID:  transactionID,
		Integrator:     in.Integrator,
		Operator:       in.Operator,
		Provider:       in.Provider,
		InternalUserID: internalUserID,
		ExternalUserID: in.ExternalUserId,
		Currency:       in.Currency,

		StartBalance: float64(in.StartBalance),
		EndBalance:   float64(in.EndBalance),
		Wager:        float64(in.Wager),
		BaseAward:    float64(in.BaseAward),
		BonusAward:   float64(in.BonusAward),

		Details:          in.Details,
		RestoringIndexes: in.RestoringIndexes,

		IsShown: in.IsShown,
		IsPFR:   in.IsPfr,
		IsDemo:  *in.IsDemo,
	}, nil
}
