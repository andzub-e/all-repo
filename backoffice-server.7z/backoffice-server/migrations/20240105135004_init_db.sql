-- +goose Up
-- +goose StatementBegin

-- ----------------------------
-- Table structure for account_organizations
-- ----------------------------
DROP TABLE IF EXISTS "public"."account_organizations";
CREATE TABLE "public"."account_organizations" (
                                                  "created_at" timestamptz(6) DEFAULT now(),
                                                  "account_id" uuid NOT NULL,
                                                  "organization_id" uuid NOT NULL
)
;

-- ----------------------------
-- Table structure for account_permissions
-- ----------------------------
DROP TABLE IF EXISTS "public"."account_permissions";
CREATE TABLE "public"."account_permissions" (
                                                "created_at" timestamptz(6) DEFAULT now(),
                                                "account_id" uuid NOT NULL,
                                                "permission_id" uuid NOT NULL,
                                                "organization_id" uuid NOT NULL
)
;

-- ----------------------------
-- Table structure for account_roles
-- ----------------------------
DROP TABLE IF EXISTS "public"."account_roles";
CREATE TABLE "public"."account_roles" (
                                          "created_at" timestamptz(6) DEFAULT now(),
                                          "account_id" uuid NOT NULL,
                                          "role_id" uuid NOT NULL
)
;

-- ----------------------------
-- Table structure for accounts
-- ----------------------------
DROP TABLE IF EXISTS "public"."accounts";
CREATE TABLE "public"."accounts" (
                                     "created_at" timestamptz(6) DEFAULT now(),
                                     "updated_at" timestamptz(6),
                                     "deleted_at" timestamptz(6),
                                     "id" uuid NOT NULL DEFAULT gen_random_uuid(),
                                     "auth_provider" varchar(40) COLLATE "pg_catalog"."default",
                                     "auth_provider_id" varchar(255) COLLATE "pg_catalog"."default",
                                     "auth_provider_token" varchar(255) COLLATE "pg_catalog"."default",
                                     "first_name" varchar(40) COLLATE "pg_catalog"."default",
                                     "last_name" varchar(40) COLLATE "pg_catalog"."default",
                                     "email" varchar(40) COLLATE "pg_catalog"."default",
                                     "status" int4,
                                     "totp_enabled" bool DEFAULT false,
                                     "totp_secret" varchar COLLATE "pg_catalog"."default" DEFAULT ''::character varying,
                                     "totp_url" varchar COLLATE "pg_catalog"."default" DEFAULT ''::character varying,
                                     "reset_password_token" varchar(255) COLLATE "pg_catalog"."default",
                                     "reset_password_expires_at" timestamptz(6)
)
;

-- ----------------------------
-- Table structure for currencies
-- ----------------------------
DROP TABLE IF EXISTS "public"."currencies";
CREATE TABLE "public"."currencies" (
                                       "title" varchar(5) COLLATE "pg_catalog"."default" NOT NULL,
                                       "alias" varchar(5) COLLATE "pg_catalog"."default" NOT NULL,
                                       "type" varchar(10) COLLATE "pg_catalog"."default" NOT NULL,
                                       "additional_alias_rate" float8 NOT NULL
)
;

-- ----------------------------
-- Table structure for currency_multipliers
-- ----------------------------
DROP TABLE IF EXISTS "public"."currency_multipliers";
CREATE TABLE "public"."currency_multipliers" (
                                                 "created_at" timestamptz(6) DEFAULT now(),
                                                 "updated_at" timestamptz(6) DEFAULT now(),
                                                 "title" varchar COLLATE "pg_catalog"."default" NOT NULL,
                                                 "multiplier" int4,
                                                 "organization_pair_id" uuid NOT NULL
)
;

-- ----------------------------
-- Table structure for currency_sets
-- ----------------------------
DROP TABLE IF EXISTS "public"."currency_sets";
CREATE TABLE "public"."currency_sets" (
                                          "created_at" timestamp(6),
                                          "updated_at" timestamp(6),
                                          "id" uuid NOT NULL,
                                          "organization_id" uuid,
                                          "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
                                          "currencies" varchar[] COLLATE "pg_catalog"."default",
                                          "is_active" bool
)
;

-- ----------------------------
-- Table structure for games
-- ----------------------------
DROP TABLE IF EXISTS "public"."games";
CREATE TABLE "public"."games" (
                                  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
                                  "organization_id" uuid,
                                  "name" varchar COLLATE "pg_catalog"."default",
                                  "jurisdictions" varchar[] COLLATE "pg_catalog"."default" NOT NULL,
                                  "currencies" varchar[] COLLATE "pg_catalog"."default" NOT NULL,
                                  "languages" varchar[] COLLATE "pg_catalog"."default" NOT NULL,
                                  "user_locales" varchar[] COLLATE "pg_catalog"."default" NOT NULL,
                                  "api_url" varchar COLLATE "pg_catalog"."default" NOT NULL,
                                  "client_url" varchar COLLATE "pg_catalog"."default" NOT NULL,
                                  "is_public" bool DEFAULT true,
                                  "is_statistic_shown" bool DEFAULT true,
                                  "wager_set_id" uuid,
                                  "is_demo" bool DEFAULT true,
                                  "is_freespins" bool DEFAULT false
)
;

-- ----------------------------
-- Table structure for integrator_games
-- ----------------------------
DROP TABLE IF EXISTS "public"."integrator_games";
CREATE TABLE "public"."integrator_games" (
                                             "organization_id" uuid NOT NULL,
                                             "game_id" uuid NOT NULL
)
;

-- ----------------------------
-- Table structure for integrator_providers
-- ----------------------------
DROP TABLE IF EXISTS "public"."integrator_providers";
CREATE TABLE "public"."integrator_providers" (
                                                 "id" uuid NOT NULL,
                                                 "provider_id" uuid,
                                                 "integrator_id" uuid
)
;

-- ----------------------------
-- Table structure for organizations
-- ----------------------------
DROP TABLE IF EXISTS "public"."organizations";
CREATE TABLE "public"."organizations" (
                                          "created_at" timestamptz(6) DEFAULT now(),
                                          "updated_at" timestamptz(6),
                                          "deleted_at" timestamptz(6),
                                          "id" uuid NOT NULL DEFAULT gen_random_uuid(),
                                          "name" varchar(255) COLLATE "pg_catalog"."default",
                                          "type" varchar(20) COLLATE "pg_catalog"."default",
                                          "status" int4,
                                          "api_key" varchar COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Table structure for permissions
-- ----------------------------
DROP TABLE IF EXISTS "public"."permissions";
CREATE TABLE "public"."permissions" (
                                        "id" uuid NOT NULL DEFAULT gen_random_uuid(),
                                        "name" varchar(255) COLLATE "pg_catalog"."default",
                                        "description" varchar(255) COLLATE "pg_catalog"."default",
                                        "subject" varchar(40) COLLATE "pg_catalog"."default",
                                        "endpoint" varchar(255) COLLATE "pg_catalog"."default",
                                        "action" varchar(255) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Table structure for role_permissions
-- ----------------------------
DROP TABLE IF EXISTS "public"."role_permissions";
CREATE TABLE "public"."role_permissions" (
                                             "created_at" timestamptz(6) DEFAULT now(),
                                             "role_id" uuid NOT NULL,
                                             "permission_id" uuid NOT NULL
)
;

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS "public"."roles";
CREATE TABLE "public"."roles" (
                                  "created_at" timestamptz(6) DEFAULT now(),
                                  "updated_at" timestamptz(6),
                                  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
                                  "organization_id" uuid,
                                  "name" varchar(255) COLLATE "pg_catalog"."default",
                                  "description" varchar(255) COLLATE "pg_catalog"."default",
                                  "type" varchar(255) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Table structure for spins
-- ----------------------------
DROP TABLE IF EXISTS "public"."spins";
CREATE TABLE "public"."spins" (
                                  "created_at" timestamptz(6) DEFAULT now(),
                                  "updated_at" timestamptz(6) DEFAULT now(),
                                  "id" uuid NOT NULL,
                                  "game_id" uuid NOT NULL,
                                  "session_token" uuid,
                                  "integrator" varchar(32) COLLATE "pg_catalog"."default",
                                  "user_id" varchar(128) COLLATE "pg_catalog"."default",
                                  "currency" varchar(10) COLLATE "pg_catalog"."default",
                                  "start_balance" int8,
                                  "end_balance" int8,
                                  "wager" int8,
                                  "base_award" int8,
                                  "bonus_award" int8,
                                  "spin" jsonb,
                                  "restoring_indexes" jsonb,
                                  "additional_data" jsonb,
                                  "is_shown" bool,
                                  "is_pfr" bool DEFAULT false,
                                  "host" varchar COLLATE "pg_catalog"."default" DEFAULT 'no-host'::character varying,
                                  "external_user_id" varchar(256) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Table structure for tokens
-- ----------------------------
DROP TABLE IF EXISTS "public"."tokens";
CREATE TABLE "public"."tokens" (
                                   "created_at" timestamptz(6) DEFAULT now(),
                                   "id" uuid NOT NULL DEFAULT gen_random_uuid(),
                                   "account_id" uuid,
                                   "access_token" text COLLATE "pg_catalog"."default" NOT NULL,
                                   "refresh_token" text COLLATE "pg_catalog"."default" NOT NULL,
                                   "expired_at" timestamptz(6) NOT NULL
)
;

-- ----------------------------
-- Table structure for wager_sets
-- ----------------------------
DROP TABLE IF EXISTS "public"."wager_sets";
CREATE TABLE "public"."wager_sets" (
                                       "created_at" timestamp(6),
                                       "updated_at" timestamp(6),
                                       "id" uuid NOT NULL,
                                       "organization_id" uuid,
                                       "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
                                       "wager_levels" int4[],
                                       "default_wager" int4,
                                       "is_active" bool
)
;

-- ----------------------------
-- Procedure structure for refresh_admin_permissions
-- ----------------------------
DROP PROCEDURE IF EXISTS "public"."refresh_admin_permissions"();
CREATE OR REPLACE PROCEDURE "public"."refresh_admin_permissions"()
 AS $BODY$
declare p uuid[];
    declare r uuid[];
    declare permission uuid;
    declare role uuid;
begin
select array(select id from permissions into p);
select array(select id from roles where "type" = 'admin' into r);

delete from role_permissions where role_id = any(r);
foreach permission in array p loop
            foreach role in array r loop
                    insert into role_permissions(created_at, role_id, permission_id)
                    values (now(), role, permission);
end loop;
end loop;
end
$BODY$
LANGUAGE plpgsql;

-- ----------------------------
-- Primary Key structure for table account_organizations
-- ----------------------------
ALTER TABLE "public"."account_organizations" ADD CONSTRAINT "account_organizations_pkey" PRIMARY KEY ("account_id", "organization_id");

-- ----------------------------
-- Primary Key structure for table account_permissions
-- ----------------------------
ALTER TABLE "public"."account_permissions" ADD CONSTRAINT "account_permissions_pkey" PRIMARY KEY ("account_id", "permission_id", "organization_id");

-- ----------------------------
-- Primary Key structure for table account_roles
-- ----------------------------
ALTER TABLE "public"."account_roles" ADD CONSTRAINT "account_roles_pkey" PRIMARY KEY ("account_id", "role_id");

-- ----------------------------
-- Primary Key structure for table accounts
-- ----------------------------
ALTER TABLE "public"."accounts" ADD CONSTRAINT "accounts_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table currencies
-- ----------------------------
ALTER TABLE "public"."currencies" ADD CONSTRAINT "currencies_pkey" PRIMARY KEY ("title");

-- ----------------------------
-- Primary Key structure for table currency_multipliers
-- ----------------------------
ALTER TABLE "public"."currency_multipliers" ADD CONSTRAINT "currency_multipliers_pkey" PRIMARY KEY ("organization_pair_id", "title");

-- ----------------------------
-- Uniques structure for table currency_sets
-- ----------------------------
ALTER TABLE "public"."currency_sets" ADD CONSTRAINT "currency_sets_organization_id_name_key" UNIQUE ("organization_id", "name");

-- ----------------------------
-- Primary Key structure for table currency_sets
-- ----------------------------
ALTER TABLE "public"."currency_sets" ADD CONSTRAINT "currency_sets_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table games
-- ----------------------------
CREATE INDEX "idx_game_name" ON "public"."games" USING hash (
    "name" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops"
    );

-- ----------------------------
-- Uniques structure for table games
-- ----------------------------
ALTER TABLE "public"."games" ADD CONSTRAINT "games_name_key" UNIQUE ("name");

-- ----------------------------
-- Primary Key structure for table games
-- ----------------------------
ALTER TABLE "public"."games" ADD CONSTRAINT "games_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table integrator_games
-- ----------------------------
ALTER TABLE "public"."integrator_games" ADD CONSTRAINT "integrator_games_pkey" PRIMARY KEY ("organization_id", "game_id");

-- ----------------------------
-- Primary Key structure for table integrator_providers
-- ----------------------------
ALTER TABLE "public"."integrator_providers" ADD CONSTRAINT "integrator_providers_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table organizations
-- ----------------------------
ALTER TABLE "public"."organizations" ADD CONSTRAINT "organizations_name_type_unique" UNIQUE ("name", "type");

-- ----------------------------
-- Primary Key structure for table organizations
-- ----------------------------
ALTER TABLE "public"."organizations" ADD CONSTRAINT "organizations_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Uniques structure for table permissions
-- ----------------------------
ALTER TABLE "public"."permissions" ADD CONSTRAINT "permissions_name_key" UNIQUE ("name");

-- ----------------------------
-- Primary Key structure for table permissions
-- ----------------------------
ALTER TABLE "public"."permissions" ADD CONSTRAINT "permissions_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table role_permissions
-- ----------------------------
ALTER TABLE "public"."role_permissions" ADD CONSTRAINT "role_permissions_pkey" PRIMARY KEY ("role_id", "permission_id");

-- ----------------------------
-- Uniques structure for table roles
-- ----------------------------
ALTER TABLE "public"."roles" ADD CONSTRAINT "role_organization_name_constraint" UNIQUE ("organization_id", "name");

-- ----------------------------
-- Primary Key structure for table roles
-- ----------------------------
ALTER TABLE "public"."roles" ADD CONSTRAINT "roles_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Indexes structure for table spins
-- ----------------------------
CREATE INDEX "idx_external_user_id" ON "public"."spins" USING hash (
    "external_user_id" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops"
    );
CREATE INDEX "idx_spins_currency" ON "public"."spins" USING hash (
    "currency" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops"
    );
CREATE INDEX "idx_spins_game_id" ON "public"."spins" USING hash (
    "game_id" "pg_catalog"."uuid_ops"
    );
CREATE INDEX "idx_spins_host" ON "public"."spins" USING hash (
    "host" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops"
    );
CREATE INDEX "idx_spins_session_token" ON "public"."spins" USING hash (
    "session_token" "pg_catalog"."uuid_ops"
    );

-- ----------------------------
-- Primary Key structure for table spins
-- ----------------------------
ALTER TABLE "public"."spins" ADD CONSTRAINT "spins_pkey" PRIMARY KEY ("id", "game_id");

-- ----------------------------
-- Uniques structure for table wager_sets
-- ----------------------------
ALTER TABLE "public"."wager_sets" ADD CONSTRAINT "wager_sets_organization_id_name_key" UNIQUE ("organization_id", "name");

-- ----------------------------
-- Primary Key structure for table wager_sets
-- ----------------------------
ALTER TABLE "public"."wager_sets" ADD CONSTRAINT "wager_sets_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Foreign Keys structure for table account_organizations
-- ----------------------------
ALTER TABLE "public"."account_organizations" ADD CONSTRAINT "account_organizations_account_id_fkey" FOREIGN KEY ("account_id") REFERENCES "public"."accounts" ("id") ON DELETE CASCADE ON UPDATE NO ACTION;
ALTER TABLE "public"."account_organizations" ADD CONSTRAINT "account_organizations_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations" ("id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table account_permissions
-- ----------------------------
ALTER TABLE "public"."account_permissions" ADD CONSTRAINT "account_permissions_account_id_fkey" FOREIGN KEY ("account_id") REFERENCES "public"."accounts" ("id") ON DELETE CASCADE ON UPDATE NO ACTION;
ALTER TABLE "public"."account_permissions" ADD CONSTRAINT "account_permissions_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations" ("id") ON DELETE CASCADE ON UPDATE NO ACTION;
ALTER TABLE "public"."account_permissions" ADD CONSTRAINT "account_permissions_permission_id_fkey" FOREIGN KEY ("permission_id") REFERENCES "public"."permissions" ("id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table account_roles
-- ----------------------------
ALTER TABLE "public"."account_roles" ADD CONSTRAINT "account_roles_account_id_fkey" FOREIGN KEY ("account_id") REFERENCES "public"."accounts" ("id") ON DELETE CASCADE ON UPDATE NO ACTION;
ALTER TABLE "public"."account_roles" ADD CONSTRAINT "account_roles_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "public"."roles" ("id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table currency_multipliers
-- ----------------------------
ALTER TABLE "public"."currency_multipliers" ADD CONSTRAINT "fk_currency_multipliers_title" FOREIGN KEY ("title") REFERENCES "public"."currencies" ("title") ON DELETE CASCADE ON UPDATE CASCADE;

-- ----------------------------
-- Foreign Keys structure for table currency_sets
-- ----------------------------
ALTER TABLE "public"."currency_sets" ADD CONSTRAINT "currency_sets_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table games
-- ----------------------------
ALTER TABLE "public"."games" ADD CONSTRAINT "games_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table integrator_games
-- ----------------------------
ALTER TABLE "public"."integrator_games" ADD CONSTRAINT "integrator_games_game_id_fkey" FOREIGN KEY ("game_id") REFERENCES "public"."games" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "public"."integrator_games" ADD CONSTRAINT "integrator_games_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations" ("id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table integrator_providers
-- ----------------------------
ALTER TABLE "public"."integrator_providers" ADD CONSTRAINT "integrator_providers_integrator_id_fkey" FOREIGN KEY ("integrator_id") REFERENCES "public"."organizations" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "public"."integrator_providers" ADD CONSTRAINT "integrator_providers_provider_id_fkey" FOREIGN KEY ("provider_id") REFERENCES "public"."organizations" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table role_permissions
-- ----------------------------
ALTER TABLE "public"."role_permissions" ADD CONSTRAINT "role_permissions_permission_id_fkey" FOREIGN KEY ("permission_id") REFERENCES "public"."permissions" ("id") ON DELETE CASCADE ON UPDATE NO ACTION;
ALTER TABLE "public"."role_permissions" ADD CONSTRAINT "role_permissions_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "public"."roles" ("id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table roles
-- ----------------------------
ALTER TABLE "public"."roles" ADD CONSTRAINT "roles_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations" ("id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table spins
-- ----------------------------
ALTER TABLE "public"."spins" ADD CONSTRAINT "spins_game_id_fkey" FOREIGN KEY ("game_id") REFERENCES "public"."games" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table wager_sets
-- ----------------------------
ALTER TABLE "public"."wager_sets" ADD CONSTRAINT "wager_sets_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "public"."organizations" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
