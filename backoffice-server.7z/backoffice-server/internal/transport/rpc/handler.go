package rpc

import (
	e "backoffice/internal/errors"
	"backoffice/internal/services"
	"backoffice/pkg/backoffice"
	"context"
	"errors"
	"io"

	"go.uber.org/zap"
)

type Handler struct {
	backoffice.BackofficeServer
	cfg                 *Config
	organizationService *services.OrganizationService
	gameService         *services.GameService
}

func NewHandler(cfg *Config, organizationService *services.OrganizationService, gameService *services.GameService) *Handler {
	return &Handler{
		cfg:                 cfg,
		organizationService: organizationService,
		gameService:         gameService,
	}
}

func (h *Handler) HasAccess(ctx context.Context, in *backoffice.HasAccessIn) (*backoffice.HasAccessOut, error) {
	ctx, cancel := context.WithTimeout(ctx, h.cfg.MaxProcessingTime)
	defer cancel()

	integrator, err := h.organizationService.GetByApiKey(ctx, in.ApiKey)
	if err != nil {
		zap.S().Error(err)

		if errors.Is(err, e.ErrEntityNotFound) {
			return nil, WrapInGRPCError(e.ErrNotAuthorized)
		}

		return nil, WrapInGRPCError(e.ErrInternal)
	}

	if err = h.organizationService.HasAccess(ctx, integrator.ID, in.Game); err != nil {
		zap.S().Error(err)

		if errors.Is(err, e.ErrDoesNotHavePermission) {
			return nil, WrapInGRPCError(err)
		}

		return nil, WrapInGRPCError(e.ErrInternal)
	}

	return &backoffice.HasAccessOut{HasAccess: true, Integrator: integrator.Name}, nil
}

func (h *Handler) GameList(ctx context.Context, in *backoffice.GameListIn) (*backoffice.GameListOut, error) {
	ctx, cancel := context.WithTimeout(ctx, h.cfg.MaxProcessingTime)
	defer cancel()

	integrator, err := h.organizationService.GetByApiKey(ctx, in.ApiKey)
	if err != nil {
		zap.S().Error(err)

		if errors.Is(err, e.ErrEntityNotFound) {
			return nil, WrapInGRPCError(err)
		}

		return nil, WrapInGRPCError(e.ErrInternal)
	}

	games, err := h.gameService.GetIntegratorGameList(ctx, integrator.ID)
	if err != nil {
		zap.S().Error(err)

		return nil, WrapInGRPCError(e.ErrInternal)
	}

	return &backoffice.GameListOut{Games: games}, nil
}

func (h *Handler) GameListFull(ctx context.Context, in *backoffice.GameListIn) (*backoffice.GameListOutFull, error) {
	ctx, cancel := context.WithTimeout(ctx, h.cfg.MaxProcessingTime)
	defer cancel()

	integrator, err := h.organizationService.GetByApiKey(ctx, in.ApiKey)
	if err != nil {
		zap.S().Error(err)

		if errors.Is(err, e.ErrEntityNotFound) {
			return nil, WrapInGRPCError(err)
		}

		return nil, WrapInGRPCError(e.ErrInternal)
	}

	games, err := h.gameService.GetIntegratorGames(ctx, integrator.ID)
	if err != nil {
		zap.S().Error(err)

		return nil, WrapInGRPCError(e.ErrInternal)
	}

	var res []*backoffice.Game = make([]*backoffice.Game, 0, len(games))

	for _, game := range games {
		res = append(res, &backoffice.Game{
			Id:               game.ID.String(),
			Name:             game.Name,
			ApiUrl:           game.ApiUrl,
			ClientUrl:        game.ClientUrl,
			IsPublic:         game.IsPublic,
			IsStatisticShown: game.IsStatisticShown,
			Languages:        game.Languages,
			Currencies:       game.Currencies,
			IsDemo:           game.IsDemo,
			IsFreespins:      game.IsFreespins,
		})
	}

	return &backoffice.GameListOutFull{Games: res}, nil
}

func (h *Handler) GetProvider(ctx context.Context, in *backoffice.GetProviderIn) (*backoffice.GetProviderOut, error) {
	res, err := h.gameService.GetGameByName(ctx, in.GameName)
	if err != nil {
		return nil, err
	}

	return &backoffice.GetProviderOut{Provider: res.Organization.Name}, err
}

func (h *Handler) HealthCheck(stream backoffice.Backoffice_HealthCheckServer) error {
	for {
		msg, err := stream.Recv()
		if err != nil {
			if err == io.EOF {
				return nil
			}

			return err
		}

		if err = stream.Send(msg); err != nil {
			if err == io.EOF {
				return nil
			}

			return err
		}
	}
}
