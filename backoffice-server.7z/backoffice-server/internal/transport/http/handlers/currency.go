package handlers

import (
	e "backoffice/internal/errors"
	"backoffice/internal/services"
	"backoffice/internal/transport/http/requests"
	"backoffice/internal/transport/http/response"
	"errors"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"github.com/google/uuid"
)

type currencyHandler struct {
	currencyService *services.CurrencyService
}

func (h *currencyHandler) Register(router *gin.RouterGroup) {
	currency := router.Group("currency")

	currency.POST("multiplier", h.create)
	currency.PUT("multiplier", h.update)
	currency.DELETE("multiplier", h.delete)
	currency.POST("multiplier/get", h.get)
	currency.POST("multiplier/search", h.search)

}

func NewCurrencyHandler(currencyService *services.CurrencyService) *currencyHandler {
	return &currencyHandler{currencyService: currencyService}
}

// @Summary Create new currency for specific provider and integrator.
// @Tags currency
// @Consume application/json
// @Description Create new currency and bound multiplier by provider_id and integrator_id.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param data body requests.CurrencyMultiplier true "CreateCurrencyMultiplier"
// @Success 200 {object} response.Response{data=entities.CurrencyMultiplier}
// @Router /api/currency/multiplier [post].
func (h *currencyHandler) create(ctx *gin.Context) {
	req := requests.CurrencyMultiplier{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	cm, err := h.currencyService.CreateCurrencyMultiplier(ctx, req.OrganizationPairID, req.Title, req.Multiplier)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, cm, nil)
}

// @Summary Get currency multiplier.
// @Tags currency
// @Consume application/json
// @Description Get currency multiplier information.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param data body requests.CurrencyMultiplierIdentify true "CurrencyMultiplierIdentify"
// @Success 200 {object} response.Response{data=entities.CurrencyMultiplier}
// @Router /api/currency/multiplier/get [post].
func (h *currencyHandler) get(ctx *gin.Context) {
	req := &requests.CurrencyMultiplierIdentify{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	cm, err := h.currencyService.Get(ctx, req.OrganizationPairID, req.Title)
	if err != nil {
		if errors.Is(err, e.ErrEntityNotFound) {
			response.NotFound(ctx, err, nil)

			return
		}

		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, cm, nil)
}

// @Summary Get all currency by filter.
// @Tags currency
// @Consume application/json
// @Description Filtering can be done by organization_pair_id or you can send an empty request body
// @Description and get all currency.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param request body requests.CurrencySearchRequest true "CurrencySearch"
// @Success 200 {object} response.Response{data=[]entities.CurrencyMultiplier}
// @Router /api/currency/multiplier/search [post].
func (h *currencyHandler) search(ctx *gin.Context) {
	req := &requests.CurrencySearchRequest{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	filter := make(map[string]interface{})

	if req.OrganizationPairID != uuid.Nil {
		filter["organization_pair_id"] = req.OrganizationPairID
	}

	cm, err := h.currencyService.Search(ctx, filter)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, cm, nil)
}

// @Summary Updates currency for specific provider and integrator.
// @Tags currency
// @Consume application/json
// @Description Updates currency and bound multiplier by provider_id and integrator_id.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param data body requests.CurrencyMultiplier true "CreateCurrencyMultiplier"
// @Success 200 {object} response.Response{data=entities.CurrencyMultiplier}
// @Router /api/currency/multiplier [put].
func (h *currencyHandler) update(ctx *gin.Context) {
	req := requests.CurrencyMultiplier{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	cm, err := h.currencyService.UpdateCurrencyMultiplier(ctx, req.OrganizationPairID, req.Title, req.Multiplier)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, cm, nil)
}

// @Summary Delete currency for specific provider and integrator.
// @Tags currency
// @Consume application/json
// @Description Delete currency and bound multiplier by provider_id and integrator_id.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param data body requests.CurrencyMultiplierIdentify true "CurrencyMultiplierIdentify"
// @Success 204
// @Router /api/currency/multiplier [delete].
func (h *currencyHandler) delete(ctx *gin.Context) {
	req := &requests.CurrencyMultiplierIdentify{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	err := h.currencyService.DeleteCurrencyMultiplier(ctx, req.OrganizationPairID, req.Title)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.NoContent(ctx)
}
