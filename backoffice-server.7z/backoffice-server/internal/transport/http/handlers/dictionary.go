package handlers

import (
	"backoffice/internal/entities"
	"backoffice/internal/services"
	"backoffice/internal/transport/http/response"
	"github.com/gin-gonic/gin"
)

type dictionaryHandler struct {
	gameService         *services.GameService
	spinService         *services.SpinService
	currencyService     *services.CurrencyService
	organizationService *services.OrganizationService
}

func NewDictionaryHandler(
	gameService *services.GameService, spinService *services.SpinService,
	currencyService *services.CurrencyService, organizationService *services.OrganizationService) *dictionaryHandler {
	return &dictionaryHandler{
		gameService:         gameService,
		spinService:         spinService,
		currencyService:     currencyService,
		organizationService: organizationService,
	}
}

func (h *dictionaryHandler) Register(route *gin.RouterGroup) {
	dictionary := route.Group("dictionaries")
	dictionary.GET("games", h.games)
	dictionary.GET("hosts", h.hosts)
	dictionary.GET("currencies", h.currencies)
	dictionary.GET("jurisdictions", h.jurisdictions)
	dictionary.GET("languages", h.languages)
	dictionary.GET("locales", h.locales)
	dictionary.GET("integrators", h.integrators)
	dictionary.GET("integrator-operators", h.integratorOperators)
	dictionary.GET("main-currencies", h.mainCurrencies)
}

// @Summary Get available games.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of available games for filters.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200 {object} response.Response{data=[]entities.Game}
// @Router /api/dictionaries/games [get].
func (h *dictionaryHandler) games(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)
	games, err := h.gameService.AllForStat(ctx, &session.OrganizationID)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, games, nil)
}

// @Summary Get available hosts.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of available hosts for filters.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200 {object} response.Response{data=[]string}
// @Router /api/dictionaries/hosts [get].
func (h *dictionaryHandler) hosts(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)
	games, err := h.spinService.Hosts(ctx, &session.OrganizationID)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, games, nil)
}

// @Summary Get available currencies.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of available currencies.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200 {object} response.Response{data=[]string}
// @Router /api/dictionaries/currencies [get].
func (h *dictionaryHandler) currencies(ctx *gin.Context) {
	currencies, err := h.currencyService.UniqueCurrencyNames(ctx)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, currencies, nil)
}

// @Summary Get available jurisdictions.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of available jurisdictions.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200 {object} response.Response{data=[]string}
// @Router /api/dictionaries/jurisdictions [get].
func (h *dictionaryHandler) jurisdictions(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)
	dict, err := h.gameService.GetDictionaries(ctx, &session.OrganizationID, "jurisdictions")
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, dict, nil)
}

// @Summary Get available languages.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of available languages.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200 {object} response.Response{data=[]string}
// @Router /api/dictionaries/languages [get].
func (h *dictionaryHandler) languages(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)
	dict, err := h.gameService.GetDictionaries(ctx, &session.OrganizationID, "languages")
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, dict, nil)
}

// @Summary Get available locales.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of available locales.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200 {object} response.Response{data=[]string}
// @Router /api/dictionaries/locales [get].
func (h *dictionaryHandler) locales(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)
	dict, err := h.gameService.GetDictionaries(ctx, &session.OrganizationID, "user_locales")
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, dict, nil)
}

// @Summary Get available integrators.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of available integrators.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200 {object} response.Response{data=[]string}
// @Router /api/dictionaries/integrators [get].
func (h *dictionaryHandler) integrators(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)

	integrators, err := h.organizationService.GetIntegratorNames(ctx, session.OrganizationID)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, integrators, nil)
}

// @Summary Get available integrator/operator pair.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of available integrator/operator pair.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200 {object} response.Response{data=map[string][]string}
// @Router /api/dictionaries/integrator-operators [get].
func (h *dictionaryHandler) integratorOperators(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)

	integrators, err := h.spinService.IntegratorOperatorsMap(ctx, &session.OrganizationID)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, integrators, nil)
}

// @Summary Get main currencies.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of main currencies.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200 {object} response.Response{data=[]string}
// @Router /api/dictionaries/main-currencies [get].
func (h *dictionaryHandler) mainCurrencies(ctx *gin.Context) {
	response.OK(ctx, []string{"usd", "eur"}, nil)
}
