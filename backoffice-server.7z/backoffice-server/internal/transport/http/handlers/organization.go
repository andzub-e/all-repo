package handlers

import (
	"backoffice/internal/entities"
	e "backoffice/internal/errors"
	"backoffice/internal/services"
	"backoffice/internal/transport/http/requests"
	"backoffice/internal/transport/http/response"
	"errors"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"github.com/google/uuid"
)

type organizationHandler struct {
	organizationService *services.OrganizationService
}

func NewOrganizationHandler(organizationService *services.OrganizationService) *organizationHandler {
	return &organizationHandler{
		organizationService: organizationService,
	}
}

func (h *organizationHandler) Register(route *gin.RouterGroup) {
	organizations := route.Group("organizations")
	{
		organizations.GET("", h.all)
		organizations.POST("", h.create)
		organizations.POST("get_organization_pair", h.getOrganizationPair)
		organizations.POST("add_organization_pair", h.addOrganizationPair)
		organizations.DELETE("delete_organization_pair", h.deleteOrganizationPair)

		organization := organizations.Group(":id")
		{
			organization.DELETE("", h.delete)
			organization.GET("", h.get)
			organization.PUT("", h.update)
			organization.GET("game", h.getGame)
			organization.POST("game", h.assignGames)
			organization.DELETE("game", h.revokeGames)
		}
	}
}

// @Summary Get organizations list.
// @Tags organizations
// @Consume application/json
// @Description Available backoffice roles.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param limit query int true "rows limit"
// @Param offset query int true "rows offset"
// @Param order query string false "order field"
// @Success 200 {object} response.Response{data=[]entities.Organization}
// @Router /api/organizations [get].
func (h *organizationHandler) all(ctx *gin.Context) {
	req := &requests.Pagination{}
	if err := ctx.ShouldBindQuery(&req); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	organizations, total, err := h.organizationService.Paginate(ctx, req.Filters, req.Order, req.Limit, req.Offset)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	req.Total = total

	response.OK(ctx, organizations, req)
}

// @Summary Get organization.
// @Tags organizations
// @Consume application/json
// @Description Get organization.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param id path string true "organization_id"
// @Success 200  {object} response.Response{data=entities.Organization}
// @Router /api/organizations/{id} [get].
func (h *organizationHandler) get(ctx *gin.Context) {
	organizationID, err := uuid.Parse(ctx.Param("id"))
	if err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	organization, err := h.organizationService.Get(ctx, organizationID)
	if err != nil {
		if errors.Is(err, e.ErrEntityNotFound) {
			response.NotFound(ctx, err, nil)

			return
		}

		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, organization, nil)
}

// @Summary Add new organization.
// @Tags organizations
// @Consume application/json
// @Description Create organization.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param data body requests.UpsertOrganizationRequest true  "CreateOrganizationRequest"
// @Success 200 {object} response.Response{data=entities.Organization}
// @Router /api/organizations [post].
func (h *organizationHandler) create(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)
	req := &requests.UpsertOrganizationRequest{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	organization, err := h.organizationService.Create(ctx, req.Status, req.Name, req.Type)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	if _, err = h.organizationService.Assign(ctx, session.Account.ID, organization.ID); err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, organization, nil)
}

// @Summary Update organization.
// @Tags organizations
// @Consume application/json
// @Description Update organization.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param id path string true "organization_id"
// @Param data body requests.UpsertOrganizationRequest true "UpdateOrganizationRequest"
// @Success 200 {object} response.Response{data=entities.Organization}
// @Router /api/organizations/{id} [put].
func (h *organizationHandler) update(ctx *gin.Context) {
	req := &requests.UpsertOrganizationRequest{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	organizationID, err := uuid.Parse(ctx.Param("id"))
	if err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	organization, err := h.organizationService.Update(ctx, organizationID, req.Status, req.Name, req.Type)
	if err != nil {
		if errors.Is(err, e.ErrEntityNotFound) {
			response.NotFound(ctx, err, nil)

			return
		}

		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, organization, nil)
}

// @Summary Delete organization.
// @Tags organizations
// @Consume application/json
// @Description Delete existing organization.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param id path string true "organization_id"
// @Success 204
// @Router /api/organizations/{id} [delete].
func (h *organizationHandler) delete(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)
	organizationID, err := uuid.Parse(ctx.Param("id"))
	if err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	err = h.organizationService.Delete(ctx, session.Account.ID, organizationID)
	if err != nil {
		if errors.Is(err, e.ErrEntityNotFound) {
			response.NotFound(ctx, err, nil)

			return
		}

		response.BadRequest(ctx, err, nil)

		return
	}

	response.NoContent(ctx)
}

// @Summary get integrator games.
// @Tags organizations
// @Consume application/json
// @Description get integrator games.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param id path string true "organization_id"
// @Success 200 {object} response.Response{data=[]entities.IntegratorGame}
// @Router /api/organizations/{id}/game [get].
func (h *organizationHandler) getGame(ctx *gin.Context) {
	integratorID, err := uuid.Parse(ctx.Param("id"))
	if err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	ig, err := h.organizationService.GetGames(ctx, integratorID)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, ig, nil)
}

// @Summary add integrator game.
// @Tags organizations
// @Consume application/json
// @Description The provider_id field is required. If you send only the provider_id,
// @Description all games from the provider will be added. To add selected games, fill out the game_id.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param id path string true "organization_id"
// @Param data body requests.IntegratorGameRequest true "IntegratorGameRequest"
// @Success 200 {object} response.Response{data=[]entities.IntegratorGame}
// @Router /api/organizations/{id}/game [post].
func (h *organizationHandler) assignGames(ctx *gin.Context) {
	req := &requests.IntegratorGameRequest{}
	if err := ctx.ShouldBind(&req); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	integratorID, err := uuid.Parse(ctx.Param("id"))
	if err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	ig, err := h.organizationService.AssignGames(ctx, integratorID, req.GameID...)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, ig, nil)
}

// @Summary delete integrator game.
// @Tags organizations
// @Consume application/json
// @Description The provider_id field is required. If you send only the provider_id,
// @Description all games from the provider will be deleted. To delete selected games, fill out the game_id.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param id path string true "organization_id"
// @Param data body requests.IntegratorGameRequest true "IntegratorGameRequest"
// @Success 204
// @Router /api/organizations/{id}/game [delete].
func (h *organizationHandler) revokeGames(ctx *gin.Context) {
	req := &requests.IntegratorGameRequest{}
	if err := ctx.ShouldBind(&req); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	integratorID, err := uuid.Parse(ctx.Param("id"))
	if err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	err = h.organizationService.RevokeGames(ctx, integratorID, req.GameID...)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.NoContent(ctx)
}

// @Summary Get organization pair.
// @Tags organizations
// @Consume application/json
// @Description Get organization pair.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param data body requests.CurrencyOrganizationPair true "CurrencyOrganizationPair"
// @Success 200 {object} response.Response{data=entities.ProviderIntegratorPair}
// @Router /api/organizations/get_organization_pair [post].
func (h *organizationHandler) getOrganizationPair(ctx *gin.Context) {
	req := &requests.CurrencyOrganizationPair{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	pair, err := h.organizationService.GetOrganizationPair(ctx, req.ProviderID, req.IntegratorID)
	if err != nil {
		if errors.Is(err, e.ErrEntityNotFound) {
			response.NotFound(ctx, err, nil)

			return
		}

		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, pair, nil)
}

// @Summary Add organization pair.
// @Tags organizations
// @Consume application/json
// @Description Add organization pair.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param data body requests.CurrencyOrganizationPair true "CurrencyOrganizationPair"
// @Success 200 {object} response.Response{data=entities.ProviderIntegratorPair}
// @Router /api/organizations/add_organization_pair [post].
func (h *organizationHandler) addOrganizationPair(ctx *gin.Context) {
	req := &requests.CurrencyOrganizationPair{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	pair, err := h.organizationService.CreateOrganizationPair(ctx, req.ProviderID, req.IntegratorID)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, pair, nil)
}

// @Summary Delete organization pair.
// @Tags organizations
// @Consume application/json
// @Description Delete organization pair.
// @Accept json
// @Produce json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param data body requests.CurrencyOrganizationPair true "CurrencyOrganizationPair"
// @Success 204
// @Router /api/organizations/delete_organization_pair [delete].
func (h *organizationHandler) deleteOrganizationPair(ctx *gin.Context) {
	req := &requests.CurrencyOrganizationPair{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	err := h.organizationService.DeleteOrganizationPair(ctx, req.ProviderID, req.IntegratorID)
	if err != nil {
		if errors.Is(err, e.ErrEntityNotFound) {
			response.NotFound(ctx, err, nil)

			return
		}

		response.BadRequest(ctx, err, nil)

		return
	}

	response.NoContent(ctx)
}
