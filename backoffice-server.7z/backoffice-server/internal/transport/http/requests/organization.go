package requests

import "github.com/google/uuid"

type UpsertOrganizationRequest struct {
	Name   string `json:"name" validate:"required"`
	Type   string `json:"type" validate:"required"`
	Status int64  `json:"status"`
}

type IntegratorGameRequest struct {
	GameID []uuid.UUID `json:"game_id" validate:"required"`
}
