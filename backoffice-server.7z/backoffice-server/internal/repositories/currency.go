package repositories

import (
	"backoffice/internal/entities"
	"context"
)

type CurrencyRepository interface {
	All(ctx context.Context) ([]*entities.CurrencyMultiplier, error)
	UniqueCurrencyNames(ctx context.Context) ([]string, error)
	Search(ctx context.Context, filter map[string]interface{}) (cm []*entities.CurrencyMultiplier, err error)
	CreateCurrencyMultiplier(ctx context.Context, cm *entities.CurrencyMultiplier) (*entities.CurrencyMultiplier, error)
	Get(ctx context.Context, params map[string]interface{}) (account *entities.CurrencyMultiplier, err error)
	UpdateCurrencyMultiplier(ctx context.Context, cm *entities.CurrencyMultiplier) (*entities.CurrencyMultiplier, error)
	DeleteCurrencyMultiplier(ctx context.Context, cm *entities.CurrencyMultiplier) error
}
