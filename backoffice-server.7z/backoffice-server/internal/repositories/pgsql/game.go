package pgsql

import (
	"backoffice/internal/entities"
	e "backoffice/internal/errors"
	"context"
	"errors"
	"fmt"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type gameRepository struct {
	conn *gorm.DB
}

func NewGameRepository(conn *gorm.DB) *gameRepository {
	return &gameRepository{conn: conn}
}

func (r *gameRepository) GetBy(ctx context.Context, condition map[string]interface{}) (*entities.Game, error) {
	g := &entities.Game{}
	if err := r.conn.WithContext(ctx).Preload("Organization").Where(condition).First(&g).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, e.ErrEntityNotFound
		}

		return nil, err
	}

	return g, nil
}

func (r *gameRepository) Create(ctx context.Context, game *entities.Game) (*entities.Game, error) {
	err := r.conn.WithContext(ctx).Create(game).Error
	if err != nil {
		return nil, err
	}

	return game, nil
}

func (r *gameRepository) All(ctx context.Context, organizationID *uuid.UUID, condition map[string]interface{}) (games []*entities.Game, err error) {
	conn := r.conn.WithContext(ctx)
	conn = r.withOwner(conn, organizationID).Preload("WagerSet")

	if err = conn.Where(condition).Find(&games).Error; err != nil {
		return nil, err
	}

	return games, nil
}

func (r *gameRepository) Paginate(ctx context.Context, filters map[string]interface{}, order string, limit int, offset int) (games []*entities.Game, total int64, err error) {
	query := r.conn.WithContext(ctx).Model(&entities.Game{}).Where(filters)

	if err = query.Count(&total).Error; err != nil {
		return
	}

	if err = query.Order(order).Limit(limit).Offset(offset).Find(&games).Error; err != nil {
		return
	}
	return
}

func (r *gameRepository) GetDictionaries(ctx context.Context, organizationID *uuid.UUID, dictType string) (dict []string, err error) {
	conn := r.conn.WithContext(ctx)
	conn = r.withOwner(conn, organizationID).Preload("WagerSet")

	query := fmt.Sprintf(`SELECT DISTINCT unnest(%s) FROM games`, dictType)

	rows, err := conn.Raw(query).Rows()
	if err != nil {
		return nil, err
	}

	defer rows.Close()

	for rows.Next() {
		var value string
		if err := rows.Scan(&value); err != nil {
			return nil, err
		}
		dict = append(dict, value)
	}

	return dict, nil
}

func (r *gameRepository) GetAllByFilter(ctx context.Context, condition map[string]interface{}) (games []*entities.Game, err error) {
	query := r.conn.WithContext(ctx).Model(&entities.Game{})

	if len(condition) > 0 {
		query = query.Where(condition)
	}

	if err = query.Find(&games).Error; err != nil {
		return
	}

	return
}

func (r *gameRepository) GetOrganizationGameList(ctx context.Context, organizationID uuid.UUID) (games []*entities.Game, err error) {
	err = r.conn.WithContext(ctx).
		Select("distinct (games.id) as _, games.*").
		Joins(`inner join integrator_providers as ip 
						on games.organization_id = ip.provider_id`).
		Where("ip.integrator_id = ? or ip.provider_id = ?", organizationID, organizationID).
		Find(&games).
		Error

	return
}

func (r *gameRepository) GetIntegratorGameList(ctx context.Context, organizationID uuid.UUID) (games []*entities.Game, err error) {
	err = r.conn.WithContext(ctx).
		Select("distinct (games.id) as _, games.*").
		Joins(`inner join integrator_games as ig 
				on games.id = ig.game_id`).
		Where("ig.organization_id = ?", organizationID).
		Find(&games).
		Error

	return
}

func (r *gameRepository) Update(ctx context.Context, gameID uuid.UUID, condition map[string]interface{}) (*entities.Game, error) {
	if err := r.conn.WithContext(ctx).Model(&entities.Game{}).Where("id = ?", gameID).Updates(condition).Error; err != nil {
		return nil, err
	}

	return r.GetBy(ctx, map[string]interface{}{"id": gameID})
}

func (r *gameRepository) Delete(ctx context.Context, game *entities.Game) error {
	return r.conn.WithContext(ctx).Where("id = ?", game.ID).Delete(&game).Error
}

func (r *gameRepository) withOwner(conn *gorm.DB, organizationID *uuid.UUID) *gorm.DB {
	conn = conn.Joins("Organization")

	if organizationID != nil {
		conn = conn.Where("organization_id = ?", organizationID)
	}

	return conn
}
