package entities

import (
	"github.com/google/uuid"
	"time"
)

const (
	OrganizationTypeIntegrator = "integrator"
	OrganizationTypeProvider   = "provider"
)

type Organization struct {
	CreatedAt time.Time  `json:"-"`
	UpdatedAt time.Time  `json:"-"`
	DeletedAt *time.Time `json:"-" sql:"index"`

	ID     uuid.UUID `json:"id"`
	Name   string    `json:"name"`
	Type   string    `json:"type"`
	Status int64     `json:"status"`
	ApiKey string    `json:"api_key"`
}

func (o *Organization) IsIntegrator() bool {
	return o.Type == OrganizationTypeIntegrator
}
