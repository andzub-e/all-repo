package services

import (
	"backoffice/internal/entities"
	e "backoffice/internal/errors"
	"backoffice/internal/repositories"
	"backoffice/internal/transport/http/requests"
	"context"
	"errors"
	"github.com/google/uuid"
	"github.com/ltunc/go-observer/observer"
	"github.com/samber/lo"
	"go.uber.org/zap"
)

type GameService struct {
	gameRepo         repositories.GameRepository
	organizationRepo repositories.OrganizationRepository
	UpdateSubject    observer.Subject[context.Context]
}

func NewGameService(gameRepo repositories.GameRepository, organizationRepo repositories.OrganizationRepository) *GameService {
	return &GameService{gameRepo: gameRepo, organizationRepo: organizationRepo}
}

func (s *GameService) Create(ctx context.Context, req *requests.GameRequest) (*entities.Game, error) {
	_, err := s.gameRepo.GetBy(ctx, map[string]interface{}{"name": req.Name})
	if err == nil {
		return nil, e.ErrEntityAlreadyExist
	}

	if err != nil && !errors.Is(err, e.ErrEntityNotFound) {
		return nil, err
	}

	organization, err := s.organizationRepo.Get(ctx, map[string]interface{}{"id": req.OrganizationID})
	if err != nil {
		zap.S().Error(err)

		return nil, err
	}

	if organization.IsIntegrator() {
		return nil, e.ErrOrganizationIsNotProvider
	}

	game := &entities.Game{
		ID:               uuid.New(),
		OrganizationID:   req.OrganizationID,
		Name:             req.Name,
		Jurisdictions:    req.Jurisdictions,
		Currencies:       req.Currencies,
		Languages:        req.Languages,
		UserLocales:      req.UserLocales,
		ApiUrl:           req.ApiURL,
		ClientUrl:        req.ClientURL,
		WagerSetID:       req.WagerSetID,
		IsPublic:         *req.IsPublic,
		IsStatisticShown: *req.IsStatisticShown,
		IsDemo:           *req.IsDemo,
		IsFreespins:      *req.IsFreeSpins,
	}

	g, err := s.gameRepo.Create(ctx, game)
	if err != nil {
		return nil, err
	}

	s.UpdateSubject.Fire(ctx)

	return g, nil
}

func (s *GameService) GetGame(ctx context.Context, gameID uuid.UUID) (*entities.Game, error) {
	return s.gameRepo.GetBy(ctx, map[string]interface{}{"id": gameID})
}

func (s *GameService) GetGameByName(ctx context.Context, name string) (*entities.Game, error) {
	return s.gameRepo.GetBy(ctx, map[string]interface{}{"name": name})
}

func (s *GameService) AllForStat(ctx context.Context, organizationID *uuid.UUID) ([]*entities.Game, error) {
	return s.gameRepo.All(ctx, organizationID, map[string]interface{}{"is_statistic_shown": true})
}

func (s *GameService) AllPublic(ctx context.Context, organizationID *uuid.UUID) ([]*entities.Game, error) {
	return s.gameRepo.All(ctx, organizationID, map[string]interface{}{"is_public": true})
}

func (s *GameService) GetDictionaries(ctx context.Context, organizationID *uuid.UUID, dictType string) ([]string, error) {
	return s.gameRepo.GetDictionaries(ctx, organizationID, dictType)
}

func (s *GameService) IDs(ctx context.Context, organizationID *uuid.UUID) ([]uuid.UUID, error) {
	games, err := s.AllPublic(ctx, organizationID)
	if err != nil {
		return nil, err
	}

	var list []uuid.UUID

	for _, game := range games {
		list = append(list, game.ID)
	}

	return list, nil
}

func (s *GameService) IDsString(ctx context.Context, organizationID *uuid.UUID) ([]string, error) {
	list, err := s.IDs(ctx, organizationID)
	if err != nil {
		return nil, err
	}

	return lo.Map(list, func(item uuid.UUID, index int) string {
		return item.String()
	}), nil
}

func (s *GameService) GetIntegratorGameNames(ctx context.Context, organizationID uuid.UUID) ([]string, error) {
	games, err := s.gameRepo.GetOrganizationGameList(ctx, organizationID)
	if err != nil {
		zap.S().Error(err)

		return nil, err
	}

	list := make([]string, 0, len(games))

	for _, game := range games {
		list = append(list, game.Name)
	}

	return list, nil
}

func (s *GameService) GetProviderGameIDs(ctx context.Context, organizationID uuid.UUID) ([]uuid.UUID, error) {
	games, err := s.gameRepo.GetOrganizationGameList(ctx, organizationID)
	if err != nil {
		zap.S().Error(err)

		return nil, err
	}

	list := make([]uuid.UUID, 0, len(games))

	for _, game := range games {
		list = append(list, game.ID)
	}

	return list, nil
}

func (s *GameService) GetIntegratorGameList(ctx context.Context, organizationID uuid.UUID) ([]string, error) {
	games, err := s.gameRepo.GetIntegratorGameList(ctx, organizationID)
	if err != nil {
		zap.S().Error(err)

		return nil, err
	}

	list := make([]string, 0, len(games))

	for _, game := range games {
		list = append(list, game.Name)
	}

	return list, nil
}

func (s *GameService) GetIntegratorGames(ctx context.Context, organizationID uuid.UUID) ([]*entities.Game, error) {
	games, err := s.gameRepo.GetIntegratorGameList(ctx, organizationID)
	if err != nil {
		zap.S().Error(err)

		return nil, err
	}

	return games, nil
}

func (s *GameService) GetGameList(ctx context.Context, filter map[string]interface{}) ([]*entities.Game, error) {
	return s.gameRepo.GetAllByFilter(ctx, filter)
}

func (s *GameService) Paginate(ctx context.Context, filters map[string]interface{}, order string, limit int, offset int) ([]*entities.Game, int64, error) {
	return s.gameRepo.Paginate(ctx, filters, order, limit, offset)
}

func (s *GameService) Update(ctx context.Context, gameID uuid.UUID, req *requests.GameRequest) (*entities.Game, error) {
	organization, err := s.organizationRepo.Get(ctx, map[string]interface{}{"id": req.OrganizationID})
	if err != nil {
		zap.S().Error(err)

		return nil, err
	}

	if organization.IsIntegrator() {
		return nil, e.ErrOrganizationIsNotProvider
	}

	gameParam := map[string]interface{}{
		"organization_id":    req.OrganizationID,
		"name":               req.Name,
		"jurisdictions":      req.Jurisdictions,
		"currencies":         req.Currencies,
		"languages":          req.Languages,
		"user_locales":       req.UserLocales,
		"api_url":            req.ApiURL,
		"client_url":         req.ClientURL,
		"wager_set_id":       req.WagerSetID,
		"is_public":          *req.IsPublic,
		"is_statistic_shown": *req.IsStatisticShown,
		"is_demo":            *req.IsDemo,
		"is_freespins":       *req.IsFreeSpins,
	}

	g, err := s.gameRepo.Update(ctx, gameID, gameParam)
	if err != nil {
		return nil, err
	}

	s.UpdateSubject.Fire(ctx)

	return g, nil
}

func (s *GameService) Delete(ctx context.Context, gameID uuid.UUID) error {
	game, err := s.gameRepo.GetBy(ctx, map[string]interface{}{"id": gameID})
	if err != nil {
		return err
	}

	err = s.gameRepo.Delete(ctx, game)
	if err != nil {
		return err
	}

	s.UpdateSubject.Fire(ctx)

	return nil
}
