package services

import (
	"backoffice/internal/entities"
	e "backoffice/internal/errors"
	"backoffice/internal/repositories"
	"context"
	"errors"
	"fmt"
	"github.com/google/uuid"
	"github.com/ltunc/go-observer/observer"
	"github.com/samber/lo"
	"go.uber.org/zap"
)

type OrganizationService struct {
	repo           repositories.OrganizationRepository
	accountService *AccountService
	gameService    *GameService
	UpdateSubject  observer.Subject[context.Context]
}

func NewOrganizationService(repo repositories.OrganizationRepository, accountService *AccountService, gameService *GameService) *OrganizationService {
	return &OrganizationService{
		repo:           repo,
		accountService: accountService,
		gameService:    gameService,
	}
}

func (s *OrganizationService) Create(ctx context.Context, status int64, name, t string) (*entities.Organization, error) {
	return s.repo.Create(ctx, &entities.Organization{
		ID:     uuid.New(),
		Name:   name,
		Type:   t,
		ApiKey: uuid.New().String(),
		Status: status,
	})
}

func (s *OrganizationService) Update(ctx context.Context, id uuid.UUID, status int64, name, t string) (*entities.Organization, error) {
	organization, err := s.repo.Get(ctx, map[string]interface{}{"id": id})
	if err != nil {
		return nil, err
	}

	return s.repo.Update(ctx, &entities.Organization{
		ID:     organization.ID,
		Name:   name,
		Type:   t,
		ApiKey: organization.ApiKey,
		Status: status,
	})
}

func (s *OrganizationService) Delete(ctx context.Context, accountID, organizationID uuid.UUID) error {
	organization, err := s.repo.Get(ctx, map[string]interface{}{"id": organizationID})
	if err != nil {
		return err
	}

	return s.repo.Delete(ctx, accountID, organization)
}

func (s *OrganizationService) Get(ctx context.Context, id uuid.UUID) (*entities.Organization, error) {
	return s.repo.Get(ctx, map[string]interface{}{"id": id})
}

func (s *OrganizationService) Paginate(ctx context.Context, filters map[string]interface{}, order string, limit int, offset int) ([]*entities.Organization, int64, error) {
	return s.repo.Paginate(ctx, filters, order, limit, offset)
}

func (s *OrganizationService) Assign(ctx context.Context, accountID, organizationID uuid.UUID) (*entities.Account, error) {
	account, err := s.accountService.FindBy(ctx, map[string]interface{}{"id": accountID})
	if err != nil {
		return nil, err
	}

	organization, err := s.repo.Get(ctx, map[string]interface{}{"id": organizationID})
	if err != nil {
		return nil, err
	}

	if err = s.repo.Assign(ctx, account, organization); err != nil {
		return nil, err
	}

	account.Organizations = append(account.Organizations, organization)

	return account, nil
}

func (s *OrganizationService) Revoke(ctx context.Context, accountID, organizationID uuid.UUID) error {
	account, err := s.accountService.FindBy(ctx, map[string]interface{}{"id": accountID})
	if err != nil {
		return err
	}

	for _, role := range account.Roles {
		if role.Type == entities.RootRoleTypeName {
			return fmt.Errorf("%v from root user", e.ErrCanNotRemoveOrganization)
		}
	}

	organization, err := s.repo.Get(ctx, map[string]interface{}{"id": organizationID})
	if err != nil {
		return err
	}

	return s.repo.Revoke(ctx, account, organization)
}

func (s *OrganizationService) LoadAccountOrganization(ctx context.Context, account *entities.Account) error {
	organizations, err := s.repo.GetByAccount(ctx, account)
	if err != nil {
		return err
	}

	account.Organizations = organizations

	return nil
}

func (s *OrganizationService) GetIntegratorGames(ctx context.Context, organizationID uuid.UUID) ([]string, error) {
	organization, err := s.repo.Get(ctx, map[string]interface{}{"id": organizationID})
	if err != nil {
		return nil, err
	}

	if !organization.IsIntegrator() {
		return nil, e.ErrOrganizationIsNotIntegrator
	}

	return s.gameService.GetIntegratorGameNames(ctx, organization.ID)
}

func (s *OrganizationService) GetByApiKey(ctx context.Context, apiKey string) (*entities.Organization, error) {
	return s.repo.Get(ctx, map[string]interface{}{"api_key": apiKey})
}

func (s *OrganizationService) HasAccess(ctx context.Context, organizationID uuid.UUID, gameName string) error {
	organization, err := s.repo.Get(ctx, map[string]interface{}{"id": organizationID})
	if err != nil {
		zap.S().Error(err)

		return err
	}

	if !organization.IsIntegrator() {
		return e.ErrOrganizationIsNotIntegrator
	}

	games, err := s.gameService.GetIntegratorGameNames(ctx, organizationID)
	if err != nil {
		zap.S().Error(err)

		return err
	}

	for _, game := range games {
		if game == gameName {
			return nil
		}
	}

	return e.ErrDoesNotHavePermission
}

func (s *OrganizationService) GetOrganizationPair(ctx context.Context, providerID, integratorID uuid.UUID) (
	*entities.ProviderIntegratorPair, error) {
	return s.repo.GetOrganizationPair(ctx, providerID, integratorID)
}

func (s *OrganizationService) CreateOrganizationPair(ctx context.Context, providerID, integratorID uuid.UUID) (
	*entities.ProviderIntegratorPair, error) {
	_, err := s.repo.GetOrganizationPair(ctx, providerID, integratorID)
	if err == nil {
		return nil, e.ErrEntityAlreadyExist
	}

	if err != nil && !errors.Is(err, e.ErrEntityNotFound) {
		return nil, err
	}

	pair := &entities.ProviderIntegratorPair{
		ID:           uuid.New(),
		ProviderID:   providerID,
		IntegratorID: integratorID,
	}

	return s.repo.CreateOrganizationPair(ctx, pair)
}

func (s *OrganizationService) DeleteOrganizationPair(ctx context.Context, providerID, integratorID uuid.UUID) error {
	pair, err := s.repo.GetOrganizationPair(ctx, providerID, integratorID)
	if err != nil {
		return err
	}

	return s.repo.DeleteOrganizationPair(ctx, pair)
}

func (s *OrganizationService) GetIntegratorNames(ctx context.Context, providerID uuid.UUID) ([]string, error) {
	orgs, err := s.repo.GetIntegratorsByProvider(ctx, providerID)
	if err != nil {
		return nil, err
	}

	return lo.Map(orgs, func(item *entities.Organization, index int) string {
		return item.Name
	}), nil
}

func (s *OrganizationService) GetGames(ctx context.Context, integratorID uuid.UUID) ([]*entities.IntegratorGame, error) {
	return s.repo.GetIntegratorGameList(ctx, integratorID)
}

func (s *OrganizationService) AssignGames(ctx context.Context, integratorID uuid.UUID, gameIDs ...uuid.UUID) ([]*entities.IntegratorGame, error) {
	organization, err := s.repo.Get(ctx, map[string]interface{}{"id": integratorID})
	if err != nil {
		zap.S().Error(err)

		return nil, err
	}

	if !organization.IsIntegrator() {
		return nil, e.ErrOrganizationIsNotIntegrator
	}

	err = s.repo.AssignGames(ctx, integratorID, gameIDs)
	if err != nil {
		return nil, err
	}

	s.UpdateSubject.Fire(ctx)

	return s.repo.GetIntegratorGameList(ctx, integratorID)
}

func (s *OrganizationService) RevokeGames(ctx context.Context, integratorID uuid.UUID, gameIDs ...uuid.UUID) error {
	organization, err := s.repo.Get(ctx, map[string]interface{}{"id": integratorID})
	if err != nil {
		zap.S().Error(err)

		return err
	}

	if !organization.IsIntegrator() {
		return e.ErrOrganizationIsNotIntegrator
	}

	err = s.repo.RevokeGames(ctx, integratorID, gameIDs)
	if err != nil {
		return err
	}

	s.UpdateSubject.Fire(ctx)

	return nil
}
