package services

import (
	"backoffice/internal/entities"
	"backoffice/internal/repositories"
	"context"
	"errors"
	"github.com/google/uuid"
	"github.com/ltunc/go-observer/observer"
	"github.com/samber/lo"
	"strings"
	"time"
)

var (
	ErrCanNotFindCurrencyConfig = errors.New("can not find currency config")
	ErrNegativeWager            = errors.New("negative wager found")
	ErrDefaultWagerOutOfList    = errors.New("default wager is out of default wager list")
)

type CurrencyService struct {
	repo                repositories.CurrencyRepository
	organizationService *OrganizationService

	UpdateSubject observer.Subject[context.Context]
}

func NewCurrencyService(repo repositories.CurrencyRepository, organizationService *OrganizationService) *CurrencyService {
	return &CurrencyService{repo: repo, organizationService: organizationService}
}

func (s *CurrencyService) All(ctx context.Context) ([]*entities.CurrencyMultiplier, error) {
	return s.repo.All(ctx)
}

func (s *CurrencyService) UniqueCurrencyNames(ctx context.Context) ([]string, error) {
	return s.repo.UniqueCurrencyNames(ctx)
}

func (s *CurrencyService) Search(ctx context.Context, filter map[string]interface{}) ([]*entities.CurrencyMultiplier, error) {
	return s.repo.Search(ctx, filter)
}

func (s *CurrencyService) CreateCurrencyMultiplier(ctx context.Context, organizationPairID uuid.UUID, title string, multiplier int64) (*entities.CurrencyMultiplier, error) {
	res, err := s.repo.CreateCurrencyMultiplier(ctx, &entities.CurrencyMultiplier{
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),

		OrganizationPairID: organizationPairID,

		Title:      strings.ToLower(title),
		Multiplier: multiplier,
	})

	if err != nil {
		return nil, err
	}

	s.UpdateSubject.Fire(ctx)

	return res, nil
}

func (s *CurrencyService) UpdateCurrencyMultiplier(ctx context.Context, organizationPairID uuid.UUID, title string, multiplier int64) (*entities.CurrencyMultiplier, error) {
	res, err := s.repo.UpdateCurrencyMultiplier(ctx, &entities.CurrencyMultiplier{
		UpdatedAt: time.Now(),

		OrganizationPairID: organizationPairID,
		Title:              strings.ToLower(title),
		Multiplier:         multiplier,
	})

	if err != nil {
		return nil, err
	}

	s.UpdateSubject.Fire(ctx)

	return res, nil
}

func (s *CurrencyService) Get(ctx context.Context, organizationPairID uuid.UUID, title string) (*entities.CurrencyMultiplier, error) {
	return s.repo.Get(ctx, map[string]interface{}{"organization_pair_id": organizationPairID, "title": title})
}

func (s *CurrencyService) DeleteCurrencyMultiplier(ctx context.Context, organizationPairID uuid.UUID, title string) error {
	cm, err := s.Get(ctx, organizationPairID, title)
	if err != nil {
		return err
	}

	err = s.repo.DeleteCurrencyMultiplier(ctx, cm)
	if err != nil {
		return err
	}

	s.UpdateSubject.Fire(ctx)

	return nil
}

func (s *CurrencyService) MergeCurrenciesByProvider(ctx context.Context, providerID uuid.UUID) ([]string, error) {
	ccs, err := s.repo.All(ctx)
	if err != nil {
		return nil, err
	}

	ccs = lo.Filter(ccs, func(item *entities.CurrencyMultiplier, index int) bool {
		return item.ProviderIntegratorPair.ProviderID == providerID
	})

	currencies := []string{}

	for _, cc := range ccs {
		currencies = append(currencies, cc.Title)
	}

	currencies = lo.Uniq(currencies)

	return currencies, nil
}
