package constants

const (
	MsgSpinType            = "spin"
	MsgCurrencyRequestType = "currency_request"
	MsgCurrencyConfigType  = "currency_config"
)

const (
	QueueOverlordName = "overlord"
)
