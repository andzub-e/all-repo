package constants

const (
	ActionView   = "VIEW"
	ActionEdit   = "EDIT"
	ActionCreate = "CREATE"
	ActionDelete = "DELETE"
)
