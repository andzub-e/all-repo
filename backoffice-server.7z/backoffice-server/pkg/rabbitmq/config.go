package rabbitmq

type Config struct {
	Name     string
	Host     string
	Port     string
	Username string
	Password string
}
