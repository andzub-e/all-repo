package mailgun

type Config struct {
	Domain string
	APIKey string
}
