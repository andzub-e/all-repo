package constants

const (
	ConfigName    = "Config"
	LoggerName    = "Logger"
	PgSQLName     = "PgSQL"
	ServerName    = "Server"
	ValidatorName = "Validator"
	TracerName    = "Tracer"

	LaunchServiceName = "LaunchService"
	LemonServiceName  = "LemonService"
	BFServiceName     = "BFService"

	LemonHandlerName       = "LemonHandler"
	BFHandlerName          = "BFHandler"
	InfinGameHandlerName   = "InfinGameHandler"
	DirectGamesHandlerName = "DirectGamesHandler"
	MetaHandlerName        = "MetaHandler"
	UPlatformHandlerName   = "UPlatformHandler"

	BackofficeClientName = "BackofficeClient"
)
