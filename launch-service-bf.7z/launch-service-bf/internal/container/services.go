package container

import (
	"github.com/sarulabs/di"
	"launch-service/internal/config"
	"launch-service/internal/constants"
	"launch-service/internal/services"
	"launch-service/pkg/backoffice"
)

func BuildServices() []di.Def {
	return []di.Def{
		{
			Name: constants.LaunchServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				cfg := ctn.Get(constants.ConfigName).(*config.Config)
				backofficeClient := ctn.Get(constants.BackofficeClientName).(backoffice.Client)

				return services.NewLaunchService(cfg.LaunchConfig, backofficeClient), nil
			},
		},
		{
			Name: constants.LemonServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				cfg := ctn.Get(constants.ConfigName).(*config.Config)

				return services.NewLemonService(cfg.LaunchConfig, cfg.LemonConfig), nil
			},
		},
		{
			Name: constants.BFServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				cfg := ctn.Get(constants.ConfigName).(*config.Config)
				backofficeClient := ctn.Get(constants.BackofficeClientName).(backoffice.Client)

				return services.NewBFService(cfg.BFConfig, backofficeClient), nil
			},
		},
	}
}
