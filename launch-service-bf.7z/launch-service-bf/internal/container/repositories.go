package container

import "github.com/sarulabs/di"

func BuildRepositories() []di.Def {
	return []di.Def{}
}
