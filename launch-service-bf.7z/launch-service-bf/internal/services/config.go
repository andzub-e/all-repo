package services

type LaunchConfig struct {
	BFBaseURL string
	BaseURL   string
	Format    string
}
