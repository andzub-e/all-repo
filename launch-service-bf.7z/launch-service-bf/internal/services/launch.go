package services

import (
	"context"
	"errors"
	"fmt"
	"github.com/google/uuid"
	"go.uber.org/zap"
	"launch-service/pkg/backoffice"
)

var (
	ErrLaunchServiceUnauthorized   = errors.New("invalid authorization")
	ErrLaunchServiceDontHaveAccess = errors.New("the game does not available")
)

type LaunchService struct {
	cfg              *LaunchConfig
	backofficeClient backoffice.Client
}

func NewLaunchService(cfg *LaunchConfig, backofficeClient backoffice.Client) *LaunchService {
	return &LaunchService{
		cfg:              cfg,
		backofficeClient: backofficeClient,
	}
}

func (s *LaunchService) Infin(key, gameName, partner, platform, lang, exitUrl, cashierUrl string) string {
	return fmt.Sprintf("%v%v/?user_id=%v&jurisdiction=UA&userlocale=%v", s.cfg.BaseURL, gameName, uuid.NewString(), lang)
}

func (s *LaunchService) Generate(ctx context.Context, apiKey, game, userID, currency, language string, platform, returnUrl *string) (string, error) {
	resp, err := s.backofficeClient.HasAccess(ctx, apiKey, game)
	if err != nil {
		zap.S().Error(err)

		return "", err
	}

	if !resp.HasAccess {
		return "", ErrLaunchServiceDontHaveAccess
	}

	url := fmt.Sprintf(s.cfg.Format, s.cfg.BaseURL, game, userID, resp.Integrator, currency, language)

	if platform != nil {
		url += "&platform_type=" + *platform
	}

	if returnUrl != nil {
		url += "&return_url=" + *returnUrl
	}

	return url, nil
}

func (s *LaunchService) Games(ctx context.Context, apiKey string) ([]string, error) {
	resp, err := s.backofficeClient.GameList(ctx, apiKey)
	if err != nil {
		zap.S().Error(err)

		return nil, err
	}

	return resp.Games, nil
}

func (s *LaunchService) UPlatform(gameID, language, userID, currency, sessionUUID string, demo bool) string {

	link := fmt.Sprintf("%v%v/?integrator=uplatform&userlocale=%v", s.cfg.BaseURL, gameID, language)

	if userID != "" {
		link += "&user_id=" + userID
	}

	if currency != "" {
		link += "&currency=" + currency
	}

	if sessionUUID != "" {
		link += "&session_uuid=" + sessionUUID
	}

	if demo {
		link += "&is_demo=true"
	}

	return link
}
