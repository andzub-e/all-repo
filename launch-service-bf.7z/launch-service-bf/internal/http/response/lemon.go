package response

type LemonDemoGameLaunch struct {
	URL string `json:"Url"`
}

type LemonGameLaunch struct {
	URL   string `json:"Url"`
	Token string `json:"Token"`
}
