package response

type BFStartResponse struct {
	GameVersion string `json:"gameVersion"`
	URL         string `json:"url"`
}
