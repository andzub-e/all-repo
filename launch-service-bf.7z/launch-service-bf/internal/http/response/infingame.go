package response

import "encoding/xml"

type InfinGameResponse struct {
	XMLName xml.Name `xml:"service"`
	Url     string   `xml:"url"`
}
