package response

import (
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"launch-service/pkg/validator"
	"net/http"
	"strconv"
)

type Response struct {
	Status  int         `json:"status"`
	Success bool        `json:"success"`
	Data    interface{} `json:"data"`
}

func new(status int, data interface{}) *Response {
	success := false
	if status >= 200 && status <= 299 {
		success = true
	}

	response := &Response{
		Status:  status,
		Success: success,
		Data:    data,
	}

	if response.Data == nil {
		response.Data = http.StatusText(status)
	}

	if v, ok := data.(error); ok {
		response.Data = v.Error()
	}

	return response
}

func OK(ctx *gin.Context, data interface{}, meta interface{}) {
	r := new(http.StatusOK, data)
	ctx.JSON(r.Status, data)
}

func OK_XML(ctx *gin.Context, data interface{}, meta interface{}) {
	r := new(http.StatusOK, data)
	ctx.XML(r.Status, data)
}

func BadRequest(ctx *gin.Context, data interface{}, meta interface{}) {
	zap.S().Warn(data)
	r := new(http.StatusBadRequest, data)
	ctx.AbortWithStatusJSON(r.Status, r)
}

func Unauthorized(ctx *gin.Context, data interface{}, meta interface{}) {
	zap.S().Warn(data)
	r := new(http.StatusUnauthorized, data)
	ctx.AbortWithStatusJSON(r.Status, data)
}

func Forbidden(ctx *gin.Context, data interface{}, meta interface{}) {
	zap.S().Warn(data)
	r := new(http.StatusForbidden, data)
	ctx.AbortWithStatusJSON(r.Status, data)
}

func NotFound(ctx *gin.Context, data interface{}, meta interface{}) {
	zap.S().Warn(data)
	r := new(http.StatusNotFound, data)
	ctx.AbortWithStatusJSON(r.Status, data)
}

func ServerError(ctx *gin.Context, data interface{}, meta interface{}) {
	zap.S().Error(data)
	r := new(http.StatusInternalServerError, data)
	ctx.AbortWithStatusJSON(r.Status, data)
}

func Code(ctx *gin.Context, code int, data interface{}, meta interface{}) {
	zap.S().Warn(data)
	zap.S().Warn("code: " + strconv.Itoa(code))
	r := new(code, data)
	ctx.AbortWithStatusJSON(r.Status, data)
}

func ValidationFailed(ctx *gin.Context, err error) {
	data := make([]string, 0)

	for _, taggedError := range validator.CheckValidationErrors(err) {
		e := taggedError.Err
		data = append(data, e.Error())
	}

	r := new(http.StatusUnprocessableEntity, data)
	ctx.AbortWithStatusJSON(r.Status, data)
}

func Conflict(ctx *gin.Context, data interface{}, meta interface{}) {
	zap.S().Error(data)
	r := new(http.StatusConflict, data)
	ctx.AbortWithStatusJSON(r.Status, data)
}
