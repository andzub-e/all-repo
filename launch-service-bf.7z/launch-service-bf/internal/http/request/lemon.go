package request

type LemonAccount struct {
	UserName string `json:"UserName"`
	Password string `json:"Password"`
}

type LemonDemoGameLaunch struct {
	GameCode     string       `json:"GameCode"`
	CurrencyCode string       `json:"CurrencyCode"`
	LanguageCode string       `json:"LanguageCode"`
	HomeURL      string       `json:"HomeUrl"`
	Account      LemonAccount `json:"Account"`
	PlatformType int          `json:"PlatformType"`
}

type LemonGameLaunch struct {
	GameCode     string       `json:"GameCode"`
	PlayerId     string       `json:"PlayerId"`
	PlayerIP     string       `json:"PlayerIP"`
	CountryCode  string       `json:"CountryCode"`
	CurrencyCode string       `json:"CurrencyCode"`
	LanguageCode string       `json:"LanguageCode"`
	Nickname     string       `json:"Nickname"`
	HomeURL      string       `json:"HomeUrl"`
	CashierURL   string       `json:"CashierUrl"`
	DateOfBirth  string       `json:"DateOfBirth"`
	Gender       int          `json:"Gender"`
	Account      LemonAccount `json:"Account"`
	PlatformType int          `json:"PlatformType"`
}
