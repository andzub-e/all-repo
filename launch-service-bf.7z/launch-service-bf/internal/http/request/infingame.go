package request

type InfinGameRequest struct {
	Key      string `form:"key"`
	GameName string `form:"gameName"`
	Partner  string `form:"partner"`
	Platform string `form:"platform"`

	Lang string `form:"lang"`

	ExitUrl    string `form:"exit_url"`
	CashierUrl string `form:"cashier_url"`
}
