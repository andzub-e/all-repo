package request

type BFStartGameRequest struct {
	GameId       string `json:"gameId"`
	GameMode     string `json:"gameMode"`
	Currency     string `json:"currency"`
	SessionToken string `json:"sessionToken"`
	Language     string `json:"language"`
}

type BFDiscoverRequest struct {
	ProviderCode string `json:"providerCode" form:"providerCode"`
}
