package handlers

import (
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"launch-service/internal/http/request"
	"launch-service/internal/http/response"
	"launch-service/internal/services"
)

type bfHandler struct {
	bfService *services.BFService
}

func NewBFHandler(bfService *services.BFService) *bfHandler {
	return &bfHandler{bfService: bfService}
}

func (h *bfHandler) Register(router *gin.RouterGroup) {
	bf := router.Group("bf")
	bf.POST("game/start", h.launch)
	bf.GET("/discovery/games", h.discoverGames)
}

func (h *bfHandler) launch(ctx *gin.Context) {
	req := request.BFStartGameRequest{}
	if err := ctx.ShouldBind(&req); err != nil {
		response.ValidationFailed(ctx, err)
	}

	zap.S().Infof("%+v", req)

	link, version, err := h.bfService.BF(ctx, req.GameId, req.GameMode, req.SessionToken, req.Currency, req.Language)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	zap.S().Info(link, version)

	response.OK(ctx, response.BFStartResponse{URL: link, GameVersion: version}, nil)
}

func (h *bfHandler) discoverGames(ctx *gin.Context) {
	req := request.BFDiscoverRequest{}
	if err := ctx.ShouldBind(&req); err != nil {
		response.ValidationFailed(ctx, err)
	}

	zap.S().Infof("%+v", ctx.Request.URL.Query())

	games, err := h.bfService.BFGames(ctx, req.ProviderCode)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, games, nil)
}
