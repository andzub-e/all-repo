package handlers

import (
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"launch-service/internal/http/request"
	"launch-service/internal/http/response"
	"launch-service/internal/services"
)

type infinGameHandler struct {
	launchService *services.LaunchService
}

func NewInfinGameHandler(launchService *services.LaunchService) *infinGameHandler {
	return &infinGameHandler{launchService: launchService}
}

func (h *infinGameHandler) Register(router *gin.RouterGroup) {
	infin := router.Group("infingame")

	infin.GET("start", h.start)
}

func (h *infinGameHandler) start(ctx *gin.Context) {
	req := request.InfinGameRequest{}

	if err := ctx.ShouldBind(&req); err != nil {
		response.ValidationFailed(ctx, err)
	}

	zap.S().Infof("%+v", req)

	link := h.launchService.Infin(req.Key, req.GameName, req.Partner, req.Platform, req.Lang, req.ExitUrl, req.CashierUrl)

	response.OK_XML(ctx, response.InfinGameResponse{Url: link}, nil)
}
