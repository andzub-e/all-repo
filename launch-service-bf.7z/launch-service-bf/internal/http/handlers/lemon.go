package handlers

import (
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"launch-service/internal/http/request"
	"launch-service/internal/http/response"
	"launch-service/internal/services"
)

type lemonHandler struct {
	lemonService *services.LemonService
}

func (l *lemonHandler) Register(router *gin.RouterGroup) {
	router.POST("LaunchDemoGame", l.LaunchDemo)
	router.POST("LaunchGame", l.Launch)
}

func NewLemonHandler(lemonService *services.LemonService) *lemonHandler {
	return &lemonHandler{lemonService: lemonService}
}

func (l *lemonHandler) LaunchDemo(ctx *gin.Context) {
	req := request.LemonDemoGameLaunch{}
	if err := ctx.ShouldBind(&req); err != nil {
		response.ValidationFailed(ctx, err)
	}

	zap.S().Infof("%+v", req)

	link := l.lemonService.LemonDemo(req.GameCode, req.CurrencyCode, req.LanguageCode, req.HomeURL, services.Account{
		Username: req.Account.UserName,
		Password: req.Account.Password,
	}, req.PlatformType)

	zap.S().Info(link)

	response.OK(ctx, response.LemonDemoGameLaunch{URL: link}, nil)
}

func (l *lemonHandler) Launch(ctx *gin.Context) {
	req := request.LemonGameLaunch{}
	if err := ctx.ShouldBind(&req); err != nil {
		response.ValidationFailed(ctx, err)
	}

	zap.S().Infof("%+v", req)

	link, token, err := l.lemonService.Lemon(req.GameCode, req.CurrencyCode, req.LanguageCode, req.HomeURL, req.PlayerId, services.Account{
		Username: req.Account.UserName,
		Password: req.Account.Password,
	}, req.PlatformType)

	if err != nil {
		zap.S().Infof("%+v", req.Account)

		response.Unauthorized(ctx, err, nil)

		return
	}

	zap.S().Info(link, token)

	response.OK(ctx, response.LemonGameLaunch{URL: link, Token: token}, nil)
}
