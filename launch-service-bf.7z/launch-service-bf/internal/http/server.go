package http

import (
	"context"
	"fmt"
	"github.com/gin-gonic/gin"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
	"go.uber.org/zap"
	"launch-service/docs"
	"launch-service/internal/http/middlewares"
	"launch-service/pkg/tracer"
	"net/http"
	"sync"
	"time"
)

type Server struct {
	wg     *sync.WaitGroup
	ctx    context.Context
	server *http.Server
	router *gin.Engine
}

// New
// @title           API
// @version         2.0
// @description     This is a sample server.
// @termsOfService  http://swagger.io/terms/
// @contact.name   API Support
// @contact.url    http://www.swagger.io/support
// @contact.email  support@swagger.io
// @license.name Apache 2.0
// @license.url http://www.apache.org/licenses/LICENSE-2.0.html
func New(ctx context.Context, wg *sync.WaitGroup, cfg *Config, tracer *tracer.JaegerTracer, publicHandlers []Handler, privateHandlers []Handler) *Server {
	docs.SwaggerInfo.Title = "API"
	docs.SwaggerInfo.Description = "This is a sample server CoinAMP server."
	docs.SwaggerInfo.Version = "2.0"
	docs.SwaggerInfo.Schemes = []string{"http", "https"}

	s := &Server{
		wg:  wg,
		ctx: ctx,
		server: &http.Server{
			Addr:              fmt.Sprintf("%s:%d", cfg.Host, cfg.Port),
			Handler:           nil,
			ReadHeaderTimeout: 10 * time.Second,
			ReadTimeout:       cfg.ReadTimeout,
			WriteTimeout:      cfg.WriteTimeout,
			IdleTimeout:       30 * time.Second,
		},
		router: gin.New(),
	}

	s.router.GET("", func(ctx *gin.Context) {
		ctx.String(http.StatusOK, "EJAW Launch Service")
	})

	s.router.GET("/docs/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))
	s.router.Use(middlewares.CORSMiddleware(), middlewares.Trace(tracer))

	api := s.router.Group("")

	s.registerPublicHandlers(api, publicHandlers...)
	s.registerPrivateHandlers(api, privateHandlers...)

	return s
}

func (s *Server) registerPublicHandlers(api *gin.RouterGroup, handlers ...Handler) {
	for _, h := range handlers {
		h.Register(api)
	}

	s.server.Handler = s.router
}

func (s *Server) registerPrivateHandlers(api *gin.RouterGroup, handlers ...Handler) {
	for _, h := range handlers {
		h.Register(api)
	}

	s.server.Handler = s.router
}

func (s *Server) Run() {
	s.wg.Add(1)
	zap.S().Infof("server listining: %s", s.server.Addr)

	if err := s.server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		zap.S().Error(err.Error())
	}
}

func (s *Server) Shutdown() error {
	zap.S().Info("Shutdown server...")
	zap.S().Info("Stopping http server...")

	ctx, cancel := context.WithTimeout(s.ctx, 30*time.Second)
	defer func() {
		cancel()
		s.wg.Done()
	}()

	if err := s.server.Shutdown(ctx); err != nil {
		zap.S().Fatal("Server forced to shutdown:", zap.Error(err))
		return err
	}

	zap.S().Info("Server successfully stopped.")

	return nil
}
