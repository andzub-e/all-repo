package validator

const (
	RequiredTag = "required"
	InvalidTag  = "invalid"
)
