package errors

import (
	"errors"
	"fmt"
)

type Error struct {
	StatusCode   int    `json:"-"`
	InternalCode int    `json:"-"`
	Err          error  `json:"-"`
	Message      string `json:"message"`
}

func (e Error) Error() string {
	if e.Message != "" {
		return fmt.Sprintf("%s: %s", e.Err.Error(), e.Message)
	}

	return e.Err.Error()
}

func (e Error) Unwrap() error {
	return e.Err
}

func (e Error) Dig() Error {
	var er Error
	if errors.As(e.Err, &er) {
		return er.Dig()
	}

	return e
}

func NewError(statusCode, internalCode int, err error, message string) error {
	return Error{
		StatusCode:   statusCode,
		InternalCode: internalCode,
		Err:          err,
		Message:      message,
	}
}
