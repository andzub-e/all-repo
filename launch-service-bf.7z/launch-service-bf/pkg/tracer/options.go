package tracer

const (
	CtxWithTraceValue   = 1
	CtxWithGRPCMetadata = 1 << 1
)
