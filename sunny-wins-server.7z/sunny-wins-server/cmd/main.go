package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
	"burning-wins-3/buildvar"
	"burning-wins-3/engine"
)

func main() {
	application, err := app.NewApp("config.yml", buildvar.Tag, buildvar.Debug, buildvar.IsCheatsAvailable, engine.GameBoot)

	if err != nil {
		panic(err)
	}

	if err := application.Run(); err != nil {
		panic(err)
	}
}
