package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/buildvar"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/services"
	"burning-wins-3/engine"
	"fmt"
	"os"
	"text/template"
	"time"

	"go.uber.org/zap"
)

func main() {
	now := time.Now()

	application, err := app.NewApp("config.yml", buildvar.Tag, buildvar.Debug, buildvar.IsCheatsAvailable, engine.GameBoot)
	if err != nil {
		panic(err)
	}

	simulator := application.GetSimulatorService()

	result, err := simulator.WithProgressListener(func(percent float64) {
		fmt.Printf("Processing: %2.0f%%\n", percent*100)
	}).
		WithWagerParameters(nil).
		Simulate("burning-wins-3", 1000*1000*100, 1000)

	if err != nil {
		fmt.Printf("simulate: %v", err)
	} else {
		err := reportTXT("./report.txt", result)
		if err != nil {
			panic(err)
		}
	}

	fmt.Printf("The program ran for %s", time.Since(now))
	zap.S().Info("Service stopped.")
}

func reportTXT(filename string, result *services.SimulationResult) error {
	f, err := os.Create(filename)
	if err != nil {
		return err
	}

	return temp.Execute(f, result)
}

var tempRaw = "Game: {{.Game}}\n" +
	"Count: {{.Count}}\n" +
	"Wager: {{.Wager}}\n" +
	"Spent: {{.Spent}}\n" +
	"\n" +
	"BaseAward  {{.BaseAward}}\n" +
	"BonusAward {{.BonusAward}}\n" +
	"Award      {{.Award}}\n" +
	"\n" +
	"BaseAwardSquareSum  {{.BaseAwardSquareSum}}\n" +
	"BonusAwardSquareSum {{.BonusAwardSquareSum}}\n" +
	"AwardSquareSum      {{.AwardSquareSum  }}\n" +
	"\n" +
	"RTP {{.RTP}}\n"
var temp *template.Template

func init() {
	var err error
	temp, err = template.New("simulation-txt").Parse(tempRaw)

	if err != nil {
		panic(err)
	}
}
