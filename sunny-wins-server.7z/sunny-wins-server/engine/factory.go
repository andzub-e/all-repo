package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine/utils"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"encoding/json"
	"github.com/samber/lo"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
	"strconv"
)

type SpinFactory struct {
	rand         rng.Client
	cheatPayload interface{}
}

func GameBoot(ctn di.Container, config *engine.Config) *engine.Bootstrap {
	rand := ctn.Get(constants.RNGMockName).(rng.Client)
	factory := NewSpinFactory(rand)

	rtp, err := strconv.ParseFloat(config.RTP, 64)
	if err != nil {
		panic(err)
	}

	highRTPProb = (lowRTP - rtp) / (lowRTP - highRTP)

	zap.S().Infof("High RTP reels probability: %.3f%%", highRTPProb*100)

	return &engine.Bootstrap{
		SpinFactory: factory,

		HTTPTransport:      true,
		WebsocketTransport: true,

		NeedLastSpin:        false,
		FreeSpinsFeature:    false,
		GambleAnyWinFeature: false,

		GambleAnyWinMaxTimes: 4,
		GambleAnyWinMaxWager: 125 * 1000 * 1000,
		GameMaxWager:         50 * 1000, // 50 $

		HistoryHandlingType: engine.SequentialRestoring,
	}
}

func NewSpinFactory(rand rng.Client) *SpinFactory {
	factory := &SpinFactory{rand: rand}

	return factory
}

func (s SpinFactory) Generate(wager int64, parameters interface{}) (engine.Spin, engine.RestoringIndexes, error) {
	reels, err := s.ChoseReels()
	if err != nil {
		return nil, nil, err
	}

	stops, err := s.getStops(reels)
	if err != nil {
		return nil, nil, err
	}

	spin, err := s.compute(stops, reels, wager)
	if err != nil {
		return nil, nil, err
	}

	return &spin, &RestoringIndexes{}, nil
}

func (s SpinFactory) ChoseReels() ([][]int, error) {
	r, err := s.rand.RandFloat()
	if err != nil {
		return nil, err
	}

	if r > highRTPProb {
		return reelsLowRTP, nil
	}

	return reelsHighRTP, nil
}

func (s SpinFactory) GambleAnyWin(spin engine.Spin, parameters interface{}) (engine.Spin, error) {
	if spin.Award() == 0 {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin, ok := spin.(*SpinBase)
	if !ok {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin = typedSpin.DeepCopy()

	payload, err := parseGambleParams(parameters)

	if payload.Color != GambleRed && payload.Color != GambleBlack {
		return nil, errs.ErrBadDataGiven
	}

	if err != nil {
		return nil, err
	}

	res, err := s.rand.Rand(2)
	if err != nil {
		return nil, err
	}

	award := typedSpin.Award() + typedSpin.BonusAward()
	g := Gamble{ExpectColor: payload.Color, WagerVal: award}

	if res == 1 {
		g.RealColor = GambleRed
	} else {
		g.RealColor = GambleBlack
	}

	g.compute()

	typedSpin.Gambles = append(typedSpin.Gambles, g)

	return typedSpin, nil
}

func (s SpinFactory) WithBoundLastSpin(spin engine.Spin) engine.SpinFactory {
	return &s
}

func (s SpinFactory) WithCheat(cheat interface{}) engine.SpinFactory {
	s.cheatPayload = cheat

	return &s
}

func (s SpinFactory) UnmarshalJSONSpin(bytes []byte) (engine.Spin, error) {
	spin := SpinBase{}
	err := json.Unmarshal(bytes, &spin)

	return &spin, err
}

func (s SpinFactory) UnmarshalJSONRestoringIndexes(bytes []byte) (engine.RestoringIndexes, error) {
	restoringIndexes := RestoringIndexes{}
	err := json.Unmarshal(bytes, &restoringIndexes)

	return &restoringIndexes, err
}

func (s *SpinFactory) getStops(reels [][]int) ([]int, error) {
	req := lo.Map(reels, func(item []int, index int) uint64 {
		return uint64(len(item))
	})

	res, err := s.rand.RandSlice(req)
	if err != nil {
		return nil, err
	}

	return lo.Map(res, func(item uint64, index int) int {
		return int(item)
	}), nil
}

func (s *SpinFactory) compute(stops []int, reels [][]int, wager int64) (SpinBase, error) {
	sb := SpinBase{}
	sb.Window.compute(reels, stops)

	award, payLinesToShow := s.computeBasicWindow(wager, sb.Window)

	sb.WagerVal = wager
	sb.Win = award
	sb.Stops = stops
	sb.PayLinesToShow = payLinesToShow

	return sb, nil
}

func (s *SpinFactory) computeBasicWindow(wager int64, window Window) (award int64, payLinesToShow []PayLine) {
	pls := utils.CalcBasePayLines[int, int](payLines, &window, AwardGetter{Wager: wager}, nil, nil, utils.LeftToRightDirection)

	lo.ForEach(pls, func(item utils.PayLine[int, int], index int) {
		payLinesToShow = append(payLinesToShow, PayLine{
			Symbol:       item.PaySymbol,
			PayLineIndex: item.PayLineIndex,
			Indexes:      item.PayLineItems,
			Award:        item.Award,
		})

		award += item.Award
	})

	return award, payLinesToShow
}
