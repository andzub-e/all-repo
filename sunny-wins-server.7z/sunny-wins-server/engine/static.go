package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine/utils"
	"github.com/samber/lo"
)

const (
	windowHeight         = 3
	windowWidth          = 3
	lowRTP       float64 = 45085.0 / 68552.0 * 100
	highRTP      float64 = 87425.0 / 85140.0 * 100

	//lowRTP       float64 = 0.65690155 * 100
	//highRTP      float64 = 1.02688212 * 100
)

var highRTPProb float64

var multipliers = map[int]map[int]int64{
	1: {3: 7},
	2: {3: 7},
	3: {3: 7},
	4: {3: 7},
	5: {3: 15},
	6: {3: 15},
	7: {3: 20},
	8: {3: 40},
	9: {3: 60},
}

var payLines = [][]int{
	{0, 1, 2},
	{3, 4, 5},
	{6, 7, 8},
	{0, 4, 8},
	{6, 4, 2},
}

var reelsHighRTP = [][]int{
	{3, 3, 3, 3, 3, 3, 9, 1, 1, 1, 1, 1, 8, 3, 3, 3, 6, 6, 6, 6, 4, 4, 4, 4, 7, 2, 2, 2, 2, 2, 2, 2, 2, 4, 4, 4, 5, 5, 5, 1, 1, 1, 7},
	{1, 1, 1, 1, 1, 1, 1, 1, 7, 2, 2, 2, 2, 2, 2, 7, 5, 5, 5, 8, 3, 3, 3, 6, 6, 6, 8, 2, 2, 2, 9, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4},
	{4, 4, 4, 4, 4, 2, 2, 2, 6, 6, 6, 8, 1, 1, 1, 7, 5, 5, 5, 7, 2, 2, 2, 2, 2, 2, 4, 4, 4, 1, 1, 1, 1, 1, 1, 9, 3, 3, 3, 3, 3, 3, 3, 3},
}

var reelsLowRTP = [][]int{
	{3, 3, 3, 3, 3, 3, 9, 1, 1, 1, 8, 3, 3, 3, 3, 3, 3, 7, 6, 6, 6, 6, 7, 2, 2, 2, 2, 2, 2, 2, 2, 4, 4, 4, 5, 5, 5, 7},
	{1, 1, 1, 1, 1, 1, 1, 7, 2, 2, 2, 2, 2, 2, 7, 5, 5, 5, 8, 3, 3, 3, 6, 6, 6, 8, 2, 2, 2, 2, 2, 2, 9, 4, 4, 4, 4, 4, 4, 4, 4},
	{4, 4, 4, 4, 4, 4, 2, 2, 2, 6, 6, 6, 8, 1, 1, 1, 1, 1, 1, 5, 5, 5, 7, 4, 4, 4, 4, 4, 4, 1, 1, 1, 1, 1, 1, 9, 3, 3, 3, 3, 3, 3, 3, 3},
}

type Window [][]int

// WrapWindow func for stupid generics (or for stupid me)
func WrapWindow(w *Window) utils.Window[int, int] {
	return w
}

func (w *Window) GetSymbol(reelIndex int, payItem int) int {
	return w.symbol(payItem)
}

func (w *Window) GetByIndexes(reelIndex, symbolIndex int) (int, int) {
	return reelIndex*windowWidth + symbolIndex, (*w)[reelIndex][symbolIndex]
}

func (w *Window) GetHeight() int {
	return windowHeight
}

func (w *Window) GetWidth() int {
	return windowWidth
}

func (w *Window) compute(reels [][]int, stops []int) {
	*w = lo.Map(stops, func(stop int, index int) []int {
		reel := reels[index]
		reelLen := len(reel)

		windowLine := make([]int, windowHeight)
		for j := 0; j < windowHeight; j++ {
			windowLine[j] = reel[(stop+j)%reelLen]
		}

		return windowLine
	})
}

func (w Window) symbol(payIndex int) int {
	position, reel := payIndex/windowWidth, payIndex%windowWidth

	return w[reel][position]
}

type AwardGetter struct {
	Wager int64
}

func (a AwardGetter) GetAward(symbol int, size int) int64 {
	mul := multipliers[symbol][size]

	return mul * a.Wager
}
