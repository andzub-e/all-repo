package engine_test

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/container"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"context"
	"github.com/samber/lo"
	"sync"
	"testing"

	en "cyber-town-server/engine"
)

var (
	factory engine.SpinFactory

	wager      int64 = 1000
	bonusCount       = 1000
	spins      []*en.Spin
)

func init() {
	ctn := container.Build(context.Background(), &sync.WaitGroup{}, "config.yml", "No Tag", true, true)

	boot := en.Bootstrap(ctn, &engine.Config{RTP: "94"})

	factory = boot.SpinFactory

	ctx := engine.Context{Context: context.Background(), Cheats: map[string]interface{}{
		"stops": []int{4, 0, 4, 0, 4},
	}}

	for i := 0; i < bonusCount; i++ {
		spin, _, err := factory.Generate(ctx, wager, nil)
		if err != nil {
			panic(err)
		}

		spins = append(spins, spin.(*en.Spin))
	}
}

func TestBaseBonusSpinCount(t *testing.T) {
	for _, spin := range spins {
		if spin.Bonus.BaseSpinBonusTriggered.TotalSpins != 15 {
			t.Errorf("triggered wrong number of free spins: %+v", spin.Bonus.BaseSpinBonusTriggered)
		}
	}
}

func TestReTriggerBonusSpinCount(t *testing.T) {
	for _, spin := range spins {
		bs := spin.Bonus.Spins

		if len(bs) < 15 {
			t.Errorf("spin count should be more than 15")
		}

		var currentSpinLeft = 15

		for _, s := range bs {
			for _, payout := range s.Payouts.SpinPayouts {
				currentSpinLeft += int(en.BonusFreeSpins[payout.Symbol][payout.Count])
			}

			currentSpinLeft--

			if currentSpinLeft != int(s.BonusSpinsLeft) {
				t.Errorf("wrong number spins left: %d", currentSpinLeft)
			}
		}
	}
}

func TestWheelOfFortune(t *testing.T) {
	for _, spin := range spins {
		if spin.Bonus.Win*spin.Bonus.FortuneMultiplier != spin.Bonus.WinAfterMultiplier {
			t.Errorf("wrong wheel of fortune calculation: %d * %d != %d",
				spin.Bonus.Win, spin.Bonus.FortuneMultiplier, spin.Bonus.WinAfterMultiplier)
		}
	}
}

func TestBonusAwardSum(t *testing.T) {
	for _, spin := range spins {
		sum := lo.SumBy(spin.Bonus.Spins, func(bs en.BonusSpin) int64 {
			return bs.CurrentWinAmount
		})

		if sum != spin.Bonus.Win {
			t.Errorf("wrong bonus sum calculation")
		}
	}
}

func TestTotalWin(t *testing.T) {
	for _, spin := range spins {
		if spin.TotalWin != spin.Bonus.WinAfterMultiplier+spin.Payouts.PayoutForSpin {
			t.Errorf("wrong total win calculation %v != %v + %v", spin.TotalWin, spin.Bonus.WinAfterMultiplier, spin.Payouts.PayoutForSpin)
		}
	}
}
