package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
	"cyber-town-server/buildvar"
	"cyber-town-server/engine"
)

func main() {
	application, err := app.NewApp("config.yml", buildvar.Tag, buildvar.Debug, buildvar.IsCheatsAvailable, engine.Bootstrap)

	if err != nil {
		panic(err)
	}

	if err := application.Run(); err != nil {
		panic(err)
	}
}
