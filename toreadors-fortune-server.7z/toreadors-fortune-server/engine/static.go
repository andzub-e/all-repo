package engine

import (
	"fmt"
	"github.com/samber/lo"
)

const (
	windowHeight          = 3
	windowWidth           = 5
	multiplicationDivider = 10
)

const (
	WildSymbol    = "W"
	ScatterSymbol = "S"
)

var BaseSpinBonusSymbols = []string{"S"}
var BonusSpinBonusSymbols = []string{"A", "K", "Q", "J", "U", "I", "O", "P", "W", "S"}

var BonusFreeSpins = map[string]map[uint]uint{
	"A": {5: 0, 4: 0, 3: 0},
	"K": {5: 0, 4: 0, 3: 0},
	"Q": {5: 0, 4: 0, 3: 0},
	"J": {5: 0, 4: 0, 3: 0},
	"U": {5: 3, 4: 2, 3: 1},
	"I": {5: 3, 4: 2, 3: 1},
	"O": {5: 3, 4: 2, 3: 1},
	"P": {5: 3, 4: 2, 3: 1},

	"W": {5: 0, 4: 0, 3: 0},  // wild
	"S": {5: 0, 4: 0, 3: 15}, // Scatter
}

var payLines = [][]int{
	{5, 6, 7, 8, 9},      //0
	{0, 1, 2, 3, 4},      //1
	{10, 11, 12, 13, 14}, //2
	{0, 6, 12, 8, 4},     //3
	{10, 6, 2, 8, 14},    //4
	{5, 1, 2, 3, 9},      //5
	{5, 11, 12, 13, 9},   //6
	{10, 11, 7, 13, 14},  //7
	{0, 1, 7, 3, 4},      //8
	{5, 1, 7, 3, 9},      //9
}

var reels = [][]string{
	{"A", "U", "K", "Q", "S", "A", "Q", "U", "A", "J", "I", "Q", "J", "S", "A", "J", "P", "Q", "J", "O", "A", "J", "P", "K", "A", "U", "J", "A", "I", "K", "Q", "O", "K", "Q", "S", "K"},
	{"A", "Q", "U", "A", "J", "I", "K", "A", "I", "J", "A", "W", "Q", "J", "I", "K", "Q", "W", "J", "A", "P", "J", "K", "W", "J", "K", "I", "Q", "J", "W", "A", "J", "U", "Q", "A", "O", "Q", "K", "W", "J", "K", "P"},
	{"A", "K", "O", "J", "Q", "S", "K", "J", "W", "K", "Q", "S", "K", "A", "P", "K", "A", "U", "J", "K", "I", "Q", "K", "W", "J", "Q", "O", "K", "A", "W", "Q", "K", "I", "J", "Q", "P", "K", "A", "U", "J", "K", "S"},
	{"A", "Q", "P", "J", "Q", "U", "K", "Q", "I", "A", "J", "O", "Q", "K", "W", "U", "A", "U", "Q", "K", "P", "J", "Q", "I", "A", "Q", "U", "K", "J", "W", "Q", "A", "I", "Q", "J", "O", "K", "Q", "W"},
	{"A", "K", "U", "Q", "J", "S", "Q", "A", "P", "J", "K", "O", "Q", "A", "I", "Q", "J", "W", "K", "J", "I", "A", "Q", "O", "K", "Q", "P", "J", "A", "U", "Q", "J", "O", "A", "K", "W", "J", "K", "U", "A", "K", "S"},
}

var bonusReels = [][]string{
	{"O", "A", "U", "Q", "I", "J", "U", "Q", "P", "A", "U", "K", "P", "J", "I", "Q", "U", "A", "I", "Q", "U", "J", "O", "Q", "U", "J", "I", "A", "U", "Q", "P", "K", "U", "J", "P", "Q", "I", "A", "U", "Q"},
	{"U", "J", "O", "K", "W", "J", "P", "A", "U", "K", "W", "Q", "O", "A", "I", "K", "U", "A", "O", "J", "I", "Q", "W", "A", "U", "K", "I", "J", "O", "K", "U", "K", "P", "J", "I", "K", "O", "J", "U", "Q", "W", "A", "I", "K", "O", "Q", "W", "J", "I", "K", "W", "Q"},
	{"K", "I", "A", "O", "J", "W", "Q", "P", "K", "W", "A", "U", "J", "O", "K", "W", "J", "U", "Q", "I", "K", "W", "J", "P", "A", "O", "K", "W", "J", "I", "A", "W", "Q", "U", "K", "O", "J", "I", "K", "U", "Q", "P", "A", "U"},
	{"K", "U", "J", "I", "K", "O", "J", "P", "K", "W", "A", "U", "K", "O", "J", "W", "Q", "I", "J", "U", "K", "I", "A", "W", "Q", "I", "A", "P", "Q", "W"},
	{"Q", "P", "J", "I", "A", "W", "K", "O", "Q", "I", "J", "U", "A", "W", "K", "O", "J", "U", "K", "I", "A", "P", "Q", "O", "K", "W", "Q", "I", "A", "W"},
}

var multipliers = map[string]map[int]int64{
	"A": {3: 5, 4: 15, 5: 50},
	"K": {3: 5, 4: 15, 5: 50},
	"Q": {3: 3, 4: 10, 5: 25},
	"J": {3: 3, 4: 10, 5: 25},
	"U": {3: 5, 4: 25, 5: 100},
	"I": {3: 10, 4: 50, 5: 250},
	"O": {3: 15, 4: 100, 5: 500},
	"P": {3: 20, 4: 150, 5: 1000},
	"W": {3: 0, 4: 0, 5: 0}, // Wild
	"S": {3: 0, 4: 0, 5: 0}, // Scatter
}

var wheelOfFortuneReel = []int64{10, 1, 3, 3, 1, 2, 5, 3, 1, 3, 2, 3, 3, 3, 5, 1, 5, 3, 3, 2, 2, 1, 5, 2, 2, 2, 2, 2, 5, 5, 5, 2, 2, 2}

type Window [][]string

func (w *Window) compute(reels [][]string, stops []int) {
	*w = lo.Map(stops, func(stop int, index int) []string {
		reel := reels[index]
		reelLen := len(reel)

		windowLine := make([]string, windowHeight)
		for j := 0; j < windowHeight; j++ {
			windowLine[j] = reel[(stop+j)%reelLen]
		}

		return windowLine
	})
}

func (w *Window) symbol(payIndex int) string {
	position, reel := payIndex/windowWidth, payIndex%windowWidth

	return (*w)[reel][position]
}

type AwardGetter struct {
	Wager int64
}

func NewAwardGetter(wager int64) (AwardGetter, error) {
	if wager < 0 {
		return AwardGetter{}, fmt.Errorf("negative wager: %v", wager)
	}

	return AwardGetter{Wager: wager}, nil
}

func (a AwardGetter) GetAward(symbol string, size int) int64 {
	mul := multipliers[symbol][size]

	return mul * a.Wager / multiplicationDivider
}

func symbolIsWild(symbol string) bool {
	return symbol == WildSymbol
}

func reelSerialized(reels [][]string) string {
	return fmt.Sprint(reels)
}
