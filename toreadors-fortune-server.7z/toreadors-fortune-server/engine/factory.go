package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/validator"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"encoding/json"
	"github.com/samber/lo"
	"github.com/sarulabs/di"
)

func Bootstrap(ctn di.Container, config *engine.Config) *engine.Bootstrap {
	rand := ctn.Get(constants.RNGMockName).(rng.Client)
	validatorEngine := ctn.Get(constants.ValidatorName).(*validator.Validator)
	factory := NewSpinFactory(rand, validatorEngine)

	return &engine.Bootstrap{
		SpinFactory: factory,

		HTTPTransport:      true,
		WebsocketTransport: true,

		GambleAnyWinFeature: false,
		FreeSpinsFeature:    true,

		HistoryHandlingType: engine.SequentialRestoring,
	}
}

func NewSpinFactory(rand rng.Client, validateEngine *validator.Validator) *SpinFactory {
	factory := &SpinFactory{rand: rand, validateEngine: validateEngine}

	return factory
}

type SpinFactory struct {
	rand           rng.Client
	validateEngine *validator.Validator
}

func (s *SpinFactory) Generate(ctx engine.Context, wager int64, parameters interface{}) (engine.Spin, engine.RestoringIndexes, error) {
	stops, isCheatStops, err := s.getStops(ctx.Cheats, reels)
	if err != nil {
		return nil, nil, err
	}

	window, payouts, award, bonus, err := s.compute(ctx, stops, wager)
	if err != nil {
		return nil, nil, err
	}

	if payouts.SpinPayouts == nil {
		payouts.SpinPayouts = make([]Payout, 0, 1)
	}

	spin := &Spin{
		LastWager: wager,
		TotalWin:  award + bonus.Award(),
		ReelState: ReelState{
			Stops:        stops,
			IsCheatStops: isCheatStops,
		},
		Window:  window,
		Payouts: payouts,
		Bonus:   bonus,
	}

	return spin, &RestoringIndexes{}, nil
}

func (s *SpinFactory) GambleAnyWin(ctx engine.Context, parameters interface{}) (engine.Spin, error) {
	return ctx.LastSpin, nil
}

func (s *SpinFactory) KeepGenerate(ctx engine.Context, parameters interface{}) (engine.Spin, bool, error) {
	return ctx.LastSpin, false, nil
}

func (s *SpinFactory) UnmarshalJSONSpin(bytes []byte) (engine.Spin, error) {
	spin := Spin{}
	err := json.Unmarshal(bytes, &spin)

	return &spin, err
}

func (s *SpinFactory) UnmarshalJSONRestoringIndexes(bytes []byte) (engine.RestoringIndexes, error) {
	restoringIndexes := RestoringIndexes{}
	err := json.Unmarshal(bytes, &restoringIndexes)

	return &restoringIndexes, err
}

func (s *SpinFactory) getStops(cheats interface{}, localReels [][]string) ([]int, bool, error) {
	c := Cheats{}

	if cheats != nil && reelSerialized(localReels) == reelSerialized(reels) {
		if err := c.Eval(cheats); err != nil {
			return nil, false, err
		}

		if len(c.Stops) != len(localReels) {
			return nil, false, errs.ErrBadDataGiven
		}

		for i := range c.Stops {
			if c.Stops[i] > len(localReels[i]) {
				return nil, false, errs.ErrBadDataGiven
			}
		}

		return c.Stops, true, nil
	}

	req := lo.Map(localReels, func(item []string, index int) uint64 {
		return uint64(len(item))
	})

	res, err := s.rand.RandSlice(req)
	if err != nil {
		return nil, false, err
	}

	return lo.Map(res, func(item uint64, index int) int {
		return int(item)
	}), false, nil
}

func (s *SpinFactory) compute(ctx engine.Context, stops []int, wager int64) (window Window, payouts Payouts, award int64, bonus *Bonus, err error) {
	window.compute(reels, stops)

	ag, err := NewAwardGetter(wager)
	if err != nil {
		return window, payouts, 0, nil, err
	}

	award, payouts = computeBasicWindow(window, ag)

	bonus, err = s.computeBonus(ctx, window, ag)
	if err != nil {
		return window, payouts, 0, nil, err
	}

	return window, payouts, award, bonus, nil
}

func (s *SpinFactory) computeBonus(ctx engine.Context, window Window, ag AwardGetter) (*Bonus, error) {
	var bonus *Bonus

	baseSpinBonusTriggered := computeBonusWindow(window, SpinTypeBase, ag)

	if baseSpinBonusTriggered.TotalSpins <= 0 {
		return bonus, nil
	}

	bonus = &Bonus{}
	bonus.BaseSpinBonusTriggered = baseSpinBonusTriggered

	for ctn := baseSpinBonusTriggered.TotalSpins; ctn != 0; ctn-- {
		var bonusSpin BonusSpin

		stops, _, err := s.getStops(ctx.Cheats, bonusReels)
		if err != nil {
			return nil, err
		}

		window.compute(bonusReels, stops)

		currentAward, payouts := computeBasicWindow(window, ag)
		if currentAward > 0 {
			bonusSpin.Payouts.SpinPayouts = append(bonusSpin.Payouts.SpinPayouts, payouts.SpinPayouts...)
			bonusSpin.Payouts.PayoutForSpin = payouts.PayoutForSpin
			bonus.Win += currentAward
		}

		additionalSpins := computeBonusWindow(window, SpinTypeBonus, ag)
		bonusSpinsLeft := ctn + additionalSpins.TotalSpins - 1

		bonusSpin.Window = window
		bonusSpin.ReelState = ReelState{Stops: stops}
		bonusSpin.AdditionalSpins = additionalSpins
		bonusSpin.CurrentWinAmount = bonusSpin.Payouts.PayoutForSpin
		bonusSpin.BonusSpinsLeft = bonusSpinsLeft

		bonus.Spins = append(bonus.Spins, bonusSpin)

		ctn += additionalSpins.TotalSpins
	}

	index, err := s.rand.Rand(uint64(len(wheelOfFortuneReel)))
	if err != nil {
		return nil, err
	}

	fortuneMultiplier := wheelOfFortuneReel[int(index)]

	bonus.FortuneMultiplierIndex = int(index)
	bonus.FortuneMultiplier = fortuneMultiplier
	bonus.WinAfterMultiplier = bonus.Win * fortuneMultiplier

	return bonus, nil
}
