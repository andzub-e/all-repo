package engine

type SpinType string

const (
	SpinTypeBase  SpinType = "base_spin"
	SpinTypeBonus SpinType = "bonus_spin"
)

type Bonus struct {
	Win                    int64               `json:"win"`
	WinAfterMultiplier     int64               `json:"total_win"`
	FortuneMultiplierIndex int                 `json:"fortune_multiplier_index"`
	FortuneMultiplier      int64               `json:"fortune_multiplier"`
	BaseSpinBonusTriggered BonusSpinsTriggered `json:"base_spins_bonus_triggered"`

	Spins []BonusSpin `json:"spins_results"`
}

type BonusSpin struct {
	Window           Window              `json:"window"`
	ReelState        ReelState           `json:"reels"`
	Payouts          Payouts             `json:"payouts"`
	AdditionalSpins  BonusSpinsTriggered `json:"additionalSpins"`
	BonusSpinsLeft   uint                `json:"bonus_spins_left" swaggertype:"integer" example:"100"`
	CurrentWinAmount int64               `json:"current_win_amount" swaggertype:"integer" example:"100"`
}

type BonusSpinsTriggered struct {
	TotalSpins              uint                 `json:"total_spins" swaggertype:"integer"`
	BonusSpinsTriggeredInfo []BonusSpinTriggered `json:"triggered_spins_info"`
}

type BonusSpinTriggered struct {
	Symbol             string `json:"symbol" swaggertype:"string"`
	PayLine            uint   `json:"payline" swaggertype:"integer"`
	PayLineIndependent bool   `json:"payline_independent" swaggertype:"bool"`
	SpinsAmount        uint   `json:"spins_amount" swaggertype:"integer"`
}

func (b *Bonus) Award() (award int64) {
	if b == nil {
		return award
	}

	return b.WinAfterMultiplier
}

func (b *Bonus) DeepCopy() *Bonus {
	if b == nil {
		return nil
	}

	newB := &Bonus{
		Win:                    b.Win,
		WinAfterMultiplier:     b.WinAfterMultiplier,
		FortuneMultiplierIndex: b.FortuneMultiplierIndex,
		FortuneMultiplier:      b.FortuneMultiplier,
		Spins:                  make([]BonusSpin, len(b.Spins)),
	}
	copy(newB.Spins, b.Spins)

	return newB
}

func getBonusSymbolCount(window Window, symbol string) uint {
	var totalSymbols uint

	for reel := 0; reel < windowWidth; reel++ {
		for row := 0; row < windowHeight; row++ {
			if window[reel][row] == symbol {
				totalSymbols++
			}
		}
	}

	spinsCount, ok := BonusFreeSpins[symbol][totalSymbols]
	if !ok {
		return 0
	}

	return spinsCount
}
