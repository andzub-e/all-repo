package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/buildvar"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/constants"
	baseEngine "bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/tests/stress"
	"bookofming-server/engine"
	"go.uber.org/zap"
	"net/url"
)

func main() {
	application, err := app.NewApp("config.yml", buildvar.Tag, buildvar.Debug, buildvar.IsCheatsAvailable, engine.Bootstrap)
	if err != nil {
		panic(err)
	}

	logger := application.Ctn().Get(constants.LoggerName).(*zap.Logger)
	url, err := url.Parse("https://dev.heronbyte.com/lucky-pint/api")
	if err != nil {
		panic(err)
	}

	spammer := stress.NewSpammer(helper{}, baseEngine.GetFromContainer().SpinFactory, logger, *url, "lucky-pint")

	rep, err := spammer.Run(1000, 10)
	if err != nil {
		logger.Sugar().Info(err)
	}

	if len(rep.Errs) > 0 {
		logger.Sugar().Info(len(rep.Errs))
		logger.Sugar().Info(rep.Errs)
	} else {
		logger.Sugar().Infof("init lat: %v, wager lat: %v, update lat: %v",
			rep.AvgInitLatency(), rep.AvgWagerLatency(), rep.AvgUpdateLatency())
	}
}

type helper struct {
}

func (h helper) WagerParams() interface{} {
	return nil
}

func (h helper) UpdateParams(spin baseEngine.Spin, restoring baseEngine.RestoringIndexes) interface{} {
	spinTyped := spin.(*engine.Spin)

	m := map[string]interface{}{"base_spin_index": 1}

	if spinTyped.Bonus != nil {
		m["bonus_spin_index"] = len(spinTyped.Bonus.Spins)
	}

	return m
}
