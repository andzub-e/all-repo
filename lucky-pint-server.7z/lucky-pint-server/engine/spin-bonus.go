package engine

import (
	"bytes"
	"fmt"
)

type Bonus struct {
	BookIndexes  []int       `json:"book_indexes"`
	ExtraScatter string      `json:"extra_scatter"`
	Spins        []BonusSpin `json:"spins"`
}

type BonusSpin struct {
	Window               Window    `json:"window"`
	Stops                []int     `json:"stops"`
	Award                int64     `json:"award"`
	PayLinesToShow       []PayLine `json:"pay_lines_to_show"`
	ExtraScatterPayLines []PayLine `json:"extra_scatter_pay_lines"`
	BookIndexes          []int     `json:"book_indexes"`
	BonusSpinsLeft       int       `json:"bonus_spins_left"`
	BonusSpinsTriggered  int       `json:"bonus_spins_triggered"`
}

func (b *Bonus) Award() (award int64) {
	if b == nil {
		return award
	}

	for _, spin := range b.Spins {
		award += spin.Award
	}

	return award
}

func (b *Bonus) DeepCopy() *Bonus {
	if b == nil {
		return nil
	}

	newB := &Bonus{ExtraScatter: b.ExtraScatter, Spins: make([]BonusSpin, len(b.Spins))}
	copy(newB.Spins, b.Spins)

	return newB
}

func (b *Bonus) DebugString() string {
	if b == nil {
		return "nil"
	}

	buf := bytes.Buffer{}

	buf.WriteString(fmt.Sprintf("Extra Skatter %v\n", b.ExtraScatter))
	buf.WriteString(fmt.Sprintf("Genetal BaseAward %v\n", b.Award()))

	for _, spin := range b.Spins {
		buf.WriteString(fmt.Sprintf("\t award: %v\n", spin.Award))
		buf.WriteString(fmt.Sprintf("\t window:\n"))
		for j := 0; j < windowHeight; j++ {
			buf.WriteString("\t\t")
			for i := 0; i < windowWidth; i++ {
				buf.WriteString(spin.Window[i][j] + " ")
			}

			buf.WriteString("\n")
		}

		buf.WriteString(fmt.Sprintf("\tpay lines to show:\n"))
		for _, payLine := range spin.PayLinesToShow {
			buf.WriteString(fmt.Sprintf("\t\t Symbol: %v BaseAward: %v, PayLineIndex: %v, Indexes: %v\n",
				payLine.Symbol, payLine.Award, payLine.PayLineIndex, payLine.Indexes))
		}

	}

	return buf.String()
}
