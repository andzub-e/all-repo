package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"go.uber.org/zap"
)

type Spin struct {
	WagerVal       int64     `json:"wager"`
	Win            int64     `json:"award"`
	Stops          []int     `json:"stops"`
	Window         Window    `json:"window"`
	PayLinesToShow []PayLine `json:"pay_lines_to_show"`
	Gambles        []Gamble  `json:"gambles"`

	Bonus *Bonus `json:"bonus,omitempty"`
}

func (s Spin) DeepCopy() engine.Spin {
	return s.deepCopy()
}

func (s Spin) deepCopy() *Spin {
	spin := &Spin{
		WagerVal: s.WagerVal,
		Win:      s.Win,
		Stops:    s.Stops,

		Window:         make(Window, len(s.Window)),
		PayLinesToShow: make([]PayLine, len(s.PayLinesToShow)),
		Gambles:        make([]Gamble, len(s.Gambles)),
		Bonus:          s.Bonus.DeepCopy(),
	}

	copy(spin.Window, s.Window)
	copy(spin.PayLinesToShow, s.PayLinesToShow)
	copy(spin.Gambles, s.Gambles)

	return spin
}

func (s *Spin) BaseAward() int64 {
	award := s.Win

	if len(s.Gambles) > 0 {
		award = s.Gambles[len(s.Gambles)-1].Win
	}

	return award
}

func (s *Spin) BonusAward() int64 {
	return s.Bonus.Award()
}

func (s *Spin) Wager() int64 {
	wager := s.WagerVal

	if len(s.Gambles) > 0 {
		wager = s.Gambles[len(s.Gambles)-1].WagerVal
	}

	return wager
}

func (s *Spin) WagerNoGambles() int64 {
	return s.WagerVal
}

func (s *Spin) GambleQuantity() int {
	return len(s.Gambles)
}

func (s *Spin) BonusTriggered() bool {
	return s.Bonus != nil
}

func (s *Spin) CanGamble(restoringIndexes engine.RestoringIndexes) bool {
	if s.Bonus != nil {
		return false
	}

	restoringIndexesTyped, ok := restoringIndexes.(*RestoringIndexes)

	if !ok {
		zap.S().Error("can not parse restoring indexes")

		return true
	}

	return !restoringIndexesTyped.IsGambleCollected
}

type PayLine struct {
	Symbol       string `json:"symbol"`
	PayLineIndex int    `json:"index"`
	Indexes      []int  `json:"indexes"`
	Award        int64  `json:"award"`
}
