package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
	"blazing-clovers-server/engine"
)

func main() {
	application, err := app.New("config.yml", engine.GameBoot)

	if err != nil {
		panic(err)
	}

	if err := application.Run(); err != nil {
		panic(err)
	}
}
