package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine/utils"
	"github.com/samber/lo"
)

type Window struct {
	matrix        [][]int       // send to the frontend that prevent
	indexed       []map[int]int // use for internal avalanche logic
	scatterQty    int
	multiplierQty int
}

type win struct {
	symbol  int
	indexes [][]int
	count   int
}

func (w *win) GetSymbol() int {
	return w.symbol
}

func (w *win) GetIndexes() [][]int {
	return w.indexes
}

func (w *win) Count() int {
	return w.count
}

func (w *Window) Compute(stops []int, reels []map[int]int, maxIndexes []int, deletedIndexes []map[int]struct{}) error {
	w.matrix = make([][]int, windowWidth)

	w.indexed = lo.Map(stops, func(stop int, index int) map[int]int {
		reel := reels[index]
		reelMaxIndex := maxIndexes[index] + 1

		windowLine := make(map[int]int, windowHeight)
		appended := 0

		for i := 0; appended < windowHeight; i++ {
			symbolIndex := mod(stop-i, reelMaxIndex)

			if symbol, exist := reel[symbolIndex]; exist {
				if _, isDeleted := deletedIndexes[index][symbolIndex]; !isDeleted {
					windowLine[symbolIndex] = symbol
					w.matrix[index] = append(w.matrix[index], symbol)

					appended++
				}
			}
		}

		return windowLine
	})

	return nil
}

func (w *Window) GetAbsIndexesBySymbol(s int) [][]int {
	results := make([][]int, windowWidth)

	for reelIndex, reel := range w.indexed {
		for symbolIndex, symbol := range reel {
			if symbol == s {
				results[reelIndex] = append(results[reelIndex], symbolIndex)
			}
		}
	}

	return results
}

func (w *Window) GetIndexesBySymbol(s int) [][]int {
	indexes := make([][]int, windowWidth)

	for reelIndex, reel := range w.matrix {
		for symbolIndex, symbol := range reel {
			if symbol == s {
				indexes[reelIndex] = append(indexes[reelIndex], symbolIndex)
			}
		}
	}

	return indexes
}

func (w *Window) CheckWin() []utils.Win[int] {
	results := make(map[int]*win)

	for reelIndex, reel := range w.matrix {
		for symbolIndex, symbol := range reel {
			if _, exist := results[symbol]; !exist {
				results[symbol] = &win{
					symbol:  symbol,
					indexes: make([][]int, windowWidth),
				}
			}

			if symbol == ScatterSymbol && results[symbol].count == maxScattersToGetAward {
				goto AppendIndex
			}

			if results[symbol].count == maxSymbolsToGetAward {
				goto AppendIndex
			}

			results[symbol].count++

		AppendIndex:
			results[symbol].indexes[reelIndex] = append(results[symbol].indexes[reelIndex], symbolIndex)
		}
	}

	wins := make([]utils.Win[int], 0, len(results))
	for _, win := range results {
		wins = append(wins, win)
	}

	return wins
}

func (w *Window) Matrix() [][]int {
	return w.matrix
}

func (w *Window) GetScatterSymbol() *int {
	return &ScatterSymbol
}

func (w *Window) SetScatterQty(qty int) {
	w.scatterQty = qty
}

func (w *Window) GetScatterQty() int {
	return w.scatterQty
}

func (w *Window) GetMultiplierSymbol() *int {
	return &MultiplierSymbol
}

func (w *Window) SetMultiplierQty(qty int) {
	w.multiplierQty = qty
}

func (w *Window) GetMultiplierQty() int {
	return w.multiplierQty
}

func mod(a, b int) int {
	return (a%b + b) % b
}

// for metrics
func getIndexesBySymbol(w [][]int) int {
	count := 0

	for _, reel := range w {
		for _, symbol := range reel {
			if symbol == ScatterSymbol {
				count++
			}
		}
	}

	return count
}
