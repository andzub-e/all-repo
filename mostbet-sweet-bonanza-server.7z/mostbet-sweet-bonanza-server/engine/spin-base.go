package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine/utils"
	"github.com/mohae/deepcopy"
)

type SpinBase struct {
	WagerVal        int64  `json:"wager"`
	AnteBetWagerVal *int64 `json:"ante_bet_wager"`
	Win             int64  `json:"award"`
	Stops           []int  `json:"stops"`
	AnteBet         bool   `json:"ante_bet"`
	BuyBonus        bool   `json:"buy_bonus"`

	Avalanches []utils.Avalanche[int] `json:"avalanches"`

	Bonus *Bonus `json:"bonus,omitempty"`
}

func (s *SpinBase) BaseAward() int64 {
	return s.Win
}

func (s *SpinBase) BonusAward() int64 {
	return s.Bonus.Award()
}

func (s *SpinBase) GambleAward() int64 {
	return 0
}

func (s *SpinBase) Wager() int64 {
	if s.AnteBet && s.AnteBetWagerVal != nil {
		return *s.AnteBetWagerVal
	}

	return s.WagerVal
}

func (s *SpinBase) BonusTriggered() bool {
	return s.Bonus != nil
}

func (s *SpinBase) WagerNoGambles() int64 {
	return s.WagerVal
}

func (s *SpinBase) GambleQuantity() int {
	return 0
}

func (s *SpinBase) CanGamble(_ engine.RestoringIndexes) bool {
	return false
}

func (s *SpinBase) Multiplier() int64 {
	return 0
}

func (s *SpinBase) DeepCopy() engine.Spin {
	return deepcopy.Copy(s).(engine.Spin)
}
