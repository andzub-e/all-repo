package engine

var (
	FreeGameCount               int
	FreeGameCountAfterAvalanche int
)
