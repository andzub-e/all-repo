package engine

import (
	"encoding/json"
	"strconv"

	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"bitbucket.org/electronicjaw/base-slot-server/utils"
	"github.com/samber/lo"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
)

func Bootstrap(ctn di.Container, config *engine.Config) *engine.Bootstrap {
	rand := ctn.Get(constants.RNGMockName).(rng.Client)

	rtp, err := strconv.ParseFloat(config.RTP, 64)
	if err != nil {
		zap.S().Panic(err)
		panic(err)
	}

	lowBaseRTPReelRate = calcBaseRTP(rtp)
	lowAnteRTPReelRate = calcAnteRTP(rtp)

	baseGame := createConfig(rand, bonusMultipliers)
	freeGame := createConfig(rand, bonusMultipliersFreeGame)

	factory := NewSpinFactory(rand, baseGame, freeGame)

	return &engine.Bootstrap{
		SpinFactory:        factory,
		HTTPTransport:      true,
		WebsocketTransport: true,

		FreeSpinsFeature: true,

		HistoryHandlingType: engine.SequentialRestoring,
	}
}

func createConfig(rand rng.Client, config map[int]int) *utils.Chooser[int, int] {
	choices := make([]utils.Choice[int, int], 0, len(config))
	for value, weight := range config {
		choices = append(choices, utils.NewChoice(value, weight))
	}

	chooser, err := utils.NewChooser(rand, choices...)
	if err != nil {
		zap.Error(err)
		panic(err)
	}

	return chooser
}

type SpinFactory struct {
	rand        rng.Client
	baseGameMul *utils.Chooser[int, int]
	freeGameMul *utils.Chooser[int, int]
}

func NewSpinFactory(rand rng.Client, baseGameMul *utils.Chooser[int, int], freeGameMul *utils.Chooser[int, int]) *SpinFactory {
	return &SpinFactory{
		rand:        rand,
		baseGameMul: baseGameMul,
		freeGameMul: freeGameMul,
	}
}

func (s *SpinFactory) Generate(ctx engine.Context, wager int64, parameters interface{}) (engine.Spin, engine.RestoringIndexes, error) {
	isAnteBet, isBuyBonus, err := getFeaturesFromParams(parameters)
	if err != nil {
		return nil, nil, err
	}

	cheats, err := getCheatsFromCtx(ctx)
	if err != nil {
		return nil, nil, err
	}

	var anteBetWagerVal *int64

	if isAnteBet {
		value := wager * anteBetMultiplier / anteBetDivider
		anteBetWagerVal = &value
	}

	reelType, err := s.getReelType(ctx.RTP, isAnteBet)
	if err != nil {
		return nil, nil, err
	}

	indexedReels := *availableIndexedReels[reelType]

	ag, err := NewAwardGetter(wager)
	if err != nil {
		return nil, nil, err
	}

	stops, err := s.getStops(cheats, reelType)
	if err != nil {
		return nil, nil, err
	}

	if isBuyBonus {
		stops = *buyFreeSpinGameStops[reelType]
		wager *= buyBonusMultiplier
	}

	award, avalanches, bonus, err := s.compute(ag, stops, indexedReels, cheats, isBuyBonus)
	if err != nil {
		return nil, nil, err
	}

	return &SpinBase{
		WagerVal:        wager,
		AnteBetWagerVal: anteBetWagerVal,
		Win:             award,
		Stops:           stops,
		AnteBet:         isAnteBet,
		BuyBonus:        isBuyBonus,
		Avalanches:      avalanches,
		Bonus:           bonus,
	}, &RestoringIndexes{}, nil
}

func (s *SpinFactory) KeepGenerate(_ engine.Context, _ interface{}) (engine.Spin, bool, error) {
	return nil, false, nil
}

func (s *SpinFactory) GambleAnyWin(_ engine.Context, _ interface{}) (engine.Spin, error) {
	return nil, nil
}

func (s *SpinFactory) UnmarshalJSONSpin(bytes []byte) (engine.Spin, error) {
	spin := SpinBase{}
	err := json.Unmarshal(bytes, &spin)

	return &spin, err
}

func (s *SpinFactory) UnmarshalJSONRestoringIndexes(bytes []byte) (engine.RestoringIndexes, error) {
	restoringIndexes := RestoringIndexes{}
	err := json.Unmarshal(bytes, &restoringIndexes)

	return &restoringIndexes, err
}

func (s *SpinFactory) getStops(cheats *Cheats, reelCode int) ([]int, error) {
	reel := *availableReels[reelCode]

	if cheats != nil {
		if reelCode == bonusReelCode {
			if cheats.AdditionalTriggerCount > 0 {
				cheats.AdditionalTriggerCount--

				stops := make([]int, len(additionalSpinsTriggerStops))
				copy(stops, additionalSpinsTriggerStops)

				return stops, nil
			}
		} else {
			if len(cheats.Stops) != len(reel) {
				return nil, errs.ErrBadDataGiven
			}

			for i := range cheats.Stops {
				if cheats.Stops[i] > len(reel[i]) {
					return nil, errs.ErrBadDataGiven
				}
			}

			return cheats.Stops, nil
		}
	}

	req := lo.Map(reel, func(item []int, index int) uint64 {
		return uint64(len(item))
	})

	res, err := s.rand.RandSlice(req)
	if err != nil {
		return nil, err
	}

	return lo.Map(res, func(item uint64, index int) int {
		return int(item)
	}), nil
}

func (s *SpinFactory) getReelType(rtp *int64, isAnteBet bool) (int, error) {
	rnd, err := s.rand.RandFloat()
	if err != nil {
		return 0, err
	}

	if rtp != nil {
		if isAnteBet {
			if rnd > calcAnteRTP(float64(*rtp)) {
				return highRTPAnteCode, nil
			}
			return lowRTPAnteCode, nil
		}

		if rnd > calcBaseRTP(float64(*rtp)) {
			return highRTPBaseCode, nil
		}
		return lowRTPBaseCode, nil
	}

	if isAnteBet {
		if rnd > lowAnteRTPReelRate {
			return highRTPAnteCode, nil
		}
		return lowRTPAnteCode, nil
	}

	if rnd > lowBaseRTPReelRate {
		return highRTPBaseCode, nil
	}
	return lowRTPBaseCode, nil
}

func calcBaseRTP(rtp float64) float64 {
	if rtp < lowBaseRTP {
		return lowBaseRTP
	}
	if rtp > highBaseRTP {
		return highBaseRTP
	}

	return (highBaseRTP - rtp) / (highBaseRTP - lowBaseRTP)
}

func calcAnteRTP(rtp float64) float64 {
	if rtp < lowAnteRTP {
		return lowAnteRTP
	}
	if rtp > highAnteRTP {
		return highAnteRTP
	}

	return (highAnteRTP - rtp) / (highAnteRTP - lowAnteRTP)
}
