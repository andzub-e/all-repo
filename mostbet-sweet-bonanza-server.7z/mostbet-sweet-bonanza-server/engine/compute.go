package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine/utils"
	"github.com/samber/lo"
)

func (s *SpinFactory) compute(ag AwardGetter, stops []int, reels []map[int]int, cheats *Cheats, buyBonus bool) (award int64, avalanches []utils.Avalanche[int], bonus *Bonus, err error) {
	award, avalanches, triggerBonus, err := s.computeBasicWindow(ag, stops, reels, buyBonus)
	if err != nil {
		return 0, nil, nil, err
	}

	if triggerBonus || buyBonus {
		bonus, err = s.computeBonusWindow(ag, cheats, buyBonus)
		if err != nil {
			return 0, nil, nil, err
		}
	}

	return award, avalanches, bonus, nil
}

func (s *SpinFactory) computeBasicWindow(
	ag AwardGetter, stops []int, reels []map[int]int, buyBonus bool,
) (award int64, avalanches []utils.Avalanche[int], triggerBonus bool, err error) {
	var window Window

	avalanches, award, err = utils.Spin[int](ag, &window, reels, stops)
	if err != nil {
		return 0, nil, false, err
	}

	if window.GetScatterQty() >= needScattersToTriggerBonus {
		// metrics
		// if len(avalanches) > 0 {
		// 	if getIndexesBySymbol(avalanches[0].Window) < needScattersToTriggerBonus {
		// 		FreeGameCountAfterAvalanche++
		// 	}
		// }

		indexes := window.GetIndexesBySymbol(ScatterSymbol)

		currentAward := int64(0)

		if !buyBonus {
			currentAward = ag.GetAward(ScatterSymbol, window.GetScatterQty())
		}

		award += currentAward

		avalanches = appendToLastOrNew(avalanches, &window, utils.PayItem[int]{Symbol: ScatterSymbol, Indexes: indexes, Award: currentAward})

		// metrics
		// FreeGameCount++

		return award, avalanches, true, nil
	}

	return award, avalanches, triggerBonus, nil
}

func (s *SpinFactory) computeBonusWindow(ag AwardGetter, cheats *Cheats, buyBonus bool) (bonus *Bonus, err error) {
	var window Window
	bonus = new(Bonus)

	var bonusSpinTriggered int

	for count := bonusSpinCount; count > 0 || bonusSpinTriggered > 0; count-- {
		var bonusAwardMultipliers []int

		stops, err := s.getStops(cheats, bonusReelCode)
		if err != nil {
			return nil, err
		}

		avalanches, award, err := utils.Spin[int](ag, &window, indexedBonusReels, stops)
		if err != nil {
			return nil, err
		}

		if bonusSpinTriggered > 0 {
			count += bonusSpinTriggered
			bonusSpinTriggered = 0
		}

		if window.GetScatterQty() >= needScattersToTriggerExtraSpins {
			indexes := window.GetIndexesBySymbol(ScatterSymbol)

			currentAward := ag.GetAward(ScatterSymbol, window.GetScatterQty())

			payItem := utils.PayItem[int]{Symbol: ScatterSymbol, Indexes: indexes, Award: currentAward}

			avalanches = appendToLastOrNew(avalanches, &window, payItem)

			bonusSpinTriggered = extraSpinCount
		}

		if award != 0 && window.GetMultiplierQty() > 0 {
			bonusAwardMultipliers = make([]int, window.GetMultiplierQty())
			for i := 0; i < window.GetMultiplierQty(); i++ {
				if buyBonus {
					bonusAwardMultipliers[i], err = s.freeGameMul.Pick()
				} else {
					bonusAwardMultipliers[i], err = s.baseGameMul.Pick()
				}

				if err != nil {
					return nil, err
				}
			}

			indexes := window.GetIndexesBySymbol(MultiplierSymbol)

			award *= int64(lo.Sum(bonusAwardMultipliers))

			avalanches = appendToLastOrNew(avalanches, &window, utils.PayItem[int]{Symbol: MultiplierSymbol, Indexes: indexes, Award: award})
		}

		window.SetScatterQty(0)
		window.SetMultiplierQty(0)

		bonus.Spins = append(bonus.Spins, SpinBonus{
			Stops:               stops,
			Award:               award,
			BonusSpinsLeft:      count,
			BonusSpinsTriggered: bonusSpinTriggered,
			Multipliers:         bonusAwardMultipliers,
			Avalanches:          avalanches,
		})
	}

	bonus.Win = bonus.Award()

	return bonus, nil
}

func appendToLastOrNew(avalanches []utils.Avalanche[int], window *Window, payItem utils.PayItem[int]) []utils.Avalanche[int] {
	if len(avalanches) == 0 {
		return []utils.Avalanche[int]{{Window: window.matrix, PayItems: []utils.PayItem[int]{payItem}}}
	}

	avalanches[len(avalanches)-1].PayItems = append(avalanches[len(avalanches)-1].PayItems, payItem)

	return avalanches
}
