package engine

import "bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine/utils"

type Bonus struct {
	Win int64 `json:"award"`

	Spins []SpinBonus `json:"spins"`
}

type SpinBonus struct {
	Stops               []int `json:"stops"`
	Award               int64 `json:"award"`
	BonusSpinsLeft      int   `json:"bonus_spins_left"`
	BonusSpinsTriggered int   `json:"bonus_spins_triggered"`
	Multipliers         []int `json:"multipliers"`

	Avalanches []utils.Avalanche[int] `json:"avalanches"`
}

func (b *Bonus) Award() (award int64) {
	if b == nil {
		return award
	}

	for _, spin := range b.Spins {
		award += spin.Award
	}

	return award
}
