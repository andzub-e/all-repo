package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/services"
	"bitbucket.org/electronicjaw/base-slot-server/utils"
	"fmt"
	"os"
	"path/filepath"
	"sweet-bonanza/engine"
	"time"
)

func main() {
	now := time.Now()

	application, err := app.New("config.yml", engine.Bootstrap)
	if err != nil {
		panic(err)
	}

	simulator := application.GetSimulatorService()

	N := 50 * 1000 * 1000
	result, err := simulator.WithProgressListener(func(percent float64) {
		fmt.Printf("Processing: %2.0f%%\n", percent*100)
	}).
		WithWagerParameters(engine.Features{
			//AnteBet: true,
			//BuyBonus: true,
		}).
		Simulate("sweet-bonanza", N, 20)

	reportPages := []utils.Page{
		{
			Name:  "Report",
			Table: utils.Transpose(utils.ExtractTable([]*services.SimulationView{result.View()}, "xlsx")),
		}}

	saveReport(reportPages)

	fmt.Printf("The program ran for %s\n", time.Since(now))

	// free game hit rate
	//fmt.Printf("Free game activated: %d\n", engine.FreeGameCount)
	//fmt.Printf("Free game activated after avalanche: %d\n", engine.FreeGameCountAfterAvalanche)
	//fmt.Printf("Free game hit rate: %f\n", 1.0/(float64(engine.FreeGameCount)/float64(N)))

	fmt.Printf("RTP: %.4f%%\n", result.RTP*100)
}

func saveReport(reportPages []utils.Page) {
	excel, err := utils.ExportMultiPageXLSX(reportPages)
	if err != nil {
		fmt.Printf("simulate: %v\n", err)
	}

	abs, err := filepath.Abs("reports")
	if err != nil {
		panic(err)
	}

	file, err := os.Create(filepath.Join(abs, fmt.Sprintf("report-%v.xlsx", time.Now().UnixNano())))
	if err != nil {
		fmt.Printf("simulate: %v\n", err)
	}

	if err = excel.Write(file); err != nil {
		fmt.Printf("simulate: %v\n", err)
	}
}
