package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"encoding/json"
	"fmt"
	"github.com/samber/lo"
	"github.com/sarulabs/di"
)

type SpinFactory struct {
	rand         rng.Client
	cheatPayload interface{}
}

type Info struct {
	BaseReels [][]string `json:"base_reels"`
}

func GameBoot(ctn di.Container, config *engine.Config) *engine.Bootstrap {
	switch config.RTP {
	case rtp93:
		baseReel = reels93
	case rtp95:
		baseReel = reels95
	case rtp96:
		baseReel = reels96

	default:
		panic(fmt.Sprintf("can't specify RTP: %v", config.RTP))
	}

	rand := ctn.Get(constants.RNGMockName).(rng.Client)
	factory := NewSpinFactory(rand)

	return &engine.Bootstrap{
		SpinFactory: factory,

		HTTPTransport:      true,
		WebsocketTransport: true,

		NeedLastSpin:        false,
		FreeSpinsFeature:    true,
		GambleAnyWinFeature: true,

		GambleAnyWinMaxTimes: 4,
		GambleAnyWinMaxWager: 125 * 1000 * 1000,
		GameMaxWager:         50 * 1000, // 50 $

		HistoryHandlingType: engine.SequentialRestoring,

		EngineInfo: Info{BaseReels: baseReel},
	}
}

func NewSpinFactory(rand rng.Client) *SpinFactory {
	factory := &SpinFactory{rand: rand}

	return factory
}

func (s SpinFactory) Generate(wager int64, parameters interface{}) (engine.Spin, engine.RestoringIndexes, error) {
	stops, err := s.getStops(baseReel)
	if err != nil {
		return nil, nil, err
	}

	window, payLinesToShow, award := s.compute(stops, wager)

	return &SpinBase{
		Window:         window,
		PayLinesToShow: payLinesToShow,
		Win:            award,
		WagerVal:       wager,
		Stops:          stops,
	}, &RestoringIndexes{}, nil
}

func (s SpinFactory) GambleAnyWin(spin engine.Spin, parameters interface{}) (engine.Spin, error) {
	if spin.Award() == 0 {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin, ok := spin.(*SpinBase)
	if !ok {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin = typedSpin.DeepCopy()

	payload, err := parseGambleParams(parameters)

	if payload.Color != GambleRed && payload.Color != GambleBlack {
		return nil, errs.ErrBadDataGiven
	}

	if err != nil {
		return nil, err
	}

	res, err := s.rand.Rand(2)
	if err != nil {
		return nil, err
	}

	award := typedSpin.Award() + typedSpin.BonusAward()
	g := Gamble{ExpectColor: payload.Color, WagerVal: award}

	c := Cheats{}
	if s.cheatPayload != nil {
		if err := c.Eval(s.cheatPayload); err != nil {
			return nil, err
		}
	}

	if c.GambleColor == GambleRed || c.GambleColor == GambleBlack {
		g.RealColor = c.GambleColor
	} else if res == 1 {
		g.RealColor = GambleRed
	} else {
		g.RealColor = GambleBlack
	}

	g.compute()

	typedSpin.Gambles = append(typedSpin.Gambles, g)

	return typedSpin, nil
}

func (s SpinFactory) WithBoundLastSpin(spin engine.Spin) engine.SpinFactory {
	return &s
}

func (s SpinFactory) WithCheat(cheat interface{}) engine.SpinFactory {
	s.cheatPayload = cheat

	return &s
}

func (s SpinFactory) UnmarshalJSONSpin(bytes []byte) (engine.Spin, error) {
	spin := SpinBase{}
	err := json.Unmarshal(bytes, &spin)

	return &spin, err
}

func (s SpinFactory) UnmarshalJSONRestoringIndexes(bytes []byte) (engine.RestoringIndexes, error) {
	restoringIndexes := RestoringIndexes{}
	err := json.Unmarshal(bytes, &restoringIndexes)

	return &restoringIndexes, err
}

func (s *SpinFactory) getStops(reels [][]string) ([]int, error) {
	if s.cheatPayload != nil {
		c := Cheats{}
		if err := c.Eval(s.cheatPayload); err != nil {
			return nil, err
		}

		if len(c.Stops) != len(reels) {
			return nil, errs.ErrBadDataGiven
		}

		for i := range c.Stops {
			if c.Stops[i] > len(reels[i]) {
				return nil, errs.ErrBadDataGiven
			}
		}

		return c.Stops, nil
	}

	req := lo.Map(reels, func(item []string, index int) uint64 {
		return uint64(len(item))
	})

	res, err := s.rand.RandSlice(req)
	if err != nil {
		return nil, err
	}

	return lo.Map(res, func(item uint64, index int) int {
		return int(item)
	}), nil
}

func (s *SpinFactory) compute(stops []int, wager int64) (window Window, payLinesToShow []PayLine, award int64) {
	window.compute(baseReel, stops)

	award, payLinesToShow = s.computeBasicWindow(wager, window)

	//scatterPayLine, ok := s.computeScatter(wager, window)
	//if ok {
	//	payLinesToShow = append(payLinesToShow, scatterPayLine)
	//	award += scatterPayLine.Award
	//}

	return window, payLinesToShow, award
}

func (s *SpinFactory) computeBasicWindow(wager int64, window Window) (award int64, payLinesToShow []PayLine) {
	for payLineIndex, payLine := range payLines {
		symbol := ""
		lineCounter := 0
		payLineIndexes := []int{}

		for _, payIndex := range payLine {
			if symbol == "" {
				if window.symbol(payIndex) == ScatterSymbol {
					break
				}

				if window.symbol(payIndex) == WildSymbol {
					lineCounter++

					payLineIndexes = append(payLineIndexes, payIndex)

					continue
				}

				symbol = window.symbol(payIndex)
				payLineIndexes = append(payLineIndexes, payIndex)

				lineCounter++
			} else {
				if window.symbol(payIndex) == WildSymbol {
					payLineIndexes = append(payLineIndexes, payIndex)

					lineCounter++
				} else if symbol == window.symbol(payIndex) {
					payLineIndexes = append(payLineIndexes, payIndex)

					lineCounter++
				} else {
					break
				}
			}
		}

		if symbol == "" {
			symbol = WildSymbol
		}

		if addAward := awardBySymbolAndCount(symbol, lineCounter, wager); addAward > 0 {
			award += addAward
			payLinesToShow = append(payLinesToShow, PayLine{Indexes: payLineIndexes, Award: addAward, Symbol: symbol, PayLineIndex: payLineIndex})
		}
	}

	if isFullLowSymbolWindow(window) {
		payLinesToShow = lo.Map(payLinesToShow, func(item PayLine, index int) PayLine {
			item.Award *= AllPayLinesLowSymbolMul

			return item
		})

		award *= AllPayLinesLowSymbolMul
	}

	return award, payLinesToShow
}

func isFullLowSymbolWindow(w Window) bool {
	s := w[0][0]

	if !lo.Contains(lowSymbols, s) {
		return false
	}

	for _, reel := range w {
		for _, symbol := range reel {
			if s != symbol {
				return false
			}
		}
	}

	return true
}
