package engine

import "github.com/samber/lo"

const (
	rtp93 = "93"
	rtp95 = "95"
	rtp96 = "96"

	windowHeight          = 3
	windowWidth           = 3
	multiplicationDivider = 10
	ScatterSymbol         = "s"
	WildSymbol            = "w"

	AllPayLinesLowSymbolMul = 3
)

var lowSymbols = []string{"c", "o", "g", "m"}

var multipliers = map[string]map[int]int64{
	"c":        {3: 5},
	"o":        {3: 5},
	"g":        {3: 5},
	"m":        {3: 5},
	"h":        {3: 50},
	"b":        {3: 50},
	"r":        {3: 100}, // revolver
	"p":        {3: 200}, // policeman
	WildSymbol: {3: 500},
}

var payLines = [][]int{
	{0, 1, 2},
	{0, 1, 5},
	{0, 1, 8},
	{0, 4, 2},
	{0, 4, 5},
	{0, 4, 8},
	{0, 7, 2},
	{0, 7, 5},
	{0, 7, 8},

	{3, 1, 2},
	{3, 1, 5},
	{3, 1, 8},
	{3, 4, 2},
	{3, 4, 5},
	{3, 4, 8},
	{3, 7, 2},
	{3, 7, 5},
	{3, 7, 8},

	{6, 1, 2},
	{6, 1, 5},
	{6, 1, 8},
	{6, 4, 2},
	{6, 4, 5},
	{6, 4, 8},
	{6, 7, 2},
	{6, 7, 5},
	{6, 7, 8},
}

var baseReel = [][]string{}
var bonusReel = [][]string{
	{"c", "c", "c", "c", "c", "w", "o", "o", "o", "o", "o", "r", "g", "g", "g", "g", "g", "w", "m", "m", "m", "m", "m", "s", "b", "b", "s", "h", "h", "s", "p", "r", "s"},
	{"o", "o", "o", "o", "o", "w", "m", "m", "m", "m", "m", "r", "c", "c", "c", "c", "c", "w", "g", "g", "g", "g", "g", "b", "s", "b", "b", "p", "s", "h", "h", "s", "h"},
	{"m", "m", "m", "m", "m", "w", "g", "g", "g", "g", "g", "r", "o", "o", "o", "o", "o", "w", "c", "c", "c", "c", "c", "p", "s", "r", "h", "h", "s", "b", "b", "p", "s"},
}

type Window [][]string

func (w *Window) compute(reels [][]string, stops []int) {
	*w = lo.Map(stops, func(stop int, index int) []string {
		reel := reels[index]
		reelLen := len(reel)

		windowLine := make([]string, windowHeight)
		for j := 0; j < windowHeight; j++ {
			windowLine[j] = reel[(stop+j)%reelLen]
		}

		return windowLine
	})
}

func (w Window) symbol(payIndex int) string {
	position, reel := payIndex/windowWidth, payIndex%windowWidth

	return w[reel][position]
}

func awardBySymbolAndCount(symbol string, count int, wager int64) int64 {
	mul := multipliers[symbol][count]

	return mul * wager / multiplicationDivider
}
