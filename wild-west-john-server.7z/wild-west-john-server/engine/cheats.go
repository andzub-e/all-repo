package engine

import "encoding/json"

type Cheats struct {
	Stops                  []int  `json:"stops"`
	AdditionalTriggerCount int    `json:"additional_trigger_count"`
	GambleColor            string `json:"gamble_color"`
}

func (s *Cheats) Eval(payload interface{}) error {
	b, err := json.Marshal(payload)
	if err != nil {
		return err
	}

	return json.Unmarshal(b, s)
}
