package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/utils"
	"fmt"
	"github.com/samber/lo"
	"os"
	"strings"
)

func main() {
	fmt.Println(lo.Map(utils.MustSubstituteReels(replaceMap, reel), func(item string, index int) string {
		s := `"` + item + `"`
		if index != len(reel)-1 {
			s += ", "
		}

		return s
	}))
}

var replaceMap = map[string]string{
	"CHERRY":     "c",
	"ORANGE":     "o",
	"GRAPE":      "g",
	"WATERMELON": "m", // melon
	"HORSESHOE":  "h",
	"BELL":       "b",
	"GUN":        "r", // revolver
	"SHERIFF":    "p", // policeman
	"WILD":       "w",
	"SCATTER":    "s",
}

var reel = []string{}

func init() {
	res, err := os.ReadFile("./tmp.txt")
	if err != nil {
		panic(err)
	}

	reel = strings.Split(string(res), "\n")
}
