package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/buildvar"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/services"
	"bitbucket.org/electronicjaw/base-slot-server/utils"

	"cyber-town-server/engine"
	"fmt"
	"os"
	"path/filepath"
	"time"
)

func main() {
	now := time.Now()

	application, err := app.NewApp("config.yml", buildvar.Tag, buildvar.Debug, buildvar.IsCheatsAvailable, engine.Bootstrap)
	if err != nil {
		panic(err)
	}

	simulator := application.GetSimulatorService()

	result, err := simulator.WithProgressListener(func(percent float64) {
		fmt.Printf("Processing: %2.0f%%\n", percent*100)
	}).
		WithWagerParameters(nil).
		Simulate("cyber-town", 1000*1000, 1000)

	reportPages := []utils.Page{
		{
			Name:  "Report",
			Table: utils.Transpose(utils.ExtractTable([]*services.SimulationView{result.View()}, "xlsx")),
		}}

	saveReport(reportPages)

	fmt.Printf("The program ran for %s\n", time.Since(now))
}

func saveReport(reportPages []utils.Page) {
	excel, err := utils.ExportMultiPageXLSX(reportPages)
	if err != nil {
		fmt.Printf("simulate: %v\n", err)
	}

	abs, err := filepath.Abs("simresults")
	if err != nil {
		panic(err)
	}

	file, err := os.Create(filepath.Join(abs, fmt.Sprintf("report-%v.xlsx", time.Now().UnixNano())))
	if err != nil {
		fmt.Printf("simulate: %v\n", err)
	}

	if err = excel.Write(file); err != nil {
		fmt.Printf("simulate: %v\n", err)
	}
}
