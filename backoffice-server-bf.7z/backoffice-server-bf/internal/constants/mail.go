package constants

import "text/template"

const (
	MailNotifyUserSubject     = "Backoffice account"
	MailNotifyUserTemplateRaw = `Welcome to: {{.FrontURL}}
Your login: {{.Login}}
Your password: {{.Password}}`
)

var MailNotifyUserTemplate *template.Template

type MailNotifyUserContent struct {
	FrontURL, Login, Password string
}

func init() {
	var err error
	MailNotifyUserTemplate, err = template.New("simulation-txt").Parse(MailNotifyUserTemplateRaw)

	if err != nil {
		panic(err)
	}
}
