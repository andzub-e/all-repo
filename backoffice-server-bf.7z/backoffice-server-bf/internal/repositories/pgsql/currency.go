package pgsql

import (
	"backoffice/internal/entities"
	"context"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type currencyRepository struct {
	conn *gorm.DB
}

func NewCurrencyRepository(conn *gorm.DB) *currencyRepository {
	return &currencyRepository{conn: conn}
}

func (r *currencyRepository) UpdateCurrencyConfig(ctx context.Context, cc *entities.CurrencyConfig) error {
	return r.conn.WithContext(ctx).Updates(cc).Error
}

func (r *currencyRepository) GetConfigByProvider(ctx context.Context, id uuid.UUID) ([]*entities.CurrencyConfig, error) {
	configs := make([]*entities.CurrencyConfig, 0)

	return configs, r.conn.WithContext(ctx).
		Model(&entities.CurrencyConfig{}).
		Where("provider_id = ?", id).
		Joins("ProviderIntegratorPair").
		Preload("ProviderIntegratorPair.Provider").
		Preload("ProviderIntegratorPair.Integrator").
		Preload("MultipliersRaw").
		Find(&configs).
		Error
}

func (r *currencyRepository) All(ctx context.Context) ([]*entities.CurrencyConfig, error) {
	configs := make([]*entities.CurrencyConfig, 0)

	return configs, r.conn.WithContext(ctx).
		Model(&entities.CurrencyConfig{}).
		Joins("ProviderIntegratorPair").
		Preload("ProviderIntegratorPair.Provider").
		Preload("ProviderIntegratorPair.Integrator").
		Preload("MultipliersRaw").
		Find(&configs).Error
}

func (r *currencyRepository) CreateCurrencyMultiplier(ctx context.Context, cm *entities.CurrencyMultiplier) (*entities.CurrencyMultiplier, error) {
	return cm, r.conn.WithContext(ctx).Create(cm).Error
}

func (r *currencyRepository) UpdateCurrencyMultiplier(ctx context.Context, cm *entities.CurrencyMultiplier) (*entities.CurrencyMultiplier, error) {
	return cm, r.conn.WithContext(ctx).
		Where("organization_pair_id = ? and title = ?", cm.OrganizationPairID, cm.Title).
		Updates(cm).Error
}

func (r *currencyRepository) DeleteCurrencyMultiplier(ctx context.Context, organizationPairID uuid.UUID, title string) error {
	return r.conn.WithContext(ctx).
		Where("organization_pair_id = ? and title = ?", organizationPairID, title).
		Error
}
