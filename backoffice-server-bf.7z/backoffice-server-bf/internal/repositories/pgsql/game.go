package pgsql

import (
	"backoffice/internal/entities"
	"context"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type gameRepository struct {
	conn *gorm.DB
}

func NewGameRepository(conn *gorm.DB) *gameRepository {
	return &gameRepository{conn: conn}
}

func (r *gameRepository) GetBy(ctx context.Context, condition map[string]interface{}) (*entities.Game, error) {
	g := &entities.Game{}
	err := r.conn.WithContext(ctx).Preload("Organization").Where(condition).First(&g).Error

	return g, err
}

func (r *gameRepository) All(ctx context.Context, organizationID *uuid.UUID, condition map[string]interface{}) (games []*entities.Game, err error) {
	conn := r.conn.WithContext(ctx)
	conn = r.withOwner(conn, organizationID)

	if err = conn.Where(condition).Find(&games).Error; err != nil {
		return nil, err
	}

	return games, nil
}

func (r *gameRepository) GetOrganizationGameList(ctx context.Context, organizationID uuid.UUID) (games []*entities.Game, err error) {
	err = r.conn.WithContext(ctx).
		Select("distinct (games.id) as _, games.*").
		Joins(`inner join integrator_providers as ip 
						on games.organization_id = ip.provider_id`).
		Where("ip.integrator_id = ? or ip.provider_id = ?", organizationID, organizationID).
		Find(&games).
		Error

	return
}

func (r *gameRepository) withOwner(conn *gorm.DB, organizationID *uuid.UUID) *gorm.DB {
	conn = conn.Joins("Organization")

	if organizationID != nil {
		conn = conn.Where("organization_id = ?", organizationID)
	}

	return conn
}
