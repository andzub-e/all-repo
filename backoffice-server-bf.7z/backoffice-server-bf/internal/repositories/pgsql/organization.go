package pgsql

import (
	"backoffice/internal/entities"
	e "backoffice/internal/errors"
	"context"
	"errors"
	"github.com/google/uuid"
	"go.uber.org/zap"
	"gorm.io/gorm"
)

type organizationRepository struct {
	conn *gorm.DB
}

func NewOrganizationRepository(conn *gorm.DB) *organizationRepository {
	return &organizationRepository{
		conn: conn,
	}
}

func (r *organizationRepository) All(ctx context.Context) (organizations []*entities.Organization, err error) {
	err = r.conn.WithContext(ctx).Find(&organizations).Error

	return
}

func (r *organizationRepository) GetIntegratorsByProvider(ctx context.Context, providerID uuid.UUID) (organizations []*entities.Organization, err error) {
	err = r.conn.WithContext(ctx).
		Joins("join integrator_providers on integrator_providers.integrator_id = organizations.id").
		Where("integrator_providers.provider_id = ?", providerID).
		Find(&organizations).Error

	return
}

func (r *organizationRepository) Create(ctx context.Context, organization *entities.Organization) (*entities.Organization, error) {
	if err := r.conn.WithContext(ctx).Where("name = ?", organization.Name).First(&entities.Organization{}).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			if err = r.conn.WithContext(ctx).Create(&organization).Error; err != nil {
				return nil, err
			}

			return organization, nil
		}

		return nil, err
	}

	return nil, e.ErrOrganizationNameMustBeUnique
}

func (r *organizationRepository) Delete(ctx context.Context, organization *entities.Organization) error {
	err := r.conn.WithContext(ctx).Where("organization_id = ?", organization.ID).First(&entities.AccountOrganization{}).Error
	if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
		return err
	}

	if err == nil {
		return e.ErrOrganizationInUse
	}

	return r.conn.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := r.conn.WithContext(ctx).Where("organization_id = ?", organization.ID).Delete(&entities.Role{}).Error; err != nil {
			return err
		}

		if err := r.conn.WithContext(ctx).Where("id = ?", organization.ID).Delete(&organization).Error; err != nil {
			return err
		}

		return nil
	})
}

func (r *organizationRepository) FindBy(ctx context.Context, params map[string]interface{}) (organization *entities.Organization, err error) {
	if err = r.conn.WithContext(ctx).Where(params).First(&organization).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, e.ErrOrganizationNotFound
		}

		return
	}

	return
}

func (r *organizationRepository) Paginate(ctx context.Context, filters map[string]interface{}, order string, limit int, offset int) (organization []*entities.Organization, total int64, err error) {
	query := r.conn.WithContext(ctx).Model(&entities.Organization{}).Where(filters)

	if err = query.Count(&total).Error; err != nil {
		return
	}

	if err = query.Order(order).Limit(limit).Offset(offset).Find(&organization).Error; err != nil {
		return
	}
	return
}

func (r *organizationRepository) Assign(ctx context.Context, account *entities.Account, organization *entities.Organization) error {
	var ao *entities.AccountOrganization

	err := r.conn.WithContext(ctx).Where("account_id = ? and organization_id = ?", account.ID, organization.ID).First(&ao).Error
	if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
		return err
	}

	if err == nil {
		return e.ErrOrganizationAlreadyAssigned
	}

	return r.conn.WithContext(ctx).Create(&entities.AccountOrganization{AccountID: account.ID, OrganizationID: organization.ID}).Error
}

func (r *organizationRepository) Revoke(ctx context.Context, account *entities.Account, organization *entities.Organization) error {
	return r.conn.WithContext(ctx).Where("account_id = ? and organization_id = ?", account.ID, organization.ID).Delete(&entities.AccountOrganization{}).Error
}

func (r *organizationRepository) GetByAccount(ctx context.Context, account *entities.Account) ([]*entities.Organization, error) {
	var organizations []*entities.Organization

	if err := r.conn.WithContext(ctx).
		Joins("join account_organizations on account_organizations.organization_id = organizations.id and account_organizations.account_id = ?", account.ID).
		Find(&organizations).Error; err != nil {
		return nil, err
	}

	return organizations, nil
}

func (r *organizationRepository) IntegratorGameExists(ctx context.Context, organization *entities.Organization, game *entities.Game) bool {
	var ig *entities.IntegratorGame

	err := r.conn.WithContext(ctx).Where("organization_id = ? and game_id = ?", organization.ID, game.ID).Find(&ig).Error
	if err != nil {
		zap.S().Error(err)

		return false
	}

	return ig != nil
}

func (r *organizationRepository) GetOrganizationPair(ctx context.Context, providerID, integratorID uuid.UUID) (
	pair *entities.ProviderIntegratorPair, err error) {
	err = r.conn.WithContext(ctx).
		Where("provider_id = ? and integrator_id = ?", providerID, integratorID).
		First(pair).Error

	return
}
