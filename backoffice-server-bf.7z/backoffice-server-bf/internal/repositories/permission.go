package repositories

import (
	"backoffice/internal/entities"
	"context"
)

type PermissionRepository interface {
	FindBy(ctx context.Context, params map[string]interface{}) (permission *entities.Permission, err error)
	All(ctx context.Context) (permissions []*entities.Permission, err error)
	GetAccountPermissions(ctx context.Context, account *entities.Account) ([]*entities.Permission, error)
	Paginate(ctx context.Context, filters map[string]interface{}, order string, limit int, offset int) (permissions []*entities.Permission, total int64, err error)
	RevokeAccountPermissions(ctx context.Context, account *entities.Account, permissions ...*entities.Permission) error
	RevokeRolePermissions(ctx context.Context, role *entities.Role, permissions ...*entities.Permission) error
	AssignAccountPermissions(ctx context.Context, account *entities.Account, permissions []*entities.Permission) error
	AssignRolePermissions(ctx context.Context, role *entities.Role, permissions []*entities.Permission) error
}
