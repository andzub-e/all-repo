package repositories

import (
	"backoffice/internal/entities"
	"context"
	"github.com/google/uuid"
)

type GameRepository interface {
	GetBy(ctx context.Context, condition map[string]interface{}) (*entities.Game, error)
	All(ctx context.Context, organizationID *uuid.UUID, condition map[string]interface{}) (games []*entities.Game, err error)
	GetOrganizationGameList(ctx context.Context, organizationID uuid.UUID) ([]*entities.Game, error)
}
