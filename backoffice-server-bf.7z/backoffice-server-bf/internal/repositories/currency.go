package repositories

import (
	"backoffice/internal/entities"
	"context"
	"github.com/google/uuid"
)

type CurrencyRepository interface {
	CreateCurrencyMultiplier(ctx context.Context, cm *entities.CurrencyMultiplier) (*entities.CurrencyMultiplier, error)
	UpdateCurrencyMultiplier(ctx context.Context, cm *entities.CurrencyMultiplier) (*entities.CurrencyMultiplier, error)
	DeleteCurrencyMultiplier(ctx context.Context, organizationPairID uuid.UUID, title string) error

	GetConfigByProvider(ctx context.Context, id uuid.UUID) ([]*entities.CurrencyConfig, error)
	All(ctx context.Context) ([]*entities.CurrencyConfig, error)
	UpdateCurrencyConfig(ctx context.Context, cc *entities.CurrencyConfig) error
}
