package handlers

import (
	"backoffice/internal/entities"
	"backoffice/internal/services"
	"backoffice/internal/transport/http/requests"
	"backoffice/internal/transport/http/response"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type currencySetHandler struct {
	currencySetService *services.CurrencySetService
}

func NewCurrencySetHandler(currencySetService *services.CurrencySetService) *currencySetHandler {
	return &currencySetHandler{
		currencySetService: currencySetService,
	}
}

func (h *currencySetHandler) Register(router *gin.RouterGroup) {
	currencySets := router.Group("currency_set")

	currencySets.GET("", h.all)
	currencySets.POST("", h.create)

	currencySet := currencySets.Group(":id")
	{
		currencySet.GET("", h.get)
		currencySet.POST("", h.update)
		currencySet.DELETE("", h.delete)
	}
}

// @Summary Get currency sets.
// @Tags currency_set
// @Consume application/json
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param   limit query int true "rows limit"
// @Param   offset query int true "rows offset"
// @Success 200  {object} response.Response{}
// @Router /currency_set [get].
func (h *currencySetHandler) all(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)

	req := &requests.PaginateCurrencySetRequest{}
	if err := ctx.ShouldBindQuery(&req); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	paginate, err := h.currencySetService.Paginate(ctx, session.OrganizationID, map[string]interface{}{}, req.Limit, req.Page)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, paginate, nil)
}

// @Summary Create currency set.
// @Tags currency_set
// @Consume application/json
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param  data body requests.CreateCurrencySetRequest true  "requests.CreateCurrencySetRequest"
// @Success 200  {object} response.Response{data=entities.CurrencySet}
// @Router /currency_set [post].
func (h *currencySetHandler) create(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)

	req := &requests.CreateCurrencySetRequest{}
	if err := ctx.ShouldBind(&req); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	ws, err := h.currencySetService.Create(ctx, session.OrganizationID, req.Name, req.Currencies)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, ws, nil)
}

// @Summary Update currency set.
// @Tags currency_set
// @Consume application/json
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param  data body requests.UpdateCurrencySetRequest true  "requests.UpdateCurrencySetRequest"
// @Success 200  {object} response.Response{data=entities.CurrencySet}
// @Router /currency_set/{id} [post].
func (h *currencySetHandler) update(ctx *gin.Context) {
	req := &requests.UpdateCurrencySetRequest{}
	if err := ctx.ShouldBind(&req); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	wsID, err := uuid.Parse(ctx.Param("id"))
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	ws, err := h.currencySetService.Update(ctx, wsID, req.Name, req.Currencies, *req.IsActive)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, ws, nil)
}

// @Summary Get currency set.
// @Tags currency_set
// @Consume application/json
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200  {object} response.Response{data=entities.CurrencySet}
// @Router /currency_set/{id} [get].
func (h *currencySetHandler) get(ctx *gin.Context) {
	wsID, err := uuid.Parse(ctx.Param("id"))
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	ws, err := h.currencySetService.Get(ctx, wsID)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, ws, nil)
}

// @Summary Delete currency set.
// @Tags currency_set
// @Consume application/json
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200  {object} response.Response{data=bool}
// @Router /currency_set/{id} [delete].
func (h *currencySetHandler) delete(ctx *gin.Context) {
	wsID, err := uuid.Parse(ctx.Param("id"))
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	if err := h.currencySetService.Delete(ctx, wsID); err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, true, nil)
}
