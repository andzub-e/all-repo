package handlers

import (
	"backoffice/internal/services"
	"backoffice/internal/transport/http/requests"
	"backoffice/internal/transport/http/response"
	"github.com/gin-gonic/gin"
)

type permissionHandler struct {
	authorizationService *services.AuthorizationService
}

func NewPermissionHandler(authorizationService *services.AuthorizationService) *permissionHandler {
	return &permissionHandler{
		authorizationService: authorizationService,
	}
}

func (h *permissionHandler) Register(route *gin.RouterGroup) {
	permissions := route.Group("permissions")
	{
		permissions.GET("", h.all)
	}
}

// @Summary Get permissions list.
// @Tags accounts
// @Consume application/json
// @Description Dashboard.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your refresh token"
// @Param   limit query int true "rows limit"
// @Param   offset query int true "rows offset"
// @Param   order query string false "order field"
// @Success 200  {object} response.Response{data=[]entities.Permission}
// @Router /permissions [get].
func (h *permissionHandler) all(ctx *gin.Context) {
	req := &requests.Pagination{}
	if err := ctx.ShouldBindQuery(&req); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	permissions, total, err := h.authorizationService.PaginatePermissions(ctx, req.Filters, req.Order, req.Limit, req.Offset)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	req.Total = total

	response.OK(ctx, permissions, req)
}
