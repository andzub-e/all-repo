package handlers

import (
	"backoffice/internal/entities"
	e "backoffice/internal/errors"
	"backoffice/internal/services"
	"backoffice/internal/transport/http/requests"
	"backoffice/internal/transport/http/response"
	"errors"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
)

type organizationHandler struct {
	organizationService *services.OrganizationService
}

func NewOrganizationHandler(organizationService *services.OrganizationService) *organizationHandler {
	return &organizationHandler{
		organizationService: organizationService,
	}
}

func (h *organizationHandler) Register(route *gin.RouterGroup) {
	organizations := route.Group("organizations")
	{
		organizations.GET("", h.all)
		organizations.POST("", h.create)

		organization := organizations.Group(":id")
		{
			organization.DELETE("", h.delete)
		}
	}
}

// @Summary Get organizations list.
// @Tags organizations
// @Consume application/json
// @Description Available backoffice roles.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your refresh token"
// @Param   limit query int true "rows limit"
// @Param   offset query int true "rows offset"
// @Param   order query string false "order field"
// @Success 200  {object} response.Response{data=[]entities.Organization}
// @Router /organizations [get].
func (h *organizationHandler) all(ctx *gin.Context) {
	req := &requests.Pagination{}
	if err := ctx.ShouldBindQuery(&req); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	organizations, total, err := h.organizationService.Paginate(ctx, req.Filters, req.Order, req.Limit, req.Offset)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	req.Total = total

	response.OK(ctx, organizations, req)
}

// @Summary Add new organization.
// @Tags organizations
// @Consume application/json
// @Description Create organization.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your refresh token"
// @Param   data body   requests.CreateOrganizationRequest true  "CreateOrganizationRequest"
// @Success 200  {object} response.Response{data=entities.Organization}
// @Router /organizations [post].
func (h *organizationHandler) create(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)
	req := &requests.CreateOrganizationRequest{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	organization, err := h.organizationService.Create(ctx, req.Name, req.Type)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	if _, err = h.organizationService.Assign(ctx, session.Account.ID, organization.ID); err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, organization, nil)
}

// @Summary Delete organization.
// @Tags organizations
// @Consume application/json
// @Description Delete existing organization.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your refresh token"
// @Param   id path   string true  "organization_id"
// @Success 200  {object} response.Response
// @Router /organizations/{id} [delete].
func (h *organizationHandler) delete(ctx *gin.Context) {
	if err := h.organizationService.Delete(ctx, ctx.Param("id")); err != nil {
		if errors.Is(err, e.ErrRoleNotFound) {
			response.NotFound(ctx, err, nil)

			return
		}

		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, "Success", nil)
}
