package handlers

import (
	"backoffice/internal/entities"
	"backoffice/internal/services"
	"backoffice/internal/transport/http/requests"
	"backoffice/internal/transport/http/response"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type wagerSetHandler struct {
	wagerSetService *services.WagerSetService
}

func NewWagerSetHandler(wagerSetService *services.WagerSetService) *wagerSetHandler {
	return &wagerSetHandler{wagerSetService: wagerSetService}
}

func (h *wagerSetHandler) Register(router *gin.RouterGroup) {
	wagerSets := router.Group("wager_set")

	wagerSets.GET("", h.all)
	wagerSets.POST("", h.create)

	wagerSet := wagerSets.Group(":id")
	{
		wagerSet.GET("", h.get)
		wagerSet.POST("", h.update)
		wagerSet.DELETE("", h.delete)
	}
}

// @Summary Get wager sets.
// @Tags wager_set
// @Consume application/json
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param   limit query int true "rows limit"
// @Param   offset query int true "rows offset"
// @Success 200  {object} response.Response{}
// @Router /wager_set [get].
func (h *wagerSetHandler) all(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)

	req := &requests.PaginateWagerSetRequest{}
	if err := ctx.ShouldBindQuery(&req); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	paginate, err := h.wagerSetService.Paginate(ctx, session.OrganizationID, map[string]interface{}{}, req.Limit, req.Page)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, paginate, nil)
}

// @Summary Create wager set.
// @Tags wager_set
// @Consume application/json
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param  data body requests.CreateWagerSetRequest true  "requests.CreateWagerSetRequest"
// @Success 200  {object} response.Response{data=entities.WagerSet}
// @Router /wager_set [post].
func (h *wagerSetHandler) create(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)

	req := &requests.CreateWagerSetRequest{}
	if err := ctx.ShouldBind(&req); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	ws, err := h.wagerSetService.Create(ctx, session.OrganizationID, req.Name, req.WagerLevels, req.DefaultWager)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, ws, nil)
}

// @Summary Update wager set.
// @Tags wager_set
// @Consume application/json
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param  data body requests.UpdateWagerSetRequest true  "requests.UpdateWagerSetRequest"
// @Success 200  {object} response.Response{data=entities.WagerSet}
// @Router /wager_set/{id} [post].
func (h *wagerSetHandler) update(ctx *gin.Context) {
	req := &requests.UpdateWagerSetRequest{}
	if err := ctx.ShouldBind(&req); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	wsID, err := uuid.Parse(ctx.Param("id"))
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	ws, err := h.wagerSetService.Update(ctx, wsID, req.Name, req.WagerLevels, req.DefaultWager, *req.IsActive)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, ws, nil)
}

// @Summary Get wager set.
// @Tags wager_set
// @Consume application/json
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200  {object} response.Response{data=entities.WagerSet}
// @Router /wager_set/{id} [get].
func (h *wagerSetHandler) get(ctx *gin.Context) {
	wsID, err := uuid.Parse(ctx.Param("id"))
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	ws, err := h.wagerSetService.Get(ctx, wsID)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, ws, nil)
}

// @Summary Delete wager set.
// @Tags wager_set
// @Consume application/json
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200  {object} response.Response{data=bool}
// @Router /wager_set/{id} [delete].
func (h *wagerSetHandler) delete(ctx *gin.Context) {
	wsID, err := uuid.Parse(ctx.Param("id"))
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	if err := h.wagerSetService.Delete(ctx, wsID); err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, true, nil)
}
