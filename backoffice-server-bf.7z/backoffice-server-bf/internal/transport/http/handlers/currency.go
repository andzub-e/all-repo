package handlers

import (
	"backoffice/internal/services"
	"backoffice/internal/transport/http/middlewares"
	"backoffice/internal/transport/http/requests"
	"backoffice/internal/transport/http/response"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"github.com/google/uuid"
)

type currencyHandler struct {
	currencyService *services.CurrencyService
}

func (h *currencyHandler) Register(router *gin.RouterGroup) {
	currency := router.Group("currency")

	currency.POST("multiplier", h.create)
	currency.PUT("multiplier", middlewares.TOTP(true), h.update)
	currency.DELETE("multiplier", h.delete)

	currency.GET("config/:provider_id", h.getByProviderID)
	currency.PUT("config", h.updateCurrencyConfig)
}

func NewCurrencyHandler(currencyService *services.CurrencyService) *currencyHandler {
	return &currencyHandler{currencyService: currencyService}
}

// @Summary Create new currency for specific provider and integrator.
// @Tags currency
// @Consume application/json
// @Description Create new currency and bound multiplier by provider_id and integrator_id.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param   provider_id body string true "provider_id"
// @Param   integrator_id body string true "integrator_id"
// @Param   title body string true "currency title"
// @Param   multiplier body int true "currency multiplier"
// @Success 200  {object} response.Response{data=entities.CurrencyMultiplier}
// @Router /currency/multiplier [post].
func (h *currencyHandler) create(ctx *gin.Context) {
	req := requests.CurrencyMultiplier{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	cm, err := h.currencyService.CreateCurrencyMultiplier(ctx, req.ProviderID, req.IntegratorID, req.Title, req.Multiplier)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, cm, nil)
}

// @Summary Updates currency for specific provider and integrator.
// @Tags currency
// @Consume application/json
// @Description Updates currency and bound multiplier by provider_id and integrator_id.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param   provider_id body string true "provider_id"
// @Param   integrator_id body string true "integrator_id"
// @Param   title body string true "currency title"
// @Param   multiplier body int true "currency multiplier"
// @Success 200  {object} response.Response{data=entities.CurrencyMultiplier}
// @Router /currency/multiplier [put].
func (h *currencyHandler) update(ctx *gin.Context) {
	req := requests.CurrencyMultiplier{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	cm, err := h.currencyService.UpdateCurrencyMultiplier(ctx, req.ProviderID, req.IntegratorID, req.Title, req.Multiplier)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, cm, nil)
}

// @Summary Delete currency for specific provider and integrator.
// @Tags currency
// @Consume application/json
// @Description Delete currency and bound multiplier by provider_id and integrator_id.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param   provider_id body string true "provider_id"
// @Param   integrator_id body string true "integrator_id"
// @Param   title body string true "currency title"
// @Success 200  {object} response.Response{data=string}
// @Router /currency/multiplier [delete].
func (h *currencyHandler) delete(ctx *gin.Context) {
	req := requests.CurrencyMultiplierIdentify{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	err := h.currencyService.DeleteCurrencyMultiplier(ctx, req.ProviderID, req.IntegratorID, req.Title)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, "Success", nil)
}

// @Summary Get all currency configs.
// @Tags currency
// @Consume application/json
// @Description  Get all integrator currency configs for specific provider.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200  {object} response.Response{data=[]entities.CurrencyConfig}
// @Router /currency/config/{provider_id} [get].
func (h *currencyHandler) getByProviderID(ctx *gin.Context) {
	providerID, err := uuid.Parse(ctx.Param("provider_id"))
	if err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	configs, err := h.currencyService.GetConfigByProvider(ctx, providerID)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, configs, nil)
}

// @Summary Update currency config.
// @Tags currency
// @Consume application/json
// @Description Update currency config.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Param   provider_id body string true "provider_id"
// @Param   integrator_id body string true "integrator_id"
// @Param   default_wager body int true "default_wager"
// @Param   wager_levels body []int true "wager_levels"
// @Success 200  {object} response.Response{data=string}
// @Router  /currency/config [put].
func (h *currencyHandler) updateCurrencyConfig(ctx *gin.Context) {
	req := requests.CurrencyConfig{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	err := h.currencyService.UpdateCurrencyConfig(ctx, req.ProviderID, req.IntegratorID, req.DefaultWager, req.WagerLevels)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, "Success", nil)
}
