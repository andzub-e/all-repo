package handlers

import (
	"backoffice/internal/entities"
	"backoffice/internal/services"
	"backoffice/internal/transport/http/response"
	"github.com/gin-gonic/gin"
)

type dictionaryHandler struct {
	gameService         *services.GameService
	spinService         *services.SpinService
	currencyService     *services.CurrencyService
	organizationService *services.OrganizationService
}

func NewDictionaryHandler(
	gameService *services.GameService, spinService *services.SpinService,
	currencyService *services.CurrencyService, organizationService *services.OrganizationService) *dictionaryHandler {
	return &dictionaryHandler{
		gameService:         gameService,
		spinService:         spinService,
		currencyService:     currencyService,
		organizationService: organizationService,
	}
}

func (h *dictionaryHandler) Register(route *gin.RouterGroup) {
	dictionary := route.Group("dictionaries")
	dictionary.GET("games", h.games)
	dictionary.GET("hosts", h.hosts)
	dictionary.GET("currencies", h.currencies)
	dictionary.GET("integrators", h.integrators)
	dictionary.GET("integrator-operators", h.integratorOperators)
	dictionary.GET("main-currencies", h.mainCurrencies)
}

// @Summary Get available games.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of available games for filters.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200  {object} response.Response{data=[]entities.Game}
// @Router /dictionaries/games [get].
func (h *dictionaryHandler) games(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)
	games, err := h.gameService.AllForStat(ctx, &session.OrganizationID)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, games, nil)
}

// @Summary Get available hosts.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of available hosts for filters.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200  {object} response.Response{data=[]string}
// @Router /dictionaries/hosts [get].
func (h *dictionaryHandler) hosts(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)
	games, err := h.spinService.Hosts(ctx, &session.OrganizationID)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, games, nil)
}

// @Summary Get available currencies.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of available currencies.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200  {object} response.Response{data=[]string}
// @Router /dictionaries/currencies [get].
func (h *dictionaryHandler) currencies(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)

	currencies, err := h.currencyService.MergeCurrenciesByProvider(ctx, session.OrganizationID)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, currencies, nil)
}

// @Summary Get available integrators.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of available integrators.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200  {object} response.Response{data=[]string}
// @Router /dictionaries/integrators [get].
func (h *dictionaryHandler) integrators(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)

	integrators, err := h.organizationService.GetIntegratorNames(ctx, session.OrganizationID)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, integrators, nil)
}

// @Summary Get available integrator/operator pair.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of available integrator/operator pair.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200  {object} response.Response{data=map[string][]string}
// @Router /dictionaries/integrator-operators [get].
func (h *dictionaryHandler) integratorOperators(ctx *gin.Context) {
	session := ctx.Value("session").(*entities.Session)

	integrators, err := h.spinService.IntegratorOperatorsMap(ctx, &session.OrganizationID)
	if err != nil {
		response.BadRequest(ctx, err, nil)

		return
	}

	response.OK(ctx, integrators, nil)
}

// @Summary Get main currencies.
// @Tags dictionaries
// @Consume application/json
// @Description Get list of main currencies.
// @Accept  json
// @Produce  json
// @Security X-Authenticate
// @Param X-Auth header string true "Insert your access token"
// @Success 200  {object} response.Response{data=[]string}
// @Router /dictionaries/main-currencies [get].
func (h *dictionaryHandler) mainCurrencies(ctx *gin.Context) {
	response.OK(ctx, []string{"usd", "eur"}, nil)
}
