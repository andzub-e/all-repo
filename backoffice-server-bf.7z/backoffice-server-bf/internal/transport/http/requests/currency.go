package requests

import "github.com/google/uuid"

type CurrencyMultiplierIdentify struct {
	ProviderID   uuid.UUID `json:"provider_id" form:"provider_id"`
	IntegratorID uuid.UUID `json:"integrator_id" form:"integrator_id"`
	Title        string    `json:"title" form:"title" validate:"min=1"`
}

type CurrencyMultiplier struct {
	CurrencyMultiplierIdentify
	Multiplier int64 `json:"multiplier" form:"multiplier"`
}

type CurrencyConfig struct {
	ProviderID   uuid.UUID `json:"provider_id" form:"provider_id"`
	IntegratorID uuid.UUID `json:"integrator_id" form:"integrator_id"`
	DefaultWager int64     `json:"default_wager" form:"default_wager"`
	WagerLevels  []int64   `json:"wager_levels" form:"wager_levels"`
}
