package services

import (
	"backoffice/internal/entities"
	"backoffice/internal/repositories"
	"context"
	"github.com/google/uuid"
	"github.com/samber/lo"
	"go.uber.org/zap"
)

type GameService struct {
	gameRepo repositories.GameRepository
}

func NewGameService(gameRepo repositories.GameRepository) *GameService {
	return &GameService{gameRepo: gameRepo}
}

func (s *GameService) GetGame(ctx context.Context, id uuid.UUID) (*entities.Game, error) {
	return s.gameRepo.GetBy(ctx, map[string]interface{}{"id": id})
}

func (s *GameService) GetGameByName(ctx context.Context, name string) (*entities.Game, error) {
	return s.gameRepo.GetBy(ctx, map[string]interface{}{"name": name})
}

func (s *GameService) AllForStat(ctx context.Context, organizationID *uuid.UUID) ([]*entities.Game, error) {
	return s.gameRepo.All(ctx, organizationID, map[string]interface{}{"is_statistic_shown": true})
}

func (s *GameService) AllPublic(ctx context.Context, organizationID *uuid.UUID) ([]*entities.Game, error) {
	return s.gameRepo.All(ctx, organizationID, map[string]interface{}{"is_public": true})
}

func (s *GameService) IDs(ctx context.Context, organizationID *uuid.UUID) ([]uuid.UUID, error) {
	games, err := s.AllPublic(ctx, organizationID)
	if err != nil {
		return nil, err
	}

	var list []uuid.UUID

	for _, game := range games {
		list = append(list, game.ID)
	}

	return list, nil
}

func (s *GameService) IDsString(ctx context.Context, organizationID *uuid.UUID) ([]string, error) {
	list, err := s.IDs(ctx, organizationID)
	if err != nil {
		return nil, err
	}

	return lo.Map(list, func(item uuid.UUID, index int) string {
		return item.String()
	}), nil
}

func (s *GameService) GetIntegratorGameNames(ctx context.Context, organizationID uuid.UUID) ([]string, error) {
	games, err := s.gameRepo.GetOrganizationGameList(ctx, organizationID)
	if err != nil {
		zap.S().Error(err)

		return nil, err
	}

	list := make([]string, 0, len(games))

	for _, game := range games {
		list = append(list, game.Name)
	}

	return list, nil
}
