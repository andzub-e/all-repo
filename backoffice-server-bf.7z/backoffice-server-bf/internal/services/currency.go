package services

import (
	"backoffice/internal/entities"
	e "backoffice/internal/errors"
	"backoffice/internal/repositories"
	"context"
	"errors"
	"github.com/google/uuid"
	"github.com/ltunc/go-observer/observer"
	"github.com/samber/lo"
	"sort"
	"strings"
	"time"
)

var (
	ErrCanNotFindCurrencyConfig = errors.New("can not find currency config")
	ErrNegativeWager            = errors.New("negative wager found")
	ErrDefaultWagerOutOfList    = errors.New("default wager is out of default wager list")
)

type CurrencyService struct {
	repo                repositories.CurrencyRepository
	organizationService *OrganizationService

	UpdateSubject observer.Subject[context.Context]
}

func NewCurrencyService(repo repositories.CurrencyRepository, organizationService *OrganizationService) *CurrencyService {
	return &CurrencyService{repo: repo, organizationService: organizationService}
}

func (s *CurrencyService) All(ctx context.Context) ([]*entities.CurrencyConfig, error) {
	return s.repo.All(ctx)
}

func (s *CurrencyService) CreateCurrencyMultiplier(ctx context.Context, providerID, integratorID uuid.UUID, title string, multiplier int64) (*entities.CurrencyMultiplier, error) {
	organizationPair, err := s.organizationService.GetOrganizationPair(ctx, providerID, integratorID)
	if err != nil {
		return nil, err
	}

	res, err := s.repo.CreateCurrencyMultiplier(ctx, &entities.CurrencyMultiplier{
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),

		OrganizationPairID: organizationPair.ID,

		Title:      strings.ToLower(title),
		Multiplier: multiplier,
	})

	if err != nil {
		return nil, err
	}

	s.UpdateSubject.Fire(ctx)

	return res, nil
}

func (s *CurrencyService) UpdateCurrencyMultiplier(ctx context.Context, providerID, integratorID uuid.UUID, title string, multiplier int64) (*entities.CurrencyMultiplier, error) {
	organizationPair, err := s.organizationService.GetOrganizationPair(ctx, providerID, integratorID)
	if err != nil {
		return nil, err
	}

	res, err := s.repo.UpdateCurrencyMultiplier(ctx, &entities.CurrencyMultiplier{
		UpdatedAt: time.Now(),

		OrganizationPairID: organizationPair.ID,
		Title:              strings.ToLower(title),
		Multiplier:         multiplier,
	})

	if err != nil {
		return nil, err
	}

	s.UpdateSubject.Fire(ctx)

	return res, nil
}

func (s *CurrencyService) DeleteCurrencyMultiplier(ctx context.Context, providerID, integratorID uuid.UUID, title string) error {
	organizationPair, err := s.organizationService.GetOrganizationPair(ctx, providerID, integratorID)
	if err != nil {
		return err
	}

	if err = s.repo.DeleteCurrencyMultiplier(ctx, organizationPair.ID, title); err != nil {
		return err
	}

	s.UpdateSubject.Fire(ctx)

	return nil
}

func (s *CurrencyService) UpdateCurrencyConfig(ctx context.Context, providerID, integratorID uuid.UUID, defaultWager int64, wagerLevels []int64) error {
	_, lessThanZeroExist := lo.Find(wagerLevels, func(item int64) bool {
		return item <= 0
	})

	if lessThanZeroExist {
		return ErrNegativeWager
	}

	if !lo.Contains(wagerLevels, defaultWager) {
		return ErrDefaultWagerOutOfList
	}

	sort.SliceStable(wagerLevels, func(i, j int) bool {
		return wagerLevels[i] < wagerLevels[j]
	})

	organizationPair, err := s.organizationService.GetOrganizationPair(ctx, providerID, integratorID)
	if err != nil {
		return err
	}

	err = s.repo.UpdateCurrencyConfig(ctx, &entities.CurrencyConfig{
		OrganizationPairID: organizationPair.ID,
		DefaultWager:       defaultWager,
		WagerLevels:        wagerLevels,
	})

	if err != nil {
		return err
	}

	s.UpdateSubject.Fire(ctx)

	return nil
}

func (s *CurrencyService) GetConfigByProvider(ctx context.Context, providerID uuid.UUID) ([]*entities.CurrencyConfig, error) {
	configs, err := s.repo.GetConfigByProvider(ctx, providerID)
	if err != nil {
		return nil, err
	}

	lo.ForEach(configs, func(item *entities.CurrencyConfig, index int) {
		item.Compute()
	})

	return configs, nil
}

func (s *CurrencyService) GetCurrencies(ctx context.Context, providerID, integratorID uuid.UUID) ([]string, error) {
	ccs, err := s.GetConfigByProvider(ctx, providerID)
	if err != nil {
		return nil, err
	}

	cc, ok := lo.Find(ccs, func(item *entities.CurrencyConfig) bool {
		return item.ProviderIntegratorPair.IntegratorID == integratorID
	})

	if !ok {
		return nil, e.ErrCurrencyConfigNotFound
	}

	return cc.Currencies(), nil
}

func (s *CurrencyService) MergeCurrenciesByProvider(ctx context.Context, providerID uuid.UUID) ([]string, error) {
	ccs, err := s.GetConfigByProvider(ctx, providerID)
	if err != nil {
		return nil, err
	}

	currencies := []string{}

	for _, cc := range ccs {
		currencies = append(currencies, cc.Currencies()...)
	}

	currencies = lo.Uniq(currencies)

	return currencies, nil
}
