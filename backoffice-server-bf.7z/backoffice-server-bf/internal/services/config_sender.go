package services

import (
	"backoffice/internal/constants"
	"backoffice/internal/entities"
	"context"
	"github.com/google/uuid"
	"github.com/samber/lo"
	"go.uber.org/zap"
)

type Sender interface {
	Send(ctx context.Context, queueName string, msgType string, payload interface{}) error
}

type ConfigSenderService struct {
	sender Sender

	gameService     *GameService
	currencyService *CurrencyService
}

func NewConfigSenderService(sender Sender, currencyService *CurrencyService, gameService *GameService) *ConfigSenderService {
	return &ConfigSenderService{sender: sender, currencyService: currencyService, gameService: gameService}
}

func (s *ConfigSenderService) Notify(ev any) {
	if err := s.SendCurrencyToLord(context.Background()); err != nil {
		zap.S().Error(err)
	}
}

func (s *ConfigSenderService) SendCurrencyToLord(ctx context.Context) error {
	configs, err := s.currencyService.All(ctx)
	if err != nil {
		return err
	}

	toSend := make([]*entities.CurrencyGameConfig, 0)
	games, err := s.gameService.AllPublic(ctx, nil)
	if err != nil {
		return err
	}

	gamesMap := map[uuid.UUID][]*entities.Game{}

	lo.ForEach(games, func(item *entities.Game, index int) {
		gamesMap[item.OrganizationID] = append(gamesMap[item.OrganizationID], item)
	})

	lo.ForEach(configs, func(item *entities.CurrencyConfig, index int) {
		item.Compute()

		providerGames := gamesMap[item.ProviderIntegratorPair.ProviderID]

		lo.ForEach(providerGames, func(game *entities.Game, index int) {
			toSend = append(toSend, item.ToGameConfig(game.Name, game.ID))
		})
	})

	return s.sender.Send(ctx, constants.QueueOverlordName, constants.MsgCurrencyConfigType, toSend)
}
