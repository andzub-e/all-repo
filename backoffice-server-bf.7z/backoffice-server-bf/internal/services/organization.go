package services

import (
	"backoffice/internal/entities"
	e "backoffice/internal/errors"
	"backoffice/internal/repositories"
	"context"
	"fmt"
	"github.com/google/uuid"
	"github.com/samber/lo"
	"go.uber.org/zap"
)

type OrganizationService struct {
	repo           repositories.OrganizationRepository
	accountService *AccountService
	gameService    *GameService
}

func NewOrganizationService(repo repositories.OrganizationRepository, accountService *AccountService, gameService *GameService) *OrganizationService {
	return &OrganizationService{
		repo:           repo,
		accountService: accountService,
		gameService:    gameService,
	}
}

func (s *OrganizationService) Create(ctx context.Context, name, t string) (*entities.Organization, error) {
	return s.repo.Create(ctx, &entities.Organization{
		ID:   uuid.New(),
		Name: name,
		Type: t,
	})
}

func (s *OrganizationService) Delete(ctx context.Context, id string) error {
	organization, err := s.repo.FindBy(ctx, map[string]interface{}{"id": id})
	if err != nil {
		return err
	}

	return s.repo.Delete(ctx, organization)
}

func (s *OrganizationService) Paginate(ctx context.Context, filters map[string]interface{}, order string, limit int, offset int) ([]*entities.Organization, int64, error) {
	return s.repo.Paginate(ctx, filters, order, limit, offset)
}

func (s *OrganizationService) Assign(ctx context.Context, accountID, organizationID uuid.UUID) (*entities.Account, error) {
	account, err := s.accountService.FindBy(ctx, map[string]interface{}{"id": accountID})
	if err != nil {
		return nil, err
	}

	organization, err := s.repo.FindBy(ctx, map[string]interface{}{"id": organizationID})
	if err != nil {
		return nil, err
	}

	if err = s.repo.Assign(ctx, account, organization); err != nil {
		return nil, err
	}

	account.Organizations = append(account.Organizations, organization)

	return account, nil
}

func (s *OrganizationService) Revoke(ctx context.Context, accountID, organizationID uuid.UUID) error {
	account, err := s.accountService.FindBy(ctx, map[string]interface{}{"id": accountID})
	if err != nil {
		return err
	}

	for _, role := range account.Roles {
		if role.Type == entities.RootRoleTypeName {
			return fmt.Errorf("%v from root user", e.ErrCanNotRemoveOrganization)
		}
	}

	organization, err := s.repo.FindBy(ctx, map[string]interface{}{"id": organizationID})
	if err != nil {
		return err
	}

	return s.repo.Revoke(ctx, account, organization)
}

func (s *OrganizationService) LoadAccountOrganization(ctx context.Context, account *entities.Account) error {
	organizations, err := s.repo.GetByAccount(ctx, account)
	if err != nil {
		return err
	}

	account.Organizations = organizations

	return nil
}

func (s *OrganizationService) GetIntegratorGames(ctx context.Context, organizationID uuid.UUID) ([]string, error) {
	organization, err := s.repo.FindBy(ctx, map[string]interface{}{"id": organizationID})
	if err != nil {
		return nil, err
	}

	if !organization.IsIntegrator() {
		return nil, e.ErrOrganizationIsNotIntegrator
	}

	return s.gameService.GetIntegratorGameNames(ctx, organization.ID)
}

func (s *OrganizationService) GetByApiKey(ctx context.Context, apiKey string) (*entities.Organization, error) {
	return s.repo.FindBy(ctx, map[string]interface{}{"api_key": apiKey})
}

func (s *OrganizationService) HasAccess(ctx context.Context, organizationID uuid.UUID, gameName string) error {
	organization, err := s.repo.FindBy(ctx, map[string]interface{}{"id": organizationID})
	if err != nil {
		zap.S().Error(err)

		return err
	}

	if !organization.IsIntegrator() {
		return e.ErrOrganizationIsNotIntegrator
	}

	games, err := s.gameService.GetIntegratorGameNames(ctx, organizationID)
	if err != nil {
		zap.S().Error(err)

		return err
	}

	for _, game := range games {
		if game == gameName {
			return nil
		}
	}

	return e.ErrDoesNotHavePermission
}

func (s *OrganizationService) GetOrganizationPair(ctx context.Context, providerID, integratorID uuid.UUID) (
	*entities.ProviderIntegratorPair, error) {
	return s.repo.GetOrganizationPair(ctx, providerID, integratorID)
}

func (s *OrganizationService) GetIntegratorNames(ctx context.Context, providerID uuid.UUID) ([]string, error) {
	orgs, err := s.repo.GetIntegratorsByProvider(ctx, providerID)
	if err != nil {
		return nil, err
	}

	return lo.Map(orgs, func(item *entities.Organization, index int) string {
		return item.Name
	}), nil
}
