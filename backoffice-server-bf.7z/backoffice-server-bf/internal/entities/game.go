package entities

import (
	"github.com/google/uuid"
	"github.com/lib/pq"
)

type Game struct {
	ID             uuid.UUID      `json:"id" gorm:"primaryKey;column:id" xlsx:"-"`
	OrganizationID uuid.UUID      `json:"organization_id,omitempty" xlsx:"-"`
	Organization   *Organization  `json:"organization,omitempty" xlsx:"-"`
	Name           string         `json:"name" xlsx:"Name"`
	Jurisdictions  pq.StringArray `json:"jurisdictions" gorm:"type:varchar[]" swaggertype:"array,string" xlsx:"-"`
	Currencies     pq.StringArray `json:"currencies" gorm:"type:varchar[]" swaggertype:"array,string" xlsx:"-"`
	Languages      pq.StringArray `json:"languages" gorm:"type:varchar[]" swaggertype:"array,string" xlsx:"-"`
	UserLocales    pq.StringArray `json:"user_locales" gorm:"type:varchar[]" swaggertype:"array,string" xlsx:"-"`
	ApiUrl         string         `json:"api_url" xlsx:"-"`
	ClientUrl      string         `json:"client_url" xlsx:"-"`

	IsPublic         bool `json:"is_public" xlsx:"-"`
	IsStatisticShown bool `json:"is_statistic_shown" xlsx:"-"`
}

func (Game) TableName() string {
	return "games"
}

func (Game) JoinTableName(table string) string {
	return "games"
}
