package entities

import (
	"github.com/google/uuid"
	"github.com/lib/pq"
	"github.com/samber/lo"
	"gorm.io/gorm"
	"time"
)

type CurrencyConfig struct {
	CreatedAt time.Time      `json:"-"`
	UpdatedAt time.Time      `json:"-"`
	DeletedAt gorm.DeletedAt `json:"-"`

	OrganizationPairID     uuid.UUID               `json:"organization_pair_id"`
	ProviderIntegratorPair *ProviderIntegratorPair `json:"provider_integrator_pair" gorm:"foreignKey:organization_pair_id"`

	DefaultWager int64         `json:"default_wager"`
	WagerLevels  pq.Int64Array `json:"wager_levels" gorm:"type:int[]" swaggerignore:"true"`

	MultipliersRaw []CurrencyMultiplier `json:"-" gorm:"foreignKey:OrganizationPairID;references:OrganizationPairID"`

	// computed
	Multipliers map[string]int64 `json:"multipliers" gorm:"-"`
}

func (cc *CurrencyConfig) Currencies() []string {
	return lo.Keys(cc.Multipliers)
}

func (cc *CurrencyConfig) Compute() {
	if cc.Multipliers == nil {
		cc.Multipliers = map[string]int64{}
	}

	for _, cm := range cc.MultipliersRaw {
		cc.Multipliers[cm.Title] = cm.Multiplier
	}
}

func (cc *CurrencyConfig) ToGameConfig(gameName string, gameID uuid.UUID) *CurrencyGameConfig {
	return &CurrencyGameConfig{
		IntegratorName: cc.ProviderIntegratorPair.Integrator.Name,
		ProviderName:   cc.ProviderIntegratorPair.Provider.Name,
		GameName:       gameName,
		GameID:         gameID,

		DefaultWager: cc.DefaultWager,
		WagerLevels:  cc.WagerLevels,
		Multipliers:  cc.Multipliers,
	}
}

func (CurrencyConfig) TableName() string {
	return "currency_configs"
}

type CurrencyMultiplier struct {
	CreatedAt time.Time `json:"-"`
	UpdatedAt time.Time `json:"-"`

	OrganizationPairID uuid.UUID `json:"organization_pair_id"`

	Title      string `json:"title"  gorm:"primaryKey"`
	Multiplier int64  `json:"multiplier"`
}

func (CurrencyMultiplier) TableName() string {
	return "currency_multipliers"
}

type CurrencyGameConfig struct {
	IntegratorName string    `json:"integrator_name"`
	ProviderName   string    `json:"provider_name"`
	GameName       string    `json:"game_name"`
	GameID         uuid.UUID `json:"game_id"`

	DefaultWager int64            `json:"default_wager"`
	WagerLevels  []int64          `json:"wager_levels"`
	Multipliers  map[string]int64 `json:"multipliers" gorm:"-"`
}
