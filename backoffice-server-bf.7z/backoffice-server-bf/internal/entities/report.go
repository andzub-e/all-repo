package entities

import "github.com/google/uuid"

type FileReportResponse struct {
	ID uuid.UUID `json:"id"`
}
