package entities

import "github.com/google/uuid"

type IntegratorGame struct {
	OrganizationID uuid.UUID
	Organization   *Organization
	GameID         uuid.UUID
	Game           *Game
}
