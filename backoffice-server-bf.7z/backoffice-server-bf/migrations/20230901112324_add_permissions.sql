-- +goose Up
-- +goose StatementBegin
insert into permissions (name, description, subject, endpoint, action)
values ('Change password', 'Change password', 'backoffice', '/auth/password/change', 'CREATE'),
       ('Generate 2fa', 'Generate 2fa', 'backoffice', '/auth/otp/generate', 'CREATE'),
       ('Enable 2fa', 'Enable 2fa', 'backoffice', '/auth/otp/enable', 'CREATE'),
       ('Disable 2fa', 'Disable 2fa', 'backoffice', '/auth/otp/disable', 'CREATE'),
       ('Dashboard', 'Dashboard', 'backoffice', '/dashboard', 'VIEW'),
       ('Delete account /', 'Delete account /', 'backoffice', '/accounts/:id', 'DELETE'),
       ('Assign role to account', 'Assign role to account', 'backoffice', '/accounts/:id/roles', 'CREATE'),
       ('Revoke role from account', 'Revoke role from account', 'backoffice', '/accounts/:id/roles', 'DELETE'),
       ('Assign permission to account', 'Assign permission to account', 'backoffice', '/accounts/:id/permissions', 'CREATE'),
       ('Revoke permission from account', 'Revoke permission from account', 'backoffice', '/accounts/:id/permissions', 'DELETE'),
       ('Assign organization to account', 'Assign organization to account', 'backoffice', '/accounts/:id/organizations', 'CREATE'),
       ('Revoke organization from account', 'Revoke organization from account', 'backoffice', '/accounts/:id/organizations', 'DELETE'),
       ('Get User Info', 'Get User Info', 'backoffice', '/reports/users/:id', 'VIEW'),
       ('Aggregated report by game', 'Aggregated report by game', 'backoffice', '/reports/aggregated/by_game', 'VIEW'),
       ('Aggregated report by game CSV', 'Aggregated report by game CSV', 'backoffice', '/reports/aggregated/by_game/csv', 'VIEW'),
       ('Aggregated report by game XLSX', 'Aggregated report by game XLSX', 'backoffice', '/reports/aggregated/by_game/xlsx', 'VIEW'),
       ('Aggregated report by country', 'Aggregated report by country', 'backoffice', '/reports/aggregated/by_country', 'VIEW'),
       ('Aggregated report by country CSV', 'Aggregated report by country CSV', 'backoffice', '/reports/aggregated/by_country/csv', 'VIEW'),
       ('Aggregated report by country XLSX', 'Aggregated report by country XLSX', 'backoffice', '/reports/aggregated/by_country/xlsx', 'VIEW'),
       ('Currency list', 'Currency list', 'backoffice', '/reports/currencies', 'VIEW'),
       ('Organization list', 'Organization list', 'backoffice', '/organizations', 'VIEW'),
       ('Create organization', 'Create organization', 'backoffice', '/organizations', 'CREATE'),
       ('Delete organization', 'Delete organization', 'backoffice', '/organizations/:id', 'DELETE'),
       ('Currencies dictionary', 'Currencies dictionary', 'backoffice', '/dictionaries/currencies', 'VIEW'),
       ('Integrators dictionary', 'Integrators dictionary', 'backoffice', '/dictionaries/integrators', 'VIEW'),
       ('Integrator-Operator pair dictionary', 'Integrator-Operator pair dictionary', 'backoffice', '/dictionaries/integrator-operators', 'VIEW'),

       ('Create currency multiplier', 'Create currency multiplier', 'backoffice', '/currency/multiplier', 'CREATE'),
       ('Delete currency multiplier', 'Delete currency multiplier', 'backoffice', '/currency/multiplier', 'DELETE'),
       ('Get currency config', 'Get currency config', 'backoffice', '/currency/config/:provider_id', 'VIEW'),
       ('Edit currency config', 'Edit currency config', 'backoffice', '/currency/config', 'EDIT'),

       ('Get wager sets', 'Get wager set', 'backoffice', '/wager_set', 'VIEW'),
       ('Create wager set', 'Create wager set', 'backoffice', '/wager_set', 'CREATE'),
       ('Get wager set', 'Create wager set', 'backoffice', '/wager_set/:id', 'VIEW'),
       ('Edit wager set', 'Edit wager set', 'backoffice', '/wager_set/:id', 'CREATE'),
       ('Delete wager set', 'Delete wager set', 'backoffice', '/wager_set/:id', 'DELETE'),

       ('Get currency sets', 'Get currency sets', 'backoffice', '/currency_set', 'VIEW'),
       ('Create currency set', 'Create currency set', 'backoffice', '/currency_set', 'CREATE'),
       ('Get currency set', 'Get password', 'backoffice', '/currency_set/:id', 'VIEW'),
       ('Edit currency set', 'Edit currency set', 'backoffice', '/currency_set/:id', 'CREATE'),
       ('Delete currency set', 'Delete currency set', 'backoffice', '/currency_set/:id', 'DELETE'),

       ('Get files', 'Change password', 'backoffice', '/files', 'VIEW'),
       ('Get file info', 'Change password', 'backoffice', '/files/:id', 'VIEW'),
       ('Ws file', 'Change password', 'backoffice', '/files/ws/:id', 'VIEW');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
