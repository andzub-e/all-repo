-- +goose Up
-- +goose StatementBegin
update games set name = 'retro-royale' where name = 'retro-royal';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
