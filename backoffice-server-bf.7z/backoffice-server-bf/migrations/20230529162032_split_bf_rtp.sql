-- +goose Up
-- +goose StatementBegin
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('smashing-hot-94',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.bf.heronbyte.com/smashing-hot-94/api',
        'https://dev.bf.heronbyte.com/smashing-hot-94/', '1010aef9-96a1-4eca-ac15-d02e59a70042');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('smashing-hot-96',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.bf.heronbyte.com/smashing-hot-96/api',
        'https://dev.bf.heronbyte.com/smashing-hot-96/', '1010aef9-96a1-4eca-ac15-d02e59a70042');


insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('smashing-hot-20-94',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.bf.heronbyte.com/smashing-hot-20-94/api',
        'https://dev.bf.heronbyte.com/smashing-hot-20-94/', '1010aef9-96a1-4eca-ac15-d02e59a70042');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('smashing-hot-20-96',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.bf.heronbyte.com/smashing-hot-20-96/api',
        'https://dev.bf.heronbyte.com/smashing-hot-20-96/', '1010aef9-96a1-4eca-ac15-d02e59a70042');



insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('book-of-dynasty-94',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.bf.heronbyte.com/book-of-dynasty-94/api',
        'https://dev.bf.heronbyte.com/book-of-dynasty-94/', '1010aef9-96a1-4eca-ac15-d02e59a70042');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('book-of-dynasty-96',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.bf.heronbyte.com/book-of-dynasty-96/api',
        'https://dev.bf.heronbyte.com/book-of-dynasty-96/', '1010aef9-96a1-4eca-ac15-d02e59a70042');


insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('book-of-sacred-94',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.bf.heronbyte.com/book-of-sacred-94/api',
        'https://dev.bf.heronbyte.com/book-of-sacred-94/', '1010aef9-96a1-4eca-ac15-d02e59a70042');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('book-of-sacred-96',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.bf.heronbyte.com/book-of-sacred-96/api',
        'https://dev.bf.heronbyte.com/book-of-sacred-96/', '1010aef9-96a1-4eca-ac15-d02e59a70042');


insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('wild-west-john-93',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.bf.heronbyte.com/wild-west-john-93/api',
        'https://dev.bf.heronbyte.com/wild-west-john-93/', '1010aef9-96a1-4eca-ac15-d02e59a70042');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('wild-west-john-95',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.bf.heronbyte.com/wild-west-john-95/api',
        'https://dev.bf.heronbyte.com/wild-west-john-95/', '1010aef9-96a1-4eca-ac15-d02e59a70042');


insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('blazing-clovers-94',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.bf.heronbyte.com/blazing-clovers-94/api',
        'https://dev.bf.heronbyte.com/blazing-clovers-94/', '1010aef9-96a1-4eca-ac15-d02e59a70042');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('blazing-clovers-96',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.bf.heronbyte.com/blazing-clovers-96/api',
        'https://dev.bf.heronbyte.com/blazing-clovers-96/', '1010aef9-96a1-4eca-ac15-d02e59a70042');

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
