-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
insert into permissions (name, description, subject, endpoint, action)
values ('Get roles', 'Get roles', 'backoffice', '/roles', 'VIEW'),
       ('Get role', 'Get role details', 'backoffice', '/roles/:id', 'VIEW'),
       ('Create role', 'Create new role', 'backoffice', '/roles', 'CREATE'),
       ('Edit role', 'Edit role', 'backoffice', '/roles/:id', 'EDIT'),
       ('Delete role', 'Delete role', 'backoffice', '/roles/:id', 'DELETE'),

       ('Assign permission to role', 'Assign permission to role', 'backoffice', '/roles/:id/permissions', 'CREATE'),
       ('Revoke permission to role', 'Assign permission to role', 'backoffice', '/roles/:id/permissions', 'DELETE'),

       ('Assign role to account', 'Assign role to account', 'backoffice', '/accounts/:id/roles', 'CREATE'),
       ('Revoke role to account', 'Assign role to account', 'backoffice', '/accounts/:id/roles', 'DELETE'),

       ('Spin details', 'Get spin details', 'backoffice', '/spins/:id', 'VIEW'),

       ('Currencies', 'Get available currencies', 'backoffice', '/reports/currencies', 'VIEW'),
       ('Financial', 'Get financial report', 'backoffice', '/reports/financial', 'VIEW'),
       ('Financial CSV', 'Get financial report in csv', 'backoffice', '/reports/financial/csv', 'VIEW'),
       ('Sessions', 'Get sessions report', 'backoffice', '/reports/sessions', 'VIEW'),
       ('Sessions CSV', 'Get sessions report in csv', 'backoffice', '/reports/sessions/csv', 'VIEW'),
       ('Spins', 'Get spins report', 'backoffice', '/reports/spins', 'VIEW'),
       ('Spins CSV', 'Get spins report in csv', 'backoffice', '/reports/spins/csv', 'VIEW');
;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
