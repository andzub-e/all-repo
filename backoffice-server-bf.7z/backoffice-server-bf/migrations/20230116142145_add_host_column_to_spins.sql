-- +goose Up
-- +goose StatementBegin
alter table spins add column host varchar default 'no-host';

create index if not exists idx_spins_host on spins using hash (host);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
alter table spins drop column host;

drop index idx_spins_host;
-- +goose StatementEnd
