-- +goose Up
-- +goose StatementBegin
insert into organizations(created_at, updated_at, id, name, type, status)
values (now(), now(), '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'infingame', 'integrator', 1);

insert into currency_configs(created_at, updated_at, provider_id, integrator_id, wager_levels, default_wager)
values (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '1e6fab03-8a91-4417-beba-faa3af8dbc51',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '1e6fab03-8a91-4417-beba-faa3af8dbc51',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '1e6fab03-8a91-4417-beba-faa3af8dbc51',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000);

insert into currency_multipliers(created_at, updated_at, provider_id, integrator_id, title, multiplier)
values (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'usd', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'eur', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'kzt', 500),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'rub', 100),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'uah', 10),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'azn', 2),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'uzs', 10000),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'xts', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'cad', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'usdt', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'inr', 100),

       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'usd', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'eur', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'kzt', 500),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'rub', 100),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'uah', 10),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'azn', 2),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'uzn', 10000),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'xts', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'cad', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'usdt', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'inr', 100),

       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'usd', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'eur', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'kzt', 500),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'rub', 100),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'uah', 10),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'azn', 2),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'uzn', 10000),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'xts', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'cad', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'usdt', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '1e6fab03-8a91-4417-beba-faa3af8dbc51', 'inr', 100);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
