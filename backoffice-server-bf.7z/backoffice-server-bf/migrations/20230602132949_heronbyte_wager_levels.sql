-- +goose Up
-- +goose StatementBegin
update currency_configs set wager_levels = '{100,200,500,700,1000,1500,2000,2500,5000,10000,25000,50000,100000}' where provider_id = '4cf6272a-72b5-44c3-a3b3-f3d1bba73500';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
