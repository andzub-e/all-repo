-- +goose Up
-- +goose StatementBegin
create table currency_configs
(
    created_at    timestamptz default now(),
    updated_at    timestamptz default now(),
    deleted_at    timestamptz,

    provider_id   uuid references organizations (id) on update cascade on delete cascade,
    integrator_id uuid references organizations (id) on update cascade on delete cascade,

    primary key (provider_id, integrator_id),

    wager_levels   int[],
    default_wager  int
);

create table currency_multipliers
(
    created_at    timestamptz default now(),
    updated_at    timestamptz default now(),

    provider_id   uuid,
    integrator_id uuid,
    title         varchar,

    primary key (provider_id, integrator_id, title),
    foreign key (provider_id, integrator_id)
        references currency_configs (provider_id, integrator_id) on update cascade on delete cascade,

    multiplier    int
);

insert into organizations(created_at, updated_at, id, name, type, status)
values (now(), now(), '4ecbb628-a60d-11ed-afa1-0242ac120002', 'mock', 'integrator', 1);

insert into currency_configs(created_at, updated_at, provider_id, integrator_id, wager_levels, default_wager)
values (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000);

insert into currency_multipliers(created_at, updated_at, provider_id, integrator_id, title, multiplier)
values (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'usd', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'eur', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'kzt', 500),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'rub', 100),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'uah', 10),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'azn', 2),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'uzs', 10000),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'xts', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'cad', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'usdt', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'inr', 100),

       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'usd', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'eur', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'kzt', 500),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'rub', 100),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'uah', 10),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'azn', 2),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'xts', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'cad', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'usdt', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'inr', 100),

       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'usd', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'eur', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'kzt', 500),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'rub', 100),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'uah', 10),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'azn', 2),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'xts', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'cad', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'usdt', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'inr', 100);


insert into permissions (name, description, subject, endpoint, action)
values
    ('Create currency multiplier', 'Create currency multiplier', 'backoffice', '/currency/multiplier', 'CREATE'),
    ('Edit currency multiplier', 'Edit currency multiplier', 'backoffice', '/currency/multiplier', 'EDIT'),
    ('Delete currency multiplier', 'Delete currency multiplier', 'backoffice', '/currency/multiplier', 'DELETE'),
    ('Get provider currency configs', 'Get provider currency configs', 'backoffice', '/currency/config/:provider_id', 'VIEW'),
    ('Edit provider currency configs', 'Edit provider currency configs', 'backoffice', '/currency/config', 'EDIT');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
drop table if exists currency_multipliers;
drop table if exists currency_configs;
-- +goose StatementEnd
