-- +goose Up
-- +goose StatementBegin
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('stonesofmagic',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/stonesofmagic/api',
        'https://dev.heronbyte.com/stonesofmagic/', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('secrettotems',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/stonesofmagic/api',
        'https://dev.heronbyte.com/secrettotems/', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('plinko',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/plinko/api',
        'https://dev.heronbyte.com/plinko/', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('asgardparty',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/asgardparty/api',
        'https://dev.heronbyte.com/asgardparty/', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('ego-draconis',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/asgardparty/api',
        'https://dev.heronbyte.com/ego-draconis/', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('robotics',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/robotics/api',
        'https://dev.heronbyte.com/robotics/', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('spells-streak',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/robotics/api',
        'https://dev.heronbyte.com/spells-streak/', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('cyber-town',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/cyber-town/api',
        'https://dev.heronbyte.com/cyber-town/', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('preciousbugs',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/cyber-town/api',
        'https://dev.heronbyte.com/preciousbugs/', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('stunning-hot',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/stunning-hot/api',
        'https://dev.heronbyte.com/stunning-hot/', '1010aef9-96a1-4eca-ac15-d02e59a70042');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('book',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/book/api',
        'https://dev.heronbyte.com/book/', '036cd780-d655-46ce-8713-f8e734bc7372');
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('burning-fruit',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/burning-fruit/api',
        'https://dev.heronbyte.com/burning-fruit/', '036cd780-d655-46ce-8713-f8e734bc7372');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
delete from games where name = 'stonesofmagic';
delete from games where name = 'secrettotems';
delete from games where name = 'plinko';
delete from games where name = 'asgardparty';
delete from games where name = 'ego-draconis';
delete from games where name = 'robotics';
delete from games where name = 'spells-streak';
delete from games where name = 'cyber-town';
delete from games where name = 'preciousbugs';
delete from games where name = 'stunning-hot';
delete from games where name = 'book';
delete from games where name = 'burning-fruit';

-- +goose StatementEnd
