-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
insert into organizations(created_at, updated_at, id, name, type, status)
values (now(), now(), 'db403ccc-aca6-4762-b632-c7cc479a31a5', 'game_hub', 'provider', 1);

insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('sweet-bonanza',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/sweet-bonanza/api',
        'https://dev.heronbyte.com/sweet-bonanza/', 'db403ccc-aca6-4762-b632-c7cc479a31a5');

insert into integrator_providers (id, provider_id, integrator_id)
values
    ('d3693bee-da6e-4685-8bb6-45c3c58d6579', 'db403ccc-aca6-4762-b632-c7cc479a31a5', '4ecbb628-a60d-11ed-afa1-0242ac120002'),
    ('0a33334b-d04a-46b0-8006-b0f785650f02', 'db403ccc-aca6-4762-b632-c7cc479a31a5', 'b400a99c-963c-49ac-acf1-4df26c018301'),
    ('c826d3e2-3bf4-4674-938d-4f7af740e598', 'db403ccc-aca6-4762-b632-c7cc479a31a5', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121'),
    ('89e520d2-eadb-4e0d-bd15-b5d44ba6a57c', 'db403ccc-aca6-4762-b632-c7cc479a31a5', '29c3849e-ed81-4cd5-a3db-412c447378b6'),
    ('c57962ab-1752-4792-9488-ae55a1730293', 'db403ccc-aca6-4762-b632-c7cc479a31a5', '1e6fab03-8a91-4417-beba-faa3af8dbc51');

insert into currency_configs(created_at, updated_at, organization_pair_id, wager_levels, default_wager)
values (now(), now(), 'd3693bee-da6e-4685-8bb6-45c3c58d6579',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000}',
        2000);

insert into currency_multipliers(created_at, updated_at, organization_pair_id, title, multiplier)
values (now(), now(), 'd3693bee-da6e-4685-8bb6-45c3c58d6579', 'usd', 1),
       (now(), now(), 'd3693bee-da6e-4685-8bb6-45c3c58d6579', 'eur', 1),
       (now(), now(), 'd3693bee-da6e-4685-8bb6-45c3c58d6579', 'kzt', 500),
       (now(), now(), 'd3693bee-da6e-4685-8bb6-45c3c58d6579', 'rub', 100),
       (now(), now(), 'd3693bee-da6e-4685-8bb6-45c3c58d6579', 'uah', 10),
       (now(), now(), 'd3693bee-da6e-4685-8bb6-45c3c58d6579', 'azn', 2),
       (now(), now(), 'd3693bee-da6e-4685-8bb6-45c3c58d6579', 'uzs', 10000),
       (now(), now(), 'd3693bee-da6e-4685-8bb6-45c3c58d6579', 'xts', 1),
       (now(), now(), 'd3693bee-da6e-4685-8bb6-45c3c58d6579', 'cad', 1),
       (now(), now(), 'd3693bee-da6e-4685-8bb6-45c3c58d6579', 'usdt', 1),
       (now(), now(), 'd3693bee-da6e-4685-8bb6-45c3c58d6579', 'inr', 100);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
