-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';

create or replace procedure refresh_admin_permissions()
    LANGUAGE plpgsql
AS $$
declare p uuid[];
    declare r uuid[];
    declare permission uuid;
    declare role uuid;
begin
    select array(select id from permissions into p);
    select array(select id from roles where "type" = 'admin' into r);

    delete from role_permissions where role_id = any(r);
    foreach permission in array p loop
            foreach role in array r loop
                    insert into role_permissions(created_at, role_id, permission_id)
                    values (now(), role, permission);
                end loop;
        end loop;
end
$$;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
