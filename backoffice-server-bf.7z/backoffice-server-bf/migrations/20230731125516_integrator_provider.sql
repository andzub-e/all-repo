-- +goose Up
-- +goose StatementBegin
create table integrator_providers
(
    id            uuid primary key,
    provider_id   uuid references organizations (id),
    integrator_id uuid references organizations (id)
);

insert into integrator_providers (id, provider_id, integrator_id)
values
-- ejaw
('7821aafc-37e2-40ea-b376-4bcffe2ce690', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002'),
('9d609770-2103-45ee-adc6-991b0ca23a75', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', 'b400a99c-963c-49ac-acf1-4df26c018301'),
('44167708-a55e-464c-810b-28a45a4302dc', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121'),
('4ee60ae0-ea56-4506-9d23-6bcd2d8d2151', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '29c3849e-ed81-4cd5-a3db-412c447378b6'),
('94342a94-7cd3-4c40-b483-de30993984b2', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '1e6fab03-8a91-4417-beba-faa3af8dbc51'),
-- lemon
('252cf9b4-9983-4d99-9dc5-2d0adac2c526', '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002'),
('75813f27-bb6b-4d01-91f1-6fc3fb1dfaa2', '036cd780-d655-46ce-8713-f8e734bc7372', 'b400a99c-963c-49ac-acf1-4df26c018301'),
('e76863a2-b1c5-4ed2-b136-1941de6377c3', '036cd780-d655-46ce-8713-f8e734bc7372', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121'),
('abf50952-2fef-4600-b534-e7a118e33a67', '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6'),
('1656aad8-7b6e-4b94-9b2c-7d1fe5c1814f', '036cd780-d655-46ce-8713-f8e734bc7372', '1e6fab03-8a91-4417-beba-faa3af8dbc51'),
-- bf
('fded59fa-4936-4cc5-9a92-ed666b01d2e4', '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002'),
('31a5da95-6e2d-4f69-a656-2dadb875faee', '1010aef9-96a1-4eca-ac15-d02e59a70042', 'b400a99c-963c-49ac-acf1-4df26c018301'),
('e7762800-0b15-4632-8a1c-77ca1cecfd38', '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121'),
('e8add7f9-14a2-469a-a1e4-70c178477dfb', '1010aef9-96a1-4eca-ac15-d02e59a70042', '29c3849e-ed81-4cd5-a3db-412c447378b6'),
('7772ff38-358a-4f50-a363-816aeebadc7b', '1010aef9-96a1-4eca-ac15-d02e59a70042', '1e6fab03-8a91-4417-beba-faa3af8dbc51'),
-- most_bet
('04670fa6-5b68-4cf1-809e-2f15e709751d', 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '4ecbb628-a60d-11ed-afa1-0242ac120002'),
('c72c070a-f144-4d25-95cd-5bbc58f61c32', 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', 'b400a99c-963c-49ac-acf1-4df26c018301'),
('e06d1be1-eb49-4d60-8bac-c176103d8497', 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121'),
('cffc00cf-27f8-4cc6-8b5f-b6dfb19b2904', 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '29c3849e-ed81-4cd5-a3db-412c447378b6'),
('67b49e6a-9012-4022-ac07-fa251d548503', 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '1e6fab03-8a91-4417-beba-faa3af8dbc51');

alter table currency_multipliers add column organization_pair_id uuid references integrator_providers(id);
alter table currency_configs add column organization_pair_id uuid references integrator_providers(id);

update currency_multipliers set organization_pair_id = (
    select id
    from integrator_providers
    where
        integrator_providers.integrator_id = currency_multipliers.integrator_id and
        integrator_providers.provider_id = currency_multipliers.provider_id
);

update currency_configs set organization_pair_id = (
    select id
    from integrator_providers
    where
            integrator_providers.integrator_id = currency_configs.integrator_id and
            integrator_providers.provider_id = currency_configs.provider_id
);

alter table currency_configs drop constraint currency_configs_integrator_id_fkey;
alter table currency_configs drop constraint currency_configs_provider_id_fkey;

alter table currency_multipliers drop constraint currency_multipliers_provider_id_integrator_id_fkey;

alter table currency_multipliers drop constraint currency_multipliers_pkey;
alter table currency_configs drop constraint currency_configs_pkey;

alter table currency_configs add primary key (organization_pair_id);
alter table currency_multipliers add primary key (organization_pair_id, title);

alter table currency_multipliers drop constraint currency_multipliers_organization_pair_id_fkey;
alter table currency_multipliers add constraint currency_multipliers_organization_pair_id_fkey
    foreign key (organization_pair_id) references currency_configs(organization_pair_id);

alter table currency_configs drop column provider_id;
alter table currency_configs drop column integrator_id;

alter table currency_multipliers drop column provider_id;
alter table currency_multipliers drop column integrator_id;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
