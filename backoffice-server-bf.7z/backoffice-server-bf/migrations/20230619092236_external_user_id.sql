-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
alter table spins add column external_user_id varchar(256);
create index if not exists idx_external_user_id on spins using hash (external_user_id);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
alter table spins drop column external_user_id;
drop index idx_external_user_id;
-- +goose StatementEnd