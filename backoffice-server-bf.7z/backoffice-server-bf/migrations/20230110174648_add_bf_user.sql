-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
insert into accounts (created_at, updated_at, id, auth_provider, auth_provider_id, auth_provider_token, first_name,
                      last_name, email, status)
values (now(), now(), '7ddd09cf-de12-491f-8dcf-b6d74dc14358', 'email', 'bf',
        '$2a$15$4Tbu2DDyt3DNRYtlecCw3.EMYgWZJg9AvL/A3EQMeRzSFJuxEF18O', 'BF', 'Admin', 'admin', 1);

insert into account_organizations(created_at, account_id, organization_id)
values (now(), '7ddd09cf-de12-491f-8dcf-b6d74dc14358', '1010aef9-96a1-4eca-ac15-d02e59a70042');

insert into roles(created_at, updated_at, id, name, description, type)
values (now(), now(), 'e61bfafd-58cf-4aa7-8616-1e71ad8a2b4e', 'Administrator', 'The main bf user', 'admin');

insert into account_roles(account_id, role_id)
values ('7ddd09cf-de12-491f-8dcf-b6d74dc14358', 'e61bfafd-58cf-4aa7-8616-1e71ad8a2b4e');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
