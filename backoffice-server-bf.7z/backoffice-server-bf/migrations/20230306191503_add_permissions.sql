-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
insert into permissions (name, description, subject, endpoint, action)
values ('Get permissions', 'Get permissions', 'backoffice', '/permissions', 'VIEW'),
       ('Session details', 'Get Session details', 'backoffice', '/reports/sessions/:id', 'VIEW'),
       ('Gameplay details', 'Get gameplay details', 'backoffice', '/reports/spins/:id', 'VIEW'),
       ('Financial XLSX', 'Get financial report in xlsx', 'backoffice', '/reports/financial/xlsx', 'VIEW'),
       ('Sessions XLSX', 'Get sessions report in xlsx', 'backoffice', '/reports/sessions/xlsx', 'VIEW'),
       ('Spins XLSX', 'Get spins report in xlsx', 'backoffice', '/reports/spins/xlsx', 'VIEW');

call refresh_admin_permissions();
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
