-- +goose Up
-- +goose StatementBegin
create table currency_sets (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,

    id uuid primary key,
    organization_id uuid references organizations(id),
    name varchar(255) not null,
    currencies varchar[],

    is_active boolean,

    unique (organization_id, name)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
