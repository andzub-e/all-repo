-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
alter table organizations
    add column api_key varchar default null;

create table if not exists integrator_games
(
    organization_id uuid references organizations (id) on delete cascade,
    game_id         uuid references games (id),
    primary key (organization_id, game_id)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
alter table organizations
    drop column api_key;

drop table if exists integrator_games;
-- +goose StatementEnd
