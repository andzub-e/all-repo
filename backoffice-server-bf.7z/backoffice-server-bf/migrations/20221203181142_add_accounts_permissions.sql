-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
insert into permissions (name, description, subject, endpoint, action)
values ('Get accounts', 'Get all backoffice accounts', 'backoffice', '/accounts', 'VIEW'),
       ('Get account', 'Get account profile', 'backoffice', '/accounts/:id', 'VIEW'),
       ('Create account', 'Create new account', 'backoffice', '/accounts', 'CREATE'),
       ('Edit account', 'Edit account', 'backoffice', '/accounts/:id', 'EDIT'),
       ('Delete account', 'Delete account', 'backoffice', '/accounts/:id', 'DELETE');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
