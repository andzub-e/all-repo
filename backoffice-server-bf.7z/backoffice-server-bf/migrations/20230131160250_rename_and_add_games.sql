-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
update games
set name = 'smashing-hot',
    api_url =  'https://dev.heronbyte.com/smashing-hot/api',
    client_url = 'https://dev.heronbyte.com/smashing-hot/'
where name = 'stunning-hot';

update games
set api_url =  'https://dev.heronbyte.com/burning-20-wins/api',
    client_url = 'https://dev.heronbyte.com/burning-20-wins/'
where name = 'burning-20-wins';

update games
set api_url =  'https://dev.heronbyte.com/book-of-jones/api',
    client_url = 'https://dev.heronbyte.com/book-of-jones/'
where name = 'book-of-jones';

insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('smashing-hot-20',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/smashing-hot-20/api',
        'https://dev.heronbyte.com/smashing-hot-20/', '1010aef9-96a1-4eca-ac15-d02e59a70042');

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
