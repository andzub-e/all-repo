-- +goose Up
-- +goose StatementBegin
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('book-of-sacred',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/book-of-sacred/api',
        'https://dev.heronbyte.com/book-of-sacred/', '1010aef9-96a1-4eca-ac15-d02e59a70042'),
        ('wild-west-john',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/wild-west-john/api',
        'https://dev.heronbyte.com/wild-west-john/', '1010aef9-96a1-4eca-ac15-d02e59a70042'),
       ('majestic-crown',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/majestic-crown/api',
        'https://dev.heronbyte.com/majestic-crown/', '1010aef9-96a1-4eca-ac15-d02e59a70042'),
       ('blazing-clovers',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/blazing-clovers/api',
        'https://dev.heronbyte.com/blazing-clovers/', '1010aef9-96a1-4eca-ac15-d02e59a70042'),
       ('blazing-clovers-20',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/blazing-clovers-20/api',
        'https://dev.heronbyte.com/blazing-clovers-20/', '1010aef9-96a1-4eca-ac15-d02e59a70042'),
       ('blazing-clovers-40',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/blazing-clovers-40/api',
        'https://dev.heronbyte.com/blazing-clovers-40/', '1010aef9-96a1-4eca-ac15-d02e59a70042');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
