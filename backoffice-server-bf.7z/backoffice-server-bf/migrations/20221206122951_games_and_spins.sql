-- +goose Up
-- +goose StatementBegin
create table if not exists games
(
    id              uuid DEFAULT gen_random_uuid() primary key,
    organization_id uuid references organizations (id),
    name            varchar unique,
    jurisdictions   varchar[] not null,
    currencies      varchar[] not null,
    languages       varchar[] not null,
    user_locales    varchar[] not null,
    api_url         varchar   not null,
    client_url      varchar   not null
);

create index if not exists idx_game_name on games using hash (name);

create table if not exists spins
(
    created_at        timestamptz default NOW(),
    updated_at        timestamptz default NOW(),

    id                uuid,
    game_id           uuid references games (id),
    session_token     uuid,
    operator          varchar(32),
    user_id           varchar(128),
    currency          varchar(10),
    start_balance     bigint,
    end_balance       bigint,
    wager             bigint,
    base_award        bigint,
    bonus_award       bigint,

    spin              jsonb,
    restoring_indexes jsonb,
    additional_data   jsonb,
    is_shown          boolean,

    primary key (id, game_id)
);

create index if not exists idx_spins_session_token on spins using hash (session_token);
create index if not exists idx_spins_game_id on spins using hash (game_id);
create index if not exists idx_spins_currency on spins using hash (currency);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
drop table if exists games;
drop table if exists spins;
drop index if exists idx_spins_session_token;
drop index if exists idx_spins_game_id;
drop index if exists idx_game_name;
drop index if exists idx_spins_currency;
-- +goose StatementEnd
