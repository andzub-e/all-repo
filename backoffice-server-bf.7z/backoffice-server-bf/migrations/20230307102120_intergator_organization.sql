-- +goose Up
-- +goose StatementBegin
alter table organizations
    drop constraint organizations_name_key;
alter table organizations
    add constraint organizations_name_type_unique unique (name, type);

insert into organizations(created_at, updated_at, id, name, type, status)
values (now(), now(), 'b400a99c-963c-49ac-acf1-4df26c018301', 'pokerdom', 'integrator', 1),
       (now(), now(), '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'bf', 'integrator', 1),
       (now(), now(), '29c3849e-ed81-4cd5-a3db-412c447378b6', 'lemon', 'integrator', 1);

insert into currency_configs(created_at, updated_at, provider_id, integrator_id, wager_levels, default_wager)
values (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', 'b400a99c-963c-49ac-acf1-4df26c018301',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', 'b400a99c-963c-49ac-acf1-4df26c018301',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', 'b400a99c-963c-49ac-acf1-4df26c018301',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '29c3849e-ed81-4cd5-a3db-412c447378b6',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '29c3849e-ed81-4cd5-a3db-412c447378b6',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000}',
        2000);

insert into currency_multipliers(created_at, updated_at, provider_id, integrator_id, title, multiplier)
values (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', 'b400a99c-963c-49ac-acf1-4df26c018301', 'usd', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', 'b400a99c-963c-49ac-acf1-4df26c018301', 'eur', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', 'b400a99c-963c-49ac-acf1-4df26c018301', 'kzt', 500),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', 'b400a99c-963c-49ac-acf1-4df26c018301', 'rub', 100),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', 'b400a99c-963c-49ac-acf1-4df26c018301', 'uah', 10),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', 'b400a99c-963c-49ac-acf1-4df26c018301', 'azn', 2),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', 'b400a99c-963c-49ac-acf1-4df26c018301', 'uzs', 10000),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', 'b400a99c-963c-49ac-acf1-4df26c018301', 'xts', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', 'b400a99c-963c-49ac-acf1-4df26c018301', 'cad', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', 'b400a99c-963c-49ac-acf1-4df26c018301', 'usdt', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', 'b400a99c-963c-49ac-acf1-4df26c018301', 'inr', 100),

       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', 'b400a99c-963c-49ac-acf1-4df26c018301', 'usd', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', 'b400a99c-963c-49ac-acf1-4df26c018301', 'eur', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', 'b400a99c-963c-49ac-acf1-4df26c018301', 'kzt', 500),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', 'b400a99c-963c-49ac-acf1-4df26c018301', 'rub', 100),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', 'b400a99c-963c-49ac-acf1-4df26c018301', 'uah', 10),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', 'b400a99c-963c-49ac-acf1-4df26c018301', 'azn', 2),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', 'b400a99c-963c-49ac-acf1-4df26c018301', 'uzn', 10000),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', 'b400a99c-963c-49ac-acf1-4df26c018301', 'xts', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', 'b400a99c-963c-49ac-acf1-4df26c018301', 'cad', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', 'b400a99c-963c-49ac-acf1-4df26c018301', 'usdt', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', 'b400a99c-963c-49ac-acf1-4df26c018301', 'inr', 100),

       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', 'b400a99c-963c-49ac-acf1-4df26c018301', 'usd', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', 'b400a99c-963c-49ac-acf1-4df26c018301', 'eur', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', 'b400a99c-963c-49ac-acf1-4df26c018301', 'kzt', 500),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', 'b400a99c-963c-49ac-acf1-4df26c018301', 'rub', 100),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', 'b400a99c-963c-49ac-acf1-4df26c018301', 'uah', 10),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', 'b400a99c-963c-49ac-acf1-4df26c018301', 'azn', 2),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', 'b400a99c-963c-49ac-acf1-4df26c018301', 'uzn', 10000),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', 'b400a99c-963c-49ac-acf1-4df26c018301', 'xts', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', 'b400a99c-963c-49ac-acf1-4df26c018301', 'cad', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', 'b400a99c-963c-49ac-acf1-4df26c018301', 'usdt', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', 'b400a99c-963c-49ac-acf1-4df26c018301', 'inr', 100),


       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'usd', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'eur', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'kzt', 500),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'rub', 100),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'uah', 10),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'azn', 2),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'uzs', 10000),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'xts', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'cad', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'usdt', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'inr', 100),

       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'usd', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'eur', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'kzt', 500),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'rub', 100),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'uah', 10),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'azn', 2),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'uzn', 10000),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'xts', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'cad', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'usdt', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'inr', 100),

       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'usd', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'eur', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'kzt', 500),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'rub', 100),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'uah', 10),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'azn', 2),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'uzn', 10000),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'xts', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'cad', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'usdt', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'inr', 100),


       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'usd', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'eur', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'kzt', 500),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'rub', 100),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'uah', 10),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'azn', 2),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'uzs', 10000),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'xts', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'cad', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'usdt', 1),
       (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'inr', 100),

       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'usd', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'eur', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'kzt', 500),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'rub', 100),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'uah', 10),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'azn', 2),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'uzn', 10000),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'xts', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'cad', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'usdt', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'inr', 100),

       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'usd', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'eur', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'kzt', 500),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'rub', 100),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'uah', 10),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'azn', 2),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'uzn', 10000),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'xts', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'cad', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'usdt', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'inr', 100);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
