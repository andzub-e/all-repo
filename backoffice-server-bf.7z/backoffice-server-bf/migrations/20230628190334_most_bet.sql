-- +goose Up
-- +goose StatementBegin
insert into organizations(created_at, updated_at, id, name, type, status)
values (now(), now(), 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', 'most_bet', 'provider', 1);

insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('burning-wins-3',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/burning-wins-3/api',
        'https://dev.heronbyte.com/burning-wins-3/', 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c');

insert into currency_configs(created_at, updated_at, provider_id, integrator_id, wager_levels, default_wager)
values (now(), now(), 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '4ecbb628-a60d-11ed-afa1-0242ac120002',
        '{100, 200, 500, 700, 1000, 1500, 2000, 2500, 5000, 10000, 25000, 50000, 100000}',
        2000);

insert into currency_multipliers(created_at, updated_at, provider_id, integrator_id, title, multiplier)
values (now(), now(), 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'usd', 1),
       (now(), now(), 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'eur', 1),
       (now(), now(), 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'kzt', 500),
       (now(), now(), 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'rub', 100),
       (now(), now(), 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'uah', 10),
       (now(), now(), 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'azn', 2),
       (now(), now(), 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'uzs', 10000),
       (now(), now(), 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'xts', 1),
       (now(), now(), 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'cad', 1),
       (now(), now(), 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'usdt', 1),
       (now(), now(), 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'inr', 100);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
