-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
alter table accounts add column totp_enabled bool default false;
alter table accounts add column totp_secret varchar default '';
alter table accounts add column totp_url varchar default '';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
alter table accounts drop column totp_enabled;
alter table accounts drop column totp_secret;
alter table accounts drop column totp_url;
-- +goose StatementEnd
