-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';

create table if not exists organizations
(
    created_at timestamptz default now(),
    updated_at timestamptz,
    deleted_at timestamptz,

    id         uuid        default gen_random_uuid() primary key,
    name       varchar(255) unique,
    type       varchar(20),
    status     int
);

create table if not exists accounts
(
    created_at          timestamptz default now(),
    updated_at          timestamptz,
    deleted_at          timestamptz,

    id                  uuid        default gen_random_uuid() primary key,
    auth_provider       varchar(40),
    auth_provider_id    varchar(255),
    auth_provider_token varchar(255),
    first_name          varchar(40),
    last_name           varchar(40),
    email               varchar(40),

    status              int
);

create table if not exists account_organizations
(
    created_at      timestamptz default now(),

    account_id      uuid references accounts (id) on delete cascade,
    organization_id uuid references organizations (id) on delete cascade,
    primary key (account_id, organization_id)
);

create table if not exists permissions
(
    id          uuid default gen_random_uuid() primary key,
    name        varchar(255) unique,
    description varchar(255),
    subject     varchar(40),
    endpoint    varchar(255),
    action      varchar(255)
);

create table if not exists roles
(
    created_at      timestamptz default now(),
    updated_at      timestamptz,

    id              uuid        default gen_random_uuid() primary key,
    organization_id uuid references organizations (id) on delete cascade,
    name            varchar(255),
    description     varchar(255),
    slug            varchar(255),
    constraint role_organization_name_constraint unique (organization_id, name),
    constraint role_organization_slug_constraint unique (organization_id, slug)
);

create table if not exists role_permissions
(
    created_at    timestamptz default now(),

    role_id       uuid references roles (id) on delete cascade,
    permission_id uuid references permissions (id) on delete cascade,
    primary key (role_id, permission_id)
);

create table if not exists account_permissions
(
    created_at      timestamptz default now(),

    account_id      uuid references accounts (id) on delete cascade,
    permission_id   uuid references permissions (id) on delete cascade,

    organization_id uuid references organizations (id) on delete cascade,

    primary key (account_id, permission_id, organization_id)
);

create table if not exists account_roles
(
    created_at timestamptz default now(),

    account_id uuid references accounts (id) on delete cascade,
    role_id    uuid references roles (id) on delete cascade,
    primary key (account_id, role_id)
);

create table if not exists tokens
(
    created_at    timestamptz default now(),
    id            uuid        default gen_random_uuid() primary key,
    account_id    uuid references accounts (id) on delete cascade,
    access_token  text        not null,
    refresh_token text        not null,
    expired_at    timestamptz not null
);
create index if not exists idx_account_id on tokens using btree (account_id);
create index if not exists idx_access_token on tokens using hash (access_token);
create index if not exists idx_refresh_token on tokens using hash (refresh_token);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
drop index idx_refresh_token;
drop index idx_access_token;
drop index idx_account_id;
drop table if exists tokens;
drop table if exists role_permissions;
drop table if exists account_permissions;
drop table if exists account_roles;
drop table if exists permissions;
drop table if exists roles;
drop table if exists accounts;
drop table if exists organizations;
-- +goose StatementEnd
