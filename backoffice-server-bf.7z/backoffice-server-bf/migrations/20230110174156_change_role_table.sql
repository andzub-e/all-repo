-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
alter table roles drop constraint role_organization_slug_constraint;
alter table roles rename column slug to type;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
