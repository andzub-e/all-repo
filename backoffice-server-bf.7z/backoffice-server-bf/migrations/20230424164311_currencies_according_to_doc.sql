-- +goose Up
-- +goose StatementBegin
insert into currency_multipliers(created_at, updated_at, provider_id, integrator_id, title, multiplier)
values
-- ejaw -> mock
(now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'huf', 300),
(now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'nzd', 1),
(now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'nok', 10),
(now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'pln', 2),
(now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'zar', 10),
(now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'brl', 5),
(now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'pen', 4),
(now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'clp', 900),
(now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'mxn', 20),
-- lemon -> mock
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'huf', 300),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'nzd', 1),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'nok', 10),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'pln', 2),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'zar', 10),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'brl', 5),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'pen', 4),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'clp', 900),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'mxn', 20),
-- bf -> mock
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'huf', 300),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'nzd', 1),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'nok', 10),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'pln', 2),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'zar', 10),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'brl', 5),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'pen', 4),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'clp', 900),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '4ecbb628-a60d-11ed-afa1-0242ac120002', 'mxn', 20),
-- lemon -> lemon
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'huf', 300),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'nzd', 1),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'nok', 10),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'pln', 2),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'zar', 10),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'brl', 5),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'pen', 4),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'clp', 900),
(now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', '29c3849e-ed81-4cd5-a3db-412c447378b6', 'mxn', 20),
-- bf -> bf
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'huf', 300),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'nzd', 1),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'nok', 10),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'pln', 2),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'zar', 10),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'brl', 5),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'pen', 4),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'clp', 900),
(now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', '51e9f87e-887d-4d24-a5ec-b15b9d8bf121', 'mxn', 20);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
