-- +goose Up
-- +goose StatementBegin
insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('lucky-skull-bonanza',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/lucky-skull-bonanza/api',
        'https://dev.heronbyte.com/lucky-skull-bonanza/', 'db403ccc-aca6-4762-b632-c7cc479a31a5');

insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('fortune-777-respin',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/fortune-777-respin/api',
        'https://dev.heronbyte.com/fortune-777-respin/', 'db403ccc-aca6-4762-b632-c7cc479a31a5');

insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('cleos-riches-flexiways',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/cleos-riches-flexiways/api',
        'https://dev.heronbyte.com/cleos-riches-flexiways/', 'db403ccc-aca6-4762-b632-c7cc479a31a5');

insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('wild-dragon-respin',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/wild-dragon-respin/api',
        'https://dev.heronbyte.com/wild-dragon-respin/', 'db403ccc-aca6-4762-b632-c7cc479a31a5');

insert into games (name, jurisdictions, currencies, languages, user_locales, api_url, client_url, organization_id)
values ('sweet-mystery-flexiways',
        '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}', '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/sweet-mystery-flexiways/api',
        'https://dev.heronbyte.com/sweet-mystery-flexiways/', 'db403ccc-aca6-4762-b632-c7cc479a31a5');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
