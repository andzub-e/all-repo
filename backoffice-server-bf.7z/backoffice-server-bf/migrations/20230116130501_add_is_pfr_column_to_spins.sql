-- +goose Up
-- +goose StatementBegin
alter table spins add column is_pfr bool default false;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
alter table spins drop column is_pfr;
-- +goose StatementEnd
