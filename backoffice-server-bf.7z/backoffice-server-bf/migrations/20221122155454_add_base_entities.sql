-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';

insert into accounts (created_at, updated_at, id, auth_provider, auth_provider_id, auth_provider_token, first_name,
                      last_name, email, status)
values (now(), now(), 'bc5449ac-40e0-4d46-91b3-9df70f7f1519', 'email', 'admin',
        '$2a$15$4Tbu2DDyt3DNRYtlecCw3.EMYgWZJg9AvL/A3EQMeRzSFJuxEF18O', 'Admin', '', 'admin', 1);

insert into organizations(created_at, updated_at, id, name, type, status)
values (now(), now(), '4cf6272a-72b5-44c3-a3b3-f3d1bba73500', 'ejaw', 'provider', 1),
       (now(), now(), '036cd780-d655-46ce-8713-f8e734bc7372', 'lemon', 'provider', 1),
       (now(), now(), '1010aef9-96a1-4eca-ac15-d02e59a70042', 'bf', 'provider', 1);

insert into account_organizations(created_at, account_id, organization_id)
values (now(), 'bc5449ac-40e0-4d46-91b3-9df70f7f1519', '4cf6272a-72b5-44c3-a3b3-f3d1bba73500'),
       (now(), 'bc5449ac-40e0-4d46-91b3-9df70f7f1519', '036cd780-d655-46ce-8713-f8e734bc7372'),
       (now(), 'bc5449ac-40e0-4d46-91b3-9df70f7f1519', '1010aef9-96a1-4eca-ac15-d02e59a70042');

insert into roles(created_at, updated_at, id, name, description, slug)
values (now(), now(), 'c69274d6-2c9e-4980-a8e6-47a1ff60d7a6', 'Owner', 'The main backoffice user', 'root');

insert into account_roles(account_id, role_id)
values ('bc5449ac-40e0-4d46-91b3-9df70f7f1519', 'c69274d6-2c9e-4980-a8e6-47a1ff60d7a6');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
