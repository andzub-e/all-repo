-- +goose Up
-- +goose StatementBegin
update organizations set api_key = '85c42cda-9d6a-4ad6-bceb-b316b40d508c' where id = '4cf6272a-72b5-44c3-a3b3-f3d1bba73500';
update organizations set api_key = 'fb9e57d9-d62a-4f18-be64-4adbf63d17bc' where id = '036cd780-d655-46ce-8713-f8e734bc7372';
update organizations set api_key = '61dac939-a3e6-4b67-91e1-a2e17671541b' where id = '1010aef9-96a1-4eca-ac15-d02e59a70042';
update organizations set api_key = 'd2f44eae-b6c4-4a14-b547-d074724ae165' where id = '4ecbb628-a60d-11ed-afa1-0242ac120002';
update organizations set api_key = '59544f3d-da61-431a-8d9a-94782af6e3ae' where id = 'b400a99c-963c-49ac-acf1-4df26c018301';
update organizations set api_key = '410a8547-2ea7-49a5-b108-5effe330fbd5' where id = '51e9f87e-887d-4d24-a5ec-b15b9d8bf121';
update organizations set api_key = 'fe587176-e887-47a0-bb75-9f39ff5286fa' where id = '29c3849e-ed81-4cd5-a3db-412c447378b6';
update organizations set api_key = '747d2c07-793a-414b-963a-9d4f1a8196d6' where id = '1e6fab03-8a91-4417-beba-faa3af8dbc51';
update organizations set api_key = '61268696-359a-4117-ae00-61fc39454e70' where id = 'ce1b0a8c-a6da-454f-a8ff-f9094584dc4c';
update organizations set api_key = 'db63639b-ea66-430c-ab83-a78a7f6803b2' where id = 'db403ccc-aca6-4762-b632-c7cc479a31a5';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
