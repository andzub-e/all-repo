-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
alter table games add column is_public boolean default true;
alter table games add column is_statistic_shown boolean default true;
update games set is_statistic_shown = false where name in ('aviator', 'robotics', 'spells-streak');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
alter table games drop column is_public;
alter table games drop column is_statistic_shown;
-- +goose StatementEnd
