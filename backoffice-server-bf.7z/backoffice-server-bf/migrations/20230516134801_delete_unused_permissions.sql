-- +goose Up
-- +goose StatementBegin
delete from permissions where name = 'Get account';
delete from permissions where name = 'Edit account';
delete from permissions where name = 'Get role';
delete from permissions where name = 'Edit role';
delete from permissions where name = 'Assign role to account';
delete from permissions where name = 'Revoke role to account';
delete from permissions where name = 'Spin details';
delete from permissions where name = 'Currencies';
delete from permissions where name = 'Financial CSV';
delete from permissions where name = 'Sessions CSV';
delete from permissions where name = 'Create currency multiplier';
delete from permissions where name = 'Delete currency multiplier';
delete from permissions where name = 'Edit provider currency configs';
delete from permissions where name = 'Sessions XLSX';
delete from permissions where name = 'Spins XLSX';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
