-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
alter table spins rename column operator to integrator;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
