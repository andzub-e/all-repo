-- +goose Up
-- +goose StatementBegin
create table wager_sets (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,

    id uuid primary key,
    organization_id uuid references organizations(id),
    name varchar(255) not null,
    wager_levels int[],
    default_wager int,

    is_active boolean,

    unique (organization_id, name)
);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
drop table wager_sets;
-- +goose StatementEnd
