-- +goose Up
-- +goose StatementBegin
insert into permissions (name, description, subject, endpoint, action)
values ('Get games', 'Get organization`s games', 'backoffice', '/dictionaries/games', 'VIEW'),
        ('Get hosts', 'Get hosts from which we receive spins', 'backoffice', '/dictionaries/hosts', 'VIEW');

call refresh_admin_permissions();
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
