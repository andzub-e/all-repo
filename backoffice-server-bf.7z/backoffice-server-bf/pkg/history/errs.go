package history

import "errors"

var (
	ErrSpinNotFound = errors.New("spin not found")
)
