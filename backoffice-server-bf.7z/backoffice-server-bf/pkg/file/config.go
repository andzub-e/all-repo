package file

import "time"

type Config struct {
	TTL time.Duration
}
