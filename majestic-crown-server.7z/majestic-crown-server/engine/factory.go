package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine/utils"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"encoding/json"
	"fmt"
	"github.com/samber/lo"
	"github.com/sarulabs/di"
)

type SpinFactory struct {
	rand         rng.Client
	cheatPayload interface{}
}

type Info struct {
	BaseReels [][]string `json:"base_reels"`
}

func GameBoot(ctn di.Container, config *engine.Config) *engine.Bootstrap {
	switch config.RTP {
	case rtp94:
		baseReels = reels94
	case rtp96:
		baseReels = reels96

	default:
		panic(fmt.Sprintf("can't specify RTP: %v", config.RTP))
	}

	rand := ctn.Get(constants.RNGName).(rng.Client)
	factory := NewSpinFactory(rand)

	return &engine.Bootstrap{
		SpinFactory: factory,

		HTTPTransport:      true,
		WebsocketTransport: true,

		NeedLastSpin:        false,
		FreeSpinsFeature:    true,
		GambleAnyWinFeature: true,

		GambleAnyWinMaxTimes: 4,
		GambleAnyWinMaxWager: 125 * 1000 * 1000,
		GameMaxWager:         50 * 1000, // 50 $

		HistoryHandlingType: engine.SequentialRestoring,

		EngineInfo: Info{BaseReels: baseReels},
	}
}

func NewSpinFactory(rand rng.Client) *SpinFactory {
	factory := &SpinFactory{rand: rand}

	return factory
}

func (s SpinFactory) Generate(wager int64, parameters interface{}) (engine.Spin, engine.RestoringIndexes, error) {
	//zap.S().Info(s.lastSpin)

	stops, err := s.getStops(baseReels)
	if err != nil {
		return nil, nil, err
	}

	sb := SpinBase{WagerVal: wager}
	sb.Window.compute(baseReels, stops)
	sb.ReelsWithCrown = sb.Window.getReelsWithWild()

	windowForCalc := sb.Window.SetCrownReels(sb.ReelsWithCrown)
	//zap.S().Info(windowForCalc)

	sb.Win, sb.PayLinesToShow = s.calcPayLinesToShow(wager, windowForCalc)

	sb.Bonus, err = s.BonusGenerate(wager, sb.ReelsWithCrown)
	if err != nil {
		return nil, nil, err
	}

	return &sb, &RestoringIndexes{}, nil
}

func (s SpinFactory) BonusGenerate(wager int64, reelsWithCrown []int) ([]SpinBonus, error) {
	bonus := []SpinBonus{}
	previousWildedReels := make([]int, len(reelsWithCrown))
	copy(previousWildedReels, reelsWithCrown)

	if len(reelsWithCrown) == 0 {
		return nil, nil
	}

	for {
		stops, err := s.getStops(wildedReels)
		if err != nil {
			return nil, err
		}

		spinBonus := SpinBonus{ReelsWithCrown: append([]int{}, previousWildedReels...)}
		spinBonus.Window.compute(wildedReels, stops)

		reelsWithWild := spinBonus.Window.getReelsWithWild()

		_, dif := lo.Difference(spinBonus.ReelsWithCrown, reelsWithWild)
		if len(dif) != 0 {
			spinBonus.NewReelTriggered = dif
			spinBonus.ReelsWithCrown = append(spinBonus.ReelsWithCrown, reelsWithWild...)
			spinBonus.ReelsWithCrown = lo.Uniq(spinBonus.ReelsWithCrown)
		}

		windowForCalc := spinBonus.Window.SetCrownReels(spinBonus.ReelsWithCrown)
		spinBonus.Win, spinBonus.PayLinesToShow = s.calcPayLinesToShow(wager, windowForCalc)

		bonus = append(bonus, spinBonus)

		previousWildedReels = make([]int, len(spinBonus.ReelsWithCrown))
		copy(previousWildedReels, spinBonus.ReelsWithCrown)

		if len(spinBonus.NewReelTriggered) == 0 {
			break
		}
	}

	return bonus, nil
}

func (s SpinFactory) GambleAnyWin(spin engine.Spin, parameters interface{}) (engine.Spin, error) {
	if spin.Award() == 0 {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin, ok := spin.(*SpinBase)
	if !ok {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin = typedSpin.DeepCopy()

	payload, err := parseGambleParams(parameters)

	if payload.Color != GambleRed && payload.Color != GambleBlack {
		return nil, errs.ErrBadDataGiven
	}

	if err != nil {
		return nil, err
	}

	res, err := s.rand.Rand(2)
	if err != nil {
		return nil, err
	}

	award := typedSpin.Award() + typedSpin.BonusAward()
	g := Gamble{ExpectColor: payload.Color, WagerVal: award}

	c := Cheats{}
	if s.cheatPayload != nil {
		if err := c.Eval(s.cheatPayload); err != nil {
			return nil, err
		}
	}

	if c.GambleColor == GambleRed || c.GambleColor == GambleBlack {
		g.RealColor = c.GambleColor
	} else if res == 1 {
		g.RealColor = GambleRed
	} else {
		g.RealColor = GambleBlack
	}

	g.compute()

	typedSpin.Gambles = append(typedSpin.Gambles, g)

	return typedSpin, nil
}

func (s SpinFactory) WithBoundLastSpin(spin engine.Spin) engine.SpinFactory {
	return &s
}

func (s SpinFactory) WithCheat(cheat interface{}) engine.SpinFactory {
	s.cheatPayload = cheat

	return &s
}

func (s SpinFactory) UnmarshalJSONSpin(bytes []byte) (engine.Spin, error) {
	spin := SpinBase{}
	err := json.Unmarshal(bytes, &spin)

	return &spin, err
}

func (s SpinFactory) UnmarshalJSONRestoringIndexes(bytes []byte) (engine.RestoringIndexes, error) {
	restoringIndexes := RestoringIndexes{}
	err := json.Unmarshal(bytes, &restoringIndexes)

	return &restoringIndexes, err
}

func (s *SpinFactory) getStops(reels [][]string) ([]int, error) {
	if s.cheatPayload != nil {
		c := Cheats{}
		if err := c.Eval(s.cheatPayload); err != nil {
			return nil, err
		}

		if len(c.Stops) != len(reels) {
			return nil, errs.ErrBadDataGiven
		}

		for i := range c.Stops {
			if c.Stops[i] > len(reels[i]) {
				return nil, errs.ErrBadDataGiven
			}
		}

		return c.Stops, nil
	}

	req := lo.Map(reels, func(item []string, index int) uint64 {
		return uint64(len(item))
	})

	res, err := s.rand.RandSlice(req)
	if err != nil {
		return nil, err
	}

	return lo.Map(res, func(item uint64, index int) int {
		return int(item)
	}), nil
}

func (s *SpinFactory) calcPayLinesToShow(wager int64, window *Window) (award int64, payLinesToShow []PayLine) {
	leftPls := utils.CalcBasePayLines[int, string](payLines, window, AwardGetter{Wager: wager}, nil, &WildSymbol, utils.LeftToRightDirection)
	rightPls := utils.CalcBasePayLines[int, string](payLines, window, AwardGetter{Wager: wager}, nil, &WildSymbol, utils.RightToLeftDirection)

	rightPls = lo.Filter(rightPls, func(left utils.PayLine[int, string], index int) bool {
		if lo.ContainsBy(leftPls, func(right utils.PayLine[int, string]) bool {
			return left.PayLineIndex == right.PayLineIndex && len(left.PayLineItems) == windowWidth
		}) {

			return false
		}

		return true
	})

	pls := append(leftPls, rightPls...)

	lo.ForEach(pls, func(item utils.PayLine[int, string], index int) {
		payLinesToShow = append(payLinesToShow, PayLine{
			Symbol:    item.PaySymbol,
			Direction: item.Direction,

			PayLineIndex: item.PayLineIndex,
			Indexes:      item.PayLineItems,
			Award:        item.Award,
		})

		award += item.Award
	})

	return award, payLinesToShow
}
