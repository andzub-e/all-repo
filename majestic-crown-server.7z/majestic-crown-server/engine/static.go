package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine/utils"
	"github.com/samber/lo"
	"go.uber.org/zap"
)

const (
	rtp94 = "94"
	rtp96 = "96"

	windowHeight          = 3
	windowWidth           = 5
	multiplicationDivider = 1
)

var (
	WildSymbol = "w"
)

var multipliers = map[string]map[int]int64{
	"c": {3: 1, 4: 2, 5: 10},
	"l": {3: 1, 4: 2, 5: 10},
	"m": {3: 1, 4: 3, 5: 15},
	"p": {3: 1, 4: 3, 5: 15},
	"g": {3: 2, 4: 5, 5: 20},
	"o": {3: 2, 4: 5, 5: 20},
	"b": {3: 5, 4: 20, 5: 50},
	"s": {3: 10, 4: 50, 5: 100},
}

var payLines = [][]int{
	{0, 1, 2, 3, 4},
	{5, 6, 7, 8, 9},
	{10, 11, 12, 13, 14},
	{0, 6, 12, 8, 4},
	{10, 6, 2, 8, 14},

	{5, 11, 12, 13, 9},
	{5, 1, 2, 3, 9},
	{10, 11, 7, 3, 4},
	{0, 1, 7, 13, 14},
	{10, 6, 7, 8, 4},
}

var baseReels = [][]string{}
var wildedReels = [][]string{
	{"c", "c", "c", "c", "s", "s", "s", "s", "p", "p", "p", "p", "g", "g", "g", "g", "c", "c", "c", "c", "c", "p", "p", "p", "p", "p", "o", "o", "o", "m", "m", "m", "m", "b", "b", "b", "l", "l", "l", "l", "g", "g", "g", "g", "g", "c", "c", "c", "c", "p", "p", "p", "p"},
	{"m", "m", "m", "b", "w", "m", "b", "b", "b", "l", "l", "l", "l", "g", "g", "g", "p", "p", "p", "p", "m", "m", "m", "m", "l", "l", "l", "l", "o", "o", "o", "o", "l", "l", "l", "l", "m", "m", "m", "m", "s", "s", "s", "s", "l", "l", "l", "l", "m", "m", "m", "m", "o", "o", "o", "o", "o", "c", "c", "c", "c", "b", "b", "b", "m"},
	{"s", "s", "s", "o", "w", "s", "o", "o", "o", "o", "l", "l", "l", "l", "l", "g", "g", "g", "g", "p", "p", "p", "p", "c", "c", "c", "c", "c", "m", "m", "m", "m", "o", "o", "o", "o", "p", "p", "p", "p", "p", "g", "g", "g", "g", "m", "m", "m", "m", "m", "c", "c", "c", "c", "c", "b", "b", "b", "b", "b", "l", "l", "l", "l", "l"},
	{"b", "b", "b", "p", "w", "b", "p", "p", "p", "p", "o", "o", "o", "c", "c", "c", "c", "m", "m", "m", "m", "c", "c", "c", "c", "p", "p", "p", "p", "g", "g", "g", "g", "s", "s", "s", "s", "p", "p", "p", "p", "g", "g", "g", "g", "g", "c", "c", "c", "c", "b", "b", "b", "l", "l", "l", "l", "c", "c", "c", "c", "p", "p", "p", "p"},
	{"l", "l", "l", "l", "m", "m", "m", "m", "p", "p", "p", "p", "c", "c", "c", "c", "l", "l", "l", "l", "l", "o", "o", "o", "o", "m", "m", "m", "m", "m", "b", "b", "b", "g", "g", "g", "s", "s", "s", "s", "l", "l", "l", "l", "o", "o", "o", "o", "o", "m", "m", "m", "m"},
}

type Window [][]string

// WrapWindow func for stupid generics (or for stupid me)
func WrapWindow(w *Window) utils.Window[int, string] {
	return w
}

func (w *Window) GetSymbol(reelIndex int, payItem int) string {
	return w.symbol(payItem)
}

func (w *Window) GetByIndexes(reelIndex, symbolIndex int) (int, string) {
	return reelIndex*windowWidth + symbolIndex, (*w)[reelIndex][symbolIndex]
}

func (w *Window) GetHeight() int {
	return windowHeight
}

func (w *Window) GetWidth() int {
	return windowWidth
}

func (w *Window) compute(reels [][]string, stops []int) {
	*w = lo.Map(stops, func(stop int, index int) []string {
		reel := reels[index]
		reelLen := len(reel)

		windowLine := make([]string, windowHeight)
		for j := 0; j < windowHeight; j++ {
			windowLine[j] = reel[(stop+j)%reelLen]
		}

		return windowLine
	})
}

func (w Window) symbol(payIndex int) string {
	position, reel := payIndex/windowWidth, payIndex%windowWidth

	return w[reel][position]
}

func (w Window) getReelsWithWild() []int {
	reelsWithWild := make([]int, 0)

	for i := 0; i < windowWidth; i++ {
		if lo.Contains(w[i], WildSymbol) {
			reelsWithWild = append(reelsWithWild, i)
		}
	}

	return reelsWithWild
}

func (w Window) deepCopy() Window {
	dc := make(Window, len(w))

	for i := 0; i < len(w); i++ {
		line := make([]string, len(w[i]))
		copy(line, w[i])
		dc[i] = line
	}

	return dc
}

func (w Window) SetCrownReels(reels []int) *Window {
	w = w.deepCopy()

	for _, reelIndex := range reels {
		if reelIndex < windowWidth && reelIndex >= 0 {
			w[reelIndex] = lo.Map(w[reelIndex], func(item string, index int) string {
				return WildSymbol
			})
		} else {
			zap.S().Errorf("wrong reel indexes: %v", reels)
		}
	}

	return &w
}

type AwardGetter struct {
	Wager int64
}

func (a AwardGetter) GetAward(symbol string, size int) int64 {
	mul := multipliers[symbol][size]

	return mul * a.Wager / multiplicationDivider
}

func awardBySymbolAndCount(symbol string, count int, wager int64) int64 {
	mul := multipliers[symbol][count]

	return mul * wager / multiplicationDivider
}
