package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"encoding/json"
)

type RestoringIndexes struct {
	IsShownVal    bool `json:"is_shown"`
	IsGambleShown bool `json:"is_gamble_shown"`
	BaseIndex     int  `json:"base_index"`
	BonusIndex    int  `json:"bonus_index"`
}

func (r *RestoringIndexes) IsShown(spin engine.Spin) bool {
	return r.IsShownVal
}

func (r *RestoringIndexes) Update(payload interface{}) error {
	bytes, err := json.Marshal(payload)
	if err != nil {
		return err
	}

	err = json.Unmarshal(bytes, r)
	if err != nil {
		return err
	}

	if r.BaseIndex < 0 || r.BonusIndex < 0 {
		return errs.ErrBadDataGiven
	}

	return nil
}
