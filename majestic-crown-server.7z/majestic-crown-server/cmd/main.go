package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
	"majestic-crown-server/buildvar"
	"majestic-crown-server/engine"
)

func main() {
	application, err := app.NewApp("config.yml", buildvar.Tag, buildvar.Debug, buildvar.IsCheatsAvailable, engine.GameBoot)

	if err != nil {
		panic(err)
	}

	if err := application.Run(); err != nil {
		panic(err)
	}
}
