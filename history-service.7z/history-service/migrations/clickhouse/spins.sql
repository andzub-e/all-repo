create table if not exists default.spins
(
    created_at        UInt8,
    updated_at Nullable(UInt8),

    host              String,
    client_ip         String,
    user_agent        String,
    request           JSON,

    id                UUID,
    game_id           UUID,
    game              String,
    session_token     UUID,
    integrator        String,
    provider          String,
    internal_user_id  String,
    external_user_id  String,
    currency          String,

    start_balance     Float64,
    end_balance       Float64,
    wager             Float64,
    base_award        Float64,
    bonus_award       Float64,

    details           JSON,
    restoring_indexes JSON,

    is_shown          Bool,
    is_pfr            Bool
)
    engine = MergeTree()
        order by (created_at, )
        partition by toYYYYMMDD(created_at);