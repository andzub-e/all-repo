-- +goose Up
-- +goose StatementBegin
alter table spins add column operator varchar;
update spins set operator = spins.integrator where operator is null;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
