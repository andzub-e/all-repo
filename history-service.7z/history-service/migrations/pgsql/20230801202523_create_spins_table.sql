-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
create table if not exists spins
(
    created_at        timestamptz default current_timestamp,
    updated_at        timestamptz default null,

    country           varchar,
    host              varchar,
    client_ip         varchar,
    user_agent        varchar,
    request           jsonb,

    id                uuid,
    game_id           uuid,
    game              varchar(128),
    session_token     uuid,
    transaction_id    uuid,
    integrator        varchar(50),
    provider          varchar(50),
    internal_user_id  uuid,
    external_user_id  varchar(128),
    currency          varchar(5),

    start_balance     bigint,
    end_balance       bigint,
    wager             bigint,
    base_award        bigint,
    bonus_award       bigint,

    details           jsonb,
    restoring_indexes jsonb,

    is_shown          bool,
    is_pfr            bool,

    primary key (id)
);

create index if not exists idx_spins_session_token on spins using hash (session_token);
create index if not exists idx_spins_game_id on spins using hash (game_id);
create index if not exists idx_spins_game on spins using hash (game);
create index if not exists idx_spins_currency on spins using hash (currency);
create index if not exists idx_spins_integrator on spins using hash (integrator);
create index if not exists idx_spins_provider on spins using hash (provider);
create index if not exists idx_spins_host on spins using hash (host);
create index if not exists idx_spins_external_user_id on spins using hash (external_user_id);
create index if not exists idx_spins_internal_user_id on spins using hash (internal_user_id);
create index if not exists idx_spins_created_at on spins using btree (created_at);

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
drop table if exists spins;
drop index if exists idx_spins_session_token;
drop index if exists idx_spins_game_id;
drop index if exists idx_spins_currency;
drop index if exists idx_spins_integrator;
drop index if exists idx_spins_provider;
drop index if exists idx_spins_host;
drop index if exists idx_spins_external_user_id;
drop index if exists idx_spins_internal_user_id;
-- +goose StatementEnd
