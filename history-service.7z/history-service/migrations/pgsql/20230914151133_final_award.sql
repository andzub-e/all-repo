-- +goose Up
-- +goose StatementBegin
alter table spins add column final_award bigint;
update spins set final_award = base_award + bonus_award;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
