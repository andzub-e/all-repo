package main

import (
	"context"
	"go.uber.org/zap"
	"history/internal/constants"
	"history/internal/container"
	"history/internal/transport/http"
	"history/internal/transport/rpc"
	"history/pkg/tracer"
	"history/utils"
	"log"
	"time"
)

func main() {
	now := time.Now()
	ctx, cancel := context.WithCancel(context.Background())
	app := container.Build(ctx)
	_ = app.Get(constants.LoggerName).(*zap.Logger)

	zap.S().Info("Starting application...")

	server := app.Get(constants.HTTPServerName).(*http.Server)

	go server.Run()

	rpcHandler := app.Get(constants.RPCServerName).(*rpc.Handler)
	tr := app.Get(constants.TracerName).(*tracer.JaegerTracer)

	go rpc.StartUnsecureRPCServer(rpcHandler, tr)

	zap.S().Infof("Up and running (%s)", time.Since(now))
	zap.S().Infof("Got %s signal. Shutting down...", <-utils.WaitTermSignal())

	if err := app.Delete(); err != nil {
		log.Println(err)
	}

	cancel()

	zap.S().Info("Service stopped.")
}
