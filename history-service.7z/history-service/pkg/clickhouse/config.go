package clickhouse

import "time"

type Config struct {
	Addr             []string
	Database         string
	Username         string
	Password         string
	Debug            bool
	DialTimeout      time.Duration
	MaxOpenConns     int
	MaxIdleConns     int
	ConnMaxLifetime  time.Duration
	MaxExecutionTime int
	BlockBufferSize  uint8
}
