package utils

import "github.com/mitchellh/mapstructure"

func StructToMap[T any](s *T) (map[string]interface{}, error) {
	m := map[string]interface{}{}

	if err := mapstructure.Decode(s, &m); err != nil {
		return nil, err
	}

	return m, nil
}
