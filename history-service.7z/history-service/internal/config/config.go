package config

import (
	"fmt"
	"github.com/spf13/viper"
	"history/internal/transport/http"
	"history/internal/transport/rpc"
	"history/pkg/exchange"
	"history/pkg/pgsql"
	"history/pkg/redis"
	"history/pkg/tracer"
	"sync"
)

var (
	err    error
	config *Config
	once   sync.Once
)

type Config struct {
	HTTPConfig     *http.Config
	RPCConfig      *rpc.Config
	PgSQLConfig    *pgsql.Config
	ExchangeConfig *exchange.Config
	RedisConfig    *redis.Config
	TracerConfig   *tracer.Config
}

func New() (*Config, error) {
	once.Do(func() {
		config = &Config{}

		viper.AddConfigPath(".")
		viper.SetConfigName("config")

		if err = viper.ReadInConfig(); err != nil {
			return
		}

		httpConfig := viper.Sub("server")
		rpcConfig := viper.Sub("rpc")
		databaseConfig := viper.Sub("database")
		exchangeConfig := viper.Sub("exchange")
		redisConfig := viper.Sub("redis")
		tracerConfig := viper.Sub("tracer")

		if err = parseSubConfig(httpConfig, &config.HTTPConfig); err != nil {
			return
		}

		if err = parseSubConfig(rpcConfig, &config.RPCConfig); err != nil {
			return
		}

		if err = parseSubConfig(databaseConfig, &config.PgSQLConfig); err != nil {
			return
		}

		if err = parseSubConfig(exchangeConfig, &config.ExchangeConfig); err != nil {
			return
		}

		if err = parseSubConfig(redisConfig, &config.RedisConfig); err != nil {
			return
		}

		if err = parseSubConfig(tracerConfig, &config.TracerConfig); err != nil {
			return
		}
	})

	return config, err
}

func parseSubConfig[T any](subConfig *viper.Viper, parseTo *T) error {
	if subConfig == nil {
		return fmt.Errorf("can not read %T config: subconfig is nil", parseTo)
	}

	if err := subConfig.Unmarshal(parseTo); err != nil {
		return err
	}

	return nil
}
