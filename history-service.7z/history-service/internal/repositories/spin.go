package repositories

import (
	"context"
	"github.com/google/uuid"
	"history/internal/entities"
)

type SpinRepository interface {
	FindBy(ctx context.Context, games []string, params map[string]interface{}) (spin *entities.Spin, err error)
	Upsert(ctx context.Context, spin entities.Spin) error
	AwardAndWager(ctx context.Context, games []string, filters map[string]interface{}) (rep map[entities.FinancialReportKey]*entities.RawFinancialReport, err error)
	SpinAndUserCount(ctx context.Context, games []string, filters map[string]interface{}) (rep map[entities.FinancialReportKey]*entities.RawUserStatReport, err error)
	Paginate(ctx context.Context, games []string, filters map[string]interface{}, order string, limit, page uint64) (pagination entities.Pagination[entities.Spin], err error)
	PaginateGrouped(ctx context.Context, games []string, filters map[string]interface{}, order string, limit, page uint64, groupBy []string) (pagination entities.Pagination[entities.GroupedSpin], err error)
	PaginateGameSession(ctx context.Context, games []string, filters map[string]interface{}, order string, limit, page uint64) (pagination entities.Pagination[entities.GameSession], err error)

	AggregatedReportByGame(ctx context.Context, games []string, filters map[string]interface{}) ([]*entities.SimpleAggregatedReportByGame, error)
	AggregatedReportByCountry(ctx context.Context, games []string, filters map[string]interface{}) ([]*entities.SimpleAggregatedReportByCountry, error)

	All(ctx context.Context, games []string, filters map[string]interface{}) ([]*entities.Spin, error)
	AllGameSession(ctx context.Context, games []string, filters map[string]interface{}) ([]*entities.GameSession, error)
	GetSession(ctx context.Context, games []string, id uuid.UUID) (session *entities.GameSession, err error)

	Currencies(ctx context.Context, filters map[string]interface{}) ([]string, error)
	Hosts(ctx context.Context, games []string) ([]string, error)
	IntegratorOperatorsMap(ctx context.Context, games []string) (map[string][]string, error)
}
