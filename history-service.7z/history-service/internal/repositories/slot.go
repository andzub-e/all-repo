package repositories

import (
	"context"
	"github.com/google/uuid"
	"history/internal/entities"
)

type SlotRepository interface {
	Create(ctx context.Context, record *entities.Spin) error
	Update(ctx context.Context, record *entities.Spin) error

	Pagination(ctx context.Context, internalUserID uuid.UUID, game string, limit, page uint64) (*entities.Pagination[entities.Spin], error)

	GetByID(ctx context.Context, id uuid.UUID) (*entities.Spin, error)
	LastRecord(ctx context.Context, internalUserID uuid.UUID, game string) (*entities.Spin, error)
	LastRecords(ctx context.Context, internalUserID uuid.UUID, game string) ([]*entities.Spin, error)
	LastRecordByWager(ctx context.Context, internalUserID uuid.UUID, game string, wager uint64) (*entities.Spin, error)
}
