package entities

import (
	"history/internal/constants"
	"history/pkg/history"
)

type FinancialFilters struct {
	Integrator     string `json:"integrator,omitempty" form:"integrator" mapstructure:"integrator,omitempty"`
	Operator       string `json:"operator,omitempty" form:"operator" mapstructure:"operator,omitempty"`
	GameName       string `json:"game,omitempty" form:"game" mapstructure:"game,omitempty"`
	StartingFrom   string `json:"starting_from,omitempty" form:"starting_from" validate:"custom_datetime" mapstructure:"starting_from,omitempty"`
	EndingAt       string `json:"ending_at,omitempty" form:"ending_at" validate:"custom_datetime" mapstructure:"ending_at,omitempty"`
	SessionToken   string `json:"session_token" form:"session_token" mapstructure:"session_token,omitempty"`
	RoundID        string `json:"round_id" form:"round_id" mapstructure:"round_id,omitempty"`
	Host           string `json:"host" form:"host" mapstructure:"host,omitempty"`
	ExternalUserID string `json:"external_user_id" form:"external_user_id" mapstructure:"external_user_id,omitempty"`
	IsDemo         *bool  `json:"is_demo,omitempty" mapstructure:"is_demo,omitempty"`
}

func FinancialFiltersFromHistory(filters *history.Filters) *FinancialFilters {
	fl := &FinancialFilters{
		Integrator:     filters.Integrator,
		Operator:       filters.Operator,
		GameName:       filters.Game,
		SessionToken:   filters.SessionToken,
		RoundID:        filters.RoundId,
		Host:           filters.Host,
		ExternalUserID: filters.ExternalUserId,
		IsDemo:         filters.IsDemo,
	}

	if filters.StartingFrom != nil {
		fl.StartingFrom = filters.StartingFrom.AsTime().Format(constants.TimeLayout)
	}

	if filters.EndingAt != nil {
		fl.EndingAt = filters.EndingAt.AsTime().Format(constants.TimeLayout)
	}

	return fl
}

type AggregateFilters struct {
	Currency string `json:"currency" form:"currency" validate:"required" mapstructure:"-"`

	Integrator   string  `json:"integrator,omitempty" form:"integrator" mapstructure:"integrator,omitempty"`
	Operator     string  `json:"operator,omitempty" form:"operator" mapstructure:"operator,omitempty"`
	StartingFrom string  `json:"starting_from,omitempty" form:"starting_from" validate:"custom_datetime" mapstructure:"starting_from,omitempty"`
	EndingAt     string  `json:"ending_at,omitempty" form:"ending_at" validate:"custom_datetime" mapstructure:"ending_at,omitempty"`
	IsPFR        *bool   `json:"is_pfr,omitempty" mapstructure:"is_pfr,omitempty"`
	IsDemo       *bool   `json:"is_demo,omitempty" mapstructure:"is_demo,omitempty"`
	Game         *string `json:"game,omitempty" mapstructure:"game,omitempty"`
	Country      *string `json:"Country,omitempty" mapstructure:"Country,omitempty"`
}

func FromHistoryAggFilters(f *history.GetAggregatedReportFilters) *AggregateFilters {
	fl := &AggregateFilters{
		Integrator: f.Integrator,
		Operator:   f.Operator,
		Currency:   f.ConvertCurrency,
		IsPFR:      f.IsPfr,
		IsDemo:     f.IsDemo,
		Game:       f.Game,
		Country:    f.Country,
	}

	if f.StartingFrom != nil {
		fl.StartingFrom = f.StartingFrom.AsTime().Format(constants.TimeLayout)
	}

	if f.EndingAt != nil {
		fl.EndingAt = f.EndingAt.AsTime().Format(constants.TimeLayout)
	}

	return fl
}
