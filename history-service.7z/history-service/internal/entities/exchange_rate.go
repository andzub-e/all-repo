package entities

import "time"

type ExchangeRate struct {
	CreatedAt time.Time `json:"created_at"`
	From      string    `json:"from"`
	To        string    `json:"to"`
	Rate      float64   `json:"rate"`
}

func (e ExchangeRate) TableName() string {
	return "exchange_rates"
}
