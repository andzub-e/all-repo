package container

import (
	"github.com/sarulabs/di"
	"gorm.io/gorm"
	"history/internal/config"
	"history/internal/constants"
	"history/internal/repositories/pgsql"
)

func BuildRepositories() []di.Def {
	return []di.Def{
		{
			Name: constants.SpinRepositoryName,
			Build: func(ctn di.Container) (interface{}, error) {
				conn := ctn.Get(constants.PgSQLConnectionName).(*gorm.DB)

				return pgsql.NewSpinRepository(conn), nil
			},
		},
		{
			Name: constants.SlotRepositoryName,
			Build: func(ctn di.Container) (interface{}, error) {
				conn := ctn.Get(constants.PgSQLConnectionName).(*gorm.DB)

				return pgsql.NewSlotRepository(conn), nil
			},
		},
		{
			Name: constants.DebugRepositoryName,
			Build: func(ctn di.Container) (interface{}, error) {
				conn := ctn.Get(constants.PgSQLConnectionName).(*gorm.DB)
				cfg := ctn.Get(constants.ConfigName).(*config.Config)

				return pgsql.NewDebugRepository(conn, cfg.PgSQLConfig.Name), nil
			},
		},
	}
}
