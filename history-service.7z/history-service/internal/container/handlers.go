package container

import (
	"github.com/sarulabs/di"
	"history/internal/constants"
	"history/internal/services"
	"history/internal/transport/http/handlers"
)

func BuildHandlers() []di.Def {
	return []di.Def{
		{
			Name: constants.MetaHTTPHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				debugService := ctn.Get(constants.DebugServiceName).(*services.DebugService)

				return handlers.NewMetaHandler(debugService), nil
			},
		},
	}
}
