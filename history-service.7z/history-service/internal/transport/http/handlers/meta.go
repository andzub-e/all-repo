package handlers

import (
	"github.com/gofiber/fiber/v2"
	"go.uber.org/zap"
	"history/internal/services"
	"history/internal/transport/http"
)

var tag = "no tag"

type metaHandler struct {
	debugService *services.DebugService
}

type InfoResponse struct {
	Tag    string   `json:"tag"`
	IP     string   `json:"ip"`
	IPs    []string `json:"ips"`
	Header string   `json:"header"`
}

func NewMetaHandler(debugService *services.DebugService) *metaHandler {
	debugService.Subscribe(func(report services.DebugReport) {
		zap.S().Infof("%+v", report)
	})

	return &metaHandler{debugService: debugService}
}

func (h *metaHandler) Register(router fiber.Router) {
	router.Get("health", h.health)
	router.Get("info", h.info)
	router.Get("debug", h.debug)
}

func (h *metaHandler) health(ctx *fiber.Ctx) error {
	return ctx.SendStatus(fiber.StatusOK)
}

func (h *metaHandler) info(ctx *fiber.Ctx) error {
	return http.OK(ctx, InfoResponse{
		Tag:    tag,
		IP:     ctx.IP(),
		IPs:    ctx.IPs(),
		Header: string(ctx.Request().Header.Header()),
	}, nil)
}

// @Summary Debug call.
// @Tags meta
// @Consume application/json
// @Description Check debug data.
// @Accept  json
// @Produce  json
// @Success 200  {object} string
// @Router /debug [get].
func (h *metaHandler) debug(ctx *fiber.Ctx) error {
	err := h.debugService.NotifyAll()
	if err != nil {
		return http.BadRequest(ctx, err, nil)
	}

	return http.OK(ctx, "ok", nil)
}
