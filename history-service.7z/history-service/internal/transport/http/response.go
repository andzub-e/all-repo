package http

import (
	"github.com/gofiber/fiber/v2"
	"github.com/samber/lo"
	"go.uber.org/zap"
	"history/pkg/validator"
	"net/http"
	"strconv"
)

type Response struct {
	Status  int         `json:"status"`
	Success bool        `json:"success"`
	Meta    interface{} `json:"meta"`
	Data    interface{} `json:"data,omitempty"`
	Errors  interface{} `json:"errors,omitempty"`
}

func new(status int, meta interface{}, data interface{}) *Response {
	success := false
	if status >= 200 && status <= 299 {
		success = true
	}

	response := &Response{
		Status:  status,
		Success: success,
		Meta:    meta,
	}

	if response.Success {
		response.Data = data

		if response.Data == nil {
			response.Data = http.StatusText(status)
		}
	} else {
		response.Errors = data

		if response.Errors == nil {
			response.Errors = http.StatusText(status)
		}
	}

	return response
}

func newWithFormattedError(status int, meta interface{}, err []error) *Response {
	return new(status, meta, lo.Map(err, func(item error, index int) string {
		return item.Error()
	}))
}

func OK(ctx *fiber.Ctx, meta interface{}, data interface{}) error {
	r := new(http.StatusOK, meta, data)

	return ctx.Status(r.Status).JSON(r)
}

func BadRequest(ctx *fiber.Ctx, meta interface{}, err ...error) error {
	zap.S().Warn(err)
	r := newWithFormattedError(http.StatusBadRequest, meta, err)

	return ctx.Status(r.Status).JSON(r)
}

func Unauthorized(ctx *fiber.Ctx, meta interface{}, err ...error) error {
	zap.S().Warn(err)
	r := newWithFormattedError(http.StatusUnauthorized, meta, err)

	return ctx.Status(r.Status).JSON(r)
}

func Forbidden(ctx *fiber.Ctx, meta interface{}, err ...error) error {
	zap.S().Warn(err)
	r := newWithFormattedError(http.StatusForbidden, meta, err)

	return ctx.Status(r.Status).JSON(r)
}

func NotFound(ctx *fiber.Ctx, meta interface{}, err ...error) error {
	zap.S().Warn(err)
	r := newWithFormattedError(http.StatusNotFound, meta, err)

	return ctx.Status(r.Status).JSON(r)
}

func ServerError(ctx *fiber.Ctx, meta interface{}, err ...error) error {
	zap.S().Error(err)
	r := newWithFormattedError(http.StatusInternalServerError, meta, err)

	return ctx.Status(r.Status).JSON(r)
}

func Code(ctx *fiber.Ctx, code int, meta interface{}, err ...error) error {
	zap.S().Warn(err)
	zap.S().Warn("code: " + strconv.Itoa(code))
	r := newWithFormattedError(code, meta, err)

	return ctx.Status(r.Status).JSON(r)
}

func ValidationFailed(ctx *fiber.Ctx, err error) error {
	data := make([]error, 0)

	for _, taggedError := range validator.CheckValidationErrors(err) {
		e := taggedError.Err
		data = append(data, e)
	}

	r := newWithFormattedError(http.StatusUnprocessableEntity, nil, data)

	return ctx.Status(r.Status).JSON(r)
}

func Conflict(ctx *fiber.Ctx, meta interface{}, err ...error) error {
	zap.S().Error(err)
	r := newWithFormattedError(http.StatusConflict, meta, err)

	return ctx.Status(r.Status).JSON(r)
}
