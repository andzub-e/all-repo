package rpc

import (
	"context"
	"go.opentelemetry.io/otel/trace"
	"go.uber.org/zap"
	"google.golang.org/grpc"
	"history/pkg/tracer"
)

func TraceInterceptor(tr *tracer.JaegerTracer) grpc.UnaryServerInterceptor {
	return func(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (
		resp interface{}, err error) {
		traceID, ok := tracer.GetTraceIDFromGRPCMetadata(ctx)

		if ok {
			var span trace.Span

			ctx, span = tr.Continue(ctx, "server", info.FullMethod, tracer.CtxWithTraceValue, traceID)
			defer span.End()
		} else {
			zap.S().Warnf("method: %v, there is no grpc metadata", info.FullMethod)
		}

		resp, err = handler(ctx, req)

		return resp, err
	}
}
