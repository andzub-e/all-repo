package rpc

import (
	"context"
	"history/internal/entities"
	"history/internal/services"
	"history/pkg/history"
	"history/utils"
	"io"

	"github.com/google/uuid"
	"github.com/samber/lo"
)

type Handler struct {
	history.HistoryServiceServer
	cfg         *Config
	spinService *services.SpinService
	slotService *services.SlotService
}

func NewHandler(cfg *Config,
	spinService *services.SpinService,
	slotService *services.SlotService) *Handler {
	return &Handler{
		cfg:         cfg,
		spinService: spinService,
		slotService: slotService,
	}
}

func (h *Handler) GetSessions(ctx context.Context, in *history.GetFinancialIn) (*history.GetSessionsOut, error) {
	ctx, cancel := context.WithTimeout(ctx, h.cfg.MaxProcessingTime)
	defer cancel()

	f := entities.FinancialFiltersFromHistory(in.Base.Filters)

	filters, err := utils.StructToMap(f)
	if err != nil {
		return nil, WrapInGRPCError(err)
	}

	pagination, err := h.spinService.PaginateGameSession(ctx, in.Base.ConvertCurrency, in.Base.Games, filters, in.Order, in.Limit, in.Page)
	if err != nil {
		return nil, WrapInGRPCError(err)
	}

	var items []*history.GameSessionOut

	lo.ForEach(pagination.Items, func(item *entities.GameSession, index int) {
		item.Compute()
		items = append(items, item.ToAPIResponse())
	})

	return &history.GetSessionsOut{
		Items:       items,
		CurrentPage: pagination.CurrentPage,
		Limit:       pagination.Limit,
		Total:       pagination.Total,
	}, nil
}

func (h *Handler) GetAllGameSession(ctx context.Context, in *history.FinancialBase) (*history.GetAllGameSessionsOut, error) {
	ctx, cancel := context.WithTimeout(ctx, h.cfg.MaxProcessingTime)
	defer cancel()

	f := entities.FinancialFiltersFromHistory(in.Filters)

	filters, err := utils.StructToMap(f)
	if err != nil {
		return nil, WrapInGRPCError(err)
	}

	gameSessions, err := h.spinService.AllGameSessions(ctx, in.ConvertCurrency, in.Games, filters)
	if err != nil {
		return nil, WrapInGRPCError(err)
	}

	sessions := lo.Map(gameSessions, func(item *entities.GameSession, index int) *history.GameSessionOut {
		return item.ToAPIResponse()
	})

	return &history.GetAllGameSessionsOut{Sessions: sessions}, nil
}

func (h *Handler) GetSpins(ctx context.Context, in *history.GetFinancialIn) (*history.GetSpinsOut, error) {
	ctx, cancel := context.WithTimeout(ctx, h.cfg.MaxProcessingTime)
	defer cancel()

	f := entities.FinancialFiltersFromHistory(in.Base.Filters)

	filters, err := utils.StructToMap(f)
	if err != nil {
		return nil, WrapInGRPCError(err)
	}

	var items []*history.SpinOut
	var total uint64

	if len(in.GroupBy) > 0 {
		pagination, err := h.spinService.PaginateGrouped(ctx, in.Base.ConvertCurrency, in.Base.Games, filters, in.Order, in.Limit, in.Page, in.GroupBy)
		if err != nil {
			return nil, WrapInGRPCError(err)
		}

		lo.ForEach(pagination.Items, func(item *entities.GroupedSpin, index int) {
			items = append(items, item.ToAPIResponse())
		})
		total = pagination.Total
	} else {
		pagination, err := h.spinService.Paginate(ctx, in.Base.ConvertCurrency, in.Base.Games, filters, in.Order, in.Limit, in.Page)
		if err != nil {
			return nil, WrapInGRPCError(err)
		}

		lo.ForEach(pagination.Items, func(item *entities.Spin, index int) {
			items = append(items, item.ToAPIResponse())
		})

		total = pagination.Total
	}

	return &history.GetSpinsOut{
		Items:       items,
		CurrentPage: in.Page,
		Limit:       in.Limit,
		Total:       total,
	}, nil
}

func (h *Handler) GetAllSpins(ctx context.Context, in *history.FinancialBase) (*history.GetAllSpinsOut, error) {
	ctx, cancel := context.WithTimeout(ctx, h.cfg.MaxProcessingTime)
	defer cancel()

	f := entities.FinancialFiltersFromHistory(in.Filters)

	filters, err := utils.StructToMap(f)
	if err != nil {
		return nil, WrapInGRPCError(err)
	}

	spins, err := h.spinService.AllSpins(ctx, in.ConvertCurrency, in.Games, filters)
	if err != nil {
		return nil, WrapInGRPCError(err)
	}

	s := lo.Map(spins, func(item *entities.Spin, index int) *history.SpinOut {
		return item.ToAPIResponse()
	})

	return &history.GetAllSpinsOut{Spins: s}, nil
}

func (h *Handler) GetFinancialReport(ctx context.Context, in *history.FinancialBase) (*history.FinancialReportOut, error) {
	ctx, cancel := context.WithTimeout(ctx, h.cfg.MaxProcessingTime)
	defer cancel()

	f := entities.FinancialFiltersFromHistory(in.Filters)

	filters, err := utils.StructToMap(f)
	if err != nil {
		return nil, WrapInGRPCError(err)
	}

	finalReport, err := h.spinService.FinancialReport(ctx, in.ConvertCurrency, in.Games, filters)
	if err != nil {
		return nil, WrapInGRPCError(err)
	}

	return &history.FinancialReportOut{Report: finalReport.ToAPIResponse()}, nil
}

func (h *Handler) GetAggregatedReportByGame(ctx context.Context, in *history.GetAggregatedReportFilters) (*history.GetAggregatedReportByGameOut, error) {
	ctx, cancel := context.WithTimeout(ctx, h.cfg.MaxProcessingTime)
	defer cancel()

	f := entities.FromHistoryAggFilters(in)

	filters, err := utils.StructToMap(f)
	if err != nil {
		return nil, WrapInGRPCError(err)
	}

	reports, err := h.spinService.AggregatedReportByGame(ctx, in.ConvertCurrency, in.Games, filters)
	if err != nil {
		return nil, WrapInGRPCError(err)
	}

	out := &history.GetAggregatedReportByGameOut{}

	lo.ForEach(reports, func(item *entities.SimpleAggregatedReportByGame, index int) {
		out.Items = append(out.Items, &history.GetAggregatedReportByGameItem{
			Game:       item.Game,
			GameId:     item.GameID.String(),
			Currency:   item.Currency,
			UserCount:  int64(item.UserCount),
			RoundCount: int64(item.RoundCount),
			Wager:      item.Wager,
			Award:      item.Award,
		})
	})

	return out, nil
}

func (h *Handler) GetAggregatedReportByCountry(ctx context.Context, in *history.GetAggregatedReportFilters) (*history.GetAggregatedReportByCountryOut, error) {
	ctx, cancel := context.WithTimeout(ctx, h.cfg.MaxProcessingTime)
	defer cancel()

	f := entities.FromHistoryAggFilters(in)

	filters, err := utils.StructToMap(f)
	if err != nil {
		return nil, WrapInGRPCError(err)
	}

	reports, err := h.spinService.AggregatedReportByCountry(ctx, in.ConvertCurrency, in.Games, filters)
	if err != nil {
		return nil, WrapInGRPCError(err)
	}

	out := &history.GetAggregatedReportByCountryOut{}

	lo.ForEach(reports, func(item *entities.SimpleAggregatedReportByCountry, index int) {
		out.Items = append(out.Items, &history.GetAggregatedReportByCountryItem{
			Country:    item.Country,
			Currency:   item.Currency,
			UserCount:  int64(item.UserCount),
			RoundCount: int64(item.RoundCount),
			Wager:      item.Wager,
			Award:      item.Award,
		})
	})

	return out, nil
}

func (h *Handler) GetSession(ctx context.Context, in *history.GetSessionIn) (*history.GameSessionOut, error) {
	ctx, cancel := context.WithTimeout(ctx, h.cfg.MaxProcessingTime)
	defer cancel()

	session, err := h.spinService.Session(ctx, in.Games, uuid.MustParse(in.SessionId), in.ConvertCurrency)
	if err != nil {
		return nil, err
	}

	return session.ToAPIResponse(), nil
}

func (h *Handler) GetHosts(ctx context.Context, in *history.FinancialBase) (*history.DictionaryOut, error) {
	ctx, cancel := context.WithTimeout(ctx, h.cfg.MaxProcessingTime)
	defer cancel()

	hosts, err := h.spinService.Hosts(ctx, in.Games)
	if err != nil {
		return nil, err
	}

	return &history.DictionaryOut{Items: hosts}, nil
}

func (h *Handler) GetCurrencies(ctx context.Context, in *history.FinancialBase) (*history.DictionaryOut, error) {
	ctx, cancel := context.WithTimeout(ctx, h.cfg.MaxProcessingTime)
	defer cancel()

	f := entities.FinancialFiltersFromHistory(in.Filters)

	filters, err := utils.StructToMap(f)
	if err != nil {
		return nil, WrapInGRPCError(err)
	}

	currencies, err := h.spinService.Currencies(ctx, filters)
	if err != nil {
		return nil, err
	}

	return &history.DictionaryOut{Items: currencies}, nil
}

func (h *Handler) GetIntegratorOperators(ctx context.Context, in *history.GamesIn) (*history.IntegratorsOperatorOut, error) {
	ctx, cancel := context.WithTimeout(ctx, h.cfg.MaxProcessingTime)
	defer cancel()

	res, err := h.spinService.IntegratorOperatorsMap(ctx, in.Games)
	if err != nil {
		return nil, err
	}

	return &history.IntegratorsOperatorOut{
		Map: lo.MapEntries(res, func(key string, value []string) (string, *history.DictionaryOut) {
			return key, &history.DictionaryOut{Items: value}
		}),
	}, nil
}

func (h *Handler) HealthCheck(stream history.HistoryService_HealthCheckServer) error {
	for {
		msg, err := stream.Recv()
		if err != nil {
			if err == io.EOF {
				return nil
			}

			return err
		}

		if err = stream.Send(msg); err != nil {
			if err == io.EOF {
				return nil
			}

			return err
		}
	}
}
