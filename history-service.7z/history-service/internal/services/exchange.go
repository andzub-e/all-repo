package services

import (
	"context"
	"fmt"
	"history/internal/entities"
	"history/internal/errs"
	"history/pkg/exchange"
	"time"

	"github.com/samber/lo"
)

type ExchangeService struct {
	exchangeClient exchange.Client
}

func NewExchangeService(exchangeClient exchange.Client) *ExchangeService {
	return &ExchangeService{exchangeClient: exchangeClient}
}

func (s *ExchangeService) ExchangeFinancialReport(ctx context.Context, toCurrency string, rep map[entities.FinancialReportKey]*entities.FinancialReport) (*entities.FinancialReport, error) {
	exchanged := &entities.FinancialReport{}

	toCurrs := toCurrencies(lo.Keys(rep))
	// TODO make time groupig

	exchangeMap, err := s.exchangeMap(ctx, toCurrency, toCurrs, time.Now(), time.Now())
	if err != nil {
		return nil, err
	}

	for key, notExchanged := range rep {
		coef, err := exchangeCoefficient(exchangeMap, toCurrency, key.Currency)
		if err != nil {
			return nil, err
		}

		exchanged.Award += notExchanged.Award * coef
		exchanged.AwardWithoutPFR += notExchanged.AwardWithoutPFR * coef
		exchanged.Wager += notExchanged.Wager * coef
		exchanged.WagerWithoutPFR += notExchanged.WagerWithoutPFR * coef

		exchanged.SpinQuantity += notExchanged.SpinQuantity
		exchanged.UserQuantity += notExchanged.UserQuantity
	}

	return exchanged, nil
}

func (s *ExchangeService) ExchangeSpinsMut(ctx context.Context, toCurrency string, spins []*entities.Spin) error {
	toCurrs := lo.Map(spins, func(item *entities.Spin, index int) string {
		return item.Currency
	})

	// TODO make time groupig
	exchangeMap, err := s.exchangeMap(ctx, toCurrency, toCurrs, time.Now(), time.Now())
	if err != nil {
		return err
	}

	toExchangeable := make([]Exchangeable, len(spins))
	for i, spin := range spins {
		toExchangeable[i] = spin
	}

	return exchangeVals(toExchangeable, toCurrency, exchangeMap)
}

func (s *ExchangeService) ExchangeGroupedSpinsMut(ctx context.Context, toCurrency string, spins []*entities.GroupedSpin) error {
	toCurrs := lo.Map(spins, func(item *entities.GroupedSpin, index int) string {
		return item.Currency
	})

	// TODO make time groupig
	exchangeMap, err := s.exchangeMap(ctx, toCurrency, toCurrs, time.Now(), time.Now())
	if err != nil {
		return err
	}

	toExchangeable := make([]Exchangeable, len(spins))
	for i, spin := range spins {
		toExchangeable[i] = spin
	}

	return exchangeVals(toExchangeable, toCurrency, exchangeMap)
}

func (s *ExchangeService) ExchangeSessionsMut(ctx context.Context, toCurrency string, gamingSessions []*entities.GameSession) error {
	toCurrs := lo.Map(gamingSessions, func(item *entities.GameSession, index int) string {
		return item.Currency
	})

	// TODO make time groupig
	exchangeMap, err := s.exchangeMap(ctx, toCurrency, toCurrs, time.Now(), time.Now())
	if err != nil {
		return err
	}

	toExchangeable := make([]Exchangeable, len(gamingSessions))
	for i, session := range gamingSessions {
		toExchangeable[i] = session
	}

	return exchangeVals(toExchangeable, toCurrency, exchangeMap)
}

func (s *ExchangeService) ExchangeAggregatedReportMut(ctx context.Context, toCurrency string, reps []*entities.AggregatedReport) error {
	toCurrs := lo.Map(reps, func(item *entities.AggregatedReport, index int) string {
		return item.Currency
	})
	// TODO make time groupig

	exchangeMap, err := s.exchangeMap(ctx, toCurrency, toCurrs, time.Now(), time.Now())
	if err != nil {
		return err
	}

	toExchangeable := make([]Exchangeable, len(reps))
	for i, session := range reps {
		toExchangeable[i] = session
	}

	return exchangeVals(toExchangeable, toCurrency, exchangeMap)
}

func (s *ExchangeService) exchangeMap(ctx context.Context, from string, to []string, start, end time.Time) (
	map[entities.ExchangeKey][]entities.ExchangeValue, error) {
	to = lo.Uniq(to)

	toAliases, err := s.CurrencyAliases(ctx, to)
	if err != nil {
		return nil, err
	}

	bag, err := s.exchangeClient.GetRates(ctx, from, lo.Values(toAliases), start, end)
	if err != nil {
		return nil, err
	}

	res := map[entities.ExchangeKey][]entities.ExchangeValue{}

	for original, alias := range toAliases {
		res[entities.ExchangeKey{From: from, To: original}] = lo.Map(bag[exchange.RateKey{From: from, To: alias}],
			func(item *exchange.RateItem, index int) entities.ExchangeValue {
				return entities.ExchangeValue{Date: item.Date.AsTime(), Rate: item.Rate}
			})
	}

	return res, nil
}

type Exchangeable interface {
	ExchangeCurrencyMut(toCurrency string, multiplier float64)
	GetCurrency() string
}

func exchangeVals(items []Exchangeable, toCurrency string, exchangeMap map[entities.ExchangeKey][]entities.ExchangeValue) error {
	for i := 0; i < len(items); i++ {
		item := items[i]

		coef, err := exchangeCoefficient(exchangeMap, toCurrency, item.GetCurrency())
		if err != nil {
			return err
		}

		item.ExchangeCurrencyMut(toCurrency, coef)
	}

	return nil
}

func exchangeCoefficient(exchangeMap map[entities.ExchangeKey][]entities.ExchangeValue, toCurrency, fromCurrency string) (float64, error) {
	key := entities.ExchangeKey{From: toCurrency, To: fromCurrency}

	mulSl, ok := exchangeMap[key]
	if !ok {
		return 0, fmt.Errorf("%s: %v", errs.ErrCanNotFindCurrencyConfig, key)
	}

	if len(mulSl) == 0 {
		return 0, fmt.Errorf("%s: %v", errs.ErrCanNotFindCurrencyConfig, key)
	}

	return 1 / mulSl[0].Rate, nil
}

// TODO: ask db/backoffice about currency aliases
func (s *ExchangeService) CurrencyAliases(ctx context.Context, to []string) (map[string]string, error) {
	return lo.SliceToMap(to, func(item string) (string, string) {
		if item == "xts" {
			return item, "usd"
		}

		if item == "usdt" {
			return item, "usd"
		}

		return item, item
	}), nil
}

func toCurrencies(keys []entities.FinancialReportKey) []string {
	return lo.Map(keys, func(item entities.FinancialReportKey, index int) string {
		return item.Currency
	})
}
