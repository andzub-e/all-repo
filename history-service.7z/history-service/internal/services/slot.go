package services

import (
	"context"
	"errors"
	"fmt"
	"history/internal/entities"
	"history/internal/repositories"
	"history/pkg/ip2country"
	"history/pkg/validator"

	"github.com/google/uuid"
	"go.uber.org/zap"
)

type SlotService struct {
	slotRepo         repositories.SlotRepository
	ipConvertClient  *ip2country.ClientWithCache
	validationEngine *validator.Validator
	exchangeService  *ExchangeService
}

func NewSlotService(slotRepo repositories.SlotRepository, ipConvertClient *ip2country.ClientWithCache, validationEngine *validator.Validator, exchangeService *ExchangeService) *SlotService {
	return &SlotService{
		slotRepo:         slotRepo,
		ipConvertClient:  ipConvertClient,
		validationEngine: validationEngine,
		exchangeService:  exchangeService,
	}
}

func (s *SlotService) validateSpin(spin *entities.Spin) error {
	verr := s.validationEngine.ValidateStruct(spin)

	var err error

	for _, taggedError := range validator.CheckValidationErrors(verr) {
		err = errors.Join(err, taggedError.Err)
	}

	if spin.ID == uuid.Nil {
		err = errors.Join(err, fmt.Errorf("field id is required"))
	}

	if spin.GameID == uuid.Nil {
		err = errors.Join(err, fmt.Errorf("field game_id is required"))
	}

	if spin.SessionToken == uuid.Nil {
		err = errors.Join(err, fmt.Errorf("field session_token is required"))
	}

	if spin.TransactionID == uuid.Nil {
		err = errors.Join(err, fmt.Errorf("field transaction_id is required"))
	}

	if spin.InternalUserID == uuid.Nil {
		err = errors.Join(err, fmt.Errorf("field internal_user_id is required"))
	}

	return err
}

func (s *SlotService) CreateSpin(ctx context.Context, spinNoCountry *entities.Spin) error {
	if err := s.validateSpin(spinNoCountry); err != nil {
		return err
	}

	country, err := s.ipConvertClient.Get(spinNoCountry.ClientIP)

	if err != nil {
		zap.S().Error(err)
	} else {
		spinNoCountry.Country = &country
	}

	return s.slotRepo.Create(ctx, spinNoCountry)
}

func (s *SlotService) UpdateSpin(ctx context.Context, spin *entities.Spin) error {
	if err := s.validateSpin(spin); err != nil {
		return err
	}

	return s.slotRepo.Update(ctx, spin)
}

func (s *SlotService) GetSpin(ctx context.Context, roundID uuid.UUID, convertToCurrency string) (*entities.Spin, error) {
	spin, err := s.slotRepo.GetByID(ctx, roundID)
	if err != nil {
		return nil, err
	}

	err = s.exchangeService.ExchangeSpinsMut(ctx, convertToCurrency, []*entities.Spin{spin})
	if err != nil {
		return nil, err
	}

	return spin, nil
}

func (s *SlotService) GetLastSpin(
	ctx context.Context, internalUserId uuid.UUID, game string) (*entities.Spin, error) {
	return s.slotRepo.LastRecord(ctx, internalUserId, game)
}

func (s *SlotService) GetLastNotShownSpins(
	ctx context.Context, internalUserId uuid.UUID, game string) ([]*entities.Spin, error) {
	return s.slotRepo.LastRecords(ctx, internalUserId, game)
}

func (s *SlotService) GetLastSpinByWager(
	ctx context.Context, internalUserId uuid.UUID, game string, wager uint64) (*entities.Spin, error) {
	return s.slotRepo.LastRecordByWager(ctx, internalUserId, game, wager)
}

func (s *SlotService) GetSpinsPagination(
	ctx context.Context, internalUserId uuid.UUID, game string, limit, page uint64) (*entities.Pagination[entities.Spin], error) {
	return s.slotRepo.Pagination(ctx, internalUserId, game, limit, page)
}
