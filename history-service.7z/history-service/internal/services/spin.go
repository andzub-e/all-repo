package services

import (
	"context"
	"history/internal/entities"
	"history/internal/repositories"

	"github.com/google/uuid"
	"github.com/samber/lo"
)

type SpinService struct {
	repo            repositories.SpinRepository
	exchangeService *ExchangeService
}

func NewSpinService(repo repositories.SpinRepository, exchangeService *ExchangeService) *SpinService {
	return &SpinService{repo: repo, exchangeService: exchangeService}
}

func (s *SpinService) FinancialReport(ctx context.Context, convertToCurrency string, games []string, filters map[string]interface{}) (*entities.FinancialReport, error) {
	rawRep, err := s.repo.AwardAndWager(ctx, games, filters)
	if err != nil {
		return nil, err
	}

	spinStat, err := s.repo.SpinAndUserCount(ctx, games, filters)
	if err != nil {
		return nil, err
	}

	rep := map[entities.FinancialReportKey]*entities.FinancialReport{}

	keys := lo.Uniq(append(lo.Keys(rawRep), lo.Keys(spinStat)...))

	lo.ForEach(keys, func(key entities.FinancialReportKey, _ int) {
		fin, stat := rawRep[key], spinStat[key]
		if fin == nil {
			fin = &entities.RawFinancialReport{}
		}

		if stat == nil {
			stat = &entities.RawUserStatReport{}
		}

		rep[key] = &entities.FinancialReport{
			Award:           fin.Award,
			Wager:           fin.Wager,
			AwardWithoutPFR: fin.AwardWithoutPFR,
			WagerWithoutPFR: fin.WagerWithoutPFR,

			SpinQuantity: stat.SpinQuantity,
			UserQuantity: stat.UserQuantity,
		}
	})

	finalReport, err := s.exchangeService.ExchangeFinancialReport(ctx, convertToCurrency, rep)
	if err != nil {
		return nil, err
	}

	return finalReport, nil
}

func (s *SpinService) AllSpins(ctx context.Context, convertToCurrency string, games []string, filters map[string]interface{}) ([]*entities.Spin, error) {
	spins, err := s.repo.All(ctx, games, filters)
	if err != nil {
		return nil, err
	}

	err = s.exchangeService.ExchangeSpinsMut(ctx, convertToCurrency, spins)
	if err != nil {
		return nil, err
	}

	return spins, nil
}

func (s *SpinService) PaginateGrouped(ctx context.Context, convertToCurrency string, games []string, filters map[string]interface{}, order string, limit, page uint64, groupBy []string) (
	pagination entities.Pagination[entities.GroupedSpin], err error) {
	groupBy = lo.Filter(groupBy, func(item string, index int) bool {
		return lo.Contains(lo.Keys(entities.AvailableColumnToGroup), item)
	})

	groupBy = lo.Uniq(append(groupBy, "currency", "integrator"))
	groupBy = lo.Map(groupBy, func(item string, index int) string {
		return entities.AvailableColumnToGroup[item]
	})

	pagination, err = s.repo.PaginateGrouped(ctx, games, filters, order, limit, page, groupBy)
	if err != nil {
		return pagination, err
	}

	err = s.exchangeService.ExchangeGroupedSpinsMut(ctx, convertToCurrency, pagination.Items)
	if err != nil {
		return pagination, err
	}

	return pagination, nil
}

func (s *SpinService) Paginate(ctx context.Context, convertToCurrency string, games []string, filters map[string]interface{}, order string, limit, page uint64) (
	pagination entities.Pagination[entities.Spin], err error) {
	pagination, err = s.repo.Paginate(ctx, games, filters, order, limit, page)
	if err != nil {
		return pagination, err
	}

	err = s.exchangeService.ExchangeSpinsMut(ctx, convertToCurrency, pagination.Items)
	if err != nil {
		return pagination, err
	}

	return pagination, nil
}

func (s *SpinService) AllGameSessions(ctx context.Context, convertToCurrency string, games []string, filters map[string]interface{}) ([]*entities.GameSession, error) {
	sessions, err := s.repo.AllGameSession(ctx, games, filters)
	if err != nil {
		return nil, err
	}

	err = s.exchangeService.ExchangeSessionsMut(ctx, convertToCurrency, sessions)
	if err != nil {
		return nil, err
	}

	return sessions, nil
}

func (s *SpinService) PaginateGameSession(ctx context.Context, convertToCurrency string, games []string, filters map[string]interface{}, order string, limit, page uint64) (pagination entities.Pagination[entities.GameSession], err error) {
	pagination, err = s.repo.PaginateGameSession(ctx, games, filters, order, limit, page)
	if err != nil {
		return pagination, err
	}

	err = s.exchangeService.ExchangeSessionsMut(ctx, convertToCurrency, pagination.Items)
	if err != nil {
		return pagination, err
	}

	return pagination, nil
}

func (s *SpinService) AggregatedReportByGame(ctx context.Context, convertToCurrency string, games []string, filters map[string]interface{}) ([]*entities.SimpleAggregatedReportByGame, error) {
	reports, err := s.repo.AggregatedReportByGame(ctx, games, filters)
	if err != nil {
		return nil, err
	}

	reportsAgg := lo.Map(reports, func(item *entities.SimpleAggregatedReportByGame, index int) *entities.AggregatedReport {
		return &item.AggregatedReport
	})

	if err = s.exchangeService.ExchangeAggregatedReportMut(ctx, convertToCurrency, reportsAgg); err != nil {
		return nil, err
	}

	groupedByGame := lo.GroupBy(reports, func(item *entities.SimpleAggregatedReportByGame) uuid.UUID {
		return item.GameID
	})

	return lo.MapToSlice(groupedByGame,
		func(key uuid.UUID, value []*entities.SimpleAggregatedReportByGame) *entities.SimpleAggregatedReportByGame {
			res := &entities.SimpleAggregatedReportByGame{}

			for _, item := range value {
				res.Game = item.Game
				res.GameID = item.GameID
				res.Currency = item.Currency

				res.UserCount += item.UserCount
				res.RoundCount += item.RoundCount
				res.Wager += item.Wager
				res.Award += item.Award
			}

			return res
		}), nil
}

func (s *SpinService) AggregatedReportByCountry(ctx context.Context, convertToCurrency string, games []string, filters map[string]interface{}) ([]*entities.SimpleAggregatedReportByCountry, error) {
	reports, err := s.repo.AggregatedReportByCountry(ctx, games, filters)
	if err != nil {
		return nil, err
	}

	reportsAgg := lo.Map(reports, func(item *entities.SimpleAggregatedReportByCountry, index int) *entities.AggregatedReport {
		return &item.AggregatedReport
	})

	if err = s.exchangeService.ExchangeAggregatedReportMut(ctx, convertToCurrency, reportsAgg); err != nil {
		return nil, err
	}

	groupedByCountry := lo.GroupBy(reports, func(item *entities.SimpleAggregatedReportByCountry) string {
		return item.Country
	})

	return lo.MapToSlice(groupedByCountry,
		func(key string, value []*entities.SimpleAggregatedReportByCountry) *entities.SimpleAggregatedReportByCountry {
			res := &entities.SimpleAggregatedReportByCountry{}

			for _, item := range value {
				res.Country = item.Country
				res.Currency = item.Currency

				res.UserCount += item.UserCount
				res.RoundCount += item.RoundCount
				res.Wager += item.Wager
				res.Award += item.Award
			}

			return res
		}), nil
}

func (s *SpinService) Session(ctx context.Context, games []string, id uuid.UUID, convertToCurrency string) (*entities.GameSession, error) {
	session, err := s.repo.GetSession(ctx, games, id)
	if err != nil {
		return nil, err
	}

	err = s.exchangeService.ExchangeSessionsMut(ctx, convertToCurrency, []*entities.GameSession{session})
	if err != nil {
		return nil, err
	}

	return session, nil
}

func (s *SpinService) Hosts(ctx context.Context, games []string) ([]string, error) {
	return s.repo.Hosts(ctx, games)
}

func (s *SpinService) Currencies(ctx context.Context, filters map[string]interface{}) ([]string, error) {
	return s.repo.Currencies(ctx, filters)
}

func (s *SpinService) IntegratorOperatorsMap(ctx context.Context, games []string) (map[string][]string, error) {
	return s.repo.IntegratorOperatorsMap(ctx, games)
}
