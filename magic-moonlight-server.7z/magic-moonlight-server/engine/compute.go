package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine/utils"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	baseUtils "bitbucket.org/electronicjaw/base-slot-server/utils"
	"github.com/samber/lo"
)

func (s *SpinFactory) computeBasicWindow(
	ag AwardGetter, reels []map[int]int, stops []int, config *baseUtils.Chooser[int, int], cheats *Cheats,
) (int64, []Avalanche, *Bonus, error) {
	window := NewWindow(config)

	window.changeWindowSize = true

	baseAvalanches, award, err := utils.Spin[int](ag, window, reels, stops)
	if err != nil {
		return 0, nil, nil, err
	}

	avalanches := mapAvalanches(baseAvalanches)

	var bonus *Bonus
	if window.GetScatterQty() >= needScattersToTriggerBonus {
		avalanches[len(avalanches)-1].PayItems = append(avalanches[len(avalanches)-1].PayItems, PayItem{
			Symbol:  scatterSymbol,
			Indexes: window.GetIndexesBySymbol(scatterSymbol),
			Award:   ag.GetAward(scatterSymbol, window.GetScatterQty()),
		})

		bonus, err = s.computeBonusWindow(ag, window.GetScatterQty(), cheats, config)
		if err != nil {
			return 0, nil, nil, err
		}

		return award, avalanches, bonus, nil
	}

	return award, avalanches, bonus, nil
}

func (s *SpinFactory) computeBonusWindow(
	ag AwardGetter, scatterQty int, cheats *Cheats, config *baseUtils.Chooser[int, int],
) (*Bonus, error) {
	wheel, err := s.generateWheel()
	if err != nil {
		return nil, err
	}

	var (
		bonus           = &Bonus{Wheel: wheel}
		window          = NewWindow(config)
		multiplier      = wheel.Multiplier
		award           = int64(0)
		additionalWheel *Wheel
	)

	for count := wheel.Spins; count > 0 || additionalWheel != nil; count-- {
		if additionalWheel != nil {
			count += additionalWheel.Spins
			multiplier += additionalWheel.Multiplier

			additionalWheel = nil
		}

		stops, err := s.getBonusStops(cheats, reelSet3Code, count)
		if err != nil {
			return nil, err
		}

		window.changeWindowSize = true

		avalanches, _, err := utils.Spin[int](ag, window, indexedReelSet3, stops)
		if err != nil {
			return nil, err
		}

		spinAward := int64(0)

		mapAvalanches := lo.Map(avalanches, func(item utils.Avalanche[int], index int) Avalanche {
			payItems := make([]PayItem, len(item.PayItems))

			for i, payItem := range item.PayItems {
				withWild := false

				// check if we have wild in the pay line
				for rI, reel := range payItem.Indexes {
					for _, sI := range reel {
						if item.Window[rI][sI] == wildSymbol {
							withWild = true
						}
					}
				}

				if withWild {
					payItem.Award *= wildMultiplier
				}

				awardWithMultiplier := payItem.Award * multiplier
				payItems[i] = PayItem{
					Symbol:              payItem.Symbol,
					Indexes:             payItem.Indexes,
					Award:               payItem.Award,
					Multiplier:          multiplier,
					AwardWithMultiplier: awardWithMultiplier,
				}
				spinAward += awardWithMultiplier
			}

			return Avalanche{
				Window:   item.Window,
				PayItems: payItems,
			}
		})

		if window.GetScatterQty() >= needScattersToTriggerBonus {
			mapAvalanches[len(mapAvalanches)-1].PayItems = append(mapAvalanches[len(mapAvalanches)-1].PayItems, PayItem{
				Symbol:  scatterSymbol,
				Indexes: window.GetIndexesBySymbol(scatterSymbol),
				Award:   ag.GetAward(scatterSymbol, window.GetScatterQty()),
			})

			w, err := s.generateWheel()
			if err != nil {
				return nil, err
			}

			additionalWheel = &w

			window.SetScatterQty(0)
		}

		bonus.Spins = append(bonus.Spins, SpinBonus{
			Stops:      stops,
			Award:      spinAward,
			SpinsLeft:  count,
			Wheel:      copyWheel(additionalWheel),
			Multiplier: multiplier,
			Avalanches: mapAvalanches,
		})

		award += spinAward
	}

	bonus.Win = award

	return bonus, nil
}

func (s *SpinFactory) getStops(cheats *Cheats, reelCode int) ([]int, error) {
	reel := *availableReels[reelCode]

	if cheats != nil {
		if len(cheats.Stops) != len(reel)+1 {
			return nil, errs.ErrBadDataGiven
		}

		last := len(cheats.Stops) - 1

		for i := range cheats.Stops {
			if i != last && cheats.Stops[i] > len(reel[i]) {
				return nil, errs.ErrBadDataGiven
			}

			if cheats.Stops[last] > len(topReelSet) {
				return nil, errs.ErrBadDataGiven
			}
		}

		return cheats.Stops, nil
	}

	req := lo.Map(reel, func(item []int, index int) uint64 {
		return uint64(len(item))
	})

	req = append(req, uint64(len(topReelSet)))

	res, err := s.rand.RandSlice(req)
	if err != nil {
		return nil, err
	}

	return lo.Map(res, func(item uint64, index int) int {
		return int(item)
	}), nil
}

func (s *SpinFactory) getBonusStops(cheats *Cheats, reelCode, spin int) ([]int, error) {
	if cheats != nil && cheats.ReTriggerBonusOnSpin == spin && !cheats.reTriggered {
		cheats.reTriggered = true

		return []int{4, 5, 5, 0, 1, 0, 0}, nil
	}

	return s.getStops(nil, reelCode)
}

func (s *SpinFactory) getBaseConfig(anteBet bool, rtp *int64) (*baseUtils.Chooser[int, int], error) {
	value, err := s.rand.RandFloat()
	if err != nil {
		return nil, err
	}

	if rtp != nil {
		userBaseConfigLowProb, userAnteConfigLowProb := calcRTP(float64(*rtp))

		return s.chooseConfig(anteBet, value, userBaseConfigLowProb, userAnteConfigLowProb), nil
	}

	return s.chooseConfig(anteBet, value, baseConfigLowProb, anteConfigLowProb), nil
}

func mapAvalanches(in []utils.Avalanche[int]) []Avalanche {
	return lo.Map(in, func(item utils.Avalanche[int], index int) Avalanche {
		payItems := make([]PayItem, len(item.PayItems))

		for i, payItem := range item.PayItems {
			payItems[i] = PayItem{
				Symbol:  payItem.Symbol,
				Indexes: payItem.Indexes,
				Award:   payItem.Award,
			}
		}

		return Avalanche{
			Window:   item.Window,
			PayItems: payItems,
		}
	})
}

func (s *SpinFactory) chooseConfig(anteBet bool, value, baseLow, anteLow float64) *baseUtils.Chooser[int, int] {
	if anteBet {
		if value <= anteLow {
			return s.cfgLow
		}

		return s.cfgHigh
	}

	if value <= baseLow {
		return s.cfgLow
	}

	return s.cfgHigh
}

func (s *SpinFactory) generateWheel() (wheel Wheel, err error) {
	wheel.Multiplier, err = s.wheelMultiplierChooser.Pick()
	if err != nil {
		return
	}

	wheel.Spins, err = s.wheelSpinChooser.Pick()
	if err != nil {
		return
	}

	return wheel, nil
}

func copyWheel(wheel *Wheel) *Wheel {
	if wheel == nil {
		return nil
	}

	return &Wheel{
		Spins:      wheel.Spins,
		Multiplier: wheel.Multiplier,
	}
}
