package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"encoding/json"
	"go.uber.org/zap"
)

type RestoringIndexes struct {
	BaseSpinIndex  int `json:"base_spin_index"`
	BonusSpinIndex int `json:"bonus_spin_index"`
}

func (r *RestoringIndexes) IsShown(spin engine.Spin) bool {
	spinTyped, ok := spin.(*SpinBase)

	if !ok {
		zap.S().Error("can not parse spin")

		return true
	}

	bonus := true
	if spinTyped.Bonus != nil {
		bonus = len(spinTyped.Bonus.Spins) == r.BonusSpinIndex
	}

	return r.BaseSpinIndex == 1 && bonus
}

func (r *RestoringIndexes) Update(payload interface{}) error {
	bytes, err := json.Marshal(payload)
	if err != nil {
		return err
	}

	return json.Unmarshal(bytes, r)
}
