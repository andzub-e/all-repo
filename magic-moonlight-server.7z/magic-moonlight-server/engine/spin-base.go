package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"github.com/mohae/deepcopy"
)

type SpinBase struct {
	WagerVal        int64       `json:"wager"`
	AnteBetWagerVal *int64      `json:"ante_bet_wager"`
	Win             int64       `json:"award"`
	Stops           []int       `json:"stops"`
	Avalanches      []Avalanche `json:"avalanches"`

	Bonus *Bonus `json:"bonus"`

	Features Features `json:"features"`
}

type Avalanche struct {
	Window   [][]int   `json:"window"`
	PayItems []PayItem `json:"pay_items"`
}

type PayItem struct {
	Symbol              int     `json:"symbol"`
	Indexes             [][]int `json:"indexes"`
	Award               int64   `json:"award"`
	Multiplier          int64   `json:"multiplier"`
	AwardWithMultiplier int64   `json:"award_with_multiplier"`
}

func (s *SpinBase) BaseAward() int64 {
	return s.Win
}

func (s *SpinBase) BonusAward() int64 {
	if s.Bonus == nil {
		return 0
	}

	return s.Bonus.Award()
}

func (s *SpinBase) GambleAward() int64 {
	return 0
}

func (s *SpinBase) Wager() int64 {
	if s.Features.AnteBet && s.AnteBetWagerVal != nil {
		return *s.AnteBetWagerVal
	}

	return s.WagerVal
}

func (s *SpinBase) BonusTriggered() bool {
	return s.Bonus != nil
}

func (s *SpinBase) GambleQuantity() int {
	return 0
}

func (s *SpinBase) CanGamble(_ engine.RestoringIndexes) bool {
	return false
}

func (s *SpinBase) DeepCopy() engine.Spin {
	return deepcopy.Copy(s).(engine.Spin)
}
