package engine

type Bonus struct {
	Wheel Wheel `json:"wheel"`

	Win   int64       `json:"award"`
	Spins []SpinBonus `json:"spins"`
}

type SpinBonus struct {
	Stops      []int  `json:"stops"`
	Award      int64  `json:"award"`
	SpinsLeft  int    `json:"spins_left"`
	Multiplier int64  `json:"multiplier"`
	Wheel      *Wheel `json:"wheel"`

	Avalanches []Avalanche `json:"avalanches"`
}

type Wheel struct {
	Spins      int   `json:"spins"`
	Multiplier int64 `json:"multiplier"`
}

func (b *Bonus) Award() int64 {
	if b == nil {
		return 0
	}

	return b.Win
}
