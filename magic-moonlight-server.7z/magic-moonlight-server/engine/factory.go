package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"bitbucket.org/electronicjaw/base-slot-server/utils"
	"encoding/json"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
	"strconv"
)

func Bootstrap(ctn di.Container, config *engine.Config) *engine.Bootstrap {
	rand := ctn.Get(constants.RNGName).(rng.Client)

	rtp, err := strconv.ParseFloat(config.RTP, 64)
	if err != nil {
		zap.S().Panic(err)
		panic(err)
	}

	baseConfigLowProb, anteConfigLowProb = calcRTP(rtp)

	cfgLow, err := utils.NewChooserFromMap(rand, configLow)
	if err != nil {
		zap.S().Panic(err)
		panic(err)
	}

	cfgHigh, err := utils.NewChooserFromMap(rand, configHigh)
	if err != nil {
		zap.S().Panic(err)
		panic(err)
	}

	cfgBuyBonus, err := utils.NewChooserFromMap(rand, configBuyBonus)
	if err != nil {
		zap.S().Panic(err)
		panic(err)
	}

	wheelSpinChooser, err := utils.NewChooserFromMap(rand, wheelSpinsConfig)
	if err != nil {
		zap.S().Panic(err)
		panic(err)
	}

	wheelMultiplierChooser, err := utils.NewChooserFromMap(rand, wheelMultipliersConfig)
	if err != nil {
		zap.S().Panic(err)
		panic(err)
	}

	factory := NewSpinFactory(rand, cfgLow, cfgHigh, cfgBuyBonus, wheelSpinChooser, wheelMultiplierChooser)

	return &engine.Bootstrap{
		SpinFactory:   factory,
		HTTPTransport: true,

		FreeSpinsFeature: true,

		AnteBetMultiplier: anteBetMultiplier,

		HistoryHandlingType: engine.SequentialRestoring,
	}
}

type SpinFactory struct {
	rand rng.Client

	cfgLow  *utils.Chooser[int, int]
	cfgHigh *utils.Chooser[int, int]

	cfgBuyBonus *utils.Chooser[int, int]

	wheelSpinChooser       *utils.Chooser[int, int]
	wheelMultiplierChooser *utils.Chooser[int64, int]
}

func NewSpinFactory(
	rand rng.Client,
	cfgLow, cfgHigh, cfgBuyBonus, wheelSpinChooser *utils.Chooser[int, int],
	wheelMultiplierChooser *utils.Chooser[int64, int],
) *SpinFactory {
	return &SpinFactory{
		rand:                   rand,
		cfgLow:                 cfgLow,
		cfgHigh:                cfgHigh,
		cfgBuyBonus:            cfgBuyBonus,
		wheelSpinChooser:       wheelSpinChooser,
		wheelMultiplierChooser: wheelMultiplierChooser,
	}
}

func (s *SpinFactory) Generate(
	ctx engine.Context, wager int64, parameters interface{},
) (engine.Spin, engine.RestoringIndexes, error) {
	features, err := getFeaturesFromParams(parameters)
	if err != nil {
		return nil, nil, err
	}

	cheats, err := getCheatsFromCtx(ctx)
	if err != nil {
		return nil, nil, err
	}

	ag, err := NewAwardGetter(wager)
	if err != nil {
		return nil, nil, err
	}

	var anteBetWagerVal *int64

	reelCode := reelSet1Code
	if features.AnteBet {
		reelCode = reelSet2Code

		anteBetWagerVal = ptr(wager * anteBetMultiplier / anteBetDivider)
	}

	stops, err := s.getStops(cheats, reelCode)
	if err != nil {
		return nil, nil, err
	}

	if features.BuyBonus {
		key, err := s.cfgBuyBonus.Pick()
		if err != nil {
			return nil, nil, err
		}

		stops = scatterStops[key]

		wager *= buyBonusMultiplier
	}

	config, err := s.getBaseConfig(features.AnteBet, ctx.RTP)
	if err != nil {
		return nil, nil, err
	}

	award, avalanches, bonus, err := s.computeBasicWindow(ag, *availableIndexedReels[reelCode], stops, config, cheats)
	if err != nil {
		return nil, nil, err
	}

	return &SpinBase{
		WagerVal:        wager,
		AnteBetWagerVal: anteBetWagerVal,
		Win:             award,
		Stops:           stops,
		Avalanches:      avalanches,
		Bonus:           bonus,
		Features:        features,
	}, &RestoringIndexes{}, nil
}

func (s *SpinFactory) KeepGenerate(_ engine.Context, _ interface{}) (engine.Spin, bool, error) {
	return nil, false, nil
}

func (s *SpinFactory) GambleAnyWin(_ engine.Context, _ interface{}) (engine.Spin, error) {
	return nil, nil
}

func (s *SpinFactory) UnmarshalJSONSpin(bytes []byte) (engine.Spin, error) {
	spin := SpinBase{}
	err := json.Unmarshal(bytes, &spin)

	return &spin, err
}

func (s *SpinFactory) UnmarshalJSONRestoringIndexes(bytes []byte) (engine.RestoringIndexes, error) {
	restoringIndexes := RestoringIndexes{}
	err := json.Unmarshal(bytes, &restoringIndexes)

	return &restoringIndexes, err
}

func ptr[T any](t T) *T {
	return &t
}

func calcRTP(rtp float64) (baseConfigLowProb, anteConfigLowProb float64) {
	mainRTP := rtp * mainRTPPercentage

	if mainRTP > highRTPBase {
		mainRTP = highRTPBase
	}

	if mainRTP < lowRTPBase {
		mainRTP = lowRTPBase
	}

	baseConfigLowProb = (highRTPBase - mainRTP) / (highRTPBase - lowRTPBase)
	anteConfigLowProb = 1 - baseConfigLowProb

	return
}
