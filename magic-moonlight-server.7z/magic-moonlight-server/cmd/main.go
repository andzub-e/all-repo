package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
	"magic-moonlight/engine"
)

func main() {
	application, err := app.New("config.yml", engine.Bootstrap)

	if err != nil {
		panic(err)
	}

	if err := application.Run(); err != nil {
		panic(err)
	}
}
