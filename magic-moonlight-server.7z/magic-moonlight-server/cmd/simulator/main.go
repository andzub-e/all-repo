package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/services"
	"bitbucket.org/electronicjaw/base-slot-server/utils"
	"fmt"
	"magic-moonlight/engine"
	"os"
	"path/filepath"
	"time"
)

func main() {
	now := time.Now()

	application, err := app.New("config.yml", engine.Bootstrap)
	if err != nil {
		panic(err)
	}

	simulator := application.GetSimulatorService()

	result, err := simulator.WithProgressListener(func(percent float64) {
		fmt.Printf("Processing: %2.0f%%\n", percent*100)
	}).WithWagerParameters(engine.Features{
		//AnteBet: true,
		//BuyBonus: true,
	}).Simulate("magic-moonlight", 1*1000*1000, 100, 16)

	if err != nil {
		panic(err)
	}

	reportPages := []utils.Page{
		{
			Name:  "Report",
			Table: utils.Transpose(utils.ExtractTable([]*services.SimulationView{result.View()}, "xlsx")),
		}}

	saveReport(reportPages)

	fmt.Printf("The program ran for %s\n", time.Since(now))
}

func saveReport(reportPages []utils.Page) {
	excel, err := utils.ExportMultiPageXLSX(reportPages)
	if err != nil {
		fmt.Printf("simulate: %v\n", err)
	}

	abs, err := filepath.Abs("reports")
	if err != nil {
		panic(err)
	}

	file, err := os.Create(filepath.Join(abs, fmt.Sprintf("report-%v.xlsx", time.Now().UnixNano())))
	if err != nil {
		fmt.Printf("simulate: %v\n", err)
	}

	if err = excel.Write(file); err != nil {
		fmt.Printf("simulate: %v\n", err)
	}
}
