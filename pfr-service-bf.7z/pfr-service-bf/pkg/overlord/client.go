package overlord

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"go.uber.org/zap"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
	"google.golang.org/grpc/credentials/insecure"
)

type Client interface {
	InitUserState(ctx context.Context, game, integrator string, lordParams interface{}) (state *InitUserStateOut, err error)
	GetStateBySessionToken(ctx context.Context, token string) (*InitUserStateOut, error)
	OpenBet(ctx context.Context, sessionToken, roundID, currency string, value int64) (*OpenBetResponse, error)
	OpenFreeBet(ctx context.Context, sessionToken, freeBetID, roundID string) (*OpenBetResponse, error)
	CloseBet(ctx context.Context, transactionID, currency string, value int64) (*CloseBetResponse, error)
	AtomicBet(ctx context.Context, sessionToken, freeBetID, roundID string, wager, award int64) (*AtomicBetOut, error)

	SaveSpin(ctx context.Context, in *SpinIn) error

	GetCurrencies(ctx context.Context) ([]string, error)
	GetIntegratorConfig(ctx context.Context, integrator, game string) (*GetIntegratorConfigOut, error)

	GetAvailableFreeSpins(ctx context.Context, sessionToken string) (*GetAvailableFreeBetsOut, error)
	CancelAvailableFreeSpins(ctx context.Context, sessionToken string) error

	AddFreeSpins(ctx context.Context, in *AddFreeBetIn) (*AddFreeBetOut, error)
	CancelFreeSpins(ctx context.Context, in *CancelFreeBetIn) (*CancelFreeBetOut, error)
}

type client struct {
	api OverlordClient
}

type Config struct {
	Host     string
	Port     string
	IsSecure bool
}

type OpenBetResponse struct {
	TransactionID string
	Balance       int64
}

type CloseBetResponse struct {
	Balance int64
}

func newClient(host, port string, isSecure bool) (OverlordClient, error) {
	addr := host + ":" + port

	var (
		conn *grpc.ClientConn
		err  error
	)

	if isSecure {
		config := &tls.Config{
			InsecureSkipVerify: false,
		}

		conn, err = grpc.Dial(addr, grpc.WithTransportCredentials(credentials.NewTLS(config)))
	} else {
		conn, err = grpc.Dial(addr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	}

	if err != nil {
		return nil, err
	}

	return NewOverlordClient(conn), nil
}

func NewClient(cfg *Config) (Client, error) {
	var err error

	service := &client{}
	service.api, err = newClient(cfg.Host, cfg.Port, cfg.IsSecure)

	if err != nil {
		return service, err
	}

	return service, nil
}

func (o *client) GetStateBySessionToken(ctx context.Context, token string) (*InitUserStateOut, error) {
	zap.S().Info("repo: GetStateBySessionToken starting...")

	in := &GetStateBySessionTokenIn{SessionToken: token}

	state, err := o.api.GetStateBySessionToken(ctx, in)
	if err != nil {
		return state, mapError(err)
	}

	return state, nil
}

func (o *client) InitUserState(ctx context.Context,
	game, integrator string, lordParams interface{}) (state *InitUserStateOut, err error) {
	zap.S().Info("repo: InitUserState starting...")

	// Create API request
	initUserStateIn := &InitUserStateIn{
		Integrator: integrator,
		Game:       game,
	}

	initUserStateIn.Params, err = json.Marshal(lordParams)
	if err != nil {
		zap.S().Error(err)

		return nil, ErrMarshaling
	}

	res, err := o.api.InitUserState(ctx, initUserStateIn)
	if err != nil {
		return nil, mapError(err)
	}

	return res, nil
}

func (o *client) OpenBet(ctx context.Context,
	sessionToken, roundID, currency string, value int64) (*OpenBetResponse, error) {
	p := &OpenBetIn{SessionToken: sessionToken, RoundId: roundID, Wager: value}

	bet, err := o.api.OpenBet(ctx, p)

	if err != nil {
		return nil, mapError(err)
	}

	y := &OpenBetResponse{TransactionID: bet.TransactionId, Balance: bet.Balance}

	return y, nil
}

func (o *client) OpenFreeBet(ctx context.Context, sessionToken, freeBetID, roundID string) (*OpenBetResponse, error) {
	p := &OpenFreeBetIn{SessionToken: sessionToken, FreeBetId: freeBetID, RoundId: roundID}

	bet, err := o.api.OpenFreeBet(ctx, p)
	if err != nil {
		return nil, mapError(err)
	}

	y := &OpenBetResponse{TransactionID: bet.TransactionId, Balance: bet.Balance}

	return y, nil
}

func (o *client) CloseBet(ctx context.Context, transactionID, currency string, value int64) (*CloseBetResponse, error) {
	p := &CloseBetIn{TransactionId: transactionID, Award: value}
	bet, err := o.api.CloseBet(ctx, p)

	if err != nil {
		return nil, err
	}

	y := &CloseBetResponse{Balance: bet.Balance}

	return y, nil
}

func (o *client) GetCurrencies(ctx context.Context) ([]string, error) {
	res, err := o.api.GetAvailableCurrencies(ctx, &GetAvailableCurrenciesIn{})
	if err != nil {
		return nil, err
	}

	return res.Currencies, nil
}

func (o *client) GetIntegratorConfig(ctx context.Context, integrator, game string) (*GetIntegratorConfigOut, error) {
	res, err := o.api.GetIntegratorConfig(ctx, &GetIntegratorConfigIn{Integrator: integrator, Game: game})
	if err != nil {
		return nil, err
	}

	return res, nil
}

func (o *client) GetAvailableFreeSpins(ctx context.Context, sessionToken string) (*GetAvailableFreeBetsOut, error) {
	zap.S().Info("repo: GetAvailableFreeSpins starting...")

	in := &GetAvailableFreeBetsIn{SessionToken: sessionToken}

	freeBets, err := o.api.GetAvailableFreeBets(ctx, in)
	if err != nil {
		return freeBets, mapError(err)
	}

	return freeBets, err
}

func (o *client) CancelAvailableFreeSpins(ctx context.Context, sessionToken string) error {
	in := &CancelAvailableFreeBetsIn{SessionToken: sessionToken}

	_, err := o.api.CancelAvailableFreeBets(ctx, in)

	return err
}

func (o *client) AddFreeSpins(ctx context.Context, in *AddFreeBetIn) (*AddFreeBetOut, error) {
	return o.api.AddFreeBets(ctx, in)
}

func (o *client) CancelFreeSpins(ctx context.Context, in *CancelFreeBetIn) (*CancelFreeBetOut, error) {
	return o.api.CancelFreeBets(ctx, in)
}

func (o *client) AtomicBet(ctx context.Context, sessionToken, freeBetID, roundID string, wager, award int64) (*AtomicBetOut, error) {
	return o.api.AtomicBet(ctx, &AtomicBetIn{
		SessionToken: sessionToken,
		FreeBetId:    freeBetID,
		RoundId:      roundID,
		Wager:        wager,
		Award:        award,
	})
}

func (o *client) SaveSpin(ctx context.Context, in *SpinIn) error {
	_, err := o.api.SaveSpin(ctx, in)

	return err
}
