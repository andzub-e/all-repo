package utils

import "encoding/json"

func RemarshalJSON(from, to interface{}) error {
	b, err := json.Marshal(from)
	if err != nil {
		return err
	}

	return json.Unmarshal(b, &to)
}
