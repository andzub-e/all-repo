package constants

const (
	ConfigName   = "Config"
	LoggerName   = "Logger"
	ServerName   = "Server"
	OverlordName = "Overlord"
	TracerName   = "Tracer"
	PgSQLName    = "PgSQL"

	FreeSpinsServiceName = "FreeSpinsService"
	LemonServiceName     = "LemonService"
	InfinServiceName     = "InfinService"
	BFServiceName        = "BFService"

	MetaHandlerName      = "MetaHandler"
	FreeSpinsHandlerName = "FreeSpinsHandler"
	LemonHandlerName     = "LemonHandler"
	InfinHandlerName     = "InfinHandler"
	BFHandlerName        = "BFHandler"

	BFProgramRepositoryName        = "BFProgramRepository"
	InfingameProgramRepositoryName = "InfingameProgramRepository"

	HTTPCorsMiddlewareName       = "HTTPCorsMiddleware"
	HTTPTraceMiddlewareName      = "HTTPTraceMiddleware"
	HTTPRequestLogMiddlewareName = "HTTPRequestLogMiddleware"
)
