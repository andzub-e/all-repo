package entities

import (
	"github.com/google/uuid"
	"time"
)

type Program[T any] struct {
	CreatedAt time.Time  `json:"created_at"`
	StartsAt  *time.Time `json:"starts_at"`
	EndsAt    *time.Time `json:"ends_at"`

	ID           uuid.UUID `json:"id"`
	IntegratorID string    `json:"integrator_id"`
	Integrator   string    `json:"integrator"`

	MaxUsageCount *int `json:"max_usage_count"`
	Data          T    `json:"data" gorm:"serializer:json"`
}

func (Program[T]) TableName() string {
	return "programs"
}

type BFProgramData struct {
	Name        string         `json:"name"`
	Games       []string       `json:"games"`
	RoundValues []BFRoundValue `json:"roundValues"`
	RoundCount  int            `json:"round_count"`
}

type BFRoundValue struct {
	Currency string `json:"currency"`
	Amount   int64  `json:"amount"`
}

type InfinProgramData struct {
	Login      string `json:"login"`
	Password   string `json:"password"`
	Game       string `json:"game"`
	Currency   string `json:"currency"`
	Spins      int    `json:"spins"`
	WagerValue int64  `json:"wager_value"`
}
