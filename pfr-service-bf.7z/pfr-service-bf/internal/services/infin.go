package services

import (
	"context"
	"encoding/json"
	"encoding/xml"
	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
	"math/rand"
	"pfr-service/internal/entities"
	"pfr-service/internal/errs"
	"pfr-service/internal/repositories"
	"pfr-service/pkg/overlord"
	"strconv"
	"strings"
	"time"
)

const (
	InfingameIntegratorName     = "infingame"
	InfingameCurrencyMultiplier = 10
)

type InfinService struct {
	overlord          overlord.Client
	programRepository repositories.ProgramRepository[entities.InfinProgramData]
}

func NewInfinService(overlord overlord.Client, programRepository repositories.ProgramRepository[entities.InfinProgramData]) *InfinService {
	return &InfinService{
		overlord:          overlord,
		programRepository: programRepository,
	}
}

type GiftOfferUser struct {
	GiftID string `xml:"gift_id,attr"`
}

type InfinResponse struct {
	XMLName xml.Name       `xml:"result"`
	Status  string         `xml:"status,attr"`
	Gift    *GiftOfferUser `xml:"gift_offer_user,omitempty"`
}

func (s *InfinService) CreateOffer(ctx context.Context, login, password, offer, currency, game string,
	spins, lines, betLine int, startLive, endDateAddOffer time.Time) (*InfinResponse, error) {

	passwordHash, err := bcrypt.GenerateFromPassword([]byte(password), 15)
	if err != nil {
		return nil, err
	}

	pr := &entities.Program[entities.InfinProgramData]{
		CreatedAt: time.Now(),
		StartsAt:  &startLive,
		EndsAt:    &endDateAddOffer,

		ID:           uuid.New(),
		IntegratorID: offer,
		Integrator:   InfingameIntegratorName,

		Data: entities.InfinProgramData{
			Login:      login,
			Password:   string(passwordHash),
			Game:       game,
			Currency:   strings.ToLower(currency),
			Spins:      spins,
			WagerValue: int64(lines * betLine),
		},
	}

	if err := s.programRepository.Upsert(ctx, pr); err != nil {
		return nil, err
	}

	return &InfinResponse{
		Status: "ok",
	}, nil
}

func (s *InfinService) AddOffer(ctx context.Context, login, password, offer, wlid string) (*InfinResponse, error) {
	pr, err := s.programRepository.FindBy(ctx, map[string]interface{}{"integrator": InfingameIntegratorName, "integrator_id": offer})
	if err != nil {
		return nil, err
	}

	if pr.Data.Login == login && bcrypt.CompareHashAndPassword([]byte(pr.Data.Password), []byte(password)) != nil {
		return nil, errs.ErrUnauthorized
	}

	bonusID := strconv.Itoa(int(rand.Int31()))

	ad := map[string]interface{}{
		"program_id": offer,
	}

	adRaw, err := json.Marshal(ad)
	if err != nil {
		return nil, err
	}

	_, err = s.overlord.AddFreeSpins(ctx, &overlord.AddFreeBetIn{
		UserId:         wlid,
		BetValue:       pr.Data.WagerValue * InfingameCurrencyMultiplier,
		FreeBets:       int32(pr.Data.Spins),
		Currency:       strings.ToLower(pr.Data.Currency),
		EndDate:        pr.EndsAt.Unix(),
		FreeBetId:      bonusID,
		Game:           pr.Data.Game,
		Provider:       InfingameIntegratorName,
		IntegratorKey:  InfingameIntegratorName,
		SecretToken:    InfingameIntegratorName,
		AdditionalData: adRaw,
	})

	if err != nil {
		return nil, err
	}

	return &InfinResponse{
		Status: "ok",
		Gift: &GiftOfferUser{
			GiftID: bonusID,
		},
	}, nil
}
