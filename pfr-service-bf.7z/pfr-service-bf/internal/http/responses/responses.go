package responses

type HealthResponse struct {
	Success string `json:"success"`
}

type InfoResponse struct {
	Tag string `json:"tag"`
}

type LemonAddResponse struct {
	BonusID string `json:"BonusId"`
}

type BFCreateProgramResponse struct {
	ProviderBonusProgramId string `json:"providerBonusProgramId"`
}

type BFCreateFreeSpinsResponse struct {
	PlayerId                string `json:"playerId"`
	ProviderBonusInstanceId string `json:"providerBonusInstanceId"`
}
