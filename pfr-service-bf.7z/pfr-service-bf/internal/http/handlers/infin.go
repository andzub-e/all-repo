package handlers

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
	"pfr-service/internal/http/requests"
	"pfr-service/internal/services"
	"time"
)

const TimeLayout = "02/01/2006 15:04"

type infinHandler struct {
	infinService *services.InfinService
}

func NewInfinHandler(infinService *services.InfinService) *infinHandler {
	return &infinHandler{infinService: infinService}
}

func (h *infinHandler) Register(router *gin.RouterGroup) {
	infin := router.Group("infin")

	infin.GET("", h.infin)
}

func (h *infinHandler) infin(ctx *gin.Context) {
	command := ctx.Query("cm")

	switch command {
	case "create_offer":
		h.createOffer(ctx)
	case "add_offer":
		h.addOffer(ctx)
	default:
		ctx.XML(http.StatusBadRequest, fmt.Sprintf("command %v not supported", command))
	}
}

func (h *infinHandler) createOffer(ctx *gin.Context) {
	req := requests.InfinCreateOfferResponse{}
	if err := ctx.BindQuery(&req); err != nil {
		ctx.XML(http.StatusBadRequest, err)

		return
	}

	startLive, err := time.Parse(TimeLayout, req.StartLive)
	if err != nil {
		ctx.XML(http.StatusBadRequest, err)

		return
	}

	endDataAddOffer, err := time.Parse(TimeLayout, req.EndDataAddOffer)
	if err != nil {
		ctx.XML(http.StatusBadRequest, err)

		return
	}

	res, err := h.infinService.CreateOffer(ctx, req.Login, req.Password, req.Offer, req.Currency, req.Game, req.Spins, req.Lines, req.BetLine, startLive, endDataAddOffer)
	if err != nil {
		ctx.XML(http.StatusBadRequest, err.Error())

		return
	}

	ctx.XML(http.StatusOK, res)
}

func (h *infinHandler) addOffer(ctx *gin.Context) {
	req := requests.InfinAddOfferResponse{}
	if err := ctx.BindQuery(&req); err != nil {
		ctx.XML(http.StatusBadRequest, err)

		return
	}

	res, err := h.infinService.AddOffer(ctx, req.Login, req.Password, req.Offer, req.Wlid)
	if err != nil {
		ctx.XML(http.StatusBadRequest, err.Error())

		return
	}

	ctx.XML(http.StatusOK, res)
}
