package handlers

import (
	"github.com/gin-gonic/gin"
	"pfr-service/internal/errs"
	"pfr-service/internal/http/responses"
)

var errorMap = map[error]func(ctx *gin.Context, data interface{}, meta map[string]interface{}){
	errs.ErrBadDataGiven:      responses.BadRequest,
	errs.ErrWrongSessionToken: responses.Unauthorized,
	errs.ErrWrongFreeSpinID:   responses.Conflict,
}

func handleServiceError(ctx *gin.Context, err error) {
	internalValidationError, ok := err.(errs.InternalValidationError)
	if ok {
		responses.ValidationFailed(ctx, internalValidationError)

		return
	}

	fn, ok := errorMap[err]
	if !ok {
		responses.ServerError(ctx, err, nil)

		return
	}

	fn(ctx, err, nil)
}
