package handlers

import (
	"github.com/gin-gonic/gin"
	"net"
	"pfr-service/internal/entities"
	"pfr-service/internal/http/responses"
	"pfr-service/internal/services"
)

type lemonHandler struct {
	lemonService   *services.LemonService
	lemonWhiteList []net.IP
}

func NewLemonHandler(lemonService *services.LemonService, lemonWhiteList []net.IP) *lemonHandler {
	return &lemonHandler{lemonService: lemonService, lemonWhiteList: lemonWhiteList}
}

func (l *lemonHandler) Register(router *gin.RouterGroup) {
	lemon := router.Group("lemon/FreeRounds")
	//lemon.Use(middlewares.IPWhiteList(l.lemonWhiteList))

	lemon.POST("Add", l.Add)
	lemon.POST("Remove", l.Remove)
}

func (l *lemonHandler) Add(ctx *gin.Context) {
	req := entities.LemonAddFreeBet{}
	if err := ctx.ShouldBindJSON(&req); err != nil {
		responses.ValidationFailed(ctx, err)

		return
	}

	bonusID, err := l.lemonService.AddFreeBet(ctx.Request.Context(), req)
	if err != nil {
		handleServiceError(ctx, err)

		return
	}

	responses.OKPure(ctx, responses.LemonAddResponse{BonusID: bonusID})
}

func (l *lemonHandler) Remove(ctx *gin.Context) {
	req := entities.LemonRemoveFreeBet{}
	if err := ctx.ShouldBindJSON(&req); err != nil {
		responses.ValidationFailed(ctx, err)

		return
	}

	err := l.lemonService.RemoveFreeBet(ctx.Request.Context(), req)
	if err != nil {
		handleServiceError(ctx, err)

		return
	}

	responses.OK(ctx, nil, nil)
}
