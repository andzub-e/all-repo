package requests

type InfinOfferRequest struct {
	Login    string `form:"login"`
	Password string `form:"password"`
	Command  string `form:"cm"`
}

type InfinCreateOfferResponse struct {
	InfinOfferRequest
	Offer    string `form:"offer"`
	Game     string `form:"game"`
	Currency string `form:"currency"`

	Spins   int `form:"spins"`
	Lines   int `form:"lines"`
	BetLine int `form:"bet-line"`

	StartLive       string `form:"start_live"`
	EndDataAddOffer string `form:"end_date_add_offer"`
}

type InfinAddOfferResponse struct {
	InfinOfferRequest
	Offer    string `form:"offer"`
	Wlid     string `form:"wlid"`
	Lifetime string `form:"lifetime"`
}
