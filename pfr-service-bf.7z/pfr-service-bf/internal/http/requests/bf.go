package requests

type BFAddProgramRequest struct {
	BonusProgramId string   `json:"bonusProgramId"`
	Name           string   `json:"name"`
	BonusSystemId  string   `json:"bonusSystemId"`
	Games          []string `json:"games"`
	RoundsCount    int      `json:"roundsCount"`

	RoundValues           []interface{} `json:"roundValues"`
	ExpiryDate            int64         `json:"expiryDate"`
	StartDate             *int64        `json:"startDate"`
	UsePeriod             int           `json:"usePeriod"`
	MaxProgramRoundsCount int           `json:"maxProgramRoundsCount"`
}

type BFAddFreeSpinsRequest struct {
	PlayerId string `json:"playerId"`

	BonusInstanceId string `json:"bonusInstanceId"`
	BonusProgramId  string `json:"bonusProgramId"`

	Games       []string `json:"games"`
	Currency    string   `json:"currency"`
	RoundsCount int      `json:"roundsCount"`
	RoundValue  int      `json:"roundValue"`
	ExpiryDate  int64    `json:"expiryDate"`
}

type BFGetFreeSpinsRequest struct {
	PlayerID     string `json:"playerId" form:"playerId"`
	ProviderCode string `json:"providerCode" form:"providerCode"`
}
