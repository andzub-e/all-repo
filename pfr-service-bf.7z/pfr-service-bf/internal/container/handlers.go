package container

import (
	"github.com/sarulabs/di"
	"pfr-service/internal/config"
	"pfr-service/internal/constants"
	"pfr-service/internal/http/handlers"
	"pfr-service/internal/services"
)

func BuildHandlers() []di.Def {
	return []di.Def{
		{
			Name: constants.FreeSpinsHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				svc := ctn.Get(constants.FreeSpinsServiceName).(*services.FreeSpinService)
				cfg := ctn.Get(constants.ConfigName).(*config.Config)

				return handlers.NewFreeSpinsHandler(svc, cfg.ServerConfig.MaxProcessingTime), nil
			},
		},
		{
			Name: constants.MetaHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				return handlers.NewMetaHandler(), nil
			},
		},
		{
			Name: constants.LemonHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				lemonService := ctn.Get(constants.LemonServiceName).(*services.LemonService)
				cfg := ctn.Get(constants.ConfigName).(*config.Config)

				return handlers.NewLemonHandler(lemonService, cfg.LemonWhiteList), nil
			},
		},
		{
			Name: constants.InfinHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				return handlers.NewInfinHandler(ctn.Get(constants.InfinServiceName).(*services.InfinService)), nil
			},
		},
		{
			Name: constants.BFHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				return handlers.NewBFHandler(ctn.Get(constants.BFServiceName).(*services.BFService)), nil
			},
		},
	}
}
