package container

import (
	"github.com/sarulabs/di"
	"pfr-service/internal/constants"
	"pfr-service/internal/http/middlewares"
	"pfr-service/pkg/tracer"
)

func BuildMiddlewares() []di.Def {
	return []di.Def{
		{
			Name: constants.HTTPCorsMiddlewareName,
			Build: func(ctn di.Container) (interface{}, error) {
				return middlewares.CORSMiddleware, nil
			},
		},
		{
			Name: constants.HTTPTraceMiddlewareName,
			Build: func(ctn di.Container) (interface{}, error) {
				tr := ctn.Get(constants.TracerName).(*tracer.JaegerTracer)

				return middlewares.TraceMiddleware(tr), nil
			},
		},
		{
			Name: constants.HTTPRequestLogMiddlewareName,
			Build: func(ctn di.Container) (interface{}, error) {
				return middlewares.RequestLog(), nil
			},
		},
	}
}
