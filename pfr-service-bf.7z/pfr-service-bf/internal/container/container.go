package container

import (
	"context"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
	"pfr-service/internal/config"
	"pfr-service/internal/constants"
	"pfr-service/internal/http"
	"pfr-service/pkg/overlord"
	"pfr-service/pkg/pgsql"
	"pfr-service/pkg/tracer"
	"sync"
)

var container di.Container
var once sync.Once

func Build(ctx context.Context, wg *sync.WaitGroup) di.Container {
	once.Do(func() {
		builder, _ := di.NewBuilder()
		defs := []di.Def{
			{
				Name: constants.LoggerName,
				Build: func(ctn di.Container) (interface{}, error) {
					logger, err := zap.NewDevelopment()

					if err != nil {
						return nil, fmt.Errorf("can't initialize zap logger: %v", err)
					}

					zap.ReplaceGlobals(logger)
					return logger, nil
				},
			},
			{
				Name: constants.ConfigName,
				Build: func(ctn di.Container) (interface{}, error) {
					return config.New()
				},
			},
			{
				Name: constants.PgSQLName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)
					tr := ctn.Get(constants.TracerName).(*tracer.JaegerTracer)

					return pgsql.NewPgsqlConnection(cfg.PgSQLConfig, tr.TracerProvider(), true)
				},
			},
			{
				Name: constants.OverlordName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return overlord.NewClient(cfg.OverlordConfig)
				},
			},
			{
				Name: constants.TracerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return tracer.NewTracer(cfg.TracerConfig)
				},
			},
			{
				Name: constants.ServerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)
					var publicHandlers = []http.Handler{
						ctn.Get(constants.FreeSpinsHandlerName).(http.Handler),
						ctn.Get(constants.LemonHandlerName).(http.Handler),
						ctn.Get(constants.InfinHandlerName).(http.Handler),
						ctn.Get(constants.BFHandlerName).(http.Handler),
						ctn.Get(constants.MetaHandlerName).(http.Handler),
					}
					var privateHandlers []http.Handler

					var middlewares = []func(ctx *gin.Context){
						ctn.Get(constants.HTTPCorsMiddlewareName).(func(ctx *gin.Context)),
						ctn.Get(constants.HTTPTraceMiddlewareName).(func(ctx *gin.Context)),
						ctn.Get(constants.HTTPRequestLogMiddlewareName).(func(ctx *gin.Context)),
					}

					return http.New(ctx, wg, cfg.ServerConfig, publicHandlers, privateHandlers, middlewares), nil
				},
			},
		}

		defs = append(defs, BuildServices()...)
		defs = append(defs, BuildHandlers()...)
		defs = append(defs, BuildMiddlewares()...)
		defs = append(defs, BuildRepositories()...)

		if err := builder.Add(defs...); err != nil {
			panic(err)
		}

		container = builder.Build()
	})

	return container
}
