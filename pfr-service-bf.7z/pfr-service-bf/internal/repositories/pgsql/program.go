package pgsql

import (
	"context"
	"gorm.io/gorm"
	"pfr-service/internal/entities"
)

type ProgramRepository[T any] struct {
	conn *gorm.DB
}

func NewProgramRepository[T any](conn *gorm.DB) *ProgramRepository[T] {
	return &ProgramRepository[T]{
		conn: conn,
	}
}

func (r *ProgramRepository[T]) Upsert(ctx context.Context, program *entities.Program[T]) error {
	return r.conn.WithContext(ctx).Save(program).Error
}

func (r *ProgramRepository[T]) FindBy(ctx context.Context, conditions map[string]interface{}) (m *entities.Program[T], err error) {
	query := r.conn.WithContext(ctx).Where(conditions)

	err = query.First(&m).Error

	return m, err
}

func (r *ProgramRepository[T]) Delete(ctx context.Context, program *entities.Program[T]) error {
	return r.conn.WithContext(ctx).Model(&program).Delete(&program).Error
}
