package repositories

import (
	"context"
	"pfr-service/internal/entities"
)

type ProgramRepository[T any] interface {
	Upsert(ctx context.Context, program *entities.Program[T]) error
	FindBy(ctx context.Context, conditions map[string]interface{}) (m *entities.Program[T], err error)
	Delete(ctx context.Context, program *entities.Program[T]) error
}
