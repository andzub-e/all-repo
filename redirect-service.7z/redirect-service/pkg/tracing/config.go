package tracing

type Config struct {
	Host string
}
