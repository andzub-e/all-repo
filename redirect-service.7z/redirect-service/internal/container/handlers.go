package container

import (
	"github.com/sarulabs/di"
	"project-layout/internal/constants"
	"project-layout/internal/http/handlers"
)

func BuildHandlers() []di.Def {
	return []di.Def{
		{
			Name: constants.TestHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {

				return handlers.NewTestHandler(), nil
			},
		},
	}
}
