package container

import "github.com/sarulabs/di"

func BuildServices() []di.Def {
	return []di.Def{}
}
