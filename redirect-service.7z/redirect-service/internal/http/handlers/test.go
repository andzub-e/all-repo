package handlers

import (
	"github.com/gin-gonic/gin"
	"go.opentelemetry.io/otel/trace"
	"project-layout/internal/http"
	"project-layout/pkg/tracing"
)

type testHandler struct {
}

func NewTestHandler() http.Handler {
	return &testHandler{}
}

func (h *testHandler) Register(route *gin.RouterGroup) {
	route.GET("/", func(ctx *gin.Context) {
		tracer := ctx.Value(tracing.TracerKey).(trace.Tracer)
		_, span := tracer.Start(ctx.Request.Context(), "Get test endpoint")
		defer span.End()

		ctx.JSON(200, []int{})
	})
}
