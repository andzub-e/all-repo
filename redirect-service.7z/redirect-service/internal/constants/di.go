package constants

const (
	ConfigName  = "Config"
	LoggerName  = "Logger"
	PgSQLName   = "PgSQL"
	ServerName  = "Server"
	TracingName = "TracingProvider"

	TestHandlerName = "TestHandler"
)
