package engine

import "github.com/samber/lo"

const (
	rtp94 = "94"
	rtp96 = "96"

	pl5  = "5"
	pl20 = "20"
	pl40 = "40"

	scatterSymbol = "s"
	windSymbol    = "w"
	potSymbol     = "t"

	windowHeight3         = 3
	windowWidth           = 5
	windowHeight4         = 4
	multiplicationDivider = 100

	HighRTPReelCode = 0
	LowRTPReelCode  = 1
)

var (
	rtp             = ""
	pl              = ""
	highRTPReelRate = 0.0
)

var (
	payLines            [][]int
	multipliers         map[string]map[int]int64
	reelsHighRTP        [][]string
	reelsLowRTP         [][]string
	currentWindowHeight int
)

var availableReelTypes = []int{HighRTPReelCode, LowRTPReelCode}
var availableReels = []*[][]string{&reelsHighRTP, &reelsLowRTP}

type Window [][]string

func (w *Window) compute(stops []int, reels [][]string) {
	*w = lo.Map(stops, func(stop int, index int) []string {
		reel := reels[index]
		reelLen := len(reel)

		windowLine := make([]string, currentWindowHeight)
		for j := 0; j < currentWindowHeight; j++ {
			windowLine[j] = reel[(stop+j)%reelLen]
		}

		return windowLine
	})
}

func (w Window) symbol(payIndex int) string {
	position, reel := payIndex/windowWidth, payIndex%windowWidth

	return w[reel][position]
}

func awardBySymbolAndCount(symbol string, count int, wager int64) int64 {
	mul := multipliers[symbol][count]

	return mul * wager / multiplicationDivider
}
