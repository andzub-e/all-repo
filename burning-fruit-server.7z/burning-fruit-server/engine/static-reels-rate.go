package engine

var HighRTPReelRates = map[string]map[string]float64{
	pl5: {
		rtp94: 0.2935,
		rtp96: 0.3035,
	},
	pl20: {
		rtp94: 0.2933,
		rtp96: 0.3035,
	},
	pl40: {
		rtp94: 0.2925,
		rtp96: 0.3037,
	},
}
