package main

import (
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/internal/roulette"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/app"
)

func main() {
	application, err := app.New("config.yml", roulette.GameBoot)

	if err != nil {
		panic(err)
	}

	if err := application.Run(); err != nil {
		panic(err)
	}
}
