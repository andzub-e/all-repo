package rng

import (
	"github.com/stretchr/testify/assert"
	"testing"
	"time"
)

func TestNewFantasmaClient(t *testing.T) {
	// https://staging.fantasma.tech/rng/numbers?provider=ejaw&game=luckyotter&total=5
	cfg := &Config{
		Host:              "staging.fantasma.tech",
		Port:              "",
		Game:              "luckyotter",
		IsSecure:          true,
		MaxProcessingTime: 30 * time.Second,
	}

	client, err := NewFantasmaClient(cfg)
	assert.NoError(t, err)
	assert.NotNil(t, client)
}

func TestFantasmaClient_Rand(t *testing.T) {
	// https://staging.fantasma.tech/rng/numbers?provider=ejaw&game=luckyotter&total=5
	cfg := &Config{
		Host:              "staging.fantasma.tech",
		Port:              "",
		Game:              "luckyotter",
		IsSecure:          true,
		MaxProcessingTime: 30 * time.Second,
	}

	client, _ := NewFantasmaClient(cfg)

	rand, err := client.Rand(100)
	assert.NoError(t, err)
	assert.True(t, rand >= 0 && rand <= 100)
}

func TestFantasmaClient_RandSlice(t *testing.T) {
	// https://staging.fantasma.tech/rng/numbers?provider=ejaw&game=luckyotter&total=5
	cfg := &Config{
		Host:              "staging.fantasma.tech",
		Port:              "",
		Game:              "luckyotter",
		IsSecure:          true,
		MaxProcessingTime: 30 * time.Second,
	}

	client, _ := NewFantasmaClient(cfg)

	maxSlice := []uint64{50, 100, 150}
	randSlice, err := client.RandSlice(maxSlice)
	assert.NoError(t, err)

	for i, maxVal := range maxSlice {
		assert.True(t, randSlice[i] >= 0 && randSlice[i] <= maxVal)
	}
}

func TestFantasmaClient_RandFloat(t *testing.T) {
	// https://staging.fantasma.tech/rng/numbers?provider=ejaw&game=luckyotter&total=5
	cfg := &Config{
		Host:              "staging.fantasma.tech",
		Port:              "",
		Game:              "luckyotter",
		IsSecure:          true,
		MaxProcessingTime: 30 * time.Second,
	}

	client, _ := NewFantasmaClient(cfg)

	randFloat, err := client.RandFloat()
	assert.NoError(t, err)
	assert.True(t, randFloat >= 0 && randFloat <= 1)
}

func TestFantasmaClient_RandFloatSlice(t *testing.T) {
	// https://staging.fantasma.tech/rng/numbers?provider=ejaw&game=luckyotter&total=5
	cfg := &Config{
		Host:              "staging.fantasma.tech",
		Port:              "",
		Game:              "luckyotter",
		IsSecure:          true,
		MaxProcessingTime: 30 * time.Second,
	}

	client, _ := NewFantasmaClient(cfg)

	count := 5
	randFloatSlice, err := client.RandFloatSlice(count)
	assert.NoError(t, err)
	assert.Len(t, randFloatSlice, count)

	for _, randFloat := range randFloatSlice {
		assert.True(t, randFloat >= 0 && randFloat <= 1)
	}
}
