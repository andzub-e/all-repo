package rng

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
)

type APIClient interface {
	GetRand(ctx context.Context, total int) ([]float64, error)
}

type api struct {
	Host     string
	Port     string
	IsSecure bool
	Game     string
}

func NewClient(host, port, game string, isSecure bool) APIClient {
	return &api{
		Host:     host,
		Port:     port,
		IsSecure: isSecure,
		Game:     game,
	}
}

func (c *api) GetRand(ctx context.Context, total int) ([]float64, error) {
	schema := "http"
	if c.IsSecure {
		schema = "https"
	}

	domain := c.Host
	if c.Port != "" {
		domain = fmt.Sprintf("%s:%s", c.Host, c.Port)
	}

	url := fmt.Sprintf("%s://%s/rng/numbers?provider=ejaw&game=%s&total=%d", schema, domain, c.Game, total)

	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return nil, err
	}

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result map[string][]float64
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}

	return result["numbers"], nil
}
