package rng

import (
	"context"
	"go.uber.org/zap"
	"math"
	"time"
)

const minValue = uint64(0)

type FantasmaClient struct {
	api               APIClient
	MaxProcessingTime time.Duration
}

func NewFantasmaClient(cfg *Config) (Client, error) {
	client := &FantasmaClient{}
	client.api = NewClient(cfg.Host, cfg.Port, cfg.Game, cfg.IsSecure)
	client.MaxProcessingTime = cfg.MaxProcessingTime

	return client, nil
}

func (c *FantasmaClient) Rand(max uint64) (rand uint64, err error) {
	ctx, cancel := context.WithTimeout(context.Background(), c.MaxProcessingTime)
	defer cancel()

	resp, err := c.api.GetRand(ctx, 1)
	if err != nil {
		zap.S().Errorf("can not rand int: %v", err)

		return 0, err
	}

	return convertToInteger(minValue, max, resp[0]), nil
}

func (c *FantasmaClient) RandSlice(maxSlice []uint64) (rand []uint64, err error) {
	ctx, cancel := context.WithTimeout(context.Background(), c.MaxProcessingTime)
	defer cancel()

	resp, err := c.api.GetRand(ctx, len(maxSlice))
	if err != nil {
		zap.S().Errorf("can not rand int: %v", err)

		return nil, err
	}

	return sliceOfValues(resp, maxSlice, len(maxSlice)), nil
}

func (c *FantasmaClient) RandFloat() (float64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), c.MaxProcessingTime)
	defer cancel()

	resp, err := c.api.GetRand(ctx, 1)
	if err != nil {
		zap.S().Errorf("can not rand int: %v", err)

		return 0, err
	}

	return resp[0], nil
}

func (c *FantasmaClient) RandFloatSlice(count int) ([]float64, error) {
	ctx, cancel := context.WithTimeout(context.Background(), c.MaxProcessingTime)
	defer cancel()

	resp, err := c.api.GetRand(ctx, count)
	if err != nil {
		zap.S().Errorf("can not rand int: %v", err)

		return nil, err
	}

	return resp, nil
}

func convertToInteger(min, max uint64, random float64) uint64 {
	return min + uint64(math.Floor(random*float64(max-min+1)))
}

func sliceOfValues(rand []float64, value []uint64, size int) []uint64 {
	buf := make([]uint64, size)
	for i := 0; i < size; i++ {
		res := convertToInteger(minValue, value[i], rand[i])
		buf[i] = res
	}

	return buf
}
