package rng

import (
	"context"
	"fmt"
	"testing"
	"time"
)

func TestApi_GetRand(t *testing.T) {
	// https://staging.fantasma.tech/rng/numbers?provider=ejaw&game=luckyotter&total=5
	client := NewClient("staging.fantasma.tech", "", "luckyotter", true)
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	total := 5

	rand, err := client.GetRand(ctx, total)
	if err != nil {
		t.Errorf(err.Error())
	}

	fmt.Println("values:")
	for i := 0; i < len(rand); i++ {
		fmt.Println(rand[i])
	}
	fmt.Println("count of values: ", len(rand))
}
