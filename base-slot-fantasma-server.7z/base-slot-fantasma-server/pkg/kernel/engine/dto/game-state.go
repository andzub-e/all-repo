package dto

type GameConfig struct {
	//todo: think about format
}

type ResponseBet struct {
	Bets map[string]*GameBets `json:"bets,omitempty"`
}

type GameBets struct {
	Available []float64 `json:"available,omitempty"`
	Default   []float64 `json:"default,omitempty"`
	MaxWin    float64   `json:"max_win,omitempty"`
	Coin      float64   `json:"coin,omitempty"`
	Validate  bool      `json:"validate"`
}

type Wager struct {
	Data  interface{} `json:"data"`
	State interface{} `json:"state"`
	Win   float64     `json:"win,omitempty" validate:"required"`
	Next  []string    `json:"next"`
}

type Action struct {
	Action string `json:"action,omitempty"`
}
