package http

import (
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"net/http"
)

const (
	errApl = "APPLICATION_ERROR"
	errSrv = "SERVER_ERROR"
)

type ErrorDetail struct {
	Message string `json:"message"`
	Code    string `json:"code"`
}

type ErrorResponse struct {
	Error *ErrorDetail `json:"error"`
}

func new(code string, data interface{}) *ErrorResponse {
	errorDetail := &ErrorDetail{
		Message: "",
		Code:    code,
	}

	response := &ErrorResponse{
		Error: errorDetail,
	}

	if v, ok := data.(error); ok {
		errorDetail.Message = v.Error()
	}

	return response
}

func OK(ctx *gin.Context, data interface{}) {
	ctx.JSON(http.StatusOK, data)
}

func BadRequest(ctx *gin.Context, data interface{}) {
	zap.S().Error(data)
	r := new(errApl, data)
	ctx.JSON(http.StatusBadRequest, r)
}

func ServerError(ctx *gin.Context, data interface{}) {
	zap.S().Error(data)
	r := new(errSrv, data)
	ctx.JSON(http.StatusInternalServerError, r)
}
