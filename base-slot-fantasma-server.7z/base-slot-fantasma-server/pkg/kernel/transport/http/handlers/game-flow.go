package handlers

import (
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/engine/dto"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/services"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/transport/http"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/transport/http/request"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
)

type gameFlowHandler struct {
	gameFlowSrv *services.GameFlowService
}

func NewGameFlowHandler(gameFlowSrv *services.GameFlowService) http.Handler {
	return &gameFlowHandler{
		gameFlowSrv: gameFlowSrv,
	}
}

func (h *gameFlowHandler) Shutdown() {}

func (h *gameFlowHandler) Register(router *gin.RouterGroup) {
	api := router.Group("api/games")
	api.GET("cheats", h.cheats)
	api.GET("config", h.config)
	api.GET("bets", h.bets)
	api.POST("play", h.play)
	api.POST("action", h.action)
}

func (h *gameFlowHandler) cheats(ctx *gin.Context) {
	http.OK(ctx, HealthResponse{Status: "success"})
}

func (h *gameFlowHandler) config(ctx *gin.Context) {
	variant := ctx.Param("variant")
	if variant == "" {
		http.BadRequest(ctx, fmt.Errorf("variant can`t be empty"))

		return
	}

	config, err := h.gameFlowSrv.Config(ctx, variant)
	if err != nil {
		http.ServerError(ctx, err)

		return
	}

	http.OK(ctx, config)
}

func (h *gameFlowHandler) bets(ctx *gin.Context) {
	bets, err := h.gameFlowSrv.Bets(ctx)
	if err != nil {
		http.ServerError(ctx, err)

		return
	}

	http.OK(ctx, bets)
}

func (h *gameFlowHandler) play(ctx *gin.Context) {
	req := &request.PlayRequest{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		http.BadRequest(ctx, err)

		return
	}

	wager, err := h.gameFlowSrv.Play(ctx, req)
	if err != nil {
		http.ServerError(ctx, err)

		return
	}

	http.OK(ctx, wager)
}

func (h *gameFlowHandler) action(ctx *gin.Context) {
	req := &dto.Wager{}
	if err := ctx.ShouldBindBodyWith(&req, binding.JSON); err != nil {
		http.BadRequest(ctx, err)

		return
	}

	action, err := h.gameFlowSrv.Action(ctx, req)
	if err != nil {
		http.ServerError(ctx, err)

		return
	}

	http.OK(ctx, action)
}
