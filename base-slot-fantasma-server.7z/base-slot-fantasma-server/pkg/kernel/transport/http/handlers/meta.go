package handlers

import (
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/transport/http"
	"github.com/gin-gonic/gin"
)

type metaHandler struct {
	Tag string
}

type HealthResponse struct {
	Status string
}

type InfoResponse struct {
	Tag string
	IP  string
}

func NewMetaHandler(buildTag string) http.Handler {
	return &metaHandler{Tag: buildTag}
}

func (h *metaHandler) Shutdown() {
}

func (h *metaHandler) Register(route *gin.RouterGroup) {
	route.GET("health", h.health)
}

func (h *metaHandler) health(ctx *gin.Context) {
	http.OK(ctx, HealthResponse{Status: "success"})
}
