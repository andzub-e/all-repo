package request

type PlayRequest struct {
	Bet     float64                `json:"bet,omitempty" validate:"required"`
	Coin    int                    `json:"coin,omitempty" validate:"required"`
	Action  string                 `json:"action,omitempty" validate:"required"`
	Cheat   string                 `json:"cheat"`
	Params  map[string]interface{} `json:"params"`
	State   interface{}            `json:"state"`
	Variant string                 `json:"variant"`
}
