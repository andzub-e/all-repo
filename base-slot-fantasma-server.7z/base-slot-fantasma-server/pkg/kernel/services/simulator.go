package services

import (
	"context"
	"fmt"
	"math/big"

	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/engine"
)

type keepGenerateWrapper func(engine.Context, engine.Spin, engine.SpinFactory) (engine.Spin, error)

type SimulatorService struct {
	boot             *engine.Bootstrap
	progressListener func(percent float64)
	wagerParameters  interface{}
	keepGenerate     bool
	keepGenerateFunc keepGenerateWrapper
}

func NewSimulatorService() *SimulatorService {
	return &SimulatorService{boot: engine.GetFromContainer()}
}

func (s *SimulatorService) WithWagerParameters(parameters interface{}) *SimulatorService {
	s.wagerParameters = parameters

	return s
}

func (s *SimulatorService) WithProgressListener(progressListener func(percent float64)) *SimulatorService {
	s.progressListener = progressListener

	return s
}

func (s *SimulatorService) WithKeepGenerate(f keepGenerateWrapper) *SimulatorService {
	s.keepGenerateFunc = f

	return s
}

func (s *SimulatorService) Simulate(game string, count int, wager int64) (*SimulationResult, error) {
	res := &SimulationResult{
		Wager: wager,
		Count: count,
		Game:  game,

		BaseAward:  new(big.Int),
		BonusAward: new(big.Int),
		Award:      new(big.Int),
		Spent:      new(big.Int),

		BaseAwardSquareSum:  new(big.Int),
		BonusAwardSquareSum: new(big.Int),
		AwardSquareSum:      new(big.Int),

		BaseAwardStandardDeviation:  new(big.Float),
		BonusAwardStandardDeviation: new(big.Float),
		AwardStandardDeviation:      new(big.Float),
	}

	var (
		factory = s.boot.SpinFactory
		percent = count / 100
	)

	var prevSpin engine.Spin
	for i := 0; i < count; i++ {
		ctx := engine.Context{Context: context.Background()}
		if prevSpin != nil {
			ctx.LastSpin = prevSpin
		}

		spin, _, err := factory.Generate(ctx, wager, s.wagerParameters)
		if err != nil {
			return nil, err
		}

		if s.keepGenerateFunc != nil {
			spin, err = s.keepGenerateFunc(ctx, spin, factory)
			if err != nil {
				return nil, err
			}
		}

		prevSpin = spin

		baseAward, bonusAward := spin.BaseAward(), spin.BonusAward()
		award := baseAward + bonusAward

		res.BaseAward.Add(res.BaseAward, big.NewInt(baseAward))
		res.BonusAward.Add(res.BonusAward, big.NewInt(bonusAward))
		res.Award.Add(res.Award, big.NewInt(award))
		res.Spent.Add(res.Spent, big.NewInt(spin.Wager()))

		if award > res.MaxExposure {
			res.MaxExposure = award
		}

		if award > 0 {
			res.AwardCount++
		}

		if spin.BonusTriggered() {
			res.BonusGameCount++
		}

		if award >= wager*1 {
			res.X1Count++
		}

		if award >= wager*10 {
			res.X10Count++
		}

		if award >= wager*100 {
			res.X100Count++
		}

		res.BaseAwardSquareSum.Add(res.BaseAwardSquareSum, big.NewInt(0).Mul(big.NewInt(baseAward), big.NewInt(baseAward)))
		res.BonusAwardSquareSum.Add(res.BonusAwardSquareSum, big.NewInt(0).Mul(big.NewInt(bonusAward), big.NewInt(bonusAward)))
		res.AwardSquareSum.Add(res.AwardSquareSum, big.NewInt(0).Mul(big.NewInt(award), big.NewInt(award)))

		if s.progressListener != nil && i%percent == 0 {
			s.progressListener(float64(i) / float64(count))
		}
	}

	baseMeanB, bonusMeanB, totalMeanB :=
		new(big.Float).SetInt(res.BaseAward), new(big.Float).SetInt(res.BonusAward), new(big.Float).SetInt(res.Award)

	baseMeanB.Quo(baseMeanB, big.NewFloat(float64(res.Count)))
	bonusMeanB.Quo(bonusMeanB, big.NewFloat(float64(res.Count)))
	totalMeanB.Quo(totalMeanB, big.NewFloat(float64(res.Count)))

	res.BaseAwardStandardDeviation = StandardDeviation(res.BaseAwardSquareSum, res.BaseAward, baseMeanB, res.Count)
	res.BonusAwardStandardDeviation = StandardDeviation(res.BonusAwardSquareSum, res.BonusAward, bonusMeanB, res.Count)
	res.AwardStandardDeviation = StandardDeviation(res.AwardSquareSum, res.Award, totalMeanB, res.Count)

	awardF := new(big.Float).SetInt(res.Award)
	baseF := new(big.Float).SetInt(res.BaseAward)
	bonusF := new(big.Float).SetInt(res.BonusAward)
	spentF := new(big.Float).SetInt(res.Spent)

	res.RTP, _ = new(big.Float).Quo(awardF, spentF).Float64()
	res.RTPBaseGame, _ = new(big.Float).Quo(baseF, spentF).Float64()
	res.RTPBonusGame, _ = new(big.Float).Quo(bonusF, spentF).Float64()

	return res, nil
}

type SimulationResult struct {
	Game        string   `xlsx:"Game"`
	Count       int      `xlsx:"Count"`
	Wager       int64    `xlsx:"Wager"`
	Spent       *big.Int `xlsx:"Spent"`
	MaxExposure int64    `xlsx:"Max Exposure"`

	AwardCount     int `xlsx:"BaseAward Count"`
	BonusGameCount int `xlsx:"Bonus Game Count"`

	X1Count   int `xlsx:"X1 Count"`
	X10Count  int `xlsx:"X10 Count"`
	X100Count int `xlsx:"X100 Count"`

	BaseAward  *big.Int `xlsx:"Base BaseAward"`
	BonusAward *big.Int `xlsx:"Bonus BaseAward"`
	Award      *big.Int `xlsx:"BaseAward"`

	BaseAwardSquareSum  *big.Int `xlsx:"Base BaseAward Square Sum"`
	BonusAwardSquareSum *big.Int `xlsx:"Bonus BaseAward Square Sum"`
	AwardSquareSum      *big.Int `xlsx:"BaseAward Square Sum"`

	BaseAwardStandardDeviation  *big.Float `xlsx:"Base BaseAward Standard Deviation"`
	BonusAwardStandardDeviation *big.Float `xlsx:"Bonus BaseAward Standard Deviation"`
	AwardStandardDeviation      *big.Float `xlsx:"BaseAward Standard Deviation"`

	RTP          float64 `xlsx:"RTP"`
	RTPBaseGame  float64 `xlsx:"RTP Base Game"`
	RTPBonusGame float64 `xlsx:"RTP Bonus Game"`
}

func (r SimulationResult) View() *SimulationView {
	return &SimulationView{
		Game:        r.Game,
		Count:       fmt.Sprint(r.Count),
		Wager:       fmt.Sprint(r.Wager),
		Spent:       fmt.Sprint(r.Spent),
		MaxExposure: fmt.Sprint(r.MaxExposure),

		AwardCount: fmt.Sprint(r.AwardCount),
		AwardRate:  countToRate(r.AwardCount, r.Count),

		BonusGameCount: fmt.Sprint(r.BonusGameCount),
		BonusGameRate:  countToRate(r.BonusGameCount, r.Count),

		X1Count:   fmt.Sprint(r.X1Count),
		X10Count:  fmt.Sprint(r.X10Count),
		X100Count: fmt.Sprint(r.X100Count),

		X1Rate:   countToRate(r.X1Count, r.Count),
		X10Rate:  countToRate(r.X10Count, r.Count),
		X100Rate: countToRate(r.X100Count, r.Count),

		BaseAward:  r.BaseAward.String(),
		BonusAward: r.BonusAward.String(),
		Award:      r.Award.String(),

		BaseAwardSquareSum:  r.BaseAwardSquareSum.String(),
		BonusAwardSquareSum: r.BonusAwardSquareSum.String(),
		AwardSquareSum:      r.AwardSquareSum.String(),

		BaseAwardStandardDeviation:  r.BaseAwardStandardDeviation.Text('f', 3),
		BonusAwardStandardDeviation: r.BonusAwardStandardDeviation.Text('f', 3),
		AwardStandardDeviation:      r.AwardStandardDeviation.Text('f', 3),

		RTP:          floatWithPrecision(r.RTP),
		RTPBaseGame:  floatWithPrecision(r.RTPBaseGame),
		RTPBonusGame: floatWithPrecision(r.RTPBonusGame),
	}
}

type SimulationView struct {
	Game        string `xlsx:"Game"`
	Count       string `xlsx:"Count"`
	Wager       string `xlsx:"Wager"`
	Spent       string `xlsx:"Spent"`
	MaxExposure string `xlsx:"Max Exposure"`

	NewLine1 string `xlsx:""`

	AwardCount string `xlsx:"BaseAward Count"`
	AwardRate  string `xlsx:"AwardRate (Hit Rate)"`

	NewLine2 string `xlsx:""`

	BonusGameCount string `xlsx:"Bonus Game Count"`
	BonusGameRate  string `xlsx:"Bonus Game Rate"`

	NewLine3 string `xlsx:""`

	X1Count   string `xlsx:"X1 Count"`
	X10Count  string `xlsx:"X10 Count"`
	X100Count string `xlsx:"X100 Count"`

	NewLine4 string `xlsx:""`

	X1Rate   string `xlsx:"X1 Rate"`
	X10Rate  string `xlsx:"X10 Rate"`
	X100Rate string `xlsx:"X100 Rate"`

	NewLine5 string `xlsx:""`

	BaseAward  string `xlsx:"Base BaseAward"`
	BonusAward string `xlsx:"Bonus BaseAward"`
	Award      string `xlsx:"BaseAward"`

	NewLine6 string `xlsx:""`

	BaseAwardSquareSum  string `xlsx:"Base BaseAward Square Sum"`
	BonusAwardSquareSum string `xlsx:"Bonus BaseAward Square Sum"`
	AwardSquareSum      string `xlsx:"BaseAward Square Sum"`

	NewLine7 string `xlsx:""`

	BaseAwardStandardDeviation  string `xlsx:"Base BaseAward Standard Deviation"`
	BonusAwardStandardDeviation string `xlsx:"Bonus BaseAward Standard Deviation"`
	AwardStandardDeviation      string `xlsx:"BaseAward Standard Deviation"`

	NewLine8 string `xlsx:""`

	RTP          string `xlsx:"RTP"`
	RTPBaseGame  string `xlsx:"RTP Base Game"`
	RTPBonusGame string `xlsx:"RTP Bonus Game"`
}

func countToRate(count, total int) string {
	div := float64(count) / float64(total)

	return floatWithPrecision(div) + "%"
}

func floatWithPrecision(f float64) string {
	return fmt.Sprintf("%.3f", f*100)
}

func StandardDeviation(squareSum, award *big.Int, mean *big.Float, count int) *big.Float {
	f1 := new(big.Float).SetInt(squareSum)

	f2 := big.NewFloat(-2)
	f2.Mul(f2, mean)
	f2.Mul(f2, new(big.Float).SetInt(award))

	f3 := new(big.Float).SetInt64(int64(count))
	f3.Mul(f3, mean)
	f3.Mul(f3, mean)

	sd := big.NewFloat(0)

	sd.Add(sd, f1)
	sd.Add(sd, f2)
	sd.Add(sd, f3)

	sd.Quo(sd, new(big.Float).SetInt64(int64(count)))
	sd.Sqrt(sd)

	return sd
}
