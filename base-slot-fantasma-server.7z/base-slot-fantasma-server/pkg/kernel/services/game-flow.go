package services

import (
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/engine/dto"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/transport/http/request"
	"context"
)

type GameFlowService struct {
	boot *engine.Bootstrap
	RTP  *int64
}

func NewGameFlowService(rtp int64) *GameFlowService {
	return &GameFlowService{
		boot: engine.GetFromContainer(),
		RTP:  &rtp,
	}
}

func (s *GameFlowService) Config(ctx context.Context, variant string) (interface{}, error) {
	config, err := s.boot.SpinFactory.Config(ctx, variant)
	if err != nil {
		return nil, err
	}

	return config, nil
}

func (s *GameFlowService) Bets(ctx context.Context) (*dto.ResponseBet, error) {
	bets, err := s.boot.SpinFactory.Bets(ctx)
	if err != nil {
		return nil, err
	}

	return &dto.ResponseBet{Bets: bets}, nil
}

func (s *GameFlowService) Play(ctx context.Context, req *request.PlayRequest) (*dto.Wager, error) {
	engCtx := engine.Context{
		Context:  ctx,
		Cheats:   nil,
		LastSpin: nil,
		RTP:      s.RTP,
	}

	if req.Params != nil {
		engCtx.Cheats, _ = req.Params["cheats"]
	}

	spin, indexes, err := s.boot.SpinFactory.Generate(engCtx, int64(req.Bet), req)
	if err != nil {
		return nil, err
	}

	_ = indexes

	wager := &dto.Wager{
		Data:  nil,
		State: nil,
		Win:   float64(engine.TotalAward(spin)),
		Next:  nil,
	}

	return wager, nil
}

func (s *GameFlowService) Action(ctx context.Context, req *dto.Wager) (*dto.Action, error) {
	action, err := s.boot.SpinFactory.Action(ctx, req)
	if err != nil {
		return nil, err
	}

	return &dto.Action{Action: action}, nil
}
