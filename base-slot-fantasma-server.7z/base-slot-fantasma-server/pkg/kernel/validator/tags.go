package validator

const (
	InvalidTag = "invalid"
)
