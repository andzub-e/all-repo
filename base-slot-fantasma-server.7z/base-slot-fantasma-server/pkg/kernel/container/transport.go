package container

import (
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/config"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/transport/http"
	"context"
	"github.com/gin-gonic/gin"
	"github.com/sarulabs/di"
	"sync"
)

func BuildTransport(ctx context.Context, wg *sync.WaitGroup) []di.Def {
	return []di.Def{
		{
			Name: constants.ServerName,
			Build: func(ctn di.Container) (interface{}, error) {
				cfg := ctn.Get(constants.ConfigName).(*config.Config)

				publicHandlers := []http.Handler{
					ctn.Get(constants.HTTPMetaHandlerName).(http.Handler),
				}

				boot := engine.GetFromContainer()

				if boot.HTTPTransport {
					publicHandlers = append(publicHandlers, ctn.Get(constants.HTTPGameFlowHandlerName).(http.Handler))
				}

				var privateHandlers []http.Handler

				var middlewares = []func(ctx *gin.Context){
					ctn.Get(constants.HTTPCorsMiddlewareName).(func(ctx *gin.Context)),
					ctn.Get(constants.HTTPSessionMiddlewareName).(func(ctx *gin.Context)),
					ctn.Get(constants.HTTPSessionMuMiddlewareName).(func(ctx *gin.Context)),
				}

				return http.New(ctx, wg, cfg.ServerConfig, cfg.ConstantsConfig, publicHandlers, privateHandlers, middlewares), nil
			},
		},
	}
}
