package container

import (
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/config"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/rng"
	"github.com/sarulabs/di"
)

func BuildPkg() []di.Def {
	return []di.Def{
		{
			Name: constants.RNGName,
			Build: func(ctn di.Container) (interface{}, error) {
				cfg := ctn.Get(constants.ConfigName).(*config.Config)

				return rng.NewFantasmaClient(cfg.RNGConfig)
			},
		},
	}
}
