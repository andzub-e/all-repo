package container

import (
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/config"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/services"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/transport/http/handlers"
	"github.com/sarulabs/di"
)

func NewBuildHandlers() []di.Def {
	defs := append(buildHandlers(),
		[]di.Def{
			{
				Name: constants.HTTPMetaHandlerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return handlers.NewMetaHandler(cfg.EngineConfig.BuildVersion), nil
				},
			},
		}...,
	)

	return defs
}

func buildHandlers() []di.Def {
	return []di.Def{
		{
			Name: constants.HTTPGameFlowHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				gameFlowSrv := ctn.Get(constants.GameFlowServiceName).(*services.GameFlowService)

				return handlers.NewGameFlowHandler(gameFlowSrv), nil
			},
		},
	}
}
