package container

import (
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/transport/http/middlewares"
	"github.com/go-co-op/gocron"
	"github.com/sarulabs/di"
)

func BuildMiddlewares() []di.Def {
	return []di.Def{
		{
			Name: constants.HTTPCorsMiddlewareName,
			Build: func(ctn di.Container) (interface{}, error) {
				return middlewares.CORSMiddleware, nil
			},
		},
		{
			Name: constants.HTTPSessionMiddlewareName,
			Build: func(ctn di.Container) (interface{}, error) {
				return middlewares.SessionMiddleware(), nil
			},
		},
		{
			Name: constants.HTTPSessionMuMiddlewareName,
			Build: func(ctn di.Container) (interface{}, error) {
				scheduler := ctn.Get(constants.SchedulerName).(*gocron.Scheduler)

				return middlewares.SessionMu(scheduler), nil
			},
		},
	}
}
