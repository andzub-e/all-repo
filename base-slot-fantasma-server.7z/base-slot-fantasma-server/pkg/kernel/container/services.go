package container

import (
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/config"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/services"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
	"strconv"
)

func BuildServices() []di.Def {
	return []di.Def{
		{
			Name: constants.GameFlowServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				cfg := ctn.Get(constants.ConfigName).(*config.Config)
				rtp, err := strconv.Atoi(cfg.EngineConfig.RTP)
				if err != nil {
					zap.S().Errorf("failed to parse RTP. Err: %v", err.Error())
					return nil, err
				}

				return services.NewGameFlowService(int64(rtp)), nil
			},
		},
		{
			Name: constants.SimulatorServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				return services.NewSimulatorService(), nil
			},
		},
	}
}
