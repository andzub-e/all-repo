package config

import (
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/transport/http"
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/rng"
	"fmt"
	"github.com/spf13/viper"
	"path/filepath"
)

var (
	config *Config
)

type Config struct {
	ServerConfig    *http.Config
	RNGConfig       *rng.Config
	ConstantsConfig *constants.Config
	EngineConfig    *engine.Config
}

func New(path string) (*Config, error) {
	viper.Reset()

	abs, err := filepath.Abs(path)
	if err != nil {
		return nil, err
	}

	viper.AddConfigPath(filepath.Dir(abs))
	viper.SetConfigFile(filepath.Base(abs))

	return build()
}

func build() (*Config, error) {
	config = &Config{}

	if err := viper.ReadInConfig(); err != nil {
		return nil, err
	}

	serverConfig := viper.Sub("server")
	constantsConfig := viper.Sub("game")
	rngConfig := viper.Sub("rng")
	engineConfig := viper.Sub("engine")

	if err := parseSubConfig(serverConfig, &config.ServerConfig); err != nil {
		return nil, err
	}

	if err := parseSubConfig(constantsConfig, &config.ConstantsConfig); err != nil {
		return nil, err
	}

	if err := parseSubConfig(rngConfig, &config.RNGConfig); err != nil {
		return nil, err
	}

	if err := parseSubConfig(engineConfig, &config.EngineConfig); err != nil {
		return nil, err
	}

	return config, nil
}

func parseSubConfig[T any](subConfig *viper.Viper, parseTo *T) error {
	if subConfig == nil {
		return fmt.Errorf("can not read %T config: subconfig is nil", parseTo)
	}

	if err := subConfig.Unmarshal(parseTo); err != nil {
		return err
	}

	return nil
}
