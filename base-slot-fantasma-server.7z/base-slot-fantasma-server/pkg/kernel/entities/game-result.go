package entities

import (
	"bitbucket.org/electronicjaw/base-slot-fantasma-server/pkg/kernel/engine"
	"encoding/json"
	"github.com/google/uuid"
	"github.com/mitchellh/mapstructure"
)

type GameResult struct {
	ID               uuid.UUID               `json:"id" mapstructure:"id"`
	Spin             engine.Spin             `json:"spin" mapstructure:"spin"`
	RestoringIndexes engine.RestoringIndexes `json:"restoring_indexes" mapstructure:"restoring_indexes"`

	IsPFR bool `json:"is_pfr" mapstructure:"is_pfr"`
	// computed
	CanGamble bool `json:"can_gamble" mapstructure:"can_gamble"`

	currencyMultiplier int64 `json:"currency_multiplier"`
}

func NewGameResult(id uuid.UUID, spin engine.Spin, restoringIndexes engine.RestoringIndexes, isPFR bool, currencyMultiplier int64) *GameResult {
	return &GameResult{ID: id, Spin: spin, RestoringIndexes: restoringIndexes, IsPFR: isPFR, currencyMultiplier: currencyMultiplier}
}

func (gr *GameResult) GetCanGable() bool {
	gr.Compute()

	return gr.CanGamble
}

func (gr *GameResult) Compute() {
	cfg := engine.GetFromContainer()

	award := engine.TotalAwardWithGambling(gr.Spin)

	gr.CanGamble = !(award > cfg.GambleAnyWinMaxWager*gr.currencyMultiplier ||
		award == 0 || gr.Spin.GambleQuantity() >= cfg.GambleAnyWinMaxTimes) && gr.Spin.CanGamble(gr.RestoringIndexes)
}

func (gr GameResult) MarshalJSON() ([]byte, error) {
	gr.Compute()

	return json.Marshal(gr.View())
}

func (gr *GameResult) View() map[string]interface{} {
	view := map[string]interface{}{}

	// bad decoding rebuild on simple map
	_ = mapstructure.Decode(gr, &view)

	if engine.GetFromContainer().HistoryHandlingType == engine.SequentialRestoring {
		delete(view, "id")
	}

	if !engine.GetFromContainer().GambleAnyWinFeature {
		delete(view, "can_gamble")
	}

	return view
}
