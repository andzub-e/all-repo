package constants

const (
	ConfigName    = "Config"
	LoggerName    = "Logger"
	SchedulerName = "Scheduler"
	RNGName       = "RNG"
	RNGMockName   = "RNGMock"
	ServerName    = "Server"
	ValidatorName = "Validator"

	HTTPGameFlowHandlerName = "HTTPGameFlowHandler"
	HTTPMetaHandlerName     = "HTTPMetaHandler"

	HTTPCorsMiddlewareName      = "HTTPCorsMiddleware"
	HTTPSessionMiddlewareName   = "HTTPSessionMiddleware"
	HTTPSessionMuMiddlewareName = "HTTPSessionMuMiddleware"

	GameFlowServiceName  = "GameFlowService"
	SimulatorServiceName = "SimulatorService"
)
