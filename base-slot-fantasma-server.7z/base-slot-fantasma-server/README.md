# Базовый слот сервер для Фантазмы

## Правила разработки
* Сущности передаем по ссылке, object value - по значению

## Документация по интеграции 
* https://confluence.ejaw.net/display/INTERNAL/%28ACTUAL%29+Fantasma