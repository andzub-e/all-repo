package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine/utils"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/validator"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"encoding/json"
	"github.com/samber/lo"
	"github.com/sarulabs/di"
)

type Info struct {
	BaseReels [][]string `json:"base_reels"`
}

func GameBoot(ctn di.Container, config *engine.Config) *engine.Bootstrap {
	rand := ctn.Get(constants.RNGName).(rng.Client)
	validatorEngine := ctn.Get(constants.ValidatorName).(*validator.Validator)
	factory := NewSpinFactory(rand, validatorEngine)

	if config.RTP == rtp94 || config.RTP == rtp96 {
		SetupReel(config.RTP)
	}

	return &engine.Bootstrap{
		SpinFactory: factory,

		HTTPTransport:      true,
		WebsocketTransport: true,

		GambleAnyWinFeature: true,
		FreeSpinsFeature:    true,

		GambleAnyWinMaxTimes: 4,
		GambleAnyWinMaxWager: 125 * 100 * 1000, // 12 500 $
		GameMaxWager:         50 * 1000,

		HistoryHandlingType: engine.SequentialRestoring,
		EngineInfo:          Info{BaseReels: reels},
	}
}

func NewSpinFactory(rand rng.Client, validateEngine *validator.Validator) *SpinFactory {
	factory := &SpinFactory{rand: rand, validateEngine: validateEngine}

	return factory
}

type SpinFactory struct {
	rand           rng.Client
	validateEngine *validator.Validator
}

func (s *SpinFactory) Generate(ctx engine.Context, wager int64, parameters interface{}) (engine.Spin, engine.RestoringIndexes, error) {
	stops, err := s.getStops(ctx)
	if err != nil {
		return nil, nil, err
	}

	window, payLinesToShow, award, err := s.compute(stops, wager)
	if err != nil {
		return nil, nil, err
	}

	if payLinesToShow == nil {
		payLinesToShow = make([]PayLine, 0, 1)
	}

	return &SpinBase{WagerVal: wager, Win: award, Stops: stops, Window: window, PayLinesToShow: payLinesToShow}, &RestoringIndexes{}, nil
}

func (s *SpinFactory) GambleAnyWin(ctx engine.Context, parameters interface{}) (engine.Spin, error) {
	if ctx.LastSpin.BaseAward() == 0 {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin, ok := ctx.LastSpin.(*SpinBase)
	if !ok {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin = typedSpin.deepCopy()

	payload, err := parseParams(parameters)

	if payload.Color != GambleRed && payload.Color != GambleBlue {
		return nil, errs.ErrBadDataGiven
	}

	if err != nil {
		return nil, err
	}

	res, err := s.rand.Rand(2)
	if err != nil {
		return nil, err
	}

	suit, err := s.rand.Rand(2)
	if err != nil {
		return nil, err
	}

	g := Gamble{ExpectColor: payload.Color, WagerVal: typedSpin.BaseAward(), Suit: int(suit)}

	c := Cheats{}
	if ctx.Cheats != nil {
		if err = c.Eval(ctx.Cheats); err != nil {
			return nil, err
		}
	}

	if c.GambleColor == GambleRed || c.GambleColor == GambleBlue {
		g.RealColor = c.GambleColor
	} else if res == 1 {
		g.RealColor = GambleRed
	} else {
		g.RealColor = GambleBlue
	}

	g.compute()

	typedSpin.Gambles = append(typedSpin.Gambles, g)

	return typedSpin, nil
}

func (s *SpinFactory) KeepGenerate(ctx engine.Context, parameters interface{}) (engine.Spin, bool, error) {
	return ctx.LastSpin, false, nil
}

func (s SpinFactory) UnmarshalJSONSpin(bytes []byte) (engine.Spin, error) {
	spin := SpinBase{}
	err := json.Unmarshal(bytes, &spin)

	return &spin, err
}

func (s SpinFactory) UnmarshalJSONRestoringIndexes(bytes []byte) (engine.RestoringIndexes, error) {
	restoringIndexes := RestoringIndexes{}
	err := json.Unmarshal(bytes, &restoringIndexes)

	return &restoringIndexes, err
}

func (s *SpinFactory) getStops(ctx engine.Context) ([]int, error) {
	if ctx.Cheats != nil {
		c := Cheats{}
		if err := c.Eval(ctx.Cheats); err != nil {
			return nil, err
		}

		if len(c.Stops) != len(reels) {
			return nil, errs.ErrBadDataGiven
		}

		for i := range c.Stops {
			if c.Stops[i] > len(reels[i]) {
				return nil, errs.ErrBadDataGiven
			}
		}

		return c.Stops, nil
	}

	req := lo.Map(reels, func(item []string, index int) uint64 {
		return uint64(len(item))
	})

	res, err := s.rand.RandSlice(req)
	if err != nil {
		return nil, err
	}

	return lo.Map(res, func(item uint64, index int) int {
		return int(item)
	}), nil
}

func (s *SpinFactory) compute(stops []int, wager int64) (window Window, payLinesToShow []PayLine, award int64, err error) {
	window.compute(stops)

	award, payLinesToShow, err = s.computeBasicWindow(wager, window)
	if err != nil {
		return Window{}, nil, 0, err
	}

	scatterPayLine, ok, err := s.computeScatter(wager, window)
	if err != nil {
		return Window{}, nil, 0, err
	}

	if ok {
		payLinesToShow = append(payLinesToShow, scatterPayLine)
		award += scatterPayLine.Award
	}

	return window, payLinesToShow, award, err
}

func (s *SpinFactory) computeBasicWindow(wager int64, window Window) (award int64, payLinesToShow []PayLine, err error) {
	ag, err := NewAwardGetter(wager)
	if err != nil {
		return 0, nil, err
	}

	pls := utils.CalcBasePayLines[int, string](PayLines, &window, ag, &ScatterSymbol, nil, utils.LeftToRightDirection)

	lo.ForEach(pls, func(item utils.PayLine[int, string], index int) {
		payLinesToShow = append(payLinesToShow, PayLine{
			Symbol: item.PaySymbol,

			PayLineIndex: item.PayLineIndex,
			Indexes:      item.PayLineItems,
			Award:        item.Award,
		})

		award += item.Award
	})

	return award, payLinesToShow, nil
}

func (s *SpinFactory) computeScatter(wager int64, window Window) (PayLine, bool, error) {
	scatterTrigger := utils.CalcScatter[int, string](&window, ScatterSymbol)
	scatterIndexes := lo.Flatten(scatterTrigger.PayLineItems)
	scatterCounter := scatterTrigger.Count()

	ag, err := NewAwardGetter(wager)
	if err != nil {
		return PayLine{}, false, err
	}

	if award := ag.GetAward(ScatterSymbol, scatterCounter); award > 0 {
		return PayLine{Indexes: scatterIndexes, Award: award, Symbol: ScatterSymbol, PayLineIndex: -1}, true, nil
	}

	return PayLine{}, false, nil
}

func parseParams(parameters interface{}) (gp GambleParams, err error) {
	b, err := json.Marshal(parameters)
	if err != nil {
		return gp, err
	}

	if err := json.Unmarshal(b, &gp); err != nil {
		return gp, err
	}

	return gp, nil
}
