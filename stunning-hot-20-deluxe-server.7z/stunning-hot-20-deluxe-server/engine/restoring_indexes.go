package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"encoding/json"
)

type RestoringIndexes struct {
	BaseSpinIndex     int  `json:"base_spin_index"`
	IsGambleCollected bool `json:"gamble_collected"`
}

func (r *RestoringIndexes) IsShown(spin engine.Spin) bool {
	return r.BaseSpinIndex >= 1
}

func (r *RestoringIndexes) Update(payload interface{}) error {
	bytes, err := json.Marshal(payload)
	if err != nil {
		return err
	}

	return json.Unmarshal(bytes, r)
}
