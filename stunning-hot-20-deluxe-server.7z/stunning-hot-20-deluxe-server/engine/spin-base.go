package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"go.uber.org/zap"
)

type SpinBase struct {
	WagerVal       int64     `json:"wager"`
	Win            int64     `json:"award"`
	Stops          []int     `json:"stops"`
	Window         Window    `json:"window"`
	PayLinesToShow []PayLine `json:"pay_lines_to_show"`
	Gambles        []Gamble  `json:"gambles"`
}

func (s SpinBase) GambleAward() int64 {
	var award int64

	if len(s.Gambles) > 0 {
		award = s.Gambles[len(s.Gambles)-1].Win
	}

	return award
}

func (s SpinBase) DeepCopy() engine.Spin {
	return s.deepCopy()
}

func (s SpinBase) deepCopy() *SpinBase {
	spin := &SpinBase{
		WagerVal: s.WagerVal,
		Win:      s.Win,
		Stops:    s.Stops,

		Window:         make(Window, len(s.Window)),
		PayLinesToShow: make([]PayLine, len(s.PayLinesToShow)),
		Gambles:        make([]Gamble, len(s.Gambles)),
	}

	copy(spin.Window, s.Window)
	copy(spin.PayLinesToShow, s.PayLinesToShow)
	copy(spin.Gambles, s.Gambles)

	return spin
}

func (s *SpinBase) BaseAward() int64 {
	return s.Win
}

func (s *SpinBase) BonusAward() int64 {
	return 0
}

func (s *SpinBase) Wager() int64 {
	return s.WagerVal
}

func (s SpinBase) CanGamble(restoringIndexes engine.RestoringIndexes) bool {
	restoringIndexesTyped, ok := restoringIndexes.(*RestoringIndexes)

	if !ok {
		zap.S().Error("can not parse restoring indexes")

		return true
	}

	return !restoringIndexesTyped.IsGambleCollected
}

func (s *SpinBase) GambleQuantity() int {
	return len(s.Gambles)
}

func (s SpinBase) BonusTriggered() bool {
	return false
}

type PayLine struct {
	Symbol       string `json:"symbol"`
	PayLineIndex int    `json:"index"`
	Indexes      []int  `json:"indexes"`
	Award        int64  `json:"award"`
}
