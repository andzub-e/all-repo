package engine

import (
	"fmt"
	"github.com/samber/lo"
)

func SetupReel(rtp string) {
	switch rtp {
	case rtp94:
		PayLines, multipliers, reels = payLines94, multipliers94, reels94
	case rtp96:
		PayLines, multipliers, reels = payLines96, multipliers96, reels96
	default:
		panic("unknown rtp")
	}

	fmt.Printf("current rtp: %v\n", rtp)
}

const (
	rtp94 = "94"
	rtp96 = "96"

	windowHeight          = 3
	windowWidth           = 5
	multiplicationDivider = 100
)

var ScatterSymbol = "s"

var PayLines [][]int
var multipliers map[string]map[int]int64
var reels [][]string

type Window [][]string

func (w *Window) GetSymbol(reelIndex int, payItem int) string {
	return w.symbol(payItem)
}

func (w *Window) GetByIndexes(reelIndex, symbolIndex int) (int, string) {
	return symbolIndex*windowWidth + reelIndex, (*w)[reelIndex][symbolIndex]
}

func (w *Window) GetHeight() int {
	return windowHeight
}

func (w *Window) GetWidth() int {
	return windowWidth
}

func (w *Window) compute(stops []int) {
	*w = lo.Map(stops, func(stop int, index int) []string {
		reel := reels[index]
		reelLen := len(reel)

		windowLine := make([]string, windowHeight)
		for j := 0; j < windowHeight; j++ {
			windowLine[j] = reel[(stop+j)%reelLen]
		}

		return windowLine
	})
}

func (w Window) symbol(payIndex int) string {
	position, reel := payIndex/windowWidth, payIndex%windowWidth
	return w[reel][position]
}

type AwardGetter struct {
	Wager int64
}

func NewAwardGetter(wager int64) (AwardGetter, error) {
	if wager < 0 {
		return AwardGetter{}, fmt.Errorf("negative wager: %v", wager)
	}
	return AwardGetter{Wager: wager}, nil
}

func (a AwardGetter) GetAward(symbol string, size int) int64 {
	mul := multipliers[symbol][size]

	return mul * a.Wager / multiplicationDivider
}
