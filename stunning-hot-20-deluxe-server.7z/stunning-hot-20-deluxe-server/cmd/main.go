package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
	"go.uber.org/zap"
	"stunning-hot-deluxe-server/buildvar"
	"stunning-hot-deluxe-server/engine"
)

func main() {
	application, err := app.NewApp("config.yml", buildvar.Tag, buildvar.Debug, buildvar.IsCheatsAvailable, engine.GameBoot)

	zap.S().Infof("Tag: %v, Debug: %v, IsCheatsAvailable: %v", buildvar.Tag, buildvar.Debug, buildvar.IsCheatsAvailable)

	if err != nil {
		panic(err)
	}

	if err := application.Run(); err != nil {
		panic(err)
	}
}
