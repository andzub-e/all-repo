package main

import (
	"context"
	"go.uber.org/zap"
	"pfr-service/internal/constants"
	"pfr-service/internal/container"
	"pfr-service/internal/http"
	"pfr-service/utils"
	"sync"
	"time"
)

func main() {
	now := time.Now()
	ctx := context.Background()
	wg := &sync.WaitGroup{}
	app := container.Build(ctx, wg)

	logger := app.Get(constants.LoggerName).(*zap.Logger)
	logger.Info("Starting application...")
	server := app.Get(constants.ServerName).(*http.Server)

	go server.Run()

	zap.S().Infof("Up and running (%s)", time.Since(now))
	zap.S().Infof("Got %s signal. Shutting down...", <-utils.WaitTermSignal())

	if err := server.Shutdown(ctx); err != nil {
		zap.S().Errorf("Error stopping server: %s", err)
	}

	wg.Wait()
	zap.S().Info("Service stopped.")
}
