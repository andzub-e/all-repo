-- +goose Up
-- +goose StatementBegin
create table if not exists programs
(
    created_at    timestamptz,
    starts_at     timestamptz,
    ends_at       timestamptz,

    id            uuid primary key,
    integrator_id varchar not null,
    integrator    varchar not null,

    max_usage_count int,
    data          jsonb,

    unique (integrator_id, integrator)
);

create index idx_programs_integrator_id on programs using hash (integrator_id);
create index idx_programs_integrator on programs using hash (integrator);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
