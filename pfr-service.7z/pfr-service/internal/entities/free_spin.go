package entities

import (
	"encoding/json"
	"pfr-service/pkg/overlord"
	"strings"
	"time"
)

type FreeSpin struct {
	ID         string `json:"id,omitempty"`
	Game       string `json:"game,omitempty"`
	Currency   string `json:"currency,omitempty"`
	Value      int64  `json:"value,omitempty"`
	SpinCount  int32  `json:"spin_count,omitempty"`
	ExpireDate int64  `json:"expire_date,omitempty"`
}

type FreeSpinCreate struct {
	PlayerID    string       `json:"player_id"`
	BetValue    int64        `json:"bet_value"`
	FreeBets    int32        `json:"free_bets"`
	Currency    string       `json:"currency"`
	EndDate     FreeSpinDate `json:"end_date"`
	FreeBetID   string       `json:"freebet_id"`
	GameID      string       `json:"game_id"`
	Provider    string       `json:"provider"`
	OperatorKey string       `json:"operator_key"`
	SecretToken string       `json:"secret_token"`
}

type FreeSpinCreated struct {
	Code      int          `json:"code"`
	Message   string       `json:"message"`
	FreebetID string       `json:"freebet_id"`
	Currency  string       `json:"currency"`
	PlayerID  string       `json:"player_id"`
	FreeBets  int          `json:"free_bets"`
	BetValue  int64        `json:"bet_value"`
	EndDate   FreeSpinDate `json:"end_date"`
	GameID    string       `json:"game_id"`
	Provider  string       `json:"provider"`
}

type FreeSpinCancel struct {
	FreebetID   string `json:"freebet_id"`
	PlayerID    string `json:"player_id"`
	OperatorKey string `json:"operator_key"`
	SecretToken string `json:"secret_token"`
	Provider    string `json:"provider"`
}

type FreeSpinCanceled struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

type FreeSpinDate struct {
	time.Time
}

func (fsd *FreeSpinDate) UnmarshalJSON(bs []byte) error {
	var s string
	err := json.Unmarshal(bs, &s)

	if err != nil {
		return err
	}

	s = strings.ReplaceAll(s, " ", "T")

	tm, err := time.Parse(time.RFC3339, s)
	if err != nil {
		return err
	}

	fsd.Time = tm

	return nil
}

func FreeSpinsFromOverlordToEntity(states *overlord.GetAvailableFreeBetsOut) []*FreeSpin {
	spins := []*FreeSpin{}

	for _, bet := range states.FreeBets {
		f := FreeSpin{
			ID:         bet.Id,
			Game:       bet.Game,
			Currency:   bet.Currency,
			Value:      bet.Value,
			SpinCount:  bet.SpinCount,
			ExpireDate: bet.ExpireDate,
		}

		spins = append(spins, &f)
	}

	return spins
}
