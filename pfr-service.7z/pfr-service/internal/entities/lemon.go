package entities

import "time"

const LemonBetValueMultiplier = 1000

type LemonAddFreeBet struct {
	PlayerId         string    `json:"PlayerId"`
	GameCode         string    `json:"GameCode"`
	NumberFreeRounds int32     `json:"NumberFreeRounds"`
	ExpirationDate   time.Time `json:"ExpirationDate"`
	CountryCode      string    `json:"CountryCode"`
	CurrencyCode     string    `json:"CurrencyCode"`
	Account          struct {
		UserName string `json:"UserName"`
		Password string `json:"Password"`
	} `json:"Account"`
	BetLevel  *int    `json:"BetLevel"`
	CoinValue *string `json:"CoinValue"`
}

type LemonRemoveFreeBet struct {
	PlayerId    string `json:"PlayerId"`
	BonusId     string `json:"BonusId"`
	CountryCode string `json:"CountryCode"`
	Account     struct {
		UserName string `json:"UserName"`
		Password string `json:"Password"`
	} `json:"Account"`
}
