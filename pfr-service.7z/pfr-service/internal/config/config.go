package config

import (
	"github.com/samber/lo"
	"github.com/spf13/viper"
	"net"
	"pfr-service/internal/http"
	"pfr-service/pkg/overlord"
	"pfr-service/pkg/pgsql"
	"pfr-service/pkg/tracer"
	"sync"
)

var config *Config
var once sync.Once

type Config struct {
	ServerConfig   *http.Config
	OverlordConfig *overlord.Config
	PgSQLConfig    *pgsql.Config
	TracerConfig   *tracer.Config

	LemonWhiteList []net.IP
}

func New() (*Config, error) {
	once.Do(func() {
		config = &Config{}

		viper.AddConfigPath(".")
		viper.SetConfigName("config")

		if err := viper.ReadInConfig(); err != nil {
			panic(err)
		}

		serverConfig := viper.Sub("server")
		overlordConfig := viper.Sub("overlord")
		tracerConfig := viper.Sub("tracer")
		pgSQLConfig := viper.Sub("database")

		lemonWhiteList, ok := viper.Get("lemonWhiteList").([]interface{})
		if ok {
			config.LemonWhiteList = lo.FilterMap(lemonWhiteList, func(item interface{}, index int) (net.IP, bool) {
				ipString, ok := item.(string)
				if !ok {
					return nil, ok
				}

				return net.ParseIP(ipString), true
			})

		}

		if err := serverConfig.Unmarshal(&config.ServerConfig); err != nil {
			panic(err)
		}

		if err := overlordConfig.Unmarshal(&config.OverlordConfig); err != nil {
			panic(err)
		}

		if err := tracerConfig.Unmarshal(&config.TracerConfig); err != nil {
			panic(err)
		}

		if err := pgSQLConfig.Unmarshal(&config.PgSQLConfig); err != nil {
			panic(err)
		}
	})

	return config, nil
}
