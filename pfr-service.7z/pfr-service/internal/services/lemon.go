package services

import (
	"context"
	"fmt"
	"github.com/google/uuid"
	"github.com/samber/lo"
	"pfr-service/internal/entities"
	"pfr-service/internal/errs"
	"pfr-service/pkg/overlord"
	"strconv"
	"strings"
)

const (
	LemonIntegratorName = "lemon"
)

type LemonService struct {
	overlord overlord.Client
}

func NewLemonService(overlord overlord.Client) *LemonService {
	return &LemonService{overlord: overlord}
}

func (l *LemonService) AddFreeBet(ctx context.Context, addFreeBet entities.LemonAddFreeBet) (bonusID string, err error) {
	var (
		betValue int64
		currency = strings.ToLower(addFreeBet.CurrencyCode)
	)

	if addFreeBet.BetLevel != nil {
		cfg, err := l.overlord.GetIntegratorConfig(ctx, LemonIntegratorName, addFreeBet.GameCode)
		if err != nil {
			return "", err
		}

		if len(cfg.WagerLevels) < *addFreeBet.BetLevel {
			return "", fmt.Errorf("%v: your index: %v, wager level length: %v",
				errs.ErrWagerLevelIsOutOfRange, *addFreeBet.BetLevel, len(cfg.WagerLevels))
		}

		mul, ok := cfg.Multipliers[currency]
		if !ok {
			return "", fmt.Errorf("%v, list of supported currencies: %v",
				errs.ErrCurrencyIsNotSupported, lo.Keys(cfg.Multipliers))
		}

		betValue = cfg.WagerLevels[*addFreeBet.BetLevel-1] * mul
	} else if addFreeBet.CoinValue != nil {
		fl64Bet, err := strconv.ParseFloat(*addFreeBet.CoinValue, 64)

		if err != nil {
			return "", err
		}
		betValue = toLordBalance(fl64Bet)
	} else {
		return "", fmt.Errorf("%v: there is no field the request that set bet value", errs.ErrBadDataGiven)
	}

	res, err := l.overlord.AddFreeSpins(ctx, &overlord.AddFreeBetIn{
		UserId:        addFreeBet.PlayerId,
		BetValue:      betValue,
		FreeBets:      addFreeBet.NumberFreeRounds,
		Currency:      currency,
		EndDate:       addFreeBet.ExpirationDate.Unix(),
		FreeBetId:     uuid.New().String(),
		Game:          addFreeBet.GameCode,
		Provider:      "lemon",
		IntegratorKey: "lemon",
		SecretToken:   "lemon",
	})

	if err != nil {
		return "", err
	}

	return res.FreeBetId, nil
}

func (l *LemonService) RemoveFreeBet(ctx context.Context, removeFreeBet entities.LemonRemoveFreeBet) error {
	_, err := l.overlord.CancelFreeSpins(ctx, &overlord.CancelFreeBetIn{
		FreeBetId:     removeFreeBet.BonusId,
		UserId:        removeFreeBet.PlayerId,
		IntegratorKey: "lemon",
		SecretToken:   "lemon",
		Provider:      "lemon",
	})

	return err
}

func toLordBalance(f float64) int64 {
	return int64(f * entities.LemonBetValueMultiplier)
}
