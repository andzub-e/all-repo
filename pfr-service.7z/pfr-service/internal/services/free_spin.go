package services

import (
	"context"
	"go.uber.org/zap"
	"pfr-service/internal/entities"
	"pfr-service/internal/errs"
	"pfr-service/pkg/overlord"
	"time"
)

type FreeSpinService struct {
	overlord overlord.Client
}

func NewFreeSpinService(overlord overlord.Client) *FreeSpinService {
	return &FreeSpinService{overlord: overlord}
}

func (srv *FreeSpinService) Create(ctx context.Context, create *entities.FreeSpinCreate) (*entities.FreeSpinCreated, error) {
	res, err := srv.overlord.AddFreeSpins(ctx, &overlord.AddFreeBetIn{
		UserId:        create.PlayerID,
		BetValue:      create.BetValue,
		FreeBets:      create.FreeBets,
		Currency:      create.Currency,
		EndDate:       create.EndDate.Unix(),
		FreeBetId:     create.FreeBetID,
		Game:          create.GameID,
		Provider:      create.Provider,
		IntegratorKey: create.OperatorKey,
		SecretToken:   create.SecretToken,
	})

	if err != nil {
		return nil, err
	}

	return &entities.FreeSpinCreated{
		Code:      int(res.Code),
		Message:   res.Message,
		FreebetID: res.FreeBetId,
		Currency:  res.Currency,
		PlayerID:  res.UserId,
		FreeBets:  int(res.FreeBets),
		BetValue:  res.BetValue,
		EndDate:   entities.FreeSpinDate{Time: time.Unix(res.EndDate, 0)},
		GameID:    res.Game,
		Provider:  res.Provider,
	}, nil
}

func (srv *FreeSpinService) Cancel(ctx context.Context, cancel *entities.FreeSpinCancel) (*entities.FreeSpinCanceled, error) {
	res, err := srv.overlord.CancelFreeSpins(ctx, &overlord.CancelFreeBetIn{
		FreeBetId:     cancel.FreebetID,
		UserId:        cancel.PlayerID,
		IntegratorKey: cancel.OperatorKey,
		SecretToken:   cancel.SecretToken,
		Provider:      cancel.Provider,
	})

	if err != nil {
		return nil, err
	}

	return &entities.FreeSpinCanceled{Code: int(res.Code), Message: res.Message}, nil
}

func (srv *FreeSpinService) GetFreeSpins(ctx context.Context, sessionToken string) ([]*entities.FreeSpin, error) {
	overlordSpins, err := srv.overlord.GetAvailableFreeSpins(ctx, sessionToken)
	if err != nil {
		zap.S().Info("overlord error: ", err)

		return nil, errs.TranslateOverlordErr(err)
	}

	return entities.FreeSpinsFromOverlordToEntity(overlordSpins), nil
}

func (srv *FreeSpinService) CancelFreeSpins(ctx context.Context, sessionToken string) error {
	err := srv.overlord.CancelAvailableFreeSpins(ctx, sessionToken)
	if err != nil {
		zap.S().Info("overlord error: ", err)

		return errs.TranslateOverlordErr(err)
	}

	return nil
}
