package services

import (
	"context"
	"encoding/json"
	"errors"
	"github.com/google/uuid"
	"go.uber.org/zap"
	"pfr-service/internal/entities"
	"pfr-service/internal/errs"
	"pfr-service/internal/repositories"
	"pfr-service/pkg/overlord"
	"pfr-service/utils"
	"strings"
	"time"
)

const (
	BFIntegratorName     = "bf"
	BFCurrencyMultiplier = 10
)

var (
	DefaultPFRDuration = time.Hour * 24 * 365
)

type BFService struct {
	overlord          overlord.Client
	programRepository repositories.ProgramRepository[entities.BFProgramData]
}

func NewBFService(overlord overlord.Client, programRepository repositories.ProgramRepository[entities.BFProgramData]) *BFService {
	return &BFService{overlord: overlord, programRepository: programRepository}
}

func (s *BFService) CreateBonusProgram(ctx context.Context, bonusProgramID, name string, games []string, roundsCount int, maxProgramRoundsCount int, roundValues []interface{}, startDate *time.Time, expiresAt time.Time) (string, error) {
	pr := &entities.Program[entities.BFProgramData]{
		CreatedAt: time.Now(),
		StartsAt:  startDate,
		EndsAt:    &expiresAt,

		ID:           uuid.New(),
		IntegratorID: bonusProgramID,
		Integrator:   BFIntegratorName,

		Data: entities.BFProgramData{
			Name:       name,
			RoundCount: roundsCount,
			Games:      games,
		},
	}

	exPr, err := s.programRepository.FindBy(ctx, map[string]interface{}{"integrator": BFIntegratorName, "integrator_id": bonusProgramID})
	if err == nil {
		pr.ID = exPr.ID
	}

	if maxProgramRoundsCount > 0 {
		pr.MaxUsageCount = &maxProgramRoundsCount
	}

	if err := utils.RemarshalJSON(roundValues, &pr.Data.RoundValues); err != nil {
		return "", err
	}

	if err := s.programRepository.Upsert(ctx, pr); err != nil {
		return "", err
	}

	return pr.ID.String(), nil
}

func (s *BFService) DeleteBonusProgram(ctx context.Context, bonusProgramID string) error {
	pr, err := s.programRepository.FindBy(ctx, map[string]interface{}{"integrator": BFIntegratorName, "integrator_id": bonusProgramID})
	if err != nil {
		return err
	}

	return s.programRepository.Delete(ctx, pr)
}

func (s *BFService) CreateBonusRounds(ctx context.Context, playerID, bonusInstanceID string, games []string, currency string, roundCount, roundValue int, expiresAt time.Time) (plID, providerBonusInstanceID string, err error) {
	errsBag := make([]error, 0)

	for _, game := range games {
		_, err = s.overlord.GetIntegratorConfig(ctx, BFIntegratorName, game)
		if err != nil {
			errsBag = append(errsBag, err)

			continue
		}

		_, err = s.overlord.AddFreeSpins(ctx, &overlord.AddFreeBetIn{
			UserId:        playerID,
			BetValue:      int64(roundValue) * BFCurrencyMultiplier,
			FreeBets:      int32(roundCount),
			Currency:      strings.ToLower(currency),
			EndDate:       expiresAt.Unix(),
			FreeBetId:     bonusInstanceID,
			Game:          game,
			Provider:      BFIntegratorName,
			IntegratorKey: BFIntegratorName,
			SecretToken:   BFIntegratorName,
		})

		if err != nil {
			errsBag = append(errsBag, err)
		}
	}

	if len(errsBag) == len(games) {
		return "", "", errors.Join(errsBag...)
	}

	if len(errsBag) > 0 {
		zap.S().Info(errors.Join(errsBag...))
	}

	return bonusInstanceID, bonusInstanceID, nil
}

func (s *BFService) CreateBonusRoundsByProgram(ctx context.Context, playerID, bonusInstanceID, bonusProgramID string) (plID, providerBonusInstanceID string, err error) {
	pr, err := s.programRepository.FindBy(ctx, map[string]interface{}{"integrator": BFIntegratorName, "integrator_id": bonusProgramID})
	if err != nil {
		return "", "", err
	}

	if len(pr.Data.RoundValues) == 0 || len(pr.Data.Games) == 0 {
		return "", "", errs.ErrBadDataGiven
	}

	endsAt := time.Now().Add(DefaultPFRDuration)
	if pr.EndsAt != nil {
		endsAt = *pr.EndsAt
	}

	ad := map[string]interface{}{
		"program_id": pr.IntegratorID,
	}

	adRaw, err := json.Marshal(ad)

	if err != nil {
		return "", "", err
	}

	errsBag := make([]error, 0)

	for _, game := range pr.Data.Games {
		_, err = s.overlord.GetIntegratorConfig(ctx, BFIntegratorName, game)
		if err != nil {
			errsBag = append(errsBag, err)

			continue
		}

		_, err = s.overlord.AddFreeSpins(ctx, &overlord.AddFreeBetIn{
			UserId:         playerID,
			BetValue:       pr.Data.RoundValues[0].Amount * BFCurrencyMultiplier,
			FreeBets:       int32(pr.Data.RoundCount),
			Currency:       strings.ToLower(pr.Data.RoundValues[0].Currency),
			EndDate:        endsAt.Unix(),
			FreeBetId:      bonusInstanceID,
			Game:           game,
			Provider:       BFIntegratorName,
			IntegratorKey:  BFIntegratorName,
			SecretToken:    BFIntegratorName,
			AdditionalData: adRaw,
		})

		if err != nil {
			errsBag = append(errsBag, err)
		}
	}

	if len(errsBag) == len(pr.Data.Games) {
		return "", "", errors.Join(errsBag...)
	}

	if len(errsBag) > 0 {
		zap.S().Info(errors.Join(errsBag...))
	}

	return bonusInstanceID, bonusInstanceID, nil
}

func (s *BFService) GetBonusRounds(ctx context.Context, playerID, providerCode string) []interface{} {
	zap.S().Infof("playerID=%s providerCode=%s", playerID, providerCode)

	return make([]interface{}, 0)
}

func (s *BFService) DeleteBonusRounds(ctx context.Context, bonusInstanceID string) bool {
	zap.S().Info(bonusInstanceID)

	return true
}
