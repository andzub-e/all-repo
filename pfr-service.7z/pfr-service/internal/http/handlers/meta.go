package handlers

import (
	"github.com/gin-gonic/gin"
	"pfr-service/internal/http"
	"pfr-service/internal/http/responses"
)

var tag = "no tag"

type metaHandler struct{}

func NewMetaHandler() http.Handler {
	return &metaHandler{}
}

func (h *metaHandler) Register(route *gin.RouterGroup) {
	route.GET("health", h.health)
	route.GET("info", h.info)
}

// @Summary Check health.
// @Tags meta
// @Consume application/json
// @Description Check service health.
// @Accept  json
// @Produce  json
// @Success 200  {object} responses.HealthResponse
// @Router /health [get]
func (h *metaHandler) health(ctx *gin.Context) {
	responses.OK(ctx, responses.HealthResponse{Success: "ok"}, nil)
}

// @Summary Check tag.
// @Tags meta
// @Consume application/json
// @Description Check service tag.
// @Accept  json
// @Produce  json
// @Success 200  {object} responses.InfoResponse
// @Router /info [get]
func (h *metaHandler) info(ctx *gin.Context) {
	responses.OK(ctx, responses.InfoResponse{Tag: tag}, nil)
}
