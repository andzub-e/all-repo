package handlers

import (
	"github.com/gin-gonic/gin"
	"pfr-service/internal/http/requests"
	"pfr-service/internal/http/responses"
	"pfr-service/internal/services"
	"strconv"
	"time"
)

type bfHandler struct {
	bfService *services.BFService
}

func NewBFHandler(bfService *services.BFService) *bfHandler {
	return &bfHandler{bfService: bfService}
}

func (h *bfHandler) Register(router *gin.RouterGroup) {
	bf := router.Group("bf/bonus")

	bf.POST("programs", h.addProgram)
	bf.DELETE("programs/:id", h.deleteProgram)
	bf.POST("instances", h.addFreeSpins)
	bf.GET("instances", h.getFreeSpins)
	bf.DELETE("instances/:id", h.deleteFreeSpins)
}

func (h *bfHandler) addProgram(ctx *gin.Context) {
	req := requests.BFAddProgramRequest{}
	if err := ctx.ShouldBind(&req); err != nil {
		responses.BadRequest(ctx, err, nil)

		return
	}

	expire, err := strconv.Atoi(req.ExpiryDate)
	if err != nil {
		responses.BadRequest(ctx, err, nil)

		return
	}

	expireDate := time.Unix(int64(expire), 0)
	var startDate *time.Time

	if req.StartDate != nil {
		start, err := strconv.Atoi(*req.StartDate)
		if err != nil {
			responses.BadRequest(ctx, err, nil)

			return
		}

		tmp := time.Unix(int64(start), 0)

		startDate = &tmp
	}

	programID, err := h.bfService.CreateBonusProgram(ctx,
		req.BonusProgramId, req.Name,
		req.Games, req.RoundsCount, req.MaxProgramRoundsCount,
		req.RoundValues, startDate, expireDate)

	if err != nil {
		responses.BadRequest(ctx, err, nil)

		return
	}

	responses.OKPure(ctx, responses.BFCreateProgramResponse{ProviderBonusProgramId: programID})
}

func (h *bfHandler) deleteProgram(ctx *gin.Context) {
	id := ctx.Param("id")
	if err := h.bfService.DeleteBonusProgram(ctx, id); err != nil {
		responses.BadRequest(ctx, err, nil)

		return
	}

	responses.OK(ctx, id, nil)
}

func (h *bfHandler) addFreeSpins(ctx *gin.Context) {
	req := requests.BFAddFreeSpinsRequest{}
	if err := ctx.ShouldBind(&req); err != nil {
		responses.BadRequest(ctx, err, nil)

		return
	}

	var (
		expireDate     = time.Unix(req.ExpiryDate, 0)
		playerId, fsID string
		err            error
	)

	if req.BonusProgramId != "" {
		playerId, fsID, err = h.bfService.CreateBonusRoundsByProgram(ctx, req.PlayerId, req.BonusInstanceId, req.BonusProgramId)
	} else {
		playerId, fsID, err = h.bfService.CreateBonusRounds(ctx, req.PlayerId, req.BonusInstanceId, req.Games, req.Currency, req.RoundsCount, req.RoundValue, expireDate)
	}

	if err != nil {
		responses.BadRequest(ctx, err, nil)

		return
	}

	responses.OKPure(ctx, responses.BFCreateFreeSpinsResponse{
		PlayerId:                playerId,
		ProviderBonusInstanceId: fsID,
	})
}

func (h *bfHandler) getFreeSpins(ctx *gin.Context) {
	req := requests.BFGetFreeSpinsRequest{}
	if err := ctx.ShouldBindQuery(&req); err != nil {
		responses.BadRequest(ctx, err, nil)

		return
	}

	resp := h.bfService.GetBonusRounds(ctx, req.PlayerID, req.ProviderCode)

	responses.OKPure(ctx, resp)
}

func (h *bfHandler) deleteFreeSpins(ctx *gin.Context) {
	id := ctx.Param("id")

	h.bfService.DeleteBonusRounds(ctx, id)

	responses.OK(ctx, id, nil)
}
