package handlers

import (
	"context"
	"github.com/gin-gonic/gin"
	"pfr-service/internal/entities"
	"pfr-service/internal/http"
	"pfr-service/internal/http/responses"
	"pfr-service/internal/services"
	"time"
)

type freeSpinsHandler struct {
	freeSpinService   *services.FreeSpinService
	maxProcessingTime time.Duration
}

func NewFreeSpinsHandler(freeSpinService *services.FreeSpinService, maxProcessingTime time.Duration) http.Handler {
	return &freeSpinsHandler{freeSpinService: freeSpinService, maxProcessingTime: maxProcessingTime}
}
func (h *freeSpinsHandler) Register(router *gin.RouterGroup) {
	router.POST("/create", h.createFreeSpin)
	router.POST("/cancel", h.cancelFreeSpin)
}

func (h *freeSpinsHandler) createFreeSpin(ctx *gin.Context) {
	ctxWithTimeout, cancel := context.WithTimeout(ctx.Request.Context(), h.maxProcessingTime)
	defer cancel()

	req := entities.FreeSpinCreate{}
	if err := ctx.ShouldBindJSON(&req); err != nil {
		responses.ValidationFailed(ctx, err)

		return
	}

	res, err := h.freeSpinService.Create(ctxWithTimeout, &req)
	if err != nil {
		handleServiceError(ctx, err)

		return
	}

	responses.OK(ctx, res, nil)
}

func (h *freeSpinsHandler) cancelFreeSpin(ctx *gin.Context) {
	ctxWithTimeout, cancel := context.WithTimeout(ctx.Request.Context(), h.maxProcessingTime)
	defer cancel()

	req := entities.FreeSpinCancel{}
	if err := ctx.ShouldBindJSON(&req); err != nil {
		responses.ValidationFailed(ctx, err)

		return
	}

	res, err := h.freeSpinService.Cancel(ctxWithTimeout, &req)

	if err != nil {
		handleServiceError(ctx, err)

		return
	}

	responses.OK(ctx, res, nil)
}
