package middlewares

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/samber/lo"
	"net"
	"pfr-service/internal/http/responses"
)

func IPWhiteList(whiteList []net.IP) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		ip := net.ParseIP(ctx.ClientIP())

		if !lo.ContainsBy(whiteList, func(item net.IP) bool {
			return item.String() == ip.String()
		}) {
			responses.BadRequest(ctx, fmt.Errorf("%v is not in white list", ip), nil)

			return
		}

		ctx.Next()
	}
}
