package middlewares

import (
	"bytes"
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"io"
)

func RequestLog() func(ctx *gin.Context) {
	return func(ctx *gin.Context) {
		zap.S().Info("Request URI: ", ctx.Request.URL.RequestURI())

		body, err := io.ReadAll(ctx.Request.Body)
		if err != nil {
			zap.S().Info(err)
		} else {
			zap.S().Info("Body: ", string(body))
			ctx.Request.Body = io.NopCloser(bytes.NewReader(body))
		}

		ctx.Next()
	}
}
