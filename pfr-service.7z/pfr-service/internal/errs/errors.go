package errs

import "errors"

type InternalValidationError struct {
	Err error
}

func (err InternalValidationError) Error() string {
	return err.Err.Error()
}

var (
	ErrWrongSessionToken = errors.New("wrong session token")
	ErrBadDataGiven      = errors.New("bad data given")
	ErrUnauthorized      = errors.New("unauthorized")
	ErrWrongFreeSpinID   = errors.New("wrong free spin id")

	ErrWagerLevelIsOutOfRange = errors.New("wager level is out of range")
	ErrCurrencyIsNotSupported = errors.New("currency is not supported")
)
