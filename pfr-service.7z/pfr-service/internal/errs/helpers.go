package errs

import "pfr-service/pkg/overlord"

var translateMap = map[error]error{
	overlord.ErrMarshaling:        ErrBadDataGiven,
	overlord.ErrWrongSessionToken: ErrWrongSessionToken,
	overlord.ErrWrongFreeSpinID:   ErrWrongFreeSpinID,
}

func TranslateOverlordErr(err error) error {
	validationErr, ok := err.(overlord.ValidationError)
	if ok {
		return InternalValidationError{Err: validationErr}
	}

	res, ok := translateMap[err]
	if !ok {
		return err
	}

	return res
}
