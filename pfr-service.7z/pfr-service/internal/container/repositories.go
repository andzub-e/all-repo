package container

import (
	"github.com/sarulabs/di"
	"gorm.io/gorm"
	"pfr-service/internal/constants"
	"pfr-service/internal/entities"
	"pfr-service/internal/repositories/pgsql"
)

func BuildRepositories() []di.Def {
	return []di.Def{
		{
			Name: constants.BFProgramRepositoryName,
			Build: func(ctn di.Container) (interface{}, error) {
				conn := ctn.Get(constants.PgSQLName).(*gorm.DB)

				return pgsql.NewProgramRepository[entities.BFProgramData](conn), nil
			},
		},
		{
			Name: constants.InfingameProgramRepositoryName,
			Build: func(ctn di.Container) (interface{}, error) {
				conn := ctn.Get(constants.PgSQLName).(*gorm.DB)

				return pgsql.NewProgramRepository[entities.InfinProgramData](conn), nil
			},
		},
	}
}
