package container

import (
	"github.com/sarulabs/di"
	"pfr-service/internal/constants"
	"pfr-service/internal/entities"
	"pfr-service/internal/repositories"
	"pfr-service/internal/services"
	"pfr-service/pkg/overlord"
)

func BuildServices() []di.Def {
	return []di.Def{
		{
			Name: constants.FreeSpinsServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				overlordClient := ctn.Get(constants.OverlordName).(overlord.Client)

				return services.NewFreeSpinService(overlordClient), nil
			},
		},
		{
			Name: constants.LemonServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				overlordClient := ctn.Get(constants.OverlordName).(overlord.Client)

				return services.NewLemonService(overlordClient), nil
			},
		},
		{
			Name: constants.InfinServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				overlordClient := ctn.Get(constants.OverlordName).(overlord.Client)
				programRepo := ctn.Get(constants.InfingameProgramRepositoryName).(repositories.ProgramRepository[entities.InfinProgramData])

				return services.NewInfinService(overlordClient, programRepo), nil
			},
		},
		{
			Name: constants.BFServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				overlordClient := ctn.Get(constants.OverlordName).(overlord.Client)
				programRepo := ctn.Get(constants.BFProgramRepositoryName).(repositories.ProgramRepository[entities.BFProgramData])

				return services.NewBFService(overlordClient, programRepo), nil
			},
		},
	}
}
