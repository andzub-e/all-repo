package main

import (
	"context"
	"exchange/internal/constants"
	"exchange/internal/container"
	"exchange/internal/transport/cron"
	"exchange/internal/transport/http"
	"exchange/internal/transport/rpc"
	"exchange/pkg/tracer"
	"exchange/utils"
	"go.uber.org/zap"
	"log"
	"time"
)

func main() {
	now := time.Now()
	ctx, cancel := context.WithCancel(context.Background())
	app := container.Build(ctx)
	_ = app.Get(constants.LoggerName).(*zap.Logger)

	zap.S().Info("Starting application...")

	server := app.Get(constants.HTTPServerName).(*http.Server)
	go server.Run()

	scheduler := app.Get(constants.SchedulerName).(*cron.Scheduler)
	scheduler.StartAsync()

	rpcHandler := app.Get(constants.RPCServerName).(*rpc.Handler)
	tr := app.Get(constants.TracerName).(*tracer.JaegerTracer)

	go rpc.StartUnsecureRPCServer(rpcHandler, tr)

	zap.S().Infof("Up and running (%s)", time.Since(now))
	zap.S().Infof("Got %s signal. Shutting down...", <-utils.WaitTermSignal())

	if err := app.Delete(); err != nil {
		log.Println(err)
	}

	cancel()

	zap.S().Info("Service stopped.")
}
