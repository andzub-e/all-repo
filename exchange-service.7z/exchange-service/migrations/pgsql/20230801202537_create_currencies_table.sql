-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
create table if not exists exchange_rates(
    created_at timestamptz default current_timestamp,
    from_currency varchar(5),
    to_currency varchar(5),
    rate float,

    primary key (created_at, from_currency, to_currency)
);

create index if not exists idx_exchange_rates_from_to on exchange_rates using hash (from_currency);
create index if not exists idx_exchange_rates_to on exchange_rates using hash (to_currency);
create index if not exists idx_exchange_rage_created_at on  exchange_rates using btree (created_at);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
drop table if exists exchange_rates;
drop index if exists idx_exchange_rates_from_to;
drop index if exists idx_exchange_rates_to;
drop index if exists idx_exchange_rage_created_at;
-- +goose StatementEnd
