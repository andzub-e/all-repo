package xe

import (
	"context"
	"exchange/pkg/xe/swaggerclient"
	"github.com/antihax/optional"
	"github.com/samber/lo"
	"go.uber.org/zap"
	"strings"
	"time"
)

const TimeParseFormat = "2006-01-02T15:04:05Z"

type Client struct {
	config *Config

	swaggerClient *swaggerclient.APIClient

	currencyFormat func(string) string
}

func NewClient(config *Config, currencyFormat func(string) string) *Client {
	if currencyFormat == nil {
		currencyFormat = func(s string) string {
			return s
		}
	}

	srv := swaggerclient.NewAPIClient(swaggerclient.NewConfiguration())

	return &Client{
		config:         config,
		swaggerClient:  srv,
		currencyFormat: currencyFormat,
	}
}

type RatesResult struct {
	From string
	Date time.Time
	To   []Rate
}

type Rate struct {
	Title string  `json:"title"`
	Rate  float64 `json:"rate"`
}

func (c *Client) GetRates(ctx context.Context, from string, to []string, date time.Time) (RatesResult, error) {
	zap.S().Infof("rates request from %v to #%v", from, len(to))

	ctx = c.patchCtx(ctx)

	hrr, _, err := c.swaggerClient.MidMarketRatesAPI.
		V1HistoricRateGet(ctx, strings.Join(to, ","), date.Format(time.DateOnly),
			&swaggerclient.MidMarketRatesApiV1HistoricRateGetOpts{
				From: optional.NewString(from),
			})

	if err != nil {
		return RatesResult{}, err
	}

	t, err := time.Parse(TimeParseFormat, hrr.Timestamp)
	if err != nil {
		return RatesResult{}, err
	}

	return RatesResult{
		From: c.currencyFormat(hrr.From),
		Date: t,
		To: lo.Map(hrr.To, func(item swaggerclient.Rate, index int) Rate {
			return Rate{Rate: item.Mid, Title: c.currencyFormat(item.Quotecurrency)}
		})}, nil
}

func (c *Client) GetCurrencies(ctx context.Context) ([]string, error) {
	ctx = c.patchCtx(ctx)

	res, _, err := c.swaggerClient.CurrencyInformationAPI.V1CurrenciesGet(ctx,
		&swaggerclient.CurrencyInformationApiV1CurrenciesGetOpts{
			Crypto: optional.NewBool(true),
		})

	if err != nil {
		return nil, err
	}

	return lo.Map(res.Currencies, func(item swaggerclient.CurrencyInfo, index int) string {
		return c.currencyFormat(item.Iso)
	}), nil
}

func (c *Client) patchCtx(ctx context.Context) context.Context {
	return context.WithValue(ctx, swaggerclient.ContextBasicAuth, swaggerclient.BasicAuth{
		UserName: c.config.ID,
		Password: c.config.Key,
	})
}
