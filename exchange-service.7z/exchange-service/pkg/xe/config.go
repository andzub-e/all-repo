package xe

type Config struct {
	ID  string
	Key string
}
