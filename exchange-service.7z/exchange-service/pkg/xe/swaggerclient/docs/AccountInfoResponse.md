# AccountInfoResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [optional] [default to null]
**Organization** | **string** |  | [optional] [default to null]
**Package_** | **string** |  | [optional] [default to null]
**ServiceStartTimestamp** | **string** |  | [optional] [default to null]
**PackageLimitDuration** | **string** |  | [optional] [default to null]
**PackageLimit** | **float64** |  | [optional] [default to null]
**PackageLimitRemaining** | **float64** |  | [optional] [default to null]
**PackageLimitReset** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

