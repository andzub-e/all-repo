# ToCurrencyIso

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MonthlyAverage** | **float64** |  | [optional] [default to null]
**Month** | **float64** |  | [optional] [default to null]
**DaysInMonth** | **float64** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

