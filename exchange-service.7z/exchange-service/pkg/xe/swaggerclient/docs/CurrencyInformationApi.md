# {{classname}}

All URIs are relative to *https://xecdapi.xe.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**V1CurrenciesGet**](CurrencyInformationApi.md#V1CurrenciesGet) | **Get** /v1/currencies | Access a list of all available currencies.

# **V1CurrenciesGet**
> CurrencyInfoResponse V1CurrenciesGet(ctx, optional)
Access a list of all available currencies.

This endpoint will return a list of all currencies, active and obsolete, available via the XE Currency Data Feed API.</br></br>If the obsolete optional parameter is included, then the list will contain both active and obsolete currencies.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***CurrencyInformationApiV1CurrenciesGetOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a CurrencyInformationApiV1CurrenciesGetOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **iso** | **optional.String**| OPTIONAL – Comma separated list of ISO 4217 codes. This will limit the data returned to only those currencies that are specified. If this parameter is omitted, this endpoint will return results for all currencies.&lt;/br&gt;&lt;/br&gt; It is a prefix match; you can provide it with one, two, or three characters and it will return a list of all the currencies with ISO 4217 codes that match.&lt;/br&gt;&lt;/br&gt; A list of acceptable ISO 4217 currency codes can be found here: http://www.xe.com/iso4217.php | 
 **obsolete** | **optional.Bool**| OPTIONAL – If &#x27;true&#x27; then endpoint will display currencies that are obsolete but for which historical data is available | 
 **language** | **optional.String**| OPTIONAL – Default is en. Specified as an RFC-1766-compliant language tag.&lt;/br&gt;&lt;/br&gt;Languages available: ar, de, en, es, fr, it, ja, pt, sv, zh-CN, zh-HK. | 
 **additionalInfo** | **optional.String**| OPTIONAL - If &#x27;symbol&#x27; then returns &#x27;currency_symbol&#x27; and &#x27;currency_symbol_on_right&#x27; in response | 
 **crypto** | **optional.Bool**| OPTIONAL – If &#x27;true&#x27; then this endpoint will return data for the following crypto currencies: ADA, BCH, DOGE, DOT, ETH, LINK, LTC, LUNA, UNI, XLM and XRP | 

### Return type

[**CurrencyInfoResponse**](CurrencyInfoResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

