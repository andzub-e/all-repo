# Stats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**To** | **string** |  | [optional] [default to null]
**High** | **float64** |  | [optional] [default to null]
**Low** | **float64** |  | [optional] [default to null]
**Average** | **float64** |  | [optional] [default to null]
**StandardDeviation** | **float64** |  | [optional] [default to null]
**Volatility** | **float64** |  | [optional] [default to null]
**HighTimestamp** | **string** |  | [optional] [default to null]
**LowTimestamp** | **string** |  | [optional] [default to null]
**DataPoints** | **int32** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

