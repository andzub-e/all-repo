# {{classname}}

All URIs are relative to *https://xecdapi.xe.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**V1CentralBankRateGet**](CentralBankExchangeRatesApi.md#V1CentralBankRateGet) | **Get** /v1/central_bank_rate | Central bank exchange rates from currency of central bank to one or multiple counter currencies, provided by specified central bank.

# **V1CentralBankRateGet**
> CentralBankExchangeRateResponse V1CentralBankRateGet(ctx, centralBank, to, optional)
Central bank exchange rates from currency of central bank to one or multiple counter currencies, provided by specified central bank.

In the example below, the endpoint converts from CAD to all available currencies for the Bank of Canada (the asterisk * represents ALL currencies).</br><a href=\"https://xecdapi.xe.com/v1/central_bank_rate.csv/?central_bank=CAN&to=*&amount=1\">https://xecdapi.xe.com/v1/central_bank_rate.csv/?central_bank=CAN&to=*&amount=1</a>

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **centralBank** | **string**| REQUIRED – Three letter codes representing the specific central bank you are querying for. The time(s) specified below highlights the time rates published by each respective central bank updates within the API service.&lt;/br&gt; | Code | Name | Available at (UTC) | |:--- |:--- |:--- | | AFG | Da Afghanistan Bank | 06:00-11:00 | | AGO | National Bank of Angola | 11:00-17:00 | | ALB | Bank of Albania | 12:00 | | AUS | Reserve Bank of Australia | 08:00 | | AZE | National Bank of Azerbaijan | 06:00 | | BRA | Central Bank of Brazil | 17:00 | | CAN | Bank of Canada | 23:00 | | CAR | Eastern Caribbean Central Bank | 14:00 | | CHE | Swiss National Bank | 11:00 | | CHN | China Foreign Exchange Trade System | hourly | | COL | Central Bank of Colombia | 22:00 | | CRI | Banco Central de Costa Rica | 15:00 | | CZE | Czech National Bank | 13:00 | | DNK | National Bank of Denmark | 17:00 | | ECB | European Central Bank | 17:00 | | GBR | Bank of England | 10:00 | | GTM | Bank of Guatemala | 14:00 | | HUN | Hungarian National Bank | 12:00 | | IDN | Bank Indonesia | 12:00 | | ISR | Bank of Israel | 05:00 | | KOR | Seoul Money Brokerage Services | 00:00 | | LAO | Bank of the Lao PDR | 03:00 | | MEX | Bank of Mexico | 19:00 | | MNG | Bank of Mongolia | 11:00 | | MOZ | Banco de Moçambique | 09:00-15:00 | | NOR | Norges Bank (Central Bank of Norway) | 16:00 | | PNG | Bank of Papua New Guinea | 02:00-10:00 | | POL | National Bank of Poland | 15:00 | | ROU | National Bank of Romania | 11:00 | | RUS | Central Bank of Russian Federation | 16:00 | | SRB | National Bank of Serbia | 07:00 | | SVN | Bank of Slovenia | 15:00 | | SYC | Central Bank of the Seychelles | 15:00 | | THA | Bank of Thailand |  | | TJK | National Bank of Tajikistan | 16:00 | | TKM | State Bank for Foreign Economic Affairs of Turkmenistan | 14:00 | | TUR | Central Bank of the Republic of Turkey | 00:00 | | UAE | Central Bank of UAE | 15:00 | | UKR | National Bank of Ukraine | 23:00 | | URY | Central Bank of Uruguay | 21:00 | | UZB | Central Bank of the Republic of Uzbekistan | 21:00 | | YEM | Central Bank of Yemen | 08:00 | | ZAF | South African Reserve Bank | 15:00 | | ZWE | Reserve Bank of Zimbabwe | 05:00 |  | 
  **to** | **string**| Comma separated list of to currencies ISO 4217 codes.  This will limit the data returned to only those currencies you are interested in. Use an asterisk * to convert all currencies. | 
 **optional** | ***CentralBankExchangeRatesApiV1CentralBankRateGetOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a CentralBankExchangeRatesApiV1CentralBankRateGetOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **amount** | **optional.Float64**| OPTIONAL – This parameter can be used to specify the amount you want to convert, if an amount is not specified then 1 is assumed.&lt;/br&gt; | 
 **date** | **optional.String**| OPTIONAL – YYYY-MM-DD format - request rates for a particular past date.  Rates are often not posted on weekends. | 
 **inverse** | **optional.Bool**| OPTIONAL – If ‘true’, the endpoint will include inverse rates. An inverse rate is a quote for which the base currency and counter currency are switched. An inverse is calculated by dividing one by the exchange rate. Example: If the exchange rate for 1 USD to EUR &#x3D; 0.874852, then the inverse rate would be 1/0.874852 &#x3D; 1.14305, meaning that US$1.14305 would buy 1 euro. | 
 **decimalPlaces** | **optional.Float64**| OPTIONAL – This parameter can be used to specify the number of decimal places included in the output. Example: if 1 USD to EUR &#x3D; 0.874852, adding decimal_places&#x3D;3 to the query will result in the endpoint returning EUR &#x3D; 0.875 | 
 **margin** | **optional.Float64**| OPTIONAL – This parameter can be used to add a margin (+/-) to the exchange rate. Example: adding margin&#x3D;2.05 to the query will result in the endpoint returning the current exchange rates with a +2.05% margin | 

### Return type

[**CentralBankExchangeRateResponse**](CentralBankExchangeRateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

