# {{classname}}

All URIs are relative to *https://xecdapi.xe.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**V1ConvertFromGet**](MidMarketRatesApi.md#V1ConvertFromGet) | **Get** /v1/convert_from | Convert from one base currency to one or multiple counter currencies.
[**V1ConvertToGet**](MidMarketRatesApi.md#V1ConvertToGet) | **Get** /v1/convert_to | Convert to a currency amount from one or multiple other currencies.
[**V1HistoricRateGet**](MidMarketRatesApi.md#V1HistoricRateGet) | **Get** /v1/historic_rate | Get historic rates for one base currency against one or more counter currencies.
[**V1HistoricRatePeriodGet**](MidMarketRatesApi.md#V1HistoricRatePeriodGet) | **Get** /v1/historic_rate/period | Get historic rates for one base currency against one or more counter currencies over a period of time.
[**V1MonthlyAverageGet**](MidMarketRatesApi.md#V1MonthlyAverageGet) | **Get** /v1/monthly_average | Get monthly average rates for a single base currency and one or more counter currency for the month/year you specify in your API query. 
[**V1StatsGet**](MidMarketRatesApi.md#V1StatsGet) | **Get** /v1/stats | Gets an average rate over the specified time period, as well various additional statistics such as the standard deviation and volatility.

# **V1ConvertFromGet**
> ConvertFromResponse V1ConvertFromGet(ctx, to, optional)
Convert from one base currency to one or multiple counter currencies.

In the example below, the Convert FROM API query endpoint is to convert from GBP to all available currencies (the asterisk * represents ALL currencies).</br><a href=\"https://xecdapi.xe.com/v1/convert_from.csv/?from=GBP&to=*&amount=1\">https://xecdapi.xe.com/v1/convert_from.csv/?from=GBP&to=*&amount=1</a>

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **to** | **string**| Comma separated list of to currencies ISO 4217 codes.  This will limit the data returned to only those currencies you are interested in. Use an asterisk * to convert all currencies.&lt;/br&gt; Note: Obsolete currencies are replaced by their successor currency.&lt;/br&gt; | 
 **optional** | ***MidMarketRatesApiV1ConvertFromGetOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a MidMarketRatesApiV1ConvertFromGetOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **from** | **optional.String**| OPTIONAL – Currency you want to convert from ISO code.  Note if this parameter is omitted, default is USD.&lt;/br&gt; | 
 **amount** | **optional.Float64**| OPTIONAL – This parameter can be used to specify the amount you want to convert, if an amount is not specified then 1 is assumed.&lt;/br&gt; | 
 **obsolete** | **optional.Bool**| OPTIONAL – If ‘true’ then endpoint will display rates for currencies that are obsolete. If ‘false’ then obsolete currencies are replaced by their successor currency. | 
 **inverse** | **optional.Bool**| OPTIONAL – If ‘true’ then endpoint will include inverse rates. An inverse rate is a quote for which the base currency and counter currency are switched. An inverse is calculated by dividing one by the exchange rate. Example: If the exchange rate for $1 USD to EUR &#x3D; 0.874852, then the inverse rate would be 1/0.874852 &#x3D; 1.14305, meaning that US$1.14305 would buy 1 euro. | 
 **decimalPlaces** | **optional.Float64**| OPTIONAL – This parameter can be used to specify the number of decimal places included in the output. Example 1 USD to EUR &#x3D; 0.874852 with decimal_places&#x3D;3, the output returned will be EUR &#x3D; 0.875 | 
 **margin** | **optional.Float64**| OPTIONAL – This parameter can be used to add a margin (-/+)  to XE&#x27;s mid-market rate. Example: add margin&#x3D;2.05 parameter to the endpoint and the API will return our mid-market rates plus the margin of 2.05 percent | 
 **crypto** | **optional.Bool**| OPTIONAL – If &#x27;true&#x27; then this endpoint will return data for the following crypto currencies: ADA, BCH, DOGE, DOT, ETH, LINK, LTC, LUNA, UNI, XLM and XRP | 
 **skipWeekends** | **optional.Bool**| OPTIONAL – LIVE accounts only - If &#x27;true&#x27; then requests during the weekend will respond with the rate as of market close (Friday, 5pm America/New_York) | 

### Return type

[**ConvertFromResponse**](ConvertFromResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **V1ConvertToGet**
> ConvertToResponse V1ConvertToGet(ctx, from, optional)
Convert to a currency amount from one or multiple other currencies.

In the example below, the Convert TO API query endpoint is to convert to GBP from all available currencies (the asterisk * represents ALL currencies).</br><a href=\"https://xecdapi.xe.com/v1/convert_to.csv/?to=GBP&from=*&amount=1\">https://xecdapi.xe.com/v1/convert_to.csv/?to=GBP&from=*&amount=1</a>

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **from** | **string**| Comma separated list of to currencies ISO codes.  This will limit the data returned to only those currencies you are interested in. Use an asterisk * to convert all currencies.&lt;/br&gt; Note: Obsolete currencies are replaced by their successor currency.&lt;/br&gt; | 
 **optional** | ***MidMarketRatesApiV1ConvertToGetOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a MidMarketRatesApiV1ConvertToGetOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **to** | **optional.String**| OPTIONAL - Currency you want to convert to ISO code.  Note if this parameter is omitted, default is USD.&lt;/br&gt; | 
 **amount** | **optional.Float64**| OPTIONAL – This parameter can be used to specify the amount you want to convert, if an amount is not specified then 1 is assumed.&lt;/br&gt; | 
 **obsolete** | **optional.Bool**| OPTIONAL – If ‘true’ then endpoint will display rates for currencies that are obsolete. If ‘false’ then obsolete currencies are replaced by their successor currency. | 
 **inverse** | **optional.Bool**| OPTIONAL – If ‘true’ then endpoint will display the inverse of the converted value. If ‘false‘ then it will not be displayed. | 
 **decimalPlaces** | **optional.Float64**| OPTIONAL – This parameter can be used to specify the number of decimal places included in the output. Example 1 USD to EUR &#x3D; 0.874852 with decimal_places&#x3D;3, the output returned will be EUR &#x3D; 0.875 | 
 **margin** | **optional.Float64**| OPTIONAL – This parameter can be used to add a margin (-/+)  to XE&#x27;s mid-market rate. Example: add margin&#x3D;2.05 parameter to the endpoint and the API will return our mid-market rates plus the margin of 2.05 percent | 
 **crypto** | **optional.Bool**| OPTIONAL – If &#x27;true&#x27; then this endpoint will return data for the following crypto currencies: ADA, BCH, DOGE, DOT, ETH, LINK, LTC, LUNA, UNI, XLM and XRP | 
 **skipWeekends** | **optional.Bool**| OPTIONAL – LIVE accounts only – If &#x27;true&#x27; then requests during the weekend will respond with the rate as of market close (Friday, 5pm America/New_York) | 

### Return type

[**ConvertToResponse**](ConvertToResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **V1HistoricRateGet**
> HistoricRateResponse V1HistoricRateGet(ctx, to, date, optional)
Get historic rates for one base currency against one or more counter currencies.

The Currency Data API provides you with access to daily historical rates back to 1998. When retrieving historical rates through our Currency Data API, you would specify your requested currencies along with the date and/or date range and time (hh:mm). If your account is registered for a Live package then you have access to minutely rates for the past 7 days and outside of 7 days you have access to rates on the hour. Historical rates are available with all API packages. The time parameter (hh:mm) only applies to Live packages.</br> The endpoint returns the historic rate for a single base currency and one or more counter currencies.</br></br><a href=\"https://xecdapi.xe.com/v1/historic_rate.csv/?from=USD&date=2011-03-05&to=CAD,EUR\">https://xecdapi.xe.com/v1/historic_rate.csv/?from=USD&date=2011-03-05&to=CAD,EUR</a></br>

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **to** | **string**| Comma separated list of to currencies ISO 4217 codes.&lt;/br&gt;This will limit the data returned to only those currencies you are interested in. Use an asterisk * to specify all currencies.&lt;/br&gt; Note: Obsolete currencies are replaced by their precursor or successor currency.&lt;/br&gt; | 
  **date** | **string**| UTC date should be in the form of YYYY-MM-DD, up to 1995-11-16.&lt;/br&gt;If your account is registered for a Daily package your endpoint will return rates at your preferred daily lock-in time.&lt;/br&gt;If your account is registered for a Live package your endpoint will return XE mid-day rate unless you specify a time parameter in your call request.&lt;/br&gt; | 
 **optional** | ***MidMarketRatesApiV1HistoricRateGetOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a MidMarketRatesApiV1HistoricRateGetOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **from** | **optional.String**| OPTIONAL – Currency you want to convert from ISO code.&lt;/br&gt;Note if this parameter is omitted, default is USD.&lt;/br&gt; | 
 **amount** | **optional.Float64**| OPTIONAL – This parameter can be used to specify the amount you want to convert, if an amount is not specified then 1.00 is assumed.&lt;/br&gt; | 
 **time** | **optional.String**| OPTIONAL – *Time parameter is applicable to Live package only*.&lt;/br&gt;UTC time is in format of HH:MM Time option is only available for the last 24 hours, if time is not specified, only one table is returned using the XE mid-day rates (As returned in http://www.xe.com/currencytables/)&lt;/br&gt; | 
 **obsolete** | **optional.Bool**| OPTIONAL – If ‘true’ then endpoint will display rates for currencies that are obsolete. If ‘false’ then obsolete currencies are replaced by their successor currency. | 
 **inverse** | **optional.Bool**| OPTIONAL – If ‘true’ then endpoint will display the inverse of the converted value. If ‘false‘ then it will not be displayed. | 
 **decimalPlaces** | **optional.Float64**| OPTIONAL – This parameter can be used to specify the number of decimal places included in the output. Example 1 USD to EUR &#x3D; 0.874852 with decimal_places&#x3D;3, the output returned will be EUR &#x3D; 0.875 | 
 **margin** | **optional.Float64**| OPTIONAL – This parameter can be used to add a margin (-/+)  to XE&#x27;s mid-market rate. Example: add margin&#x3D;2.05 parameter to the endpoint and the API will return our mid-market rates plus the margin of 2.05 percent | 
 **crypto** | **optional.Bool**| OPTIONAL – If &#x27;true&#x27; then this endpoint will return data for the following crypto currencies: ADA, BCH, DOGE, DOT, ETH, LINK, LTC, LUNA, UNI, XLM and XRP | 

### Return type

[**HistoricRateResponse**](HistoricRateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **V1HistoricRatePeriodGet**
> HistoricRatePeriodResponse V1HistoricRatePeriodGet(ctx, to, optional)
Get historic rates for one base currency against one or more counter currencies over a period of time.

This endpoint returns a daily historic rate for a single base currency and one or more counter currencies over a period of time.</br></br><a href=\"https://xecdapi.xe.com/v1/historic_rate/period.csv/?from=USD&to=CAD&start_timestamp=2017-09-01&end_timestamp=2017-11-30&per_page=500\">https://xecdapi.xe.com/v1/historic_rate/period.csv/?from=USD&to=CAD&start_timestamp=2017-09-01&end_timestamp=2017-11-30&per_page=500</a></br></br>Optional parameters available with Live accounts:</br></br>&interval=minutely</br>&interval=hourly</br>

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **to** | **string**| Comma separated list of to currencies based on ISO 4217 codes.&lt;/br&gt;This will limit the data returned to only those currencies you are interested in.&lt;/br&gt; Note: Obsolete currencies are replaced by their precursor or successor currency.&lt;/br&gt; | 
 **optional** | ***MidMarketRatesApiV1HistoricRatePeriodGetOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a MidMarketRatesApiV1HistoricRatePeriodGetOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **from** | **optional.String**| OPTIONAL – Currency you want to convert from ISO code.  Note if this parameter is omitted, default is USD.&lt;/br&gt; | 
 **amount** | **optional.Float64**| OPTIONAL – This parameter can be used to specify the amount you want to convert, if an amount is not specified then 1.00 is assumed.&lt;/br&gt; | 
 **startTimestamp** | **optional.String**| OPTIONAL - ISO 8601 timestamp in the format yyyy-mm-ddThh:mm giving the UTC date and time of the start of the period for which you would like rates returned.&lt;/br&gt;&lt;/br&gt;If your account is registered for a Daily package your endpoint will return rates at your preferred daily lock-in time starting on the date specified in your request.  If your account does not have a preferred daily lock-in time then rates will return as of 00:00 UTC&lt;/br&gt;If your account is registered for a Live package your endpoint will return rates starting at 00:00 UTC if no time portion is specified.&lt;/br&gt; | 
 **endTimestamp** | **optional.String**| OPTIONAL – ISO 8601 timestamp in the format yyyy-mm-ddThh:mm giving the UTC date and time of the end of the period for which you would like rates returned. If a time in the future is specified, the current time will be used. If no end_time is specified, the time specified in the  “start_timestamp” paramenter will also be used for the end_timestamp.”&lt;/br&gt;If your account is registered for a Daily package your endpoint will return rates at your preferred daily lock-in time ending on the date specified in your request.  If your account does not have a preferred daily lock-in time then rates will return as of 00:00 UTC.&lt;/br&gt;If your account is registered for a Live package your endpoint will return rates at 00:00 UTC unless you specify a time parameter in your rate request.&lt;/br&gt; | 
 **interval** | **optional.String**| OPTIONAL – Interval is applicable to Live packages only.  Using one of the interval values below in your call request will return rates for that specific interval within the time period specified.&lt;/br&gt;&lt;/br&gt;Example: adding the interval of \&quot;hourly\&quot; will return rates for every hour in the time period you specified.&lt;/br&gt;&lt;/br&gt;  \&quot;daily\&quot; - Returns one rate for the days specified in your time period,&lt;/br&gt;\&quot;hourly\&quot; - Returns rates for every hour in the time period you specify&lt;/br&gt;&lt;/br&gt;If omitted, \&quot;daily\&quot; is used.  This parameter is only used if both the \&quot;start_timestamp\&quot; and \&quot;end_timestamp\&quot; parameters have been specified | 
 **page** | **optional.Float64**| OPTIONAL – You can specify the page number you want to request.&lt;/br&gt;Note: that page numbering is 1-based (the first page being page 1).&lt;/br&gt;Omitting this parameter will return the first page.&lt;/br&gt; | 
 **perPage** | **optional.Float64**| OPTIONAL – You can specify the number of results per page. The default is 30 results per page with a maximum of 500 results per page.&lt;/br&gt; | 
 **obsolete** | **optional.Bool**| OPTIONAL – If ‘true’ then endpoint will display rates for currencies that are obsolete. If ‘false’ then obsolete currencies are replaced by their successor currency. | 
 **inverse** | **optional.Bool**| OPTIONAL – If ‘true’ then endpoint will display the inverse of the converted value. If ‘false‘ then it will not be displayed. | 
 **decimalPlaces** | **optional.Float64**| OPTIONAL – This parameter can be used to specify the number of decimal places included in the output. Example 1 USD to EUR &#x3D; 0.874852 with decimal_places&#x3D;3, the output returned will be EUR &#x3D; 0.875 | 
 **margin** | **optional.Float64**| OPTIONAL – This parameter can be used to add a margin (-/+)  to XE&#x27;s mid-market rate. Example: add margin&#x3D;2.05 parameter to the endpoint and the API will return our mid-market rates plus the margin of 2.05 percent | 
 **crypto** | **optional.Bool**| OPTIONAL – If &#x27;true&#x27; then this endpoint will return data for the following crypto currencies: ADA, BCH, DOGE, DOT, ETH, LINK, LTC, LUNA, UNI, XLM and XRP | 

### Return type

[**HistoricRatePeriodResponse**](HistoricRatePeriodResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **V1MonthlyAverageGet**
> MonthlyAverageResponse V1MonthlyAverageGet(ctx, to, optional)
Get monthly average rates for a single base currency and one or more counter currency for the month/year you specify in your API query. 

The monthly average endpoint returns monthly average rates for a single base currency and one or more counter currency for the year you specify in your API query. The monthly average rate is calculated by taking the 00:00 UTC Daily rate for each day in the month/year you specify in your query. Months are returned as a numeric value from 1 to 12 where 1 is for January and 12 is for December. If no month is provided, then all months for the given year are returned.</br>

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **to** | **string**| Comma separated list of to currencies based on ISO 4217 codes. This will limit the data returned to only those currencies that are specified.&lt;/br&gt; | 
 **optional** | ***MidMarketRatesApiV1MonthlyAverageGetOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a MidMarketRatesApiV1MonthlyAverageGetOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **from** | **optional.String**| OPTIONAL – Currency you want to convert from ISO code.  Note if this parameter is omitted, default is USD.&lt;/br&gt; | 
 **amount** | **optional.Float64**| OPTIONAL – This parameter can be used to specify the amount you want to convert, if an amount is not specified then 1 is assumed.&lt;/br&gt; | 
 **year** | **optional.Float64**| OPTIONAL – This parameter specifies the year to calculate average monthly rates.&lt;/br&gt; | 
 **month** | **optional.Float64**| OPTIONAL – This parameter specifies the month in the given year to return average monthly rates. This is a numeric value from 1 to 12 where 1 is for January and 12 is for December. If no month is provided, then all months for the given year are returned.&lt;/br&gt; | 
 **obsolete** | **optional.Bool**| OPTIONAL – If ‘true’ then endpoint will display rates for currencies that are obsolete. If ‘false’ then obsolete currencies are replaced by their successor currency. | 
 **inverse** | **optional.Bool**| OPTIONAL – If ‘true’ then endpoint will include inverse rates. | 
 **decimalPlaces** | **optional.Float64**| OPTIONAL – This parameter can be used to specify the number of decimal places included in the output. Example 1 USD to EUR &#x3D; 0.874852 with decimal_places&#x3D;3, the output returned will be EUR &#x3D; 0.875 | 
 **crypto** | **optional.Bool**| OPTIONAL – If &#x27;true&#x27; then this endpoint will return data for the following crypto currencies: ADA, BCH, DOGE, DOT, ETH, LINK, LTC, LUNA, UNI, XLM and XRP | 

### Return type

[**MonthlyAverageResponse**](MonthlyAverageResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **V1StatsGet**
> StatsResponse V1StatsGet(ctx, to, optional)
Gets an average rate over the specified time period, as well various additional statistics such as the standard deviation and volatility.

The stats endpoint returns average rates for a single base currency and one or more counter currencies over the time period you specify in your API query. Note that, unlike the monthly_average endpoint, you specify exact start and end dates, which provides a heightened level of control. This can be quite useful if you want statistics for bi-monthly averages or any other intervals of time. </br></br>  This endpoint also provides several other statistics: the highest and lowest rate over the period (and their respective timestamps), the average rate, the standard deviation, volatility, and the number of data points over this period. </br></br> To provide some background to how we obtain our statistics, volatility is measured by applying the standard deviation of the logarithmic daily returns, expressed in a percentage score. We calculate daily returns using the values of two consecutive days at 00:00 UTC, and measure the gain or loss of a currency pair. Then, we apply a logarithm to the ratio between those two values (Ex: ln (valueDay2 / valueDay1) is the logarithmic return between day2 and day1). As for the standard deviation, we apply it to the daily logarithmic returns we calculated during the given time period. When applicable, values are expressed as a percentage so they are already multiplied by 100.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **to** | **string**| Comma separated list of to currencies based on ISO 4217 codes. This will limit the data returned to only those currencies that are specified.&lt;/br&gt; | 
 **optional** | ***MidMarketRatesApiV1StatsGetOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a MidMarketRatesApiV1StatsGetOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **from** | **optional.String**| OPTIONAL – Currency you want to convert from ISO code.  Note if this parameter is omitted, default is USD.&lt;/br&gt; | 
 **startDate** | **optional.String**| OPTIONAL – ISO 8601 timestamp in the format yyyy-mm-dd giving the UTC date of the start of the period for which you would like to compute the volatility from. Note if this parameter is omitted, the start date will default to today.&lt;/br&gt; | 
 **endDate** | **optional.String**| OPTIONAL – ISO 8601 timestamp in the format yyyy-mm-dd giving the UTC date of the end of the period for which you would like to compute the volatility to. Note if this parameter is omitted, the end date will default to today.&lt;/br&gt; | 
 **obsolete** | **optional.Bool**| OPTIONAL – If ‘true’ then endpoint will display rates for currencies that are obsolete. If ‘false’ then obsolete currencies are replaced by their successor currency. | 
 **decimalPlaces** | **optional.Float64**| OPTIONAL – This parameter can be used to specify the number of decimal places included in the output. Example 1 USD to EUR &#x3D; 0.874852 with decimal_places&#x3D;3, the output returned will be EUR &#x3D; 0.875 | 
 **daysInPeriod** | **optional.Float64**| OPTIONAL – This parameter can be used to specify the number of days in the period that we are considering. | 
 **crypto** | **optional.Bool**| OPTIONAL – If &#x27;true&#x27; then this endpoint will return data for the following crypto currencies: ADA, BCH, DOGE, DOT, ETH, LINK, LTC, LUNA, UNI, XLM and XRP | 

### Return type

[**StatsResponse**](StatsResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

