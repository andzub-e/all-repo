# CurrencyInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Iso** | **string** |  | [optional] [default to null]
**CurrencyName** | **string** |  | [optional] [default to null]
**IsObsolete** | **bool** |  | [optional] [default to null]
**SupersededBy** | **string** |  | [optional] [default to null]
**CurrencySymbol** | **string** |  | [optional] [default to null]
**CurrencySymbolOnRight** | **bool** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

