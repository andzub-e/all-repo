# StatsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Terms** | **string** |  | [optional] [default to null]
**Privacy** | **string** |  | [optional] [default to null]
**From** | **string** |  | [optional] [default to null]
**Stats** | [**[]Stats**](Stats.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

