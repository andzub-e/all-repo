# {{classname}}

All URIs are relative to *https://xecdapi.xe.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**V1AccountInfoGet**](AccountInformationApi.md#V1AccountInfoGet) | **Get** /v1/account_info | This endpoint will return basic information for a specific account.

# **V1AccountInfoGet**
> AccountInfoResponse V1AccountInfoGet(ctx, )
This endpoint will return basic information for a specific account.

Requires Headers \"username\" and \"password\"</br>

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**AccountInfoResponse**](AccountInfoResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

