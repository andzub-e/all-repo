package tracer

type Config struct {
	URL         string
	ServiceName string
	Disabled    bool
}
