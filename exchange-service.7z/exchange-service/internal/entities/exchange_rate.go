package entities

import "time"

type ExchangeRate struct {
	CreatedAt time.Time `json:"created_at"`
	From      string    `json:"from" gorm:"column:from_currency"`
	To        string    `json:"to"  gorm:"column:to_currency"`
	Rate      float64   `json:"rate"`
}

type ExchangeKey struct {
	From, To string
}

type ExchangeValue struct {
	CreatedAt time.Time
	Rate      float64
}

type ExchangeBag map[ExchangeKey][]ExchangeValue

func (e ExchangeRate) TableName() string {
	return "exchange_rates"
}
