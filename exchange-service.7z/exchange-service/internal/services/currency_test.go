package services

import (
	"testing"
	"time"
)

var day = time.Hour * 24
var today = time.Now().Truncate(day)
var end = today.Add(day * 5)

func Test_GetRatesTimestamp_ZeroValue(t *testing.T) {
	dates := getRatesTimestamp(time.Time{}, today, 1)

	if len(dates) != 1 {
		t.Error("wrong dates size: ", len(dates))

		return
	}

	if !dates[0].Equal(today) {
		t.Errorf("date is wrong %v, %v expected", dates[0], today)
	}
}

func Test_GetRatesTimestamp_WithStart(t *testing.T) {
	dates := getRatesTimestamp(today, end, 2)

	if len(dates) != 2 {
		t.Error("wrong dates size: ", len(dates))

		return
	}

	if !dates[0].Equal(today.Add(day * 2)) {
		t.Errorf("date is wrong %v, %v expected", dates[0], today.Add(day*2))
	}

	if !dates[1].Equal(today.Add(day * 4)) {
		t.Errorf("date is wrong %v, %v expected", dates[1], today.Add(day*4))
	}
}

func Test_GetRatesTimestamp_WithAliquotEnd(t *testing.T) {
	end = today.Add(day * 4)

	dates := getRatesTimestamp(today, end, 2)

	if len(dates) != 2 {
		t.Error("wrong dates size: ", len(dates))

		return
	}

	if !dates[0].Equal(today.Add(day * 2)) {
		t.Errorf("date is wrong %v, %v expected", dates[0], today.Add(day*2))
	}

	if !dates[1].Equal(today.Add(day * 4)) {
		t.Errorf("date is wrong %v, %v expected", dates[1], today.Add(day*4))
	}
}
