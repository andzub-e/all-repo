package services

import (
	"context"
	"exchange/internal/entities"
	"exchange/internal/repositories"
	"exchange/pkg/xe"
	"fmt"
	"github.com/samber/lo"
	"sort"
	"time"
)

var MainCurrencies = []string{"usd", "eur"}

type CurrencyService struct {
	currencyRepo repositories.CurrencyRepository
	xeClient     *xe.Client
}

func NewCurrencyService(currencyRepo repositories.CurrencyRepository, xeClient *xe.Client) *CurrencyService {
	return &CurrencyService{currencyRepo: currencyRepo, xeClient: xeClient}
}

func (s *CurrencyService) GetRates(ctx context.Context,
	from string, to []string, start, end time.Time) (entities.ExchangeBag, error) {
	to = lo.Uniq(to)

	rates, err := s.currencyRepo.GetRates(ctx, from, to, start, end)
	if err != nil {
		return nil, err
	}

	bag := entities.ExchangeBag{}

	for _, rate := range rates {
		bag[entities.ExchangeKey{From: rate.From, To: rate.To}] =
			append(bag[entities.ExchangeKey{From: rate.From, To: rate.To}],
				entities.ExchangeValue{Rate: rate.Rate, CreatedAt: rate.CreatedAt})
	}

	for key := range bag {
		toSort := bag[key]

		sort.Slice(toSort, func(i, j int) bool {
			return toSort[i].CreatedAt.Before(toSort[j].CreatedAt)
		})

		if bag[key][0].CreatedAt.After(start) {
			return nil, fmt.Errorf("have no rate for %v", start)
		}
	}

	return bag, nil
}

func (s *CurrencyService) ParseIfNeeded(ctx context.Context) error {
	t, isFound, err := s.currencyRepo.GetLastDate(ctx)
	if err != nil {
		return err
	}

	day := time.Hour * 24
	today := time.Now().Truncate(day)

	if !isFound {
		t = time.Time{}
	}

	datesToParse := getRatesTimestamp(t, today, 2)

	to, err := s.xeClient.GetCurrencies(ctx)
	if err != nil {
		return err
	}

	buf := []entities.ExchangeRate{}

	for _, d := range datesToParse {
		for _, from := range MainCurrencies {
			res, err := s.xeClient.GetRates(ctx, from, to, d)
			if err != nil {
				return err
			}

			lo.ForEach(res.To, func(item xe.Rate, index int) {
				buf = append(buf, entities.ExchangeRate{
					CreatedAt: res.Date,
					From:      res.From,
					To:        item.Title,
					Rate:      item.Rate,
				})
			})
		}
	}

	if len(buf) > 0 {
		return s.currencyRepo.Save(ctx, buf)
	}

	return nil
}

func getRatesTimestamp(start, end time.Time, daysStep int) []time.Time {
	dates := []time.Time{}

	day := time.Hour * 24
	step := day * time.Duration(daysStep)

	if start.IsZero() {
		dates = append(dates, time.Now().Truncate(day))
	} else {
		for start = start.Add(step); start.Before(end) || start.Equal(end); start = start.Add(step) {
			dates = append(dates, start)
		}
	}

	return dates
}
