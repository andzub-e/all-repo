package repositories

import (
	"context"
	"exchange/internal/entities"
	"time"
)

type CurrencyRepository interface {
	GetLastDate(ctx context.Context) (time.Time, bool, error)
	Save(ctx context.Context, rates []entities.ExchangeRate) error
	GetRates(ctx context.Context, from string, to []string, start, end time.Time) ([]entities.ExchangeRate, error)
}
