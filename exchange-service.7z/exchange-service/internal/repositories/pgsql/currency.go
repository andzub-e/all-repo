package pgsql

import (
	"context"
	"errors"
	"exchange/internal/entities"
	"gorm.io/gorm"
	"time"
)

func NewCurrencyRepository(conn *gorm.DB) *currencyRepository {
	return &currencyRepository{conn: conn}
}

type currencyRepository struct {
	conn *gorm.DB
}

func (c *currencyRepository) GetRates(ctx context.Context,
	from string, to []string, start, end time.Time) ([]entities.ExchangeRate, error) {
	items := []entities.ExchangeRate{}

	conn := c.conn.WithContext(ctx)
	req := conn.Raw("? UNION (?)",
		conn.
			Model(&entities.ExchangeRate{}).
			Select("created_at, from_currency, to_currency, rate").
			Where("from_currency = ? and to_currency in (?) and created_at > ? and created_at <= ?", from, to, start, end),
		conn.
			Model(&entities.ExchangeRate{}).
			Select("distinct on (to_currency) created_at, from_currency, to_currency, rate").
			Where("from_currency = ? and to_currency in (?) and created_at < ?", from, to, start).
			Order("to_currency, created_at desc"),
	).Order("to_currency, created_at desc")

	err := req.Scan(&items).Error

	return items, err
}

func (c *currencyRepository) Save(ctx context.Context, rates []entities.ExchangeRate) error {
	return c.conn.WithContext(ctx).Create(rates).Error
}

func (c *currencyRepository) GetLastDate(ctx context.Context) (time.Time, bool, error) {
	last := &entities.ExchangeRate{}
	err := c.conn.WithContext(ctx).Order("created_at desc").First(&last).Error

	if errors.Is(err, gorm.ErrRecordNotFound) {
		return time.Time{}, false, nil
	}

	if err != nil {
		return time.Time{}, false, err
	}

	return last.CreatedAt, true, nil
}
