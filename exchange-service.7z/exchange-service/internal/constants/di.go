package constants

const (
	ConfigName     = "Config"
	LoggerName     = "Logger"
	HTTPServerName = "HTTPServer"
	RPCServerName  = "RPCServer"
	TracerName     = "Tracer"
	XEName         = "XE"
	SchedulerName  = "Scheduler"
	ValidatorName  = "Validator"

	PgSQLConnectionName = "PgSQL"

	MetaHTTPHandlerName = "MetaHTTPHandler"

	CurrencyRepositoryName = "CurrencyRepository"

	CurrencyServiceName = "CurrencyService"

	CurrencyJobName = "CurrencyJob"
)
