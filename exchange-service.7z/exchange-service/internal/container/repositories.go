package container

import (
	"exchange/internal/constants"
	"exchange/internal/repositories/pgsql"
	"github.com/sarulabs/di"
	"gorm.io/gorm"
)

func BuildRepositories() []di.Def {
	return []di.Def{
		{
			Name: constants.CurrencyRepositoryName,
			Build: func(ctn di.Container) (interface{}, error) {
				conn := ctn.Get(constants.PgSQLConnectionName).(*gorm.DB)

				return pgsql.NewCurrencyRepository(conn), nil
			},
		},
	}
}
