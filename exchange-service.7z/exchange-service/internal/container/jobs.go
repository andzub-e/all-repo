package container

import (
	"exchange/internal/constants"
	"exchange/internal/services"
	"exchange/internal/transport/cron/jobs"
	"github.com/sarulabs/di"
)

func BuildJobs() []di.Def {
	return []di.Def{
		{
			Name: constants.CurrencyJobName,
			Build: func(ctn di.Container) (interface{}, error) {
				currencyService := ctn.Get(constants.CurrencyServiceName).(*services.CurrencyService)

				return jobs.NewCurrencyJob(currencyService), nil
			},
		},
	}
}
