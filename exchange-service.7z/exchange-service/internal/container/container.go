package container

import (
	"context"
	"exchange/internal/config"
	"exchange/internal/constants"
	"exchange/internal/services"
	"exchange/internal/transport/cron"
	"exchange/internal/transport/http"
	"exchange/internal/transport/rpc"
	"exchange/pkg/pgsql"
	"exchange/pkg/tracer"
	"exchange/pkg/xe"
	"fmt"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
	"strings"
	"sync"
)

var container di.Container
var once sync.Once

func Build(ctx context.Context) di.Container {
	once.Do(func() {
		builder, _ := di.NewBuilder()
		defs := []di.Def{
			{
				Name: constants.LoggerName,
				Build: func(ctn di.Container) (interface{}, error) {
					logger, err := zap.NewProduction()
					if err != nil {
						return nil, fmt.Errorf("can't initialize zap logger: %v", err)
					}

					zap.ReplaceGlobals(logger)

					return logger, nil
				},
			},
			{
				Name: constants.ConfigName,
				Build: func(ctn di.Container) (interface{}, error) {
					return config.New()
				},
			},
			{
				Name: constants.PgSQLConnectionName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return pgsql.NewPgsqlConnection(cfg.PgSQLConfig)
				},
			},
			{
				Name: constants.TracerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return tracer.NewTracer(cfg.TracerConfig)
				},
			},
			{
				Name: constants.SchedulerName,
				Build: func(ctn di.Container) (interface{}, error) {
					jobs := []cron.Job{
						ctn.Get(constants.CurrencyJobName).(cron.Job),
					}

					return cron.NewScheduler(jobs...)
				},
			},
			{
				Name: constants.XEName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return xe.NewClient(cfg.XEConfig, strings.ToLower), nil
				},
			},
			{
				Name: constants.HTTPServerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)
					handlers := []http.Handler{
						ctn.Get(constants.MetaHTTPHandlerName).(http.Handler),
					}

					return http.New(ctx, cfg.HTTPConfig, handlers), nil
				},
				Close: func(obj interface{}) error {
					if err := obj.(*http.Server).Shutdown(); err != nil {
						zap.S().Errorf("Error stopping server: %s", err)

						return err
					}

					return nil
				},
			},
			{
				Name: constants.RPCServerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)
					currencyService := ctn.Get(constants.CurrencyServiceName).(*services.CurrencyService)

					return rpc.NewHandler(cfg.RPCConfig, currencyService), nil
				},
			},
		}

		defs = append(defs, BuildRepositories()...)
		defs = append(defs, BuildServices()...)
		defs = append(defs, BuildHandlers()...)
		defs = append(defs, BuildJobs()...)

		if err := builder.Add(defs...); err != nil {
			panic(err)
		}

		container = builder.Build()
	})

	return container
}
