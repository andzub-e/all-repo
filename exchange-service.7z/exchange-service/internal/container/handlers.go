package container

import (
	"exchange/internal/constants"
	"exchange/internal/transport/http/handlers"
	"github.com/sarulabs/di"
)

func BuildHandlers() []di.Def {
	return []di.Def{
		{
			Name: constants.MetaHTTPHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				return handlers.NewMetaHandler(), nil
			},
		},
	}
}
