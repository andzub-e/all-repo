package container

import (
	"exchange/internal/constants"
	"exchange/internal/repositories"
	"exchange/internal/services"
	"exchange/pkg/xe"
	"github.com/sarulabs/di"
)

func BuildServices() []di.Def {
	return []di.Def{
		{
			Name: constants.CurrencyServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				currencyRepo := ctn.Get(constants.CurrencyRepositoryName).(repositories.CurrencyRepository)
				xeClient := ctn.Get(constants.XEName).(*xe.Client)

				return services.NewCurrencyService(currencyRepo, xeClient), nil
			},
		},
	}
}
