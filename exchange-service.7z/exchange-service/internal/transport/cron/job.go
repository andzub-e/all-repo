package cron

import "time"

type Job interface {
	Do()
	Period() time.Duration
}
