package jobs

import (
	"context"
	"exchange/internal/services"
	"go.uber.org/zap"
	"time"
)

type currencyJob struct {
	currencyService *services.CurrencyService
}

func NewCurrencyJob(currencyService *services.CurrencyService) *currencyJob {
	return &currencyJob{currencyService: currencyService}
}

func (c *currencyJob) Do() {
	zap.S().Info("Parsing")

	if err := c.currencyService.ParseIfNeeded(context.Background()); err != nil {
		zap.S().Error(err)
	}
}

func (c currencyJob) Period() time.Duration {
	return time.Minute * 30
}
