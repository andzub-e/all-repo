package cron

import (
	"github.com/go-co-op/gocron"
	"time"
)

type Scheduler struct {
	s *gocron.Scheduler
}

func NewScheduler(jobs ...Job) (*Scheduler, error) {
	s := &Scheduler{s: gocron.NewScheduler(time.UTC)}

	for _, j := range jobs {
		_, err := s.s.Every(j.Period()).Do(j.Do)

		if err != nil {
			return nil, err
		}
	}

	return s, nil
}

func (s *Scheduler) StartAsync() {
	s.s.StartAsync()
}
