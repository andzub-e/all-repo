package handlers

import (
	"exchange/internal/transport/http"
	"github.com/gofiber/fiber/v2"
)

var tag = "no tag"

type metaHandler struct {
}

type InfoResponse struct {
	Tag    string   `json:"tag"`
	IP     string   `json:"ip"`
	IPs    []string `json:"ips"`
	Header string   `json:"header"`
}

func NewMetaHandler() *metaHandler {
	return &metaHandler{}
}

func (h *metaHandler) Register(router fiber.Router) {
	router.Get("health", h.health)
	router.Get("info", h.info)
}

func (h *metaHandler) health(ctx *fiber.Ctx) error {
	return ctx.SendStatus(fiber.StatusOK)
}

func (h *metaHandler) info(ctx *fiber.Ctx) error {
	return http.OK(ctx, InfoResponse{
		Tag:    tag,
		IP:     ctx.IP(),
		IPs:    ctx.IPs(),
		Header: string(ctx.Request().Header.Header()),
	}, nil)
}
