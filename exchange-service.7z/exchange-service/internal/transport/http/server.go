package http

import (
	"context"
	"fmt"
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/recover"
	"go.uber.org/zap"
)

type Server struct {
	ctx    context.Context
	cfg    *Config
	router *fiber.App
}

func New(ctx context.Context, cfg *Config, handlers []Handler) *Server {
	s := &Server{
		ctx: ctx,
		cfg: cfg,
		router: fiber.New(fiber.Config{
			ReadTimeout:       cfg.ReadTimeout,
			WriteTimeout:      cfg.WriteTimeout,
			AppName:           "[Go] History Service",
			EnablePrintRoutes: true,
		}),
	}

	s.router.Use(recover.New(recover.Config{
		EnableStackTrace: true,
		StackTraceHandler: func(ctx *fiber.Ctx, e interface{}) {
			zap.S().Error(e)
		},
	}))

	s.router.Use(cors.New(cors.ConfigDefault))
	s.registerHandlers(s.router, handlers...)

	return s
}

func (s *Server) registerHandlers(api fiber.Router, handlers ...Handler) {
	for _, h := range handlers {
		h.Register(api)
	}
}

func (s *Server) Run() {
	if err := s.router.Listen(fmt.Sprintf("%s:%d", s.cfg.Host, s.cfg.Port)); err != nil {
		zap.S().Fatal(err.Error())
	}
}

func (s *Server) Shutdown() error {
	zap.S().Info("Shutdown server...")

	defer func() {
		zap.S().Info("Server successfully stopped.")
	}()

	if err := s.router.ShutdownWithContext(s.ctx); err != nil {
		zap.S().Error("Server forced to shutdown:", zap.Error(err))

		return err
	}

	return nil
}
