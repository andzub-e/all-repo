package rpc

import (
	"bytes"
	"exchange/pkg/validator"
)

type ValidationError struct {
	ErrorsBug []validator.TaggedError
}

func NewValidationError(errFromValidator error) ValidationError {
	return ValidationError{
		ErrorsBug: validator.CheckValidationErrors(errFromValidator),
	}
}

func (v ValidationError) Error() string {
	buf := bytes.Buffer{}

	for i, err := range v.ErrorsBug {
		buf.WriteString(err.Err.Error())

		if i != len(v.ErrorsBug)-1 {
			buf.WriteString("\n")
		}
	}

	return buf.String()
}
