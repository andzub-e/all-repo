package rpc

import (
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

func WrapInGRPCError(err error) error {
	validationErr, ok := err.(ValidationError)
	if ok {
		return status.Error(codes.InvalidArgument, validationErr.Error())
	}

	return status.Error(codes.Internal, err.Error())
}
