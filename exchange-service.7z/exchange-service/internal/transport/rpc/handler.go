package rpc

import (
	"context"
	"exchange/internal/entities"
	"exchange/internal/services"
	"exchange/pkg/exchange"
	"github.com/samber/lo"
	"google.golang.org/protobuf/types/known/timestamppb"
	"io"
)

type Handler struct {
	cfg             *Config
	currencyService *services.CurrencyService
}

func NewHandler(cfg *Config, currencyService *services.CurrencyService) *Handler {
	return &Handler{
		cfg:             cfg,
		currencyService: currencyService,
	}
}

func (h Handler) GetRates(ctx context.Context, in *exchange.RatesIn) (*exchange.RatesOut, error) {
	out, err := h.currencyService.GetRates(ctx, in.From, in.To, in.Start.AsTime(), in.End.AsTime())
	if err != nil {
		return nil, err
	}

	return &exchange.RatesOut{
		Bag: lo.MapEntries(out, func(key entities.ExchangeKey, value []entities.ExchangeValue) (string, *exchange.RateItems) {
			return key.From + "->" + key.To,
				&exchange.RateItems{Items: lo.Map(value, func(item entities.ExchangeValue, index int) *exchange.RateItem {
					return &exchange.RateItem{Rate: item.Rate, Date: timestamppb.New(item.CreatedAt)}
				})}
		})}, nil
}

func (h Handler) HealthCheck(stream exchange.ExchangeService_HealthCheckServer) error {
	for {
		msg, err := stream.Recv()
		if err != nil {
			if err == io.EOF {
				return nil
			}

			return err
		}

		if err = stream.Send(msg); err != nil {
			if err == io.EOF {
				return nil
			}

			return err
		}
	}
}
