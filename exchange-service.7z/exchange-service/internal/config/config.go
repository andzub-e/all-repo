package config

import (
	"exchange/internal/transport/http"
	"exchange/internal/transport/rpc"
	"exchange/pkg/pgsql"
	"exchange/pkg/tracer"
	"exchange/pkg/xe"
	"fmt"
	"github.com/spf13/viper"
	"sync"
)

var (
	err    error
	config *Config
	once   sync.Once
)

type Config struct {
	HTTPConfig   *http.Config
	RPCConfig    *rpc.Config
	PgSQLConfig  *pgsql.Config
	TracerConfig *tracer.Config
	XEConfig     *xe.Config
}

func New() (*Config, error) {
	once.Do(func() {
		config = &Config{}

		viper.AddConfigPath(".")
		viper.SetConfigName("config")

		if err = viper.ReadInConfig(); err != nil {
			return
		}

		httpConfig := viper.Sub("server")
		rpcConfig := viper.Sub("rpc")
		databaseConfig := viper.Sub("database")
		tracerConfig := viper.Sub("tracer")
		xeConfig := viper.Sub("xe")

		if err = parseSubConfig(httpConfig, &config.HTTPConfig); err != nil {
			return
		}

		if err = parseSubConfig(rpcConfig, &config.RPCConfig); err != nil {
			return
		}

		if err = parseSubConfig(databaseConfig, &config.PgSQLConfig); err != nil {
			return
		}

		if tracerConfig != nil {
			if err := tracerConfig.Unmarshal(&config.TracerConfig); err != nil {
				panic(err)
			}
		} else {
			config.TracerConfig = &tracer.Config{Disabled: true}
		}

		if err = parseSubConfig(xeConfig, &config.XEConfig); err != nil {
			return
		}
	})

	return config, err
}

func parseSubConfig[T any](subConfig *viper.Viper, parseTo *T) error {
	if subConfig == nil {
		return fmt.Errorf("can not read %T config: subconfig is nil", parseTo)
	}

	if err := subConfig.Unmarshal(parseTo); err != nil {
		return err
	}

	return nil
}
