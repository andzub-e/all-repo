package models

type ReelSymbol string

// returns true if the given symbol is a IsWild
func (symbol ReelSymbol) IsWild() bool {
	return symbol == "W"
}

// returns true if the given symbol is a IsScatter
func (symbol ReelSymbol) IsScatter() bool {
	return symbol == "F"
}

// returns true if the given symbol is a IsForDestroy
func (symbol ReelSymbol) IsForDestroy() bool {
	return symbol == "-"
}
