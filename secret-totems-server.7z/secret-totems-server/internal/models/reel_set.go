package models

import (
	"fmt"

	"secret-totems/internal/models/constants"
)

type Reel []ReelSymbol
type ReelSet [constants.ReelCount]Reel

var BaseReels = ReelSet{
	Reel{"D", "X", "D", "X", "X", "Y", "D", "Y", "F", "A", "Y", "B", "Y", "C", "X", "Z", "Z", "D", "F", "Y", "Y", "C", "Z", "Z", "D", "X", "Y", "D", "Z", "Y", "X", "C", "F", "Y", "Y", "X", "C", "D", "C", "Y", "Y", "Z", "D", "B", "A", "B", "C", "B", "Y", "D", "X", "Z", "X", "Y", "Z", "X", "X", "A", "D", "Y", "B", "Y", "Z", "Z", "Z", "D", "X", "Z", "Y", "X", "Z", "C", "Y", "Z", "Y", "X", "Z", "D", "C", "Y", "C", "Y", "Z", "X", "Y", "D", "F", "Y", "Y", "Z", "B", "B", "Z", "B", "C", "Y", "C", "B", "Y", "D", "X", "X", "X", "X", "F", "Z", "C", "D", "Z", "Y", "D", "Z", "Y", "Z", "A", "X", "Z", "Z", "Z", "C", "Z", "Z", "W", "Z", "Y", "X", "D", "X", "F", "D", "F", "X", "B", "Y", "C", "Z", "Y", "B", "Y", "F", "A", "Y", "Y", "C", "Z", "D", "D", "Y", "Z", "Y", "D", "D", "Y", "X", "Y", "Z", "F", "C", "D", "Y", "F", "A", "B", "B", "D", "D", "Y", "Z", "X", "C", "Y", "Y", "D", "C", "C", "D", "W", "C", "Y", "Z", "X", "D", "B", "Z", "Z", "D", "Y", "Z", "Y", "C", "Y", "B", "Z", "X", "X", "B", "A", "Z", "C", "Y"},
	Reel{"Z", "X", "Y", "Z", "Z", "X", "Y", "X", "Z", "Z", "X", "Z", "Z", "Y", "Y", "Z", "B", "X", "C", "A", "A", "D", "Y", "Y", "C", "Z", "C", "F", "F", "Y", "F", "X", "C", "D", "Y", "Z", "Z", "D", "X", "B", "Z", "C", "Z", "Y", "Z", "Y", "A", "Z", "Y", "Z", "F", "Y", "B", "F", "Y", "A", "Y", "Z", "F", "D", "Y", "X", "Y", "D", "C", "D", "Y", "Z", "D", "Y", "D", "Y", "X", "Y", "B", "Y", "F", "C", "Y", "D", "X", "D", "C", "X", "Z", "Y", "X", "Z", "Z", "D", "X", "X", "F", "F", "F", "D", "D", "Z", "Z", "X", "Y", "D", "Y", "D", "X", "Z", "C", "Y", "Z", "C", "B", "Z", "F", "X", "Z", "F", "C", "D", "X", "Z", "Z", "X", "Z", "Z", "D", "Z", "C", "X", "Z", "B", "Y", "X", "C", "X", "C", "X", "B", "Y", "C", "Z", "Z", "Z", "B", "F", "D", "A", "Y", "Z", "Y", "D", "Z", "B", "A", "Y", "Y", "Y", "Z", "Y", "F", "B", "D", "Y", "F", "Y", "Y", "Y", "Z", "Y", "B", "D", "C", "A", "C", "F", "Z", "Y", "Y", "Z", "D", "Z", "X", "Y", "Z", "C", "A", "Z", "D", "A", "B", "B", "A", "X", "X", "X", "D", "Y", "Z", "D", "D", "D"},
	Reel{"C", "B", "D", "B", "X", "B", "F", "Y", "B", "F", "Y", "A", "F", "Y", "W", "X", "Z", "X", "W", "Y", "X", "Z", "Y", "Z", "D", "Y", "Z", "Y", "X", "Y", "B", "D", "D", "Y", "X", "Y", "C", "D", "F", "Z", "D", "D", "X", "D", "W", "Z", "C", "W", "Z", "Z", "Y", "X", "X", "D", "X", "Y", "A", "Y", "F", "Z", "Y", "A", "Z", "C", "X", "W", "Y", "C", "C", "Z", "Y", "B", "X", "X", "X", "X", "Y", "Z", "Y", "D", "D", "B", "Z", "C", "F", "Z", "D", "C", "D", "D", "Y", "Y", "B", "Z", "X", "Z", "X", "F", "C", "Z", "D", "Z", "C", "Z", "B", "D", "Z", "D", "C", "F", "Z", "Y", "Y", "X", "C", "D", "X", "D", "X", "Z", "D", "F", "D", "Y", "D", "D", "W", "X", "Z", "B", "A", "D", "X", "W", "X", "C", "Z", "Y", "Y", "B", "Y", "Z", "B", "Z", "B", "Y", "F", "Z", "Z", "B", "Z", "Y", "Z", "D", "C", "Z", "C", "X", "B", "Z", "Z", "B", "Y", "Z", "X", "X", "D", "X", "C", "Y", "X", "X", "D", "X", "Z", "D", "D", "D", "X", "Y", "Y", "X", "Z", "Y", "D", "Z", "D", "X", "D", "B", "X", "D", "F", "Z", "Z", "Y", "D", "C", "Y", "C"},
	Reel{"D", "Y", "X", "Y", "X", "Z", "Z", "B", "Y", "C", "Y", "B", "Y", "W", "D", "A", "D", "D", "D", "C", "Z", "C", "C", "C", "D", "A", "C", "X", "X", "W", "X", "D", "X", "X", "D", "C", "Y", "B", "Y", "Z", "C", "Y", "Y", "Y", "Z", "C", "Y", "X", "Z", "X", "B", "Z", "Y", "Y", "Y", "X", "D", "A", "Y", "B", "X", "C", "B", "X", "D", "X", "Z", "Y", "Z", "Z", "Z", "X", "Z", "D", "W", "Y", "X", "B", "Z", "Y", "Z", "Y", "Y", "W", "Y", "Z", "Z", "A", "X", "X", "Z", "Y", "X", "B", "Y", "Y", "Y", "Y", "D", "D", "Z", "Z", "Z", "Z", "Z", "Z", "Z", "Z", "D", "Z", "Y", "B", "D", "D", "D", "A", "Y", "C", "Y", "Z", "D", "Z", "X", "X", "X", "Y", "X", "B", "X", "A", "B", "Z", "B", "X", "D", "Y", "Y", "C", "X", "Y", "D", "Z", "C", "Y", "B", "Y", "A", "C", "Y", "X", "W", "B", "Z", "Z", "Y", "A", "C", "C", "A", "Z", "B", "Z", "C", "X", "C", "D", "B", "Y", "D", "Z", "Z", "Y", "B", "C", "Y", "B", "C", "Y", "D", "Z", "Y", "Y", "Y", "D", "X", "Z", "B", "D", "Y", "X", "Z", "Z", "D", "D", "Y", "W", "B", "Z", "D", "Z"},
	Reel{"Z", "X", "Z", "Y", "Y", "X", "Y", "X", "X", "Y", "Y", "Z", "Y", "A", "C", "B", "X", "Y", "D", "Z", "D", "Y", "X", "C", "Z", "Y", "Z", "D", "C", "A", "Z", "X", "D", "A", "A", "Z", "Y", "C", "Y", "Y", "Z", "Z", "D", "C", "Z", "Z", "Z", "X", "X", "Z", "D", "D", "Y", "Z", "C", "A", "C", "Z", "D", "Z", "Y", "D", "D", "Z", "Z", "X", "Y", "Z", "Y", "C", "Z", "C", "Y", "D", "D", "B", "Y", "D", "Y", "Z", "Y", "Z", "Z", "D", "X", "Y", "Y", "X", "X", "Z", "A", "A", "Z", "Z", "A", "Z", "Z", "D", "Y", "C", "Y", "X", "Z", "Z", "Z", "X", "Z", "D", "A", "C", "X", "Y", "Z", "Z", "Z", "D", "B", "D", "Y", "Y", "W", "A", "D", "X", "D", "Z", "Y", "D", "X", "B", "Z", "X", "X", "Y", "X", "A", "Z", "Z", "Z", "X", "D", "Y", "C", "B", "D", "C", "C", "B", "D", "A", "Y", "A", "Y", "X", "Y", "Y", "D", "D", "Y", "A", "Y", "D", "B", "Y", "Y", "Y", "Z", "X", "C", "Y", "X", "D", "D", "Y", "D", "Y", "Y", "Y", "D", "Y", "Z", "Y", "Z", "Y", "Z", "Z", "X", "A", "B", "D", "Z", "Y", "X", "D", "D", "C", "W", "X", "X", "Z"},
}

var BonusReels = ReelSet{
	Reel{"D", "X", "D", "X", "X", "Y", "D", "Y", "F", "A", "Y", "B", "Y", "C", "X", "Z", "Z", "D", "F", "Y", "Y", "C", "Z", "Z", "D", "X", "Y", "D", "Z", "Y", "X", "C", "F", "Y", "Y", "X", "C", "D", "C", "Y", "Y", "Z", "D", "B", "A", "B", "C", "B", "Y", "D", "X", "Z", "X", "Y", "Z", "X", "X", "A", "D", "Y", "B", "Y", "Z", "Z", "Z", "D", "X", "Z", "Y", "X", "Z", "C", "Y", "Z", "Y", "X", "Z", "D", "C", "Y", "C", "Y", "Z", "X", "Y", "D", "F", "Y", "Y", "Z", "B", "B", "Z", "B", "C", "Y", "C", "B", "Y", "D", "X", "X", "X", "X", "F", "Z", "C", "D", "Z", "Y", "D", "Z", "Y", "Z", "A", "X", "Z", "Z", "Z", "C", "Z", "Z", "W", "Z", "Y", "X", "D", "X", "F", "D", "F", "X", "B", "Y", "C", "Z", "Y", "B", "Y", "F", "A", "Y", "Y", "C", "Z", "D", "D", "Y", "Z", "Y", "D", "D", "Y", "X", "Y", "Z", "F", "C", "D", "Y", "F", "A", "B", "B", "D", "D", "Y", "Z", "X", "C", "Y", "Y", "D", "C", "C", "D", "W", "C", "Y", "Z", "X", "D", "B", "Z", "Z", "D", "Y", "Z", "Y", "C", "Y", "B", "Z", "X", "X", "B", "A", "Z", "C", "Y"},
	Reel{"Z", "X", "Y", "Z", "Z", "X", "Y", "X", "Z", "Z", "X", "Z", "Z", "Y", "Y", "Z", "B", "X", "C", "A", "A", "D", "Y", "Y", "C", "Z", "C", "F", "F", "Y", "F", "X", "C", "D", "Y", "Z", "Z", "D", "X", "B", "Z", "C", "Z", "Y", "Z", "Y", "A", "Z", "Y", "Z", "F", "Y", "B", "F", "Y", "A", "Y", "Z", "F", "D", "Y", "X", "Y", "D", "C", "D", "Y", "Z", "D", "Y", "D", "Y", "X", "Y", "B", "Y", "F", "C", "Y", "D", "X", "D", "C", "X", "Z", "Y", "X", "Z", "Z", "D", "X", "X", "F", "F", "F", "D", "D", "Z", "Z", "X", "Y", "D", "Y", "D", "X", "Z", "C", "Y", "Z", "C", "B", "Z", "F", "X", "Z", "F", "C", "D", "X", "Z", "Z", "X", "Z", "Z", "D", "Z", "C", "X", "Z", "B", "Y", "X", "C", "X", "C", "X", "B", "Y", "C", "Z", "Z", "Z", "B", "F", "D", "A", "Y", "Z", "Y", "D", "Z", "B", "A", "Y", "Y", "Y", "Z", "Y", "F", "B", "D", "Y", "F", "Y", "Y", "Y", "Z", "Y", "B", "D", "C", "A", "C", "F", "Z", "Y", "Y", "Z", "D", "Z", "X", "Y", "Z", "C", "A", "Z", "D", "A", "B", "B", "A", "X", "X", "X", "D", "Y", "Z", "D", "D", "D"},
	Reel{"C", "B", "D", "B", "X", "B", "F", "Y", "B", "F", "Y", "A", "F", "Y", "W", "X", "Z", "X", "W", "Y", "X", "Z", "Y", "Z", "D", "Y", "Z", "Y", "X", "Y", "B", "D", "D", "Y", "X", "Y", "C", "D", "F", "Z", "D", "D", "X", "D", "W", "Z", "C", "W", "Z", "Z", "Y", "X", "X", "D", "X", "Y", "A", "Y", "F", "Z", "Y", "A", "Z", "C", "X", "W", "Y", "C", "C", "Z", "Y", "B", "X", "X", "X", "X", "Y", "Z", "Y", "D", "D", "B", "Z", "C", "F", "Z", "D", "C", "D", "D", "Y", "Y", "B", "Z", "X", "Z", "X", "F", "C", "Z", "D", "Z", "C", "Z", "B", "D", "Z", "D", "C", "F", "Z", "Y", "Y", "X", "C", "D", "X", "D", "X", "Z", "D", "F", "D", "Y", "D", "D", "W", "X", "Z", "B", "A", "D", "X", "W", "X", "C", "Z", "Y", "Y", "B", "Y", "Z", "B", "Z", "B", "Y", "F", "Z", "Z", "B", "Z", "Y", "Z", "D", "C", "Z", "C", "X", "B", "Z", "Z", "B", "Y", "Z", "X", "X", "D", "X", "C", "Y", "X", "X", "D", "X", "Z", "D", "D", "D", "X", "Y", "Y", "X", "Z", "Y", "D", "Z", "D", "X", "D", "B", "X", "D", "F", "Z", "Z", "Y", "D", "C", "Y", "C"},
	Reel{"D", "Y", "X", "Y", "X", "Z", "Z", "B", "Y", "C", "Y", "B", "Y", "W", "D", "A", "D", "D", "D", "C", "Z", "C", "C", "C", "D", "A", "C", "X", "X", "W", "X", "D", "X", "X", "D", "C", "Y", "B", "Y", "Z", "C", "Y", "Y", "Y", "Z", "C", "Y", "X", "Z", "X", "B", "Z", "Y", "Y", "Y", "X", "D", "A", "Y", "B", "X", "C", "B", "X", "D", "X", "Z", "Y", "Z", "Z", "Z", "X", "Z", "D", "W", "Y", "X", "B", "Z", "Y", "Z", "Y", "Y", "W", "Y", "Z", "Z", "A", "X", "X", "Z", "Y", "X", "B", "Y", "Y", "Y", "Y", "D", "D", "Z", "Z", "Z", "Z", "Z", "Z", "Z", "Z", "D", "Z", "Y", "B", "D", "D", "D", "A", "Y", "C", "Y", "Z", "D", "Z", "X", "X", "X", "Y", "X", "B", "X", "A", "B", "Z", "B", "X", "D", "Y", "Y", "C", "X", "Y", "D", "Z", "C", "Y", "B", "Y", "A", "C", "Y", "X", "W", "B", "Z", "Z", "Y", "A", "C", "C", "A", "Z", "B", "Z", "C", "X", "C", "D", "B", "Y", "D", "Z", "Z", "Y", "B", "C", "Y", "B", "C", "Y", "D", "Z", "Y", "Y", "Y", "D", "X", "Z", "B", "D", "Y", "X", "Z", "Z", "D", "D", "Y", "W", "B", "Z", "D", "Z"},
	Reel{"Z", "X", "Z", "Y", "Y", "X", "Y", "X", "X", "Y", "Y", "Z", "Y", "A", "C", "B", "X", "Y", "D", "Z", "D", "Y", "X", "C", "Z", "Y", "Z", "D", "C", "A", "Z", "X", "D", "A", "A", "Z", "Y", "C", "Y", "Y", "Z", "Z", "D", "C", "Z", "Z", "Z", "X", "X", "Z", "D", "D", "Y", "Z", "C", "A", "C", "Z", "D", "Z", "Y", "D", "D", "Z", "Z", "X", "Y", "Z", "Y", "C", "Z", "C", "Y", "D", "D", "B", "Y", "D", "Y", "Z", "Y", "Z", "Z", "D", "X", "Y", "Y", "X", "X", "Z", "A", "A", "Z", "Z", "A", "Z", "Z", "D", "Y", "C", "Y", "X", "Z", "Z", "Z", "X", "Z", "D", "A", "C", "X", "Y", "Z", "Z", "Z", "D", "B", "D", "Y", "Y", "W", "A", "D", "X", "D", "Z", "Y", "D", "X", "B", "Z", "X", "X", "Y", "X", "A", "Z", "Z", "Z", "X", "D", "Y", "C", "B", "D", "C", "C", "B", "D", "A", "Y", "A", "Y", "X", "Y", "Y", "D", "D", "Y", "A", "Y", "D", "B", "Y", "Y", "Y", "Z", "X", "C", "Y", "X", "D", "D", "Y", "D", "Y", "Y", "Y", "D", "Y", "Z", "Y", "Z", "Y", "Z", "Z", "X", "A", "B", "D", "Z", "Y", "X", "D", "D", "C", "W", "X", "X", "Z"},
}

// GetRawSymbol - return symbol from window by position
func (r *ReelSet) GetRawSymbol(reelID int, rowID int, stopID ReelStop, reelSize int) ReelSymbol {

	return r[reelID][(rowID+int(stopID))%(reelSize)]
}

// DestroyFields - return new stops after applying destroyMask
func (r *ReelSet) DestroyFields(reelStops ReelStops, destroyMask DestroyMask) ReelStops {
	// mark symbols for destroy
	for reelID := 0; reelID < constants.ReelCount; reelID++ {
		for rowID := 0; rowID < constants.WindowHeight; rowID++ {
			if destroyMask[reelID][rowID] {
				reelLine := r[reelID]
				reelSize := len(reelLine)
				reelSymbolID := (rowID + int(reelStops[reelID])) % (reelSize)
				r[reelID][reelSymbolID] = "-"
			}
		}
	}

	//fmt.Println("=====Stage====")
	//r.Debug(reelStops)
	/////
	//fmt.Println("=====Start====")
	//fmt.Println(reelStops)
	//fmt.Println(len(r[1]))
	////
	// destroy marked symbols
	for reelID := 0; reelID < constants.ReelCount; reelID++ {
		reelSize := len(r[reelID])
		for rowID := 0; rowID < reelSize; rowID++ {
			if r[reelID][rowID].IsForDestroy() {

				r[reelID] = append(r[reelID][:rowID], r[reelID][rowID+1:]...)

				if rowID < int(reelStops[reelID]) { // after cutting our reel in start - our high stops coming down
					reelStops[reelID] -= 1
				}

				if reelStops[reelID] == 0 {
					reelStops[reelID] = ReelStop(len(r[reelID]) - 1)
				} else {
					reelStops[reelID] -= 1
				}

				// check again
				reelID--
				break
			}
		}
	}
	/////
	//fmt.Println(reelStops)
	//fmt.Println(len(r[1]))
	//fmt.Println("=====END====")
	////

	return reelStops
}

func (r *ReelSet) Debug(reelStops ReelStops) {
	for rowID := 0; rowID < constants.WindowHeight; rowID++ {
		for reelID := 0; reelID < constants.ReelCount; reelID++ {
			reelLine := r[reelID]
			reelSize := len(reelLine)
			reelSymbolID := (rowID + int(reelStops[reelID])) % (reelSize)
			fmt.Printf("%v ", r[reelID][reelSymbolID])
		}
		fmt.Printf("\n")
	}
	fmt.Printf("\n")
}

// GetDuplicate - copy existed reelSet and return it without pointers
func (r *ReelSet) GetDuplicate() (newReelSet ReelSet) {
	for reelID := 0; reelID < constants.ReelCount; reelID++ {
		reelSize := len(r[reelID])
		newReelSet[reelID] = Reel{}
		for rowID := 0; rowID < reelSize; rowID++ {
			newReelSet[reelID] = append(newReelSet[reelID], r[reelID][rowID])
		}
	}

	return
}
