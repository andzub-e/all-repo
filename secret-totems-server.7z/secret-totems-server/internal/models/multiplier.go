package models

import "secret-totems/internal/models/constants"

type Multiplier uint

func (m Multiplier) ApplyTo(wager CurrencyAmount) CurrencyAmount {
	return (wager / constants.MathWager) * CurrencyAmount(m)
}
