package models

type GameState struct {
	Spins        []interface{}  `json:"spins"` // BaseSpin{} or BonusSpin{}
	IsCheatStops bool           `json:"is_cheat_stops"`
	IsAutospin   bool           `json:"is_autospin"`
	IsTurbospin  bool           `json:"is_turbospin"`
	Amount       CurrencyAmount `json:"amount"`
}

type BaseStage struct {
	Payouts      Payouts     `json:"payouts"`
	Multiplier   Multiplier  `json:"multiplier"`
	ReelWindow   ReelWindow  `json:"reel_window"`
	DestroyMask  DestroyMask `json:"destroy_mask"`
	DestroyStops ReelStops   `json:"destroy_stops"`
	BonusGame    *GameState  `json:"bonus_game"` // GameState{}
}

type BonusStage struct {
	Payouts      Payouts     `json:"payouts"`
	Multiplier   Multiplier  `json:"multiplier"`
	ReelWindow   ReelWindow  `json:"reel_window"`
	DestroyMask  DestroyMask `json:"destroy_mask"`
	DestroyStops ReelStops   `json:"destroy_stops"`
	BonusGame    bool
}

type Payout struct {
	Symbol         ReelSymbol     `json:"symbol" example:"A"`
	Count          uint           `json:"count" example:"5"`
	PaylineId      int            `json:"payline" swaggertype:"string" example:"0"`
	Amount         CurrencyAmount `json:"amount" swaggertype:"integer" example:"100"`
	Cycle          int            `json:"cycle,omitempty"`
	StartReelIndex uint           `json:"start_reel_index"`
	Multiplier     Multiplier     `json:"-"` // not exported - purely internal
}
