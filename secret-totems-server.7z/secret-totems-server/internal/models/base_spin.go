package models

type CurrencyAmount int64

type BaseSpin struct {
	ReelStops ReelStops      `json:"reel_stops"`
	Stages    []BaseStage    `json:"stages"`
	Amount    CurrencyAmount `json:"amount" swaggertype:"integer" example:"100"`
}

// CalculateStageMultiplier - return multiplier dependent on number of Stages
func (s *BaseSpin) CalculateStageMultiplier() Multiplier {
	stageCounter := len(s.Stages)
	switch stageCounter {
	case 0:
		return 1
	case 1:
		return 2
	case 2:
		return 3
	default: // 3 stages or more
		return 5
	}
}
