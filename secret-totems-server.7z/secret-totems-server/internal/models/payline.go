package models

import "secret-totems/internal/models/constants"

type WindowSlot uint
type AbsolutePayline [constants.PayLineSize]WindowSlot

type Paylines [constants.PayLineCount]AbsolutePayline

var PayLines = Paylines{
	{5, 6, 7, 8, 9},      //1
	{0, 1, 2, 3, 4},      //2
	{10, 11, 12, 13, 14}, //3
	{0, 6, 12, 8, 4},     //4
	{10, 6, 2, 8, 14},    //5
	{0, 1, 7, 3, 4},      //6
	{10, 11, 7, 13, 14},  //7
	{5, 11, 12, 13, 9},   //8
	{5, 1, 2, 3, 9},      //9
	{5, 1, 7, 3, 9},      //10
	{5, 11, 7, 13, 9},    //11
	{0, 6, 2, 8, 4},      //12
	{10, 6, 12, 8, 14},   //13
	{5, 6, 2, 8, 9},      //14
	{5, 6, 12, 8, 9},     //15
	{0, 6, 7, 8, 4},      //16
	{10, 6, 7, 8, 14},    //17
	{0, 6, 12, 13, 14},   //18
	{10, 6, 2, 3, 4},     //19
	{0, 11, 2, 13, 4},    //20
}

// returns the expanded reel & row for a given slot location
func (slot WindowSlot) Location() (reelID int, rowID int) {
	reelID = int(slot % constants.ReelCount)
	rowID = int(slot / constants.ReelCount)
	return
}

// returns true if this slot is a member of given collection of slots
func (slot WindowSlot) MemberOf(slots []WindowSlot) bool {
	for _, test := range slots {
		if slot == test {
			return true
		}
	}
	return false
}
