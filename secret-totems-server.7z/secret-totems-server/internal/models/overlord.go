package models

type OpenFreeBetRequest struct {
	SessionToken string
	FreeBetId    string
	RoundId      string
}

type OpenBetRequest struct {
	SessionToken string
	RoundId      string
	Currency     string
	Value        int64
}

type OpenBetResponse struct {
	TransactionId string
	Currency      string
	Balance       int64
}

type CloseBetRequest struct {
	SessionToken  string
	TransactionId string
	Currency      string
	Value         int64
}

type CloseBetResponse struct {
	Currency string
	Balance  int64
}
