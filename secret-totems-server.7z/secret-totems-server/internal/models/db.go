package models

import (
	"time"
)

type Transaction struct {
	TransactionID string          `gorm:"primaryKey"`
	Type          TransactionType `gorm:"not null"`
	Currency      string          `gorm:"not null"`
	RoundID       string          `gorm:"not null"`
	Value         int64           `gorm:"not null"`
	CreatedAt     time.Time       `gorm:"not null"`
}

type TransactionType string

const (
	Withdraw TransactionType = "WITHDRAW"
	Deposit  TransactionType = "DEPOSIT"
)

type Round struct {
	RoundID             string    `gorm:"primaryKey"`
	GameState           []byte    `gorm:"not null"`
	SessionToken        string    `gorm:"not null"`
	AfterBalance        int64     `gorm:"not null"`
	BeforeBalance       int64     `gorm:"not null"`
	Currency            string    `gorm:"not null"`
	UserID              string    `gorm:"not null"`
	Operator            string    `gorm:"not null"`
	IsShowed            bool      `gorm:"not null"`
	StartTime           time.Time `gorm:""`
	FinishTime          time.Time `gorm:""`
	BaseSpinIndex       int64     `gorm:""`
	BonusSpinIndex      int64     `gorm:""`
	CreatedAt           time.Time `gorm:"not null"`
	WagerAmount         int64     `gorm:""`
	Payout              int64     `gorm:""`
	BonusPay            int64     `gorm:""`
	TransactionDeposit  string    `gorm:""`
	TransactionWithdraw string    `gorm:""`
	FreespinID          string    `gorm:""`
}

type CheatStops struct {
	SessionId string `gorm:"primaryKey"`
	Reels     []byte `gorm:"not null"`
}
