package models

import (
	"github.com/google/uuid"
	"time"
)

type RoundState struct {
	RoundId      string    `json:"round_id"`
	SessionToken string    `json:"session_token"`
	Balance      int64     `json:"balance"`
	Currency     string    `json:"currency"`
	Wager        int64     `json:"wager"`
	FreespinId   string    `json:"free_spin_id"`
	ReelsState   GameState `json:"reels"` // TODO TYPE
	BaseStages   int       `json:"base_stages"`
	BonusStages  int       `json:"bonus_stages"`
	Win          int64     `json:"total_wins"`

	SpinIndexes interface{} `json:"-"` // TODO TYPE

	UserID        string `json:"-"`
	Operator      string `json:"-"`
	OperatorToken string `json:"-"`
	StartBalance  int64  `json:"-"`
	TransactionId string `json:"-"`

	StartTime  int64 `json:"-"`
	FinishTime int64 `json:"-"`
}

func (r *RoundState) RollBaseSpin(wager int64, cheatStops *ReelStops) {
	reelSet := BaseReels.GetDuplicate()
	paytable := BasePaytable
	reelStops := GenerateStops(reelSet)

	if cheatStops != nil {
		reelStops = *cheatStops
	}

	s := BaseSpin{}
	s.ReelStops = reelStops
	for {
		var stage BaseStage
		stage.Multiplier = s.CalculateStageMultiplier()
		stage.ReelWindow.GetValues(reelSet, reelStops)
		stage.Payouts.FindPaylines(paytable, stage.ReelWindow).CalculateAmounts(CurrencyAmount(wager), stage.Multiplier).Sort()
		// bonus game trigger
		if stage.Payouts.IsScatterPaylineExist(paytable, stage.ReelWindow) {
			var bonusGame GameState
			freeSpins := 10
			for freeSpins > 0 {
				freeSpins--
				var spin BonusSpin
				spin.Roll(CurrencyAmount(wager))
				spin.FreeSpinsLeft = freeSpins
				bonusGame.Amount += spin.Amount
				freeSpins += spin.FreeSpins
				bonusGame.Spins = append(bonusGame.Spins, spin)
				r.BonusStages += len(spin.Stages)
			}
			stage.BonusGame = &bonusGame
			s.Amount += bonusGame.Amount // save bonus game reward
		}
		// prepear and save stage
		s.Amount += stage.Payouts.Amount // save payouts reward
		stage.DestroyMask.GetValues(stage.Payouts.Values)
		reelStops = reelSet.DestroyFields(reelStops, stage.DestroyMask)
		stage.DestroyStops = reelStops
		s.Stages = append(s.Stages, stage)
		r.BaseStages = len(s.Stages)

		if len(stage.Payouts.Values) > 0 {
			continue
		}

		break
	}

	r.ReelsState.Spins = append(r.ReelsState.Spins, s)
	r.ReelsState.Amount = s.Amount
	r.Balance += int64(r.ReelsState.Amount)

}

func (r *RoundState) SetStartTime() {
	r.StartTime = time.Now().Unix()
}

func (r *RoundState) SetFinishTime() {
	r.FinishTime = time.Now().Unix()
}

func (r *RoundState) SetRoundId() {
	r.RoundId = uuid.New().String()
}
