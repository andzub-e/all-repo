package models

type BonusSpin struct {
	ReelSet       ReelSet        `json:"-"`
	ReelStops     ReelStops      `json:"reel_stops"`
	Paytable      Paytable       `json:"-"`
	Stages        []BonusStage   `json:"stages"`
	Amount        CurrencyAmount `json:"amount" swaggertype:"integer" example:"100"`
	FreeSpinsLeft int            `json:"free_spins_left"`
	FreeSpins     int            `json:"-"`
}

// Roll - bonus spin logic
func (s *BonusSpin) Roll(totalWager CurrencyAmount) *BonusSpin {
	s.ReelSet = BonusReels.GetDuplicate() // TODO remake & test duplicate
	s.Paytable = BonusPaytable

	s.ReelStops.GenerateNewValues(s.ReelSet)
	tmpReelStops := s.ReelStops // dynamic reelStops that changes after each stage
	for {
		var stage BonusStage
		stage.Multiplier = s.CalculateStageMultiplier()
		stage.ReelWindow.GetValues(s.ReelSet, tmpReelStops)
		stage.Payouts.FindPaylines(s.Paytable, stage.ReelWindow).CalculateAmounts(totalWager, stage.Multiplier).Sort()
		// additional bonus spins trigger
		if stage.Payouts.IsScatterPaylineExist(s.Paytable, stage.ReelWindow) {
			s.FreeSpins += 10
		}
		// prepear and save stage
		s.Amount += stage.Payouts.Amount // add reward to total spin amount
		stage.DestroyMask.GetValues(stage.Payouts.Values)
		tmpReelStops = s.ReelSet.DestroyFields(tmpReelStops, stage.DestroyMask)
		stage.DestroyStops = tmpReelStops
		s.Stages = append(s.Stages, stage)

		if len(stage.Payouts.Values) > 0 {
			continue
		}

		break
	}
	// calculate total amount (reward)

	return s
}

// CalculateStageMultiplier - return multiplier dependent on number of Stages
func (s *BonusSpin) CalculateStageMultiplier() Multiplier {
	stageCounter := len(s.Stages)
	switch stageCounter {
	case 0:
		return 3
	case 1:
		return 6
	case 2:
		return 9
	default: // 3 stages or more
		return 15
	}
}
