package models

import "secret-totems/internal/models/constants"

type RoundHistory struct {
	ID            string      `json:"id"`
	TransactionID string      `json:"transaction_id"`
	Currency      string      `json:"currency"`
	Balance       int64       `json:"balance"`
	Bet           int64       `json:"bet"`
	FinalBalance  int64       `json:"final_balance"`
	RoundID       string      `json:"round_id"`
	BasePay       int64       `json:"base_pay"`
	BonusPay      int64       `json:"bonus_pay"`
	Reels         interface{} `json:"reels"`
	FreespinID    string      `json:"freespin_id"`
	StartTime     int64       `json:"start_time"`
	FinishTime    int64       `json:"finish_time"`
}

type HistoryResponse struct {
	Round []RoundHistory `json:"spins_history"`
}

type Freespin struct {
	Id         string `json:"id,omitempty"`
	Game       string `json:"game,omitempty"`
	Currency   string `json:"currency,omitempty"`
	Value      int64  `json:"value,omitempty"`
	SpinCount  int32  `json:"spin_count,omitempty"`
	ExpireDate int64  `json:"expire_date,omitempty"`
}

type FreespinsResponse struct {
	Freespins *[]Freespin `json:"freespins"`
}

type UpdateSpinIndexRequest struct {
	Spins        SpinData `json:"data"`
	SessionToken string   `json:"session_token"`
}

type SpinData struct {
	BaseStageIndex int64 `json:"base_stage_index"`
	BonusSpinIndex int64 `json:"bonus_spin_index"`
}

type ValidateStopsParams struct {
	Stops [constants.ReelCount]ReelStop
	Reels ReelSet
}

type CommonRequired struct {
	SessionToken string `json:"session_token"`
}

type CheatBonusGameRequest struct {
	CommonRequired
}

type CheatCustomStopsRequest struct {
	CommonRequired
	Stops ReelStops `json:"reel_stops"`
}

type CheatsStageCountRequest struct {
	CommonRequired
	StageCount int `json:"stage_counts"`
}
