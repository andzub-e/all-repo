package models

import (
	"secret-totems/internal/models/constants"
	"secret-totems/pkg/random"
)

type ReelStop uint
type ReelStops [constants.ReelCount]ReelStop

//var stripeId int

// GenerateNewValues - return random values for reelSet indexes
func (rs *ReelStops) GenerateNewValues(reelSet ReelSet) *ReelStops {
	for i := 0; i < constants.ReelCount; i++ {
		getInt, err := random.GetInt(0, int64(len(reelSet[i])))
		if err != nil { // TODO: add error handler
			panic(err)
		}
		stopIndex := ReelStop(getInt)
		//stripeId = (141*stripeId + 28411) % 134456
		//stopIndex := ReelStop((stripeId) % 200)

		rs[i] = stopIndex
	}

	return rs
}

func GenerateStops(reelSet ReelSet) ReelStops {
	var rs ReelStops
	rs.GenerateNewValues(reelSet)

	return rs
}
