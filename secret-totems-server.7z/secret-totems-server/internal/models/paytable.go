package models

type Paytable map[ReelSymbol]PaytableLine
type PaytableLine map[uint]Multiplier

var BasePaytable = Paytable{
	"A": {5: 2500, 4: 250, 3: 50},
	"B": {5: 1000, 4: 100, 3: 20},
	"C": {5: 500, 4: 50, 3: 15},
	"D": {5: 200, 4: 25, 3: 10},
	"X": {5: 100, 4: 20, 3: 5},
	"Y": {5: 75, 4: 15, 3: 4},
	"Z": {5: 50, 4: 10, 3: 3},

	"W": {5: 0, 4: 0, 3: 0}, // Wild
	"F": {5: 0, 4: 0, 3: 0}, // Scatter
}

var BonusPaytable = Paytable{ // TODO: oldname BOnusFreeSpins
	"A": {5: 2500, 4: 250, 3: 50},
	"B": {5: 1000, 4: 100, 3: 20},
	"C": {5: 500, 4: 50, 3: 15},
	"D": {5: 200, 4: 25, 3: 10},
	"X": {5: 100, 4: 20, 3: 5},
	"Y": {5: 75, 4: 15, 3: 4},
	"Z": {5: 50, 4: 10, 3: 3},

	"W": {5: 0, 4: 0, 3: 0}, // Wild
	"F": {5: 0, 4: 0, 3: 0}, // Scatter
}

func (t Paytable) GetMultiplier(sym ReelSymbol, consecutive uint) Multiplier {
	return t[sym][consecutive]
}
