package models

import (
	"sort"

	"secret-totems/internal/models/constants"
)

type Payouts struct {
	Amount CurrencyAmount `json:"amount"`
	Values []Payout       `json:"values"`
}

// FindPaylines - save unsorted list of payouts by paylines at existen window
func (p *Payouts) FindPaylines(paytable Paytable, reelWindow ReelWindow) *Payouts {
	p.Values = nil

	for paylineID := 0; paylineID < constants.PayLineCount; paylineID++ {
		// the line we're processing
		line := PayLines[paylineID]

		// preprocess the first symbol in the line
		symbol := reelWindow.SymbolAt(line[0])

		// capture our initial symbol or wild state
		wildChain := symbol.IsWild()
		consecutiveWilds := uint(0)
		if wildChain {
			consecutiveWilds++
		}

		// we've already processed the first symbol / wild
		consecutive := uint(1)

		// walk remaining in payline to find consecutive count (and true pay symbol if we started with a wild)
		for ; consecutive < constants.PayLineSize; consecutive++ {

			// process next symbol in line
			nextSymbol := reelWindow.SymbolAt(line[consecutive])

			// check if our next symbol is wild
			if nextSymbol.IsWild() {
				if wildChain {
					consecutiveWilds++
				}
			} else if nextSymbol == symbol {
				// continue
			} else if wildChain {
				symbol = nextSymbol
				wildChain = false
			} else {
				break
			}
		}

		// get multiplier
		mult := paytable.GetMultiplier(symbol, consecutive)
		wildmult := paytable.GetMultiplier("A", consecutiveWilds)

		// use the better one
		if wildmult > mult {
			mult = wildmult
			consecutive = consecutiveWilds
			symbol = "A"
		}

		// if we ended up without a multiplier, we're done
		if mult == 0 {
			continue
		}

		// add finded payout
		payout := Payout{
			Symbol:     symbol,
			Count:      consecutive,
			PaylineId:  paylineID,
			Multiplier: mult,
		}
		p.Values = append(p.Values, payout)
	}

	return p
}

// CalculateAmounts - save total payouts reward
func (p *Payouts) CalculateAmounts(totalWager CurrencyAmount, multiplier Multiplier) *Payouts {
	for payoutID := range p.Values {
		p.Values[payoutID].Amount = p.Values[payoutID].Multiplier.ApplyTo(totalWager) * CurrencyAmount(multiplier)
		p.Amount += p.Values[payoutID].Amount
	}

	return p
}

// Sort - resave list of payouts after sort by ASC reward value
func (p *Payouts) Sort() *Payouts {
	sort.SliceStable(p.Values, func(i, j int) bool {
		return p.Values[i].Amount < p.Values[j].Amount
	})

	return p
}

// IsScatterPaylineExist - checking paylines for scatter comination exists
func (p *Payouts) IsScatterPaylineExist(paytable Paytable, reelWindow ReelWindow) (isScatterComboExist bool) {
	for paylineID := 0; paylineID < constants.PayLineCount; paylineID++ {
		// the line we're processing
		line := PayLines[paylineID]
		var isScatterSymbolExist bool // needs for known that payline included not only wild sysmbols
		var consecutive = uint(0)
		var symbol ReelSymbol
		for ; consecutive < constants.PayLineSize; consecutive++ {
			symbol := reelWindow.SymbolAt(line[consecutive])
			if symbol.IsScatter() {
				isScatterSymbolExist = true
			}
			if !symbol.IsScatter() && !symbol.IsWild() {
				break
			}
		}
		// if exist in paytable
		if isScatterSymbolExist {
			_, ok := paytable["F"][consecutive]
			if ok {
				isScatterComboExist = true
				// add finded payout
				mult := paytable.GetMultiplier(symbol, consecutive)
				payout := Payout{
					Symbol:     "F",
					Count:      consecutive,
					PaylineId:  paylineID,
					Multiplier: mult,
				}
				p.Values = append(p.Values, payout)
			}
		}
	}

	return
}
