package models

import (
	"secret-totems/internal/models/constants"
)

type ReelWindow [constants.ReelCount]ReelWindowColumn
type ReelWindowColumn [constants.WindowHeight]ReelSymbol

// GetValues - return reel symbolic values for window
func (rw *ReelWindow) GetValues(reelSet ReelSet, reelStops ReelStops) *ReelWindow {
	for reelID := 0; reelID < constants.ReelCount; reelID++ {
		for rowID := 0; rowID < constants.WindowHeight; rowID++ {
			reelSize := len(reelSet[reelID])
			rw[reelID][rowID] = reelSet.GetRawSymbol(reelID, rowID, reelStops[reelID], reelSize)
		}
	}

	return rw
}

// SymbolAt - returns the symbol at the given absolute slot position
func (rw *ReelWindow) SymbolAt(slot WindowSlot) ReelSymbol {
	reel, row := slot.Location()

	return rw[reel][row]
}

type IsDestroyed bool
type DestroyMask [constants.ReelCount]DestroyMaskColumn
type DestroyMaskColumn [constants.WindowHeight]IsDestroyed

// GetValues - return mask for destroy reelset fields (value "true" for remove)
func (dm *DestroyMask) GetValues(payouts []Payout) *DestroyMask {
	for _, payout := range payouts {
		line := PayLines[payout.PaylineId]
		for i := 0; i < int(payout.Count); i++ {
			reel, row := WindowSlot(line[i]).Location()
			dm[reel][row] = true
		}
	}

	return dm
}
