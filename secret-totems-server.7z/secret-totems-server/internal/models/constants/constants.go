package constants

const (
	HistoryMaxCount = 50
	HistoryVersion  = 1
	PayLineCount    = 20
	PayLineSize     = 5

	ReelCount = 5
	// ReelSize     = 120
	WindowHeight = 3
	WindowSize   = ReelCount * WindowHeight
	MathWager    = 20
)
