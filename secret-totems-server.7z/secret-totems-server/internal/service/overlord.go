package service

import (
	"context"
	"encoding/json"
	"github.com/sirupsen/logrus"
	"google.golang.org/grpc/status"
	"secret-totems/internal/config"
	"secret-totems/internal/models"
	"secret-totems/pkg/errs"
	"secret-totems/pkg/overlord"
	"secret-totems/pkg/overlord/api"
)

type OverlordService interface {
	InitUserState(ctx context.Context, params *models.UserStateParams) (*models.UserState, error)
	GetStateBySessionToken(ctx context.Context, token string) (*models.UserState, error)
	GetFreespins(ctx context.Context, token string) (*[]models.Freespin, error)
	OpenBet(ctx context.Context, in *models.OpenBetRequest) (*models.OpenBetResponse, error)
	OpenFreeBet(ctx context.Context, in *models.OpenFreeBetRequest) (*models.OpenBetResponse, error)
	CloseBet(ctx context.Context, in *models.CloseBetRequest) (*models.CloseBetResponse, error)
}

type overlordService struct {
	log logrus.FieldLogger
	api api.OverlordClient
}

func (o *overlordService) OpenBet(ctx context.Context, in *models.OpenBetRequest) (*models.OpenBetResponse, error) {
	p := &api.OpenBetIn{SessionToken: in.SessionToken, RoundId: in.RoundId, Currency: in.Currency, Value: in.Value}

	bet, err := o.api.OpenBet(ctx, p)

	if err != nil {
		return nil, err
	}

	y := &models.OpenBetResponse{TransactionId: bet.TransactionId, Currency: bet.Currency, Balance: bet.Balance}

	return y, nil
}

func (o *overlordService) OpenFreeBet(ctx context.Context, in *models.OpenFreeBetRequest) (*models.OpenBetResponse, error) {
	p := &api.OpenFreeBetIn{SessionToken: in.SessionToken, FreeBetId: in.FreeBetId, RoundId: in.RoundId}

	bet, err := o.api.OpenFreeBet(ctx, p)

	if err != nil {
		return nil, err
	}

	y := &models.OpenBetResponse{TransactionId: bet.TransactionId, Currency: bet.Currency, Balance: bet.Balance}

	return y, nil
}

func (o *overlordService) CloseBet(ctx context.Context, in *models.CloseBetRequest) (*models.CloseBetResponse, error) {
	p := &api.CloseBetIn{SessionToken: in.SessionToken, TransactionId: in.TransactionId, Currency: in.Currency, Value: in.Value}

	bet, err := o.api.CloseBet(ctx, p)

	if err != nil {
		return nil, err
	}

	y := &models.CloseBetResponse{Currency: bet.Currency, Balance: bet.Balance}

	return y, nil
}

func NewOverlordService(
	log logrus.FieldLogger,
	cfg *config.OverlordConfig,
) (OverlordService, error) {
	service := &overlordService{
		log: log,
	}
	var err error
	service.api, err = overlord.NewClient(cfg.Host, cfg.Port)
	if err != nil {
		return service, err
	}
	return service, nil
}

func (o *overlordService) GetStateBySessionToken(ctx context.Context, token string) (*models.UserState, error) {
	o.log.Info("repo: GetStateBySessionToken starting...")

	in := &api.GetStateBySessionTokenIn{SessionToken: token}

	overlordState, err := o.api.GetStateBySessionToken(ctx, in)
	if err != nil {
		return nil, err
	}

	state := &models.UserState{
		UserId:        overlordState.UserId,
		Operator:      overlordState.Operator,
		Game:          overlordState.Game,
		Username:      overlordState.Username,
		OperatorToken: overlordState.OperatorToken,
		SessionToken:  overlordState.SessionToken,
		Balance:       overlordState.Balance,
		Currency:      overlordState.Currency,
		IsOpened:      overlordState.IsOpened,
		DefaultWager:  overlordState.DefaultWager,
		WagerLevels:   overlordState.WagerLevels,
	}

	return state, nil

}

func (o *overlordService) GetFreespins(ctx context.Context, token string) (*[]models.Freespin, error) {
	o.log.Info("repo: GetFreespins starting...")

	in := &api.GetAvailableFreeBetsIn{SessionToken: token}

	overlordState, err := o.api.GetAvailableFreeBets(ctx, in)
	if err != nil {
		return nil, err
	}

	spins := make([]models.Freespin, 0)

	for _, bet := range overlordState.FreeBets {
		f := models.Freespin{
			Id:         bet.Id,
			Game:       bet.Game,
			Currency:   bet.Currency,
			Value:      bet.Value,
			SpinCount:  bet.SpinCount,
			ExpireDate: bet.ExpireDate,
		}

		spins = append(spins, f)
	}

	return &spins, nil

}

func (o *overlordService) InitUserState(ctx context.Context, params *models.UserStateParams) (state *models.UserState, err error) {
	o.log.Info("repo: InitUserState starting...")

	// Create API request
	initUserStateIn := &api.InitUserStateIn{
		Operator: params.Operator,
		Game:     params.Game,
	}

	initUserStateIn.Params, err = json.Marshal(params.OperatorParams)
	if err := o.checkError(err, "repo: failed to Marshal OperatorParams"); err != nil {
		return nil, err
	}

	// API call
	overlordState, err := o.api.InitUserState(ctx, initUserStateIn)
	if err := o.checkError(err, "repo: failed to InitUserState"); err != nil {
		return nil, err
	}

	// Create response
	state = &models.UserState{
		UserId:        overlordState.UserId,
		Operator:      overlordState.Operator,
		Game:          overlordState.Game,
		Username:      overlordState.Username,
		OperatorToken: overlordState.OperatorToken,
		SessionToken:  overlordState.SessionToken,
		Balance:       overlordState.Balance,
		Currency:      overlordState.Currency,
		IsOpened:      overlordState.IsOpened,
		DefaultWager:  overlordState.DefaultWager,
		WagerLevels:   overlordState.WagerLevels,
	}

	return state, nil
}

func (o *overlordService) checkError(err error, msgs ...string) error {
	if err != nil {
		o.log.WithError(err).Error(msgs)
		code, _ := status.FromError(err)
		switch code.Code() {
		case 100:
			return errs.BalanceTooLowErr
		case 101:
			return errs.WrongSessionTokenErr
		default:
			return errs.InternalServerErr
		}
	}
	return nil
}
