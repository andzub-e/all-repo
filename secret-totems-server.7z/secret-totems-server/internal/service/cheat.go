package service

import (
	"context"
	"errors"
	"fmt"
	"github.com/sirupsen/logrus"
	"secret-totems/internal/models"
	"secret-totems/internal/repository"
)

type CheatService interface {
	CustomStops(ctx context.Context, req *models.CheatCustomStopsRequest) error
	StageCount(ctx context.Context, req *models.CheatsStageCountRequest) error
	BonusGame(ctx context.Context, req *models.CheatBonusGameRequest) error
}

type cheat struct {
	log  logrus.FieldLogger
	repo repository.Repository
}

func NewCheatService(log logrus.FieldLogger, repo repository.Repository) CheatService {
	return &cheat{
		log:  log,
		repo: repo,
	}
}

func (c cheat) CustomStops(ctx context.Context, req *models.CheatCustomStopsRequest) error {
	err := validateStops(&models.ValidateStopsParams{
		Stops: req.Stops,
		Reels: models.BaseReels,
	})

	if err != nil {
		return err
	}

	err = c.repo.SetCheatStops(ctx, req.SessionToken, req.Stops)

	return err
}

func (c cheat) StageCount(ctx context.Context, req *models.CheatsStageCountRequest) error {
	var testState models.RoundState

	if req.StageCount < 1 || req.StageCount > 5 {
		return errors.New("required stage count range: 1-5")
	}

	for i := 0; ; i++ {
		testState = models.RoundState{}
		testState.RollBaseSpin(0, nil)
		if testState.BaseStages == req.StageCount {
			break
		}
		if i > 1e6 {
			return errors.New("infinity loop")
		}
	}

	r := &models.CheatCustomStopsRequest{}
	r.SessionToken = req.SessionToken
	r.Stops = testState.ReelsState.Spins[0].(models.BaseSpin).ReelStops

	return c.CustomStops(ctx, r)
}

func (c cheat) BonusGame(ctx context.Context, req *models.CheatBonusGameRequest) error {
	var stops models.ReelStops

	for reelID := 0; reelID < 3; reelID++ {
		reelSize := len(models.BaseReels[reelID])
		for rowID := 0; rowID < reelSize; rowID++ {
			if models.BaseReels[reelID][rowID].IsScatter() {
				stops[reelID] = models.ReelStop(rowID)
			}
		}
	}

	r := &models.CheatCustomStopsRequest{}
	r.SessionToken = req.SessionToken
	r.Stops = stops

	return c.CustomStops(ctx, r)
}

func validateStops(params *models.ValidateStopsParams) error {

	for i, v := range params.Stops {
		if len(params.Reels[i]) <= int(v) {
			return fmt.Errorf("reel stop in out of range: reel %d, input stop %d, max stop %d", i, v, len(params.Reels[i]))
		}
	}

	return nil
}
