package service

import (
	"context"
	"encoding/json"
	"fmt"
	"gorm.io/gorm"
	"secret-totems/pkg/errs"
	"time"

	"github.com/google/uuid"
	"github.com/sirupsen/logrus"
	"secret-totems/internal/models"
	"secret-totems/internal/repository"
)

type CoreService interface {
	GetUserState(ctx context.Context, params *models.UserStateParams) (*models.UserState, error)
	PlaceWager(ctx context.Context, params *models.PlaceWagerParams) (*models.RoundState, error)
	SetRoundAsShowed(ctx context.Context, params *models.SetRoundAsShowedParams) error
	UpdateLastRoundIndex(ctx context.Context, params *models.UpdateSpinIndexRequest) error
	GetHistory(ctx context.Context, sessionToken string) (*[]models.Round, error)
	GetFreespins(ctx context.Context, params *models.GetFreespins) (*[]models.Freespin, error)
	GetUserBySessionToken(ctx context.Context, sessionToken string) (*models.UserState, error)
}

type coreService struct {
	log      logrus.FieldLogger
	repo     repository.Repository
	overlord OverlordService
}

func (c *coreService) GetHistory(ctx context.Context, sessionToken string) (*[]models.Round, error) {
	userInfo, err := c.overlord.GetStateBySessionToken(ctx, sessionToken)
	if err != nil {
		return nil, err
	}

	return c.repo.GetRoundsByUserId(ctx, userInfo.UserId)
}

func (c *coreService) GetUserBySessionToken(ctx context.Context, sessionToken string) (*models.UserState, error) {

	overlordState, err := c.overlord.GetStateBySessionToken(ctx, sessionToken)
	if err != nil {
		return nil, err
	}

	// Create response
	state := &models.UserState{
		UserId:        overlordState.UserId,
		Operator:      overlordState.Operator,
		Game:          overlordState.Game,
		Username:      overlordState.Username,
		OperatorToken: overlordState.OperatorToken,
		SessionToken:  overlordState.SessionToken,
		Balance:       overlordState.Balance,
		Currency:      overlordState.Currency,
		IsOpened:      overlordState.IsOpened,
		DefaultWager:  overlordState.DefaultWager,
		WagerLevels:   overlordState.WagerLevels,
	}

	return state, err
}

func (c *coreService) GetFreespins(ctx context.Context, params *models.GetFreespins) (*[]models.Freespin, error) {
	return c.overlord.GetFreespins(ctx, params.SessionToken)
}

func NewCoreService(log logrus.FieldLogger, repo repository.Repository, overlord OverlordService) CoreService {
	return &coreService{
		log:      log,
		repo:     repo,
		overlord: overlord,
	}
}

func (c *coreService) GetUserState(ctx context.Context, params *models.UserStateParams) (*models.UserState, error) {
	c.log.Infof("service: InitUserState starting...")
	state, err := c.overlord.InitUserState(ctx, params)
	if err != nil {
		return nil, err
	}

	// check for not showed round
	round, err := c.repo.GetLastRound(ctx, state.UserId)

	if err == nil {
		fmt.Println(round.RoundID, err)
		if round.IsShowed == false {
			var gameState models.GameState
			if r := json.Unmarshal(round.GameState, &gameState); r != nil {
				return nil, r
			}
			state.ReelsState = gameState
			state.SpinIndexes = models.SpinData{BaseStageIndex: round.BaseSpinIndex, BonusSpinIndex: round.BonusSpinIndex}
		}

	} else if err == gorm.ErrRecordNotFound {
		err = nil
	}

	return state, err
}

func (c *coreService) PlaceWager(ctx context.Context, params *models.PlaceWagerParams) (*models.RoundState, error) {
	c.log.Infof("service: PlaceWager starting...")

	userState, err := c.overlord.GetStateBySessionToken(ctx, params.SessionToken)
	if err != nil {
		return nil, err
	}

	round := models.RoundState{
		Wager:        params.Wager,
		Currency:     params.Currency,
		SessionToken: params.SessionToken,
		StartBalance: userState.Balance,
		UserID:       userState.UserId,
	}

	round.SetRoundId()
	round.SetStartTime()

	if round.StartBalance < params.Wager {
		return nil, errs.BalanceTooLowErr
	}

	transWithdraw := models.Transaction{
		TransactionID: uuid.New().String(),
		Type:          models.Deposit,
		Currency:      params.Currency,
		RoundID:       round.RoundId,
		Value:         params.Wager,
		CreatedAt:     time.Now(),
	}
	err = c.repo.CreateTransaction(ctx, transWithdraw)
	if err != nil {
		return nil, err
	}

	var openBet *models.OpenBetResponse

	if params.FreeSpinID != "" {
		fsBet := &models.OpenFreeBetRequest{
			SessionToken: params.SessionToken,
			FreeBetId:    params.FreeSpinID,
			RoundId:      round.RoundId,
		}
		openBet, err = c.overlord.OpenFreeBet(ctx, fsBet)
	} else {
		openBetLord := &models.OpenBetRequest{
			SessionToken: params.SessionToken,
			RoundId:      round.RoundId,
			Currency:     params.Currency,
			Value:        params.Wager,
		}
		openBet, err = c.overlord.OpenBet(ctx, openBetLord)
	}
	if err != nil {
		return nil, err
	}

	round.Balance = openBet.Balance

	stopsFromDB, ok, err := c.repo.GetCheatStops(ctx, params.SessionToken)
	if err != nil {
		return nil, err
	}
	var stops *models.ReelStops

	if ok {
		stops = &stopsFromDB
	}
	// play round
	round.RollBaseSpin(params.Wager, stops)
	//round.Balance += int64(round.ReelsState.Amount)

	round.Win = int64(round.ReelsState.Amount)
	// deposit wager
	transDeposit := models.Transaction{
		TransactionID: uuid.New().String(),
		Type:          models.Withdraw,
		Currency:      params.Currency,
		RoundID:       round.RoundId,
		Value:         round.Win,
		CreatedAt:     time.Now(),
	}

	err = c.repo.CreateTransaction(ctx, transDeposit)
	if err != nil {
		return nil, err
	}

	closeBetRequest := &models.CloseBetRequest{
		SessionToken:  params.SessionToken,
		TransactionId: openBet.TransactionId,
		Currency:      params.Currency,
		Value:         round.Win,
	}
	closeBetResponse, err := c.overlord.CloseBet(ctx, closeBetRequest)
	if err != nil {
		return nil, err
	}
	round.Balance = closeBetResponse.Balance

	// save round (not finished)
	gameStateBytes, _ := json.Marshal(&round.ReelsState)

	roundHistory := models.Round{
		RoundID:             round.RoundId,
		GameState:           gameStateBytes,
		SessionToken:        round.SessionToken,
		AfterBalance:        round.Balance,
		BeforeBalance:       round.StartBalance,
		Currency:            round.Currency,
		UserID:              round.UserID,
		Operator:            round.Operator,
		FreespinID:          round.FreespinId,
		IsShowed:            false,
		StartTime:           time.Now(),
		FinishTime:          time.Now(),
		CreatedAt:           time.Now(),
		WagerAmount:         params.Wager,
		Payout:              int64(round.ReelsState.Amount),
		TransactionDeposit:  transDeposit.TransactionID,
		TransactionWithdraw: transWithdraw.TransactionID,
	}
	err = c.repo.CreateRound(ctx, roundHistory)

	return &round, err
}

func (c *coreService) SetRoundAsShowed(ctx context.Context, params *models.SetRoundAsShowedParams) error {
	c.log.Infof("service: SetRoundAsShowed starting...")
	err := c.repo.SetRoundAsShowed(ctx, params.RoundID)

	return err
}
func (c *coreService) UpdateLastRoundIndex(ctx context.Context, params *models.UpdateSpinIndexRequest) error {
	c.log.Infof("service: UpdateLastRoundIndex starting...")

	user, err := c.GetUserBySessionToken(ctx, params.SessionToken)
	if err != nil {
		return err
	}

	return c.repo.UpdateLastRoundSpinIndex(ctx, user.UserId, params.Spins)
}
