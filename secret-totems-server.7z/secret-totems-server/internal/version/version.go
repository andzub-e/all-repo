package version

const GameVersion = `1.1.0`
