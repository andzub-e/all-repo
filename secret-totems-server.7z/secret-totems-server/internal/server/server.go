package server

import (
	"net/http"
	"time"

	"github.com/pkg/errors"
	"github.com/sirupsen/logrus"
	"secret-totems/internal/config"

	_ "secret-totems/docs"
)

type Server struct {
	log    logrus.FieldLogger
	cfg    *config.HTTPConfig
	server http.Server
}

func NewServer(
	log logrus.FieldLogger,
	cfg *config.HTTPConfig,
	handler http.Handler,
) *Server {

	server := &Server{
		log: log,
		cfg: cfg,
	}

	server.server = http.Server{
		Addr:         server.cfg.Host + ":" + server.cfg.Port,
		Handler:      handler,
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 30 * time.Second,
		IdleTimeout:  120 * time.Second,
	}

	return server
}

func (s *Server) Run() error {

	s.log.Infoln("Listening on:", s.server.Addr)

	if err := s.server.ListenAndServe(); err != nil {
		return errors.Wrap(err, "failed to start http server")
	}

	return nil
}
