package server

import (
	"encoding/json"
	"fmt"
	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"github.com/sirupsen/logrus"
	"net/http"
	"secret-totems/internal/models"
	"secret-totems/internal/service"
	"secret-totems/internal/version"
	"secret-totems/pkg/errs"
)

//goland:noinspection ALL
const ENABLE_CHEATS = true

type Handler struct {
	log logrus.FieldLogger
	svc service.CoreService
	cht service.CheatService
	http.Handler
}

func NewHandler(log logrus.FieldLogger, svc service.CoreService, cht service.CheatService) http.Handler {
	handler := &Handler{log: log, svc: svc, cht: cht}
	handler.set()
	return handler
}

func (h *Handler) set() {
	gin.SetMode(gin.DebugMode)
	handler := gin.Default()

	core := handler.Group("/core")
	{
		core.POST("/state", h.state)
		core.POST("/wager", h.placeWager)
		core.POST("/round/is_showed", h.setRoundAsShowed)
		core.POST("/spins_indexes/update", h.updateSpinsIndexes)
		core.GET("/spins_history", h.getHistory)
	}

	fs := core.Group("/free_spins")
	{
		fs.GET("/get", h.getFreeSpins)
	}

	cheat := handler.Group("/cheat")

	if ENABLE_CHEATS {
		cheat.POST("/custom_stops", h.cheatCustomStops)
		cheat.POST("/stage_count", h.cheatStageCount)
		cheat.POST("/bonus_game", h.cheatBonusGame)
	}

	handler.Use(cors.Default())

	h.Handler = handler
}

// @Summary State
// @Tags core
// @Consume application/json
// @Param JSON body models.UserStateParams{operator_params=models.OperatorParamsExample} true "user state params"
// @Accept  json
// @Produce  json
// @Success 200 {object} models.UserState
// @Failure 400 {object} myerr.ErrResp
// @Failure 500 {object} myerr.ErrResp
// @Router /core/state [post]
func (h *Handler) state(ctx *gin.Context) {
	h.log.Info("http: state starting...")

	// Create service request
	params := &models.UserStateParams{}
	if err := ctx.BindJSON(params); err != nil {
		h.log.WithError(err).Error("invalid json")
		ctx.JSON(http.StatusBadRequest, errs.BadParamInBodyErr)
		return
	}

	// Service call
	state, err := h.svc.GetUserState(ctx, params)
	if err != nil {
		h.log.WithError(err).Error("failed to get user state from db")
		ctx.JSON(errs.GetHttpCode(err), err)
		return
	}

	state.GameVersion = version.GameVersion

	ctx.JSON(http.StatusOK, state)
}

func (h *Handler) cheatCustomStops(ctx *gin.Context) {

	req := &models.CheatCustomStopsRequest{}

	err := ctx.BindJSON(req)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, err)
		return
	}

	h.log.Info("calling custom stops")

	err = h.cht.CustomStops(ctx, req)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, err)
		return
	}

	ctx.JSON(http.StatusOK, map[string]interface{}{"ok": true})
}

func (h *Handler) cheatStageCount(ctx *gin.Context) {
	req := &models.CheatsStageCountRequest{}

	err := ctx.BindJSON(req)
	if err != nil {
		fmt.Println(err)
		ctx.JSON(http.StatusBadRequest, err)
		return
	}

	h.log.Info("calling stage count")

	err = h.cht.StageCount(ctx, req)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, err)
		return
	}

	ctx.JSON(http.StatusOK, map[string]interface{}{"ok": true})
}

func (h *Handler) cheatBonusGame(ctx *gin.Context) {
	req := &models.CheatBonusGameRequest{}

	err := ctx.BindJSON(req)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, err)
		return
	}

	h.log.Info("calling stage count")

	err = h.cht.BonusGame(ctx, req)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, err)
		return
	}

	ctx.JSON(http.StatusOK, map[string]interface{}{"ok": true})
}

// @Summary Place a bet
// @Tags core
// @Consume application/json
// @Param JSON body models.PlaceWagerParams true "place wager params"
// @Description Make a bet (spin).
// @Accept  json
// @Produce  json
// @Success 200 {object} models.RoundState
// @Failure 400 {object} myerr.ErrResp
// @Failure 402 {object} myerr.ErrResp
// @Failure 500 {object} myerr.ErrResp
// @Router /core/wager [post]
func (h *Handler) placeWager(ctx *gin.Context) {
	h.log.Info("http: placeWager starting...")

	// Create service request
	params := &models.PlaceWagerParams{}
	if err := ctx.BindJSON(params); err != nil {
		h.log.WithError(err).Error("http: failed to parse place wager request")
		ctx.JSON(http.StatusBadRequest, errs.BadParamInBodyErr)
		return
	}

	// Service call
	state, err := h.svc.PlaceWager(ctx, params)
	if err != nil {
		h.log.WithError(err).Error("http: failed to place wager")
		ctx.JSON(errs.GetHttpCode(err), err)
		return
	}

	ctx.JSON(http.StatusOK, state)
}

// @Summary Set round as showed
// @Tags core
// @Consume application/json
// @Param JSON body models.SetRoundAsShowedParams true "set round as showed"
// @Description Set round as showed.
// @Accept  json
// @Produce  json
// @Success 200
// @Failure 400 {object} myerr.ErrResp
// @Failure 402 {object} myerr.ErrResp
// @Failure 500 {object} myerr.ErrResp
// @Router /core/round/is_showed [post]
func (h *Handler) setRoundAsShowed(ctx *gin.Context) {
	h.log.Info("http: setRoundAsShowed starting...")

	// Create service request
	params := &models.SetRoundAsShowedParams{}
	if err := ctx.BindJSON(params); err != nil {
		h.log.WithError(err).Error("http: failed to parse params for set round is showed")
		ctx.JSON(http.StatusBadRequest, errs.BadParamInBodyErr)
		return
	}

	// Service call
	err := h.svc.SetRoundAsShowed(ctx, params)
	if err != nil {
		h.log.WithError(err).Error("http: failed to setRoundAsShowed")
		ctx.JSON(errs.GetHttpCode(err), err)
		return
	}

	ctx.JSON(http.StatusOK, "OK")
}

func (h *Handler) getHistory(ctx *gin.Context) {
	h.log.Info("http: setRoundAsShowed starting...")

	var q struct {
		SessionToken string `form:"session_token"`
	}

	if err := ctx.BindQuery(&q); err != nil {
		h.log.WithError(err).Error("http: failed to parse params for get_history")
		ctx.JSON(http.StatusBadRequest, errs.BadParamInBodyErr)
		return
	}

	history, err := h.svc.GetHistory(ctx, q.SessionToken)
	if err != nil {
		h.log.WithError(err).Error("http: failed to get a history")
		ctx.JSON(http.StatusInternalServerError, errs.ServerInternalError)
		return
	}

	var hr models.HistoryResponse
	for _, round := range *history {

		var gameState models.GameState
		_ = json.Unmarshal(round.GameState, &gameState)

		round := models.RoundHistory{
			ID:            round.RoundID,
			TransactionID: round.TransactionWithdraw,
			Currency:      round.Currency,
			Balance:       round.BeforeBalance,
			Bet:           round.WagerAmount,
			FinalBalance:  round.AfterBalance,
			RoundID:       round.RoundID,
			BasePay:       round.Payout,
			BonusPay:      round.BonusPay,
			Reels:         gameState,
			FreespinID:    round.FreespinID,
			StartTime:     round.StartTime.Unix(),
			FinishTime:    round.FinishTime.Unix(),
		}

		hr.Round = append(hr.Round, round)

	}

	ctx.JSON(http.StatusOK, hr)

}

func (h *Handler) getFreeSpins(ctx *gin.Context) {
	h.log.Info("http: getFreeSpins starting...")

	sessionToken := ctx.Query("session_token")

	freespins, err := h.svc.GetFreespins(ctx, &models.GetFreespins{SessionToken: sessionToken})
	if err != nil {
		h.log.WithError(err).Error("failed to get free spins")
		ctx.JSON(http.StatusInternalServerError, errs.ServerInternalError)
		return
	}

	resp := models.FreespinsResponse{Freespins: freespins}

	ctx.JSON(http.StatusOK, resp)
}

func (h *Handler) updateSpinsIndexes(ctx *gin.Context) {
	s := &models.UpdateSpinIndexRequest{}

	if err := ctx.BindJSON(s); err != nil {
		h.log.WithError(err).Error("http: failed to parse params for upd spin")
		ctx.JSON(http.StatusBadRequest, errs.BadParamInBodyErr)
		return
	}

	err := h.svc.UpdateLastRoundIndex(ctx, s)
	if err != nil {
		h.log.WithError(err).Error("failed to UpdateRoundIndex")
		ctx.JSON(http.StatusInternalServerError, errs.ServerInternalError)
		return
	}

	ctx.JSON(http.StatusOK, map[string]interface{}{"ok": true})
}
