package repository

import (
	"context"
	"time"

	"secret-totems/internal/models"
)

func (r Repository) CreateRound(ctx context.Context, round models.Round) error {
	return r.conn.WithContext(ctx).Create(&round).Error
}

func (r Repository) SetRoundAsShowed(ctx context.Context, roundID string) error {
	var round models.Round
	err := r.conn.WithContext(ctx).First(&round, "round_id = ?", roundID).Error
	if err != nil {
		return err
	}

	round.FinishTime = time.Now()
	round.IsShowed = true
	return r.conn.WithContext(ctx).Updates(&round).Error
}

func (r Repository) UpdateLastRoundSpinIndex(ctx context.Context, userId string, spins models.SpinData) error {
	var round models.Round
	err := r.conn.WithContext(ctx).Order("created_at desc").Take(&round, "user_id = ?", userId).Error
	if err != nil {
		return err
	}

	round.BaseSpinIndex, round.BonusSpinIndex = spins.BaseStageIndex, spins.BonusSpinIndex

	return r.conn.WithContext(ctx).Updates(&round).Error
}

func (r Repository) GetLastRound(ctx context.Context, userId string) (models.Round, error) {
	var round models.Round
	err := r.conn.WithContext(ctx).Order("created_at desc").Take(&round, "user_id = ?", userId).Error

	return round, err
}

func (r Repository) GetRoundsByUserId(ctx context.Context, userId string) (rounds *[]models.Round, err error) {
	var sl = make([]models.Round, 0)
	err = r.conn.WithContext(ctx).Where("user_id = ?", userId).Order("created_at").Find(&sl).Error
	rounds = &sl
	return
}
