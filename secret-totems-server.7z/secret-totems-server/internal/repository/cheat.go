package repository

import (
	"context"
	"encoding/json"
	"errors"
	"gorm.io/gorm/clause"
	"secret-totems/internal/models"
	"secret-totems/internal/models/constants"
)

func (r Repository) SetCheatStops(ctx context.Context, session string, stops models.ReelStops) error {
	reelsJson, _ := json.Marshal(stops)
	var o = &models.CheatStops{
		SessionId: session,
		Reels:     reelsJson,
	}

	return r.conn.WithContext(ctx).Clauses(clause.OnConflict{
		Columns:   []clause.Column{{Name: "session_id"}},
		DoUpdates: clause.AssignmentColumns([]string{"reels"}),
	}).Create(o).Error

}

func (r Repository) GetCheatStops(ctx context.Context, session string) (rs models.ReelStops, ok bool, err error) {
	var y models.CheatStops
	t := r.conn.WithContext(ctx).Clauses(clause.Returning{}).Where("session_id = ?", session).Delete(&y)

	err = t.Error
	ok = t.RowsAffected > 0

	if ok && err == nil {
		var reels = make([]models.ReelStop, 0)
		err = json.Unmarshal(y.Reels, &reels)

		if len(reels) != constants.ReelCount {
			err = errors.New("reels from json is not correct")
			return
		}

		for i, reel := range reels {
			rs[i] = reel
		}
	}

	return
}
