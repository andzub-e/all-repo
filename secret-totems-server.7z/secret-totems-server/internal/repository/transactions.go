package repository

import (
	"context"

	"secret-totems/internal/models"
)

func (r Repository) CreateTransaction(ctx context.Context, trans models.Transaction) error {
	return r.conn.WithContext(ctx).Create(&trans).Error
}
