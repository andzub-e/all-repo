package repository

import (
	"fmt"
	"github.com/sirupsen/logrus"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"secret-totems/internal/config"
	"secret-totems/internal/models"
)

type Repository struct {
	log  logrus.FieldLogger
	cfg  *config.DBConfig
	conn *gorm.DB
}

func NewRepository(log logrus.FieldLogger, cfg *config.DBConfig) (Repository, error) {
	repo := Repository{
		log: log,
		cfg: cfg,
	}

	var err error
	repo.conn, err = gorm.Open(postgres.Open(repo.GetDSN()), &gorm.Config{})
	if err != nil {
		log.WithError(err).Fatal("Failed to connect conn")
	}

	err = loadMigrations(repo.conn)
	if err != nil {
		log.WithError(err).Fatal("Failed to execute migrations")
	}

	return repo, err
}

func (r *Repository) GetDSN() string {
	return fmt.Sprintf("user=%s password=%s sslmode=disable host=%s port=%s database=%s",
		r.cfg.User, r.cfg.Password, r.cfg.Host, r.cfg.Port, r.cfg.Database)
}

func loadMigrations(c *gorm.DB) error {
	return c.AutoMigrate(
		&models.Round{},
		&models.Transaction{},
		&models.CheatStops{},
	)
}
