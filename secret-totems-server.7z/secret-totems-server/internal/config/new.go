package config

type Config struct {
	HTTPConfig     *HTTPConfig
	DBConfig       *DBConfig
	OverlordConfig *OverlordConfig
}

func NewConfig() (*Config, error) {
	cfg := &Config{}

	var err error
	cfg.HTTPConfig, err = newHTTPConfig()
	if err != nil {
		return nil, err
	}

	cfg.DBConfig, err = newDBConfig()
	if err != nil {
		return nil, err
	}

	cfg.OverlordConfig, err = newOverlordConfig()
	if err != nil {
		return nil, err
	}

	return cfg, nil
}
