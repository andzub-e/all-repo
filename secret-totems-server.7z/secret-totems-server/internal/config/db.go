package config

import (
	"github.com/spf13/viper"
)

type DBConfig struct {
	Host     string
	Port     string
	Database string
	User     string
	Password string
	SSL      string
}

var db *DBConfig

func newDBConfig() (*DBConfig, error) {
	if db != nil {
		return db, nil
	}

	viper.AddConfigPath("./config")
	viper.SetConfigName("db")
	err := viper.ReadInConfig()
	if err != nil {
		return nil, err
	}

	db = &DBConfig{
		Host:     viper.GetString("host"),
		Port:     viper.GetString("port"),
		Database: viper.GetString("database"),
		User:     viper.GetString("user"),
		Password: viper.GetString("password"),
		SSL:      viper.GetString("ssl"),
	}

	return db, nil
}
