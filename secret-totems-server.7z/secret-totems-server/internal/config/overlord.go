package config

import "github.com/spf13/viper"

type OverlordConfig struct {
	Host string
	Port string
}

var overlord *OverlordConfig

func newOverlordConfig() (*OverlordConfig, error) {
	if overlord != nil {
		return overlord, nil
	}

	viper.AddConfigPath("./config")
	viper.SetConfigName("overlord")
	err := viper.ReadInConfig()
	if err != nil {
		return nil, err
	}

	overlord = &OverlordConfig{
		Host: viper.GetString("rpc_host"),
		Port: viper.GetString("rpc_port"),
	}

	return overlord, nil
}
