package config

import (
	"github.com/spf13/viper"
)

type HTTPConfig struct {
	Host string
	Port string
}

var http *HTTPConfig

func newHTTPConfig() (*HTTPConfig, error) {
	if http != nil {
		return http, nil
	}

	viper.AddConfigPath("./config")
	viper.SetConfigName("http")
	err := viper.ReadInConfig()
	if err != nil {
		return nil, err
	}

	http = &HTTPConfig{
		Host: viper.GetString("host"),
		Port: viper.GetString("port"),
	}

	return http, nil
}
