package overlord

import (
	"google.golang.org/grpc"
	"secret-totems/pkg/overlord/api"
)

func NewClient(host, port string) (api.OverlordClient, error) {

	addr := host + ":" + port
	conn, err := grpc.Dial(addr, grpc.WithInsecure())
	if err != nil {
		return nil, err
	}

	return api.NewOverlordClient(conn), nil
}
