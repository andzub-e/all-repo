package random

import (
	"crypto/rand"
	"math/big"
)

// GetInt bounds are [left:right)
func GetInt(leftBound, rightBound int64) (int64, error) {
	bi := big.NewInt(rightBound - leftBound)
	n, err := rand.Int(rand.Reader, bi)
	return n.Int64() + leftBound, err
}
