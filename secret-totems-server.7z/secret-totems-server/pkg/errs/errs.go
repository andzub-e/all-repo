package errs

import (
	"errors"
	"net/http"
)

type ErrResp struct {
	Message string `json:"error" example:"INTERNAL_SERVER_ERROR"`
	Code    int    `json:"code" example:"500"`
} //@name ErrResp

func (e ErrResp) ToError() error {
	return errors.New(e.Message)
}

func (e ErrResp) Error() string {
	return e.Message
}

var (
	SpinDidNotFinishErr   = ErrResp{"SPIN_DID_NOT_FINISH", http.StatusConflict}
	InternalServerErr     = ErrResp{"INTERNAL_SERVER_ERROR", http.StatusInternalServerError}
	BadParamInBodyErr     = ErrResp{"BAD_PARAM_IN_BODY", http.StatusBadRequest}
	WrongSessionTokenErr  = ErrResp{"WRONG_SESSION_TOKEN", http.StatusBadRequest}
	BalanceTooLowErr      = ErrResp{"INSUFFICIENT_FUNDS", http.StatusPaymentRequired}
	NoFeatureAvailableErr = ErrResp{"NO_FEATURE_AVAILABLE", http.StatusBadRequest}
	NoSpinsDidErr         = ErrResp{"NO_SPINS_DID", http.StatusBadRequest}
	ServerInternalError   = ErrResp{"SERVER_INTERNAL_ERROR", http.StatusInternalServerError}
)

func GetHttpCode(err error) int {
	if ourErr, ok := err.(ErrResp); ok {
		if ok {
			return ourErr.Code
		}
	}
	return http.StatusInternalServerError
}
