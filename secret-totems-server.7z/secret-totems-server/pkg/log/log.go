package log

import (
	"time"

	"github.com/sirupsen/logrus"
)

// GetLogEntry returns logger entity
func New() (logrus.FieldLogger, error) {
	level, err := logrus.ParseLevel("debug")
	if err != nil {
		return nil, err
	}

	logger := logrus.New()
	logger.SetLevel(level)
	logger.SetFormatter(&logrus.TextFormatter{
		ForceColors:      true,
		DisableTimestamp: false,
		FullTimestamp:    true,
		TimestampFormat:  time.RFC1123,
	})

	return logrus.NewEntry(logger), nil
}
