-- Table: public.rounds

-- DROP TABLE IF EXISTS public.rounds;

CREATE TABLE IF NOT EXISTS public.rounds
(
    round_id character varying(36) COLLATE pg_catalog."default" NOT NULL,
    game_state bytea NOT NULL,
    session_token character varying(36) COLLATE pg_catalog."default" NOT NULL,
    balance bigint NOT NULL,
    start_balance bigint NOT NULL,
    currency character varying(4) COLLATE pg_catalog."default" NOT NULL,
    used_id character varying(36) COLLATE pg_catalog."default" NOT NULL,
    operator character varying COLLATE pg_catalog."default" NOT NULL,
    is_showed boolean NOT NULL,
    start_time timestamp with time zone,
    finish_time timestamp with time zone,
    spin_indexes text COLLATE pg_catalog."default",
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT rounds_pkey PRIMARY KEY (round_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.rounds
    OWNER to postgres;