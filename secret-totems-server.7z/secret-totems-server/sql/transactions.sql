-- Table: public.transactions

-- DROP TABLE IF EXISTS public.transactions;

CREATE TABLE IF NOT EXISTS public.transactions
(
    transaction_id character varying(36) COLLATE pg_catalog."default" NOT NULL,
    type character varying(16) COLLATE pg_catalog."default" NOT NULL,
    currency character varying(36) COLLATE pg_catalog."default" NOT NULL,
    round_id character varying(36) COLLATE pg_catalog."default" NOT NULL,
    value bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT transactions_pkey1 PRIMARY KEY (transaction_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.transactions
    OWNER to postgres;