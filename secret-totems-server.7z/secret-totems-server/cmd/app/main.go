package main

import (
	"secret-totems/internal/config"
	"secret-totems/internal/repository"
	"secret-totems/internal/server"
	"secret-totems/internal/service"
	"secret-totems/pkg/log"
)

func main() {
	if err := run(); err != nil {
		panic(err)
	}
}

func run() error {
	logger, err := log.New()
	if err != nil {
		return err
	}

	cfg, err := config.NewConfig()
	if err != nil {
		return err
	}

	repo, err := repository.NewRepository(logger, cfg.DBConfig)
	if err != nil {
		return err
	}

	overlordService, err := service.NewOverlordService(logger, cfg.OverlordConfig)
	if err != nil {
		return err
	}

	coreService := service.NewCoreService(logger, repo, overlordService)
	cheatService := service.NewCheatService(logger, repo)

	handler := server.NewHandler(logger, coreService, cheatService)
	newServer := server.NewServer(logger, cfg.HTTPConfig, handler)

	return newServer.Run()
}
