package constants

const (
	GameRuleName       = "game"
	IntegratorRuleName = "integrator"
)
