package constants

type ContextKey string

const (
	CtxAdditionalDataKey ContextKey = "additional_data"
)
