package game

const (
	WindowWidth    = 7
	WindowHeight   = 9
	TopWindowWidth = 3
	MathWager      = 100
)
