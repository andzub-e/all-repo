package cryptolut_rgs

type Config struct {
	BaseURL  string
	WithLogs bool
}
