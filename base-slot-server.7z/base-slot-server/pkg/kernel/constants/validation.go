package constants

const (
	GameRuleName = "game"
)
