package services

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/utils"
	"context"
	"fmt"
	"github.com/samber/lo"
	"github.com/schollz/progressbar/v3"
	"math/big"
	"os"
	"path/filepath"
	"sync"
	"time"
)

type SimulatorConfig struct {
	GameName       string
	ReportPath     string
	Spins          int64
	Wager          int64
	Workers        int
	GenerateParams interface{}
}

type KeepGenerateWrapper func(engine.Context, engine.Spin, engine.SpinFactory) (engine.Spin, error)

type SimulatorService struct {
	boot             *engine.Bootstrap
	generateParams   interface{}
	keepGenerate     bool
	keepGenerateFunc KeepGenerateWrapper
}

func NewSimulatorService() *SimulatorService {
	return &SimulatorService{boot: engine.GetFromContainer()}
}

func (s *SimulatorService) WithKeepGenerate(f KeepGenerateWrapper) *SimulatorService {
	s.keepGenerateFunc = f

	return s
}

func (s *SimulatorService) SimulateV2(cfg *SimulatorConfig, rtp, volatility string) error {
	s.generateParams = cfg.GenerateParams

	result, err := s.Simulate(cfg.GameName, cfg.Spins, cfg.Wager, cfg.Workers)
	if err != nil {
		return fmt.Errorf("simulator error: %w", err)
	}

	reportPages := []utils.Page{{
		Name:  "Report",
		Table: utils.Transpose(utils.ExtractTable([]*SimulationView{result.View()}, "xlsx")),
	}}

	return saveReport(cfg, reportPages, rtp, volatility)
}

func saveReport(cfg *SimulatorConfig, reportPages []utils.Page, rtp, volatility string) error {
	excel, err := utils.ExportMultiPageXLSX(reportPages)
	if err != nil {
		return err
	}

	abs, err := filepath.Abs(cfg.ReportPath)
	if err != nil {
		return err
	}

	if err := os.MkdirAll(abs, os.ModePerm); err != nil {
		return err
	}

	withDash := func(str string) string {
		return lo.Ternary(str != "", fmt.Sprintf("-%s", str), "")
	}

	filename := cfg.GameName
	filename += withDash(rtp)
	filename += withDash(volatility)
	filename += withDash(time.Now().UTC().Format("2006-01-02-15-04-05"))
	filename += ".xlsx"

	file, err := os.Create(filepath.Join(abs, filename))
	if err != nil {
		return err
	}

	if err = excel.Write(file); err != nil {
		return err
	}

	return nil
}

func (s *SimulatorService) Simulate(game string, count int64, wager int64, workersCount int) (*SimulationResult, error) {
	res := &SimulationResult{
		Wager: wager,
		Count: count,
		Game:  game,

		BaseAward:  new(big.Int),
		BonusAward: new(big.Int),
		Award:      new(big.Int),
		Spent:      new(big.Int),

		BaseAwardSquareSum:  new(big.Int),
		BonusAwardSquareSum: new(big.Int),
		AwardSquareSum:      new(big.Int),

		BaseAwardStandardDeviation:  new(big.Float),
		BonusAwardStandardDeviation: new(big.Float),
		AwardStandardDeviation:      new(big.Float),
	}

	type result struct {
		Wager          int64
		BaseAward      int64
		BonusAward     int64
		BonusTriggered bool
	}
	now := time.Now()
	bar := progressbar.NewOptions64(count,
		progressbar.OptionThrottle(200*time.Millisecond),
		progressbar.OptionSetDescription("Simulating..."),
		progressbar.OptionShowCount(),
		progressbar.OptionSetWidth(50),
		progressbar.OptionShowIts(),
		progressbar.OptionOnCompletion(func() {
			fmt.Println("\nTime elapsed:", time.Since(now))
		}),
	)

	var (
		factory = s.boot.SpinFactory

		inputCh  = make(chan int64, workersCount)
		outputCh = make(chan result, workersCount)
		errCh    = make(chan error, 1)

		wg = new(sync.WaitGroup)
	)

	worker := func(wg *sync.WaitGroup, inputCh <-chan int64, outputCh chan<- result) {
		defer wg.Done()

		var prevSpin engine.Spin

		for {
			if _, ok := <-inputCh; !ok {
				return
			}

			ctx := engine.Context{Context: context.Background()}
			if prevSpin != nil {
				ctx.LastSpin = prevSpin
			}

			spin, _, err := factory.Generate(ctx, wager, s.generateParams)
			if err != nil {
				errCh <- err

				return
			}

			if s.keepGenerateFunc != nil {
				spin, err = s.keepGenerateFunc(ctx, spin, factory)
				if err != nil {
					errCh <- err

					return
				}
			}

			prevSpin = spin

			outputCh <- result{
				Wager:          spin.Wager(),
				BaseAward:      spin.BaseAward(),
				BonusAward:     spin.BonusAward(),
				BonusTriggered: spin.BonusTriggered(),
			}
		}
	}

	go func() {
		defer close(inputCh)

		for i := int64(0); i < count; i++ {
			inputCh <- i
		}
	}()

	go func() {
		for i := 0; i < workersCount; i++ {
			wg.Add(1)
			go worker(wg, inputCh, outputCh)
		}

		wg.Wait()
		close(outputCh)
	}()

	i := 0

Loop:
	for {
		select {
		case output, ok := <-outputCh:
			if !ok {
				break Loop
			}

			award := output.BaseAward + output.BonusAward

			res.BaseAward.Add(res.BaseAward, big.NewInt(output.BaseAward))
			res.BonusAward.Add(res.BonusAward, big.NewInt(output.BonusAward))
			res.Award.Add(res.Award, big.NewInt(award))
			res.Spent.Add(res.Spent, big.NewInt(output.Wager))

			if award > res.MaxExposure {
				res.MaxExposure = award
			}

			if award > 0 {
				res.BaseAwardCount++
			}

			if output.BonusTriggered {
				res.BonusGameCount++
			}

			if award >= wager*1 {
				res.X1Count++
			}

			if award >= wager*10 {
				res.X10Count++
			}

			if award >= wager*100 {
				res.X100Count++
			}

			res.BaseAwardSquareSum.Add(res.BaseAwardSquareSum, big.NewInt(0).Mul(big.NewInt(output.BaseAward), big.NewInt(output.BaseAward)))
			res.BonusAwardSquareSum.Add(res.BonusAwardSquareSum, big.NewInt(0).Mul(big.NewInt(output.BonusAward), big.NewInt(output.BonusAward)))
			res.AwardSquareSum.Add(res.AwardSquareSum, big.NewInt(0).Mul(big.NewInt(award), big.NewInt(award)))

			_ = bar.Add(1) // ignore error

			i++
		case err := <-errCh:
			return nil, err
		}
	}

	baseMeanB := new(big.Float).SetInt(res.BaseAward)
	bonusMeanB := new(big.Float).SetInt(res.BonusAward)
	totalMeanB := new(big.Float).SetInt(res.Award)

	baseMeanB.Quo(baseMeanB, big.NewFloat(float64(res.Count)))
	bonusMeanB.Quo(bonusMeanB, big.NewFloat(float64(res.Count)))
	totalMeanB.Quo(totalMeanB, big.NewFloat(float64(res.Count)))

	res.BaseAwardStandardDeviation = StandardDeviation(res.BaseAwardSquareSum, res.BaseAward, baseMeanB, res.Count)
	res.BonusAwardStandardDeviation = StandardDeviation(res.BonusAwardSquareSum, res.BonusAward, bonusMeanB, res.Count)
	res.AwardStandardDeviation = StandardDeviation(res.AwardSquareSum, res.Award, totalMeanB, res.Count)

	awardF := new(big.Float).SetInt(res.Award)
	baseF := new(big.Float).SetInt(res.BaseAward)
	bonusF := new(big.Float).SetInt(res.BonusAward)
	spentF := new(big.Float).SetInt(res.Spent)

	res.RTP, _ = new(big.Float).Quo(awardF, spentF).Float64()
	res.RTPBaseGame, _ = new(big.Float).Quo(baseF, spentF).Float64()
	res.RTPBonusGame, _ = new(big.Float).Quo(bonusF, spentF).Float64()

	return res, nil
}

type SimulationResult struct {
	Game        string   `xlsx:"Game"`
	Count       int64    `xlsx:"Count"`
	Wager       int64    `xlsx:"Wager"`
	Spent       *big.Int `xlsx:"Spent"`
	MaxExposure int64    `xlsx:"Max Exposure"`

	BaseAwardCount int64 `xlsx:"Base Award Count"`
	BonusGameCount int64 `xlsx:"Bonus Game Count"`

	X1Count   int64 `xlsx:"X1 Count"`
	X10Count  int64 `xlsx:"X10 Count"`
	X100Count int64 `xlsx:"X100 Count"`

	BaseAward  *big.Int `xlsx:"Base BaseAward"`
	BonusAward *big.Int `xlsx:"Bonus BaseAward"`
	Award      *big.Int `xlsx:"Award"`

	BaseAwardSquareSum  *big.Int `xlsx:"Base BaseAward Square Sum"`
	BonusAwardSquareSum *big.Int `xlsx:"Bonus BaseAward Square Sum"`
	AwardSquareSum      *big.Int `xlsx:"BaseAward Square Sum"`

	BaseAwardStandardDeviation  *big.Float `xlsx:"Base BaseAward Standard Deviation"`
	BonusAwardStandardDeviation *big.Float `xlsx:"Bonus BaseAward Standard Deviation"`
	AwardStandardDeviation      *big.Float `xlsx:"BaseAward Standard Deviation"`

	RTP          float64 `xlsx:"RTP"`
	RTPBaseGame  float64 `xlsx:"RTP Base Game"`
	RTPBonusGame float64 `xlsx:"RTP Bonus Game"`
}

func (r SimulationResult) View() *SimulationView {
	return &SimulationView{
		Game:        r.Game,
		Count:       fmt.Sprint(r.Count),
		Wager:       fmt.Sprint(r.Wager),
		Spent:       fmt.Sprint(r.Spent),
		MaxExposure: fmt.Sprint(r.MaxExposure),

		AwardCount: fmt.Sprint(r.BaseAwardCount),
		AwardRate:  countToRate(r.BaseAwardCount, r.Count),

		BonusGameCount: fmt.Sprint(r.BonusGameCount),
		BonusGameRate:  countToRate(r.BonusGameCount, r.Count),

		X1Count:   fmt.Sprint(r.X1Count),
		X10Count:  fmt.Sprint(r.X10Count),
		X100Count: fmt.Sprint(r.X100Count),

		X1Rate:   countToRate(r.X1Count, r.Count),
		X10Rate:  countToRate(r.X10Count, r.Count),
		X100Rate: countToRate(r.X100Count, r.Count),

		BaseAward:  r.BaseAward.String(),
		BonusAward: r.BonusAward.String(),
		Award:      r.Award.String(),

		BaseAwardSquareSum:  r.BaseAwardSquareSum.String(),
		BonusAwardSquareSum: r.BonusAwardSquareSum.String(),
		AwardSquareSum:      r.AwardSquareSum.String(),

		BaseAwardStandardDeviation:  r.BaseAwardStandardDeviation.Text('f', 3),
		BonusAwardStandardDeviation: r.BonusAwardStandardDeviation.Text('f', 3),
		AwardStandardDeviation:      r.AwardStandardDeviation.Text('f', 3),

		RTP:          floatWithPrecision(r.RTP),
		RTPBaseGame:  floatWithPrecision(r.RTPBaseGame),
		RTPBonusGame: floatWithPrecision(r.RTPBonusGame),
	}
}

type SimulationView struct {
	Game        string `xlsx:"Game"`
	Count       string `xlsx:"Count"`
	Wager       string `xlsx:"Wager"`
	Spent       string `xlsx:"Spent"`
	MaxExposure string `xlsx:"Max Exposure"`

	NewLine1 string `xlsx:""`

	AwardCount string `xlsx:"BaseAward Count"`
	AwardRate  string `xlsx:"AwardRate (Hit Rate)"`

	NewLine2 string `xlsx:""`

	BonusGameCount string `xlsx:"Bonus Game Count"`
	BonusGameRate  string `xlsx:"Bonus Game Rate"`

	NewLine3 string `xlsx:""`

	X1Count   string `xlsx:"X1 Count"`
	X10Count  string `xlsx:"X10 Count"`
	X100Count string `xlsx:"X100 Count"`

	NewLine4 string `xlsx:""`

	X1Rate   string `xlsx:"X1 Rate"`
	X10Rate  string `xlsx:"X10 Rate"`
	X100Rate string `xlsx:"X100 Rate"`

	NewLine5 string `xlsx:""`

	BaseAward  string `xlsx:"Base BaseAward"`
	BonusAward string `xlsx:"Bonus BaseAward"`
	Award      string `xlsx:"BaseAward"`

	NewLine6 string `xlsx:""`

	BaseAwardSquareSum  string `xlsx:"Base BaseAward Square Sum"`
	BonusAwardSquareSum string `xlsx:"Bonus BaseAward Square Sum"`
	AwardSquareSum      string `xlsx:"BaseAward Square Sum"`

	NewLine7 string `xlsx:""`

	BaseAwardStandardDeviation  string `xlsx:"Base BaseAward Standard Deviation"`
	BonusAwardStandardDeviation string `xlsx:"Bonus BaseAward Standard Deviation"`
	AwardStandardDeviation      string `xlsx:"BaseAward Standard Deviation"`

	NewLine8 string `xlsx:""`

	RTP          string `xlsx:"RTP"`
	RTPBaseGame  string `xlsx:"RTP Base Game"`
	RTPBonusGame string `xlsx:"RTP Bonus Game"`
}

func countToRate(count, total int64) string {
	div := float64(count) / float64(total)

	return floatWithPrecision(div) + "%"
}

func floatWithPrecision(f float64) string {
	return fmt.Sprintf("%.3f", f*100)
}

func StandardDeviation(squareSum, award *big.Int, mean *big.Float, count int64) *big.Float {
	f1 := new(big.Float).SetInt(squareSum)

	f2 := big.NewFloat(-2)
	f2.Mul(f2, mean)
	f2.Mul(f2, new(big.Float).SetInt(award))

	f3 := new(big.Float).SetInt64(int64(count))
	f3.Mul(f3, mean)
	f3.Mul(f3, mean)

	sd := big.NewFloat(0)

	sd.Add(sd, f1)
	sd.Add(sd, f2)
	sd.Add(sd, f3)

	sd.Quo(sd, new(big.Float).SetInt64(int64(count)))
	sd.Sqrt(sd)

	return sd
}
