package services

import (
	"context"

	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/entities"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/overlord"
	"github.com/google/uuid"
	"github.com/samber/lo"
	"go.uber.org/zap"
)

type GameFlowService struct {
	lord       overlord.Client
	boot       *engine.Bootstrap
	historySrv *HistoryService
	cheatsSrv  *CheatsService
}

func NewGameFlowService(lord overlord.Client, historySrv *HistoryService, cheatsSrv *CheatsService) *GameFlowService {
	return &GameFlowService{
		lord:       lord,
		boot:       engine.GetFromContainer(),
		historySrv: historySrv,
		cheatsSrv:  cheatsSrv,
	}
}

func (s *GameFlowService) InitGame(ctx context.Context,
	game, integrator string, lordParams interface{}) (*entities.GameState, error) {
	lordState, err := s.lord.InitUserState(ctx, game, integrator, lordParams)
	if err != nil {
		return nil, errs.TranslateOverlordErr(err)
	}

	state, err := entities.GameStateFromLordState(lordState)
	if err != nil {
		return nil, err
	}

	return state.
		SetEngineInfo(s.boot.GetEngineInfo()).
		SetBootInfo(s.boot.GetBootInfo()), nil
}

func (s *GameFlowService) GameState(ctx context.Context, sessionToken string) (*entities.GameState, error) {
	lordState, err := s.lord.GetStateBySessionToken(ctx, sessionToken)
	if err != nil {
		return nil, errs.TranslateOverlordErr(err)
	}

	state, err := entities.GameStateFromLordState(lordState)
	if err != nil {
		return nil, err
	}

	return state.
		SetEngineInfo(s.boot.GetEngineInfo()).
		SetBootInfo(s.boot.GetBootInfo()), nil
}

func (s *GameFlowService) Wager(ctx context.Context,
	gameState *entities.GameState, freeSpinID string, wager int64, params interface{}) (
	*entities.GameState, *entities.HistoryRecord, error) {
	isPFR := freeSpinID != ""

	if !isPFR && !lo.Contains(gameState.WagerLevels, wager) {
		return nil, nil, errs.NewInternalValidationErrorFromString(errs.OneOfListError("wager", gameState.WagerLevels))
	}

	if isPFR {
		fs, err := s.findUserFreeSpin(ctx, gameState.SessionToken, freeSpinID)
		if err != nil {
			return nil, nil, err
		}

		wager = int64(fs.Value)
	}

	if !isPFR && gameState.Balance < wager {
		return nil, nil, errs.ErrNotEnoughMoney
	}

	engCtx := s.getEngineContext(ctx, gameState)

	spin, indexes, err := s.boot.SpinFactory.Generate(engCtx, wager, params)
	if err != nil {
		return nil, nil, err
	}

	var (
		record  *entities.HistoryRecord
		award   = engine.TotalAward(spin)
		roundID = uuid.NewString()
	)

	bet, err := s.lord.AtomicBet(ctx, gameState.SessionToken.String(), freeSpinID, roundID, spin.Wager(), award)
	if err != nil {
		return nil, nil, errs.TranslateOverlordErr(err)
	}

	if isPFR {
		record = gameState.SetGeneratedFreeSpin(spin, indexes, isPFR, bet.Balance)
	} else {
		record = gameState.SetGeneratedSpin(spin, indexes, isPFR, bet.Balance)
	}

	transactionID, err := uuid.Parse(bet.TransactionId)
	if err != nil {
		// rollback
		return nil, nil, errs.ErrInternalBadData
	}

	record.SetTransactionID(transactionID)

	return gameState, record, nil
}

func (s *GameFlowService) GambleAnyWin(ctx context.Context, gameState *entities.GameState, params interface{}) (*entities.GameState, *entities.HistoryRecord, error) {
	engCtx := s.getEngineContext(ctx, gameState)

	lgr, ok := gameState.GameResults.Last()
	if !ok {
		return nil, nil, errs.ErrHistoryRecordNotFound
	}

	if !lgr.GetCanGable() {
		return nil, nil, errs.ErrCanNotGamble
	}

	spin, err := s.boot.SpinFactory.GambleAnyWin(engCtx, params)
	if err != nil {
		return nil, nil, err
	}

	roundID := uuid.NewString()
	award := spin.GambleAward()
	wager := engine.TotalAwardWithGambling(lgr.Spin)

	bet, err := s.lord.AtomicBet(ctx, gameState.SessionToken.String(), "", roundID, wager, award)
	if err != nil {
		return nil, nil, errs.TranslateOverlordErr(err)
	}

	record := gameState.UpdateLastSpin(spin, bet.Balance)

	transactionID, err := uuid.Parse(bet.TransactionId)
	if err != nil {
		// rollback
		return nil, nil, errs.ErrInternalBadData
	}

	record.SetTransactionID(transactionID)

	return gameState, record, nil
}

func (s *GameFlowService) KeepGenerating(ctx context.Context, gameState *entities.GameState, params interface{}) (*entities.GameState, *entities.HistoryRecord, error) {
	engCtx := s.getEngineContext(ctx, gameState)

	lgr, ok := gameState.GameResults.Last()
	if !ok {
		return nil, nil, errs.ErrHistoryRecordNotFound
	}

	oldSpin := lgr.Spin.DeepCopy()

	spin, ok, err := s.boot.SpinFactory.KeepGenerate(engCtx, params)
	if err != nil {
		return nil, nil, err
	}

	if !ok {
		return nil, nil, errs.ErrSpinGenerationCanNotBeContinued
	}

	var (
		roundID = uuid.NewString()
	)

	award := engine.TotalAward(spin) - engine.TotalAward(oldSpin)
	if award < 0 {
		zap.S().Errorf("negative award %v", award)

		return nil, nil, errs.ErrBadDataGiven
	}

	bet, err := s.lord.AtomicBet(ctx, gameState.SessionToken.String(), "", roundID, 0, award)
	if err != nil {
		return nil, nil, errs.TranslateOverlordErr(err)
	}

	record := gameState.UpdateLastSpin(spin, bet.Balance)

	transactionID, err := uuid.Parse(bet.TransactionId)
	if err != nil {
		zap.S().Errorf("can not parse uuid %v", bet.TransactionId)

		return nil, nil, errs.ErrInternalBadData
	}

	record.SetTransactionID(transactionID)

	return gameState, record, nil

}

func (s *GameFlowService) findUserFreeSpin(ctx context.Context, session uuid.UUID, fsID string) (*entities.FreeSpin, error) {
	pureFS, err := s.lord.GetAvailableFreeSpins(ctx, session.String())
	if err != nil {
		return nil, errs.TranslateOverlordErr(err)
	}

	fs := entities.FreeSpinsFromLord(pureFS.FreeBets)

	item, ok := lo.Find(fs, func(item *entities.FreeSpin) bool {
		return item.ID == fsID
	})

	if !ok {
		return nil, errs.ErrWrongFreeSpinID
	}

	return item, nil
}

func (s *GameFlowService) getEngineContext(ctx context.Context, gameState *entities.GameState) (engCtx engine.Context) {
	engCtx = engine.Context{Context: ctx}

	return s.bound(engCtx, gameState)
}

func (s *GameFlowService) bound(ctx engine.Context, gameState *entities.GameState) engine.Context {
	lgr, ok := gameState.GameResults.Last()
	if ok {
		ctx.LastSpin = lgr.Spin
	}

	if payload, ok := s.cheatsSrv.Get(gameState.SessionToken.String()); ok {
		ctx.Cheats = payload
	}

	if gameState.RTP != nil || gameState.Volatility != nil {
		ctx.UserParams = &engine.UserParams{
			RTP:        gameState.RTP,
			Volatility: gameState.Volatility,
		}
	}

	return ctx
}
