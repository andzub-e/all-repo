package integrations

const StatusSessionExpired = 419

const (
	StatePath   = "core/state"
	WagerPath   = "core/wager"
	HistoryPath = "core/spins_history"
)
