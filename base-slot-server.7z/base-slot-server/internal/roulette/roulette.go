package roulette

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"encoding/json"
	"github.com/sarulabs/di"
)

const (
	max        = 37
	payLine    = 18
	multiplier = 2
)

func GameBoot(ctn di.Container, config *engine.Config) *engine.Bootstrap {
	rand := ctn.Get(constants.RNGMockName).(rng.Client)
	factory := NewSpinFactory(rand)

	return &engine.Bootstrap{
		SpinFactory: factory,

		HTTPTransport:      true,
		WebsocketTransport: true,

		HistoryHandlingType: engine.SequentialRestoring,
	}
}

type SpinFactory struct {
	rand rng.Client
}

func (s *SpinFactory) UnmarshalJSONRestoringIndexes(bytes []byte) (engine.RestoringIndexes, error) {
	ri := RestoringIndexes{}

	if err := json.Unmarshal(bytes, &ri); err != nil {
		return nil, err
	}

	return &ri, nil
}

func (s *SpinFactory) SupportedSkins() []string {
	return []string{"roulette", "roulette2"}
}

func (s *SpinFactory) GameName() string {
	return "roulette"
}

func (s *SpinFactory) UnmarshalJSONSpin(bytes []byte) (engine.Spin, error) {
	spin := Spin{}
	err := json.Unmarshal(bytes, &spin)

	return &spin, err
}

func NewSpinFactory(rand rng.Client) *SpinFactory {
	return &SpinFactory{rand: rand}
}

func (s *SpinFactory) Generate(ctx engine.Context, wager int64, parameters interface{}) (engine.Spin, engine.RestoringIndexes, error) {
	randValue, err := s.rand.Rand(max)
	if err != nil {
		// TODO: translate error
		return nil, nil, err
	}

	spin := Spin{WagerVal: wager, CurrentValue: int(randValue), MaxValue: max}
	if isWon := spin.CurrentValue < payLine; isWon {
		spin.AwardVal = wager * multiplier
	}

	return &spin, &RestoringIndexes{}, nil
}

func (s *SpinFactory) GambleAnyWin(ctx engine.Context, parameters interface{}) (engine.Spin, error) {
	return ctx.LastSpin, nil
}

func (s *SpinFactory) KeepGenerate(ctx engine.Context, parameters interface{}) (engine.Spin, bool, error) {
	return ctx.LastSpin, false, nil
}
