package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/internal/roulette"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
)

func main() {
	application, err := app.New("config.yml", roulette.GameBoot)
	if err != nil {
		panic(err)
	}

	if err := application.RunOrSimulate(nil); err != nil {
		panic(err)
	}
}
