package engine

import "sync/atomic"

var (
	BaseWin  atomic.Int64
	BonusWin atomic.Int64

	NoWildsFromBaseGame    atomic.Int64
	OneWildFromBaseGame    atomic.Int64
	OneWildWin             atomic.Int64
	TwoWildsFromBaseGame   atomic.Int64
	TwoWildWin             atomic.Int64
	ThreeWildsFromBaseGame atomic.Int64
	ThreeWildWin           atomic.Int64

	ZeroRestart          atomic.Int64
	OneRestartInReSpin   atomic.Int64
	TwoRestartInReSpin   atomic.Int64
	ThreeRestartInReSpin atomic.Int64

	TotalNoWildWin    atomic.Int64
	TotalOneWildWin   atomic.Int64
	TotalTwoWildWin   atomic.Int64
	TotalThreeWildWin atomic.Int64
)
