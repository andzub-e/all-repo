package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine/utils"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"encoding/json"
	"github.com/samber/lo"
	"github.com/sarulabs/di"
)

type Info struct {
	BaseReels [][]string `json:"base_reels"`
}

func GameBoot(ctn di.Container, config *engine.Config) *engine.Bootstrap {
	rand := utils.GetRNG(ctn, config)
	factory := NewSpinFactory(rand)

	return &engine.Bootstrap{
		SpinFactory: factory,

		HTTPTransport:      true,
		WebsocketTransport: true,

		FreeSpinsFeature:    true,
		GambleAnyWinFeature: true,

		GambleAnyWinMaxTimes: 4,
		GambleAnyWinMaxWager: 125 * 100 * 1000, // 12 500 $

		GameMaxWager: 25 * 1000, // 25 $

		HistoryHandlingType: engine.SequentialRestoring,

		EngineInfo: Info{BaseReels: baseReels},
	}
}

func NewSpinFactory(rand rng.Client) *SpinFactory {
	factory := &SpinFactory{rand: rand}

	return factory
}

type SpinFactory struct {
	rand rng.Client
}

func (s *SpinFactory) Generate(ctx engine.Context, wager int64, _ interface{}) (engine.Spin, engine.RestoringIndexes, error) {
	cheats, err := getCheatsFromCtx(ctx)
	if err != nil {
		return nil, nil, err
	}

	stops, err := s.getStops(cheats, baseReels, nil)
	if err != nil {
		return nil, nil, err
	}

	ag, err := NewAwardGetter(wager)
	if err != nil {
		return nil, nil, err
	}

	sb := SpinBase{
		WagerVal: wager,
		Stops:    stops,
	}

	sb.Window.compute(baseReels, stops)
	sb.ReelsWithCrown = sb.Window.getReelsWithWild()

	windowForCalc := sb.Window.SetCrownReels(sb.ReelsWithCrown)

	sb.Win, sb.PayLinesToShow = s.calcPayLinesToShow(ag, windowForCalc)

	stats(len(sb.ReelsWithCrown), sb.Win)

	//switch len(sb.ReelsWithCrown) {
	//case 0:
	//	NoWildsFromBaseGame.Add(1)
	//	BaseWin.Add(sb.Win)
	//case 1:
	//	OneWildFromBaseGame.Add(1)
	//	OneWildWin.Add(sb.Win)
	//case 2:
	//	TwoWildsFromBaseGame.Add(1)
	//	TwoWildWin.Add(sb.Win)
	//case 3:
	//	ThreeWildsFromBaseGame.Add(1)
	//	ThreeWildWin.Add(sb.Win)
	//}

	sb.Bonus, err = s.BonusGenerate(cheats, ag, sb.ReelsWithCrown)
	if err != nil {
		return nil, nil, err
	}

	for _, bonus := range sb.Bonus {
		stats(len(bonus.ReelsWithCrown), bonus.Win)
	}

	BonusWin.Add(sb.BonusAward())

	return &sb, &RestoringIndexes{}, nil
}

func (s *SpinFactory) BonusGenerate(cheats *Cheats, ag AwardGetter, reelsWithCrown []int) ([]SpinBonus, error) {
	var bonus []SpinBonus

	previousWildedReels := make([]int, len(reelsWithCrown))
	copy(previousWildedReels, reelsWithCrown)

	if len(reelsWithCrown) == 0 {
		return nil, nil
	}

	for {
		stops, err := s.getStops(cheats, wildedReels, previousWildedReels)
		if err != nil {
			return nil, err
		}

		spinBonus := SpinBonus{ReelsWithCrown: append([]int{}, previousWildedReels...), Stops: stops}
		spinBonus.Window.compute(wildedReels, stops)

		reelsWithWild := spinBonus.Window.getReelsWithWild()

		_, dif := lo.Difference(spinBonus.ReelsWithCrown, reelsWithWild)
		if len(dif) != 0 {
			spinBonus.NewReelTriggered = dif
			spinBonus.ReelsWithCrown = append(spinBonus.ReelsWithCrown, dif...)
		}

		windowForCalc := spinBonus.Window.SetCrownReels(spinBonus.ReelsWithCrown)
		spinBonus.Win, spinBonus.PayLinesToShow = s.calcPayLinesToShow(ag, windowForCalc)

		bonus = append(bonus, spinBonus)

		previousWildedReels = make([]int, len(spinBonus.ReelsWithCrown))
		copy(previousWildedReels, spinBonus.ReelsWithCrown)

		if len(spinBonus.NewReelTriggered) == 0 {
			break
		}
	}

	return bonus, nil
}

func (s *SpinFactory) GambleAnyWin(ctx engine.Context, parameters interface{}) (engine.Spin, error) {
	award := engine.TotalAwardWithGambling(ctx.LastSpin)

	if award == 0 {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin, ok := ctx.LastSpin.(*SpinBase)
	if !ok {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin = typedSpin.deepCopy()

	payload, err := parseGambleParams(parameters)

	if payload.Color != GambleRed && payload.Color != GambleBlack {
		return nil, errs.ErrBadDataGiven
	}

	if err != nil {
		return nil, err
	}

	res, err := s.rand.Rand(2)
	if err != nil {
		return nil, err
	}

	g := Gamble{ExpectColor: payload.Color, WagerVal: award}

	c := Cheats{}
	if ctx.Cheats != nil {
		if err := c.Eval(ctx.Cheats); err != nil {
			return nil, err
		}
	}

	if c.GambleColor == GambleRed || c.GambleColor == GambleBlack {
		g.RealColor = c.GambleColor
	} else if res == 1 {
		g.RealColor = GambleRed
	} else {
		g.RealColor = GambleBlack
	}

	g.compute()

	typedSpin.Gambles = append(typedSpin.Gambles, g)

	return typedSpin, nil
}

func (s *SpinFactory) KeepGenerate(ctx engine.Context, _ interface{}) (engine.Spin, bool, error) {
	return ctx.LastSpin, false, nil
}

func (s *SpinFactory) UnmarshalJSONSpin(bytes []byte) (engine.Spin, error) {
	spin := SpinBase{}
	err := json.Unmarshal(bytes, &spin)

	return &spin, err
}

func (s *SpinFactory) UnmarshalJSONRestoringIndexes(bytes []byte) (engine.RestoringIndexes, error) {
	restoringIndexes := RestoringIndexes{}
	err := json.Unmarshal(bytes, &restoringIndexes)

	return &restoringIndexes, err
}

func (s *SpinFactory) getStops(cheats *Cheats, reels [][]string, reelsWithCrown []int) ([]int, error) {
	if cheats != nil {
		if cheats.BonusSpinsCount > 0 {
			cheats.BonusSpinsCount--

			return getBonusStops(s.rand, reelsWithCrown, reels)
		}

		if cheats.Stops == nil {
			return s.randStops(reels)
		}

		// used to get cheats.Stops only once
		// to make random stops if wild appears
		defer func() {
			cheats.Stops = nil
		}()

		if len(cheats.Stops) != len(reels) {
			return nil, errs.ErrBadDataGiven
		}

		for i := range cheats.Stops {
			if cheats.Stops[i] > len(reels[i]) {
				return nil, errs.ErrBadDataGiven
			}
		}

		return cheats.Stops, nil
	}

	return s.randStops(reels)
}

func (s *SpinFactory) randStops(reels [][]string) ([]int, error) {
	req := lo.Map(reels, func(item []string, index int) uint64 {
		return uint64(len(item))
	})

	res, err := s.rand.RandSlice(req)
	if err != nil {
		return nil, err
	}

	return lo.Map(res, func(item uint64, index int) int {
		return int(item)
	}), nil
}

func (s *SpinFactory) calcPayLinesToShow(ag AwardGetter, window *Window) (award int64, payLinesToShow []PayLine) {
	leftPls := utils.CalcBasePayLines[int, string](payLines, window, ag, nil, &WildSymbol, utils.LeftToRightDirection)
	rightPls := utils.CalcBasePayLines[int, string](payLines, window, ag, nil, &WildSymbol, utils.RightToLeftDirection)

	leftPlsMap := lo.SliceToMap(leftPls, func(item utils.PayLine[int, string]) (int, utils.PayLine[int, string]) {
		return item.PayLineIndex, item
	})

	rightPls = lo.Filter(rightPls, func(rightPayLine utils.PayLine[int, string], index int) bool {
		leftPayLine, ok := leftPlsMap[rightPayLine.PayLineIndex]
		if !ok {
			return true
		}

		if len(leftPayLine.PayLineItems) == windowWidth {
			return false
		}

		if leftPayLine.Award >= rightPayLine.Award {
			return false
		}

		delete(leftPlsMap, rightPayLine.PayLineIndex)

		return true
	})

	pls := append(lo.Values(leftPlsMap), rightPls...)

	lo.ForEach(pls, func(item utils.PayLine[int, string], index int) {
		payLinesToShow = append(payLinesToShow, PayLine{
			Symbol:    item.PaySymbol,
			Direction: item.Direction,

			PayLineIndex: item.PayLineIndex,
			Indexes:      item.PayLineItems,
			Award:        item.Award,
		})

		award += item.Award
	})

	return award, payLinesToShow
}

func stats(crownQty int, award int64) {
	switch crownQty {
	case 0:
		ZeroRestart.Add(1)
		TotalNoWildWin.Add(award)
	case 1:
		OneRestartInReSpin.Add(1)
		TotalOneWildWin.Add(award)
	case 2:
		TwoRestartInReSpin.Add(1)
		TotalTwoWildWin.Add(award)
	case 3:
		ThreeRestartInReSpin.Add(1)
		TotalThreeWildWin.Add(award)
	}
}
