package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"github.com/samber/lo"
)

const (
	Base  = 0
	Crown = 1
)

var bonusSettings = map[int][]int{
	1: {Base, Crown, Base, Base, Base},
	2: {Base, Base, Crown, Base, Base},
	3: {Base, Base, Base, Crown, Base},
}

func getBonusStops(rng rng.Client, reelsWithCrown []int, reels [][]string) ([]int, error) {
	nextPossibleCrownReels, _ := lo.Difference([]int{1, 2, 3}, reelsWithCrown)

	if len(nextPossibleCrownReels) == 0 {
		return []int{0, 0, 0, 0, 0}, nil
	}

	index, err := rng.Rand(uint64(len(nextPossibleCrownReels)))
	if err != nil {
		return nil, err
	}

	stops := make([]int, windowWidth)
	for i, symbol := range bonusSettings[nextPossibleCrownReels[index]] {
		var (
			stop    int
			randMax uint64
		)

		switch symbol {
		case Base:
			randMax = uint64(len(reels[i]))

		case Crown:
			randMax = windowHeight
			// to cover random value between 2 and 4 where we have wild symbol
			// 0 0 | 0 0 w | 0 0
			// 0 1 _ 2 3 4 _ 5 6
			stop += 2
		}

	Again:
		value, err := rng.Rand(randMax)
		if err != nil {
			return nil, err
		}

		stops[i] = stop + int(value)

		if symbol != Crown {
			for j := 0; j < windowHeight; j++ {
				symbolIndex := mod(stop-i, len(reels[i]))

				// wild symbol can appear only on the defined reel
				if reels[i][symbolIndex] == WildSymbol {
					goto Again
				}
			}
		}
	}

	return stops, nil
}

func mod(a, b int) int {
	return (a%b + b) % b
}
