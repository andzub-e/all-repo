package engine

import "errors"

type AwardGetter struct {
	Wager int64
}

func NewAwardGetter(wager int64) (AwardGetter, error) {
	if wager < 0 {
		return AwardGetter{}, errors.New("wager must be greater than 0")
	}

	return AwardGetter{Wager: wager}, nil
}

func (a AwardGetter) GetAward(symbol string, size int) int64 {
	mul := multipliers[symbol][size]

	return mul * a.Wager / multiplicationDivider
}
