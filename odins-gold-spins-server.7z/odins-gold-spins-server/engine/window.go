package engine

import (
	"github.com/samber/lo"
	"go.uber.org/zap"
)

type Window [][]string

func (w *Window) GetSymbol(_, payItem int) string {
	return w.symbol(payItem)
}

func (w *Window) GetByIndexes(reelIndex, symbolIndex int) (int, string) {
	return symbolIndex*windowWidth + reelIndex, (*w)[reelIndex][symbolIndex]
}

func (w *Window) GetHeight() int {
	return windowHeight
}

func (w *Window) GetWidth() int {
	return windowWidth
}

func (w *Window) compute(reels [][]string, stops []int) {
	*w = lo.Map(stops, func(stop int, index int) []string {
		reel := reels[index]
		reelLen := len(reel)

		windowLine := make([]string, windowHeight)
		for j := 0; j < windowHeight; j++ {
			windowLine[j] = reel[(stop+j)%reelLen]
		}

		return windowLine
	})
}

func (w Window) symbol(payIndex int) string {
	position, reel := payIndex/windowWidth, payIndex%windowWidth

	return w[reel][position]
}

func (w Window) getReelsWithWild() []int {
	reelsWithWild := make([]int, 0)

	for i := 0; i < windowWidth; i++ {
		if lo.Contains(w[i], WildSymbol) {
			reelsWithWild = append(reelsWithWild, i)
		}
	}

	return reelsWithWild
}

func (w Window) deepCopy() Window {
	dc := make(Window, len(w))

	for i := 0; i < len(w); i++ {
		line := make([]string, len(w[i]))
		copy(line, w[i])
		dc[i] = line
	}

	return dc
}

func (w Window) SetCrownReels(reels []int) *Window {
	w = w.deepCopy()

	for _, reelIndex := range reels {
		if reelIndex < windowWidth && reelIndex >= 0 {
			w[reelIndex] = lo.Map(w[reelIndex], func(item string, index int) string {
				return WildSymbol
			})
		} else {
			zap.S().Errorf("wrong reel indexes: %v", reels)
		}
	}

	return &w
}
