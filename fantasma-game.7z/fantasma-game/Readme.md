# Proxies games

This repository clone all other repositories by tag and build all games into one docker image and make nginx proxy for all games.

games.yaml file example
```yaml
# this base repository url repo need be like this  git@bitbucket.org:electronicjaw/sunny-wins-server.git
baseRepo: git@bitbucket.org:electronicjaw/

# list of games and their tags need to build
games:
  sunny-wins:
    tag: 1.0.1
  # Example
  <game-name>:
    tag: <repository tag for deploy>
```
After adding game in games.yaml you need add ssh key this repository to game repository (sunny-wins-server)  and to all dependency repository (base-slot-server, base-slot-fantasma-server etc)

When you want update game tag change game tag in games.yaml  and push to master branch after this, bitbucket-pipelines make build and send image to container registry (rg.fr-par.scw.cloud/ejaw/fantasma-games:master.<COMMIT_SHORT:7>). 
After pushing to container registry you can run this image with mounting config files into container in /games/<game-name>/config.fantasma.yaml and open port <YOUR_PORT>:80, and after you can open your local port and play game.