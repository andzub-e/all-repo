#!/bin/bash

set -x

if ! command -v yq &> /dev/null
then
    echo "yq is not installed. Installing now..."
    apt-get update && apt-get install -y yq
else
    echo "yq is already installed."
fi

games_yaml="games.yaml"

# Ensure Bash version supports associative arrays
if ((BASH_VERSINFO[0] < 4)); then
    echo "Bash version 4 or greater is required."
    exit 1
fi

# Check if the YAML file exists and is readable
if [[ ! -r "$games_yaml" ]]; then
    echo "Error: Unable to read the file '$games_yaml'"
    exit 1
fi

declare -A games_info

mapfile -t keys < <(yq -r '.games | keys' "$games_yaml")

for key in "${keys[@]}"; do
    key="${key#- }"
    tag=$(yq -r ".games.\"$key\".tag" "$games_yaml")

    if [[ -z "$tag" ]]; then
        echo "Error: Missing port for $key"
        continue
    fi

    games_info["$key"]=$tag

done

echo games_info

baseRepo=$(yq -r ".baseRepo" "$games_yaml")
blocks=""


for name in "${!games_info[@]}"; do
   tag=${games_info[$name]}
   repo_url="$baseRepo$name-server.git"
   blocks+="\nRUN git clone --depth 1 --branch $tag  $repo_url ./$name \nRUN mkdir -p \"bin/games/$name\" \nRUN cd $name \&\& go mod download \nRUN cd $name \&\& set -x; apk add --no-cache \&\& CGO_ENABLED=0 go build -ldflags=\"-s -w\" -o ../bin/games/$name/$name cmd/main.go \n"
done




cat <<EOF > Dockerfile
FROM golang:1.21.4-alpine3.18 as builder

ARG SSH_KEY=""
ARG MODE

WORKDIR /app

RUN apk update && apk add --no-cache openssh-client git
RUN mkdir /root/.ssh/

RUN if [ "\$MODE" = "local" ]; \
    then cat id_rsa > ~/.ssh/id_rsa; \
    else echo "\$SSH_KEY" > /root/.ssh/id_rsa; \
    fi

RUN chmod 600 /root/.ssh/id_rsa
RUN ssh-keyscan -T 60 bitbucket.org >> /root/.ssh/known_hosts
RUN eval "\$(ssh-agent -s)"
RUN git config --global url."git@bitbucket.org:".insteadOf "https://bitbucket.org/"
RUN go env -w GOPRIVATE="bitbucket.org/electronicjaw/*"

RUN mkdir -p "bin"
RUN mkdir -p "bin/games"


#BLOCKS#


# Debian image
FROM debian:bookworm

WORKDIR /games

COPY --from=builder /app/bin/games/ .

RUN apt-get update && apt-get install -y nginx yq supervisor

COPY games.yaml games.yaml
COPY entrypoint.sh .
RUN chmod +x entrypoint.sh
EXPOSE 80

ENTRYPOINT ["./entrypoint.sh"]
EOF
sed -i "s|#BLOCKS#|$blocks|" Dockerfile