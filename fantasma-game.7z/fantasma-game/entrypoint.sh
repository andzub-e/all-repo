#!/bin/bash

#set -x

games_yaml="games.yaml"

# Ensure Bash version supports associative arrays
if ((BASH_VERSINFO[0] < 4)); then
    echo "Bash version 4 or greater is required."
    exit 1
fi

# Check if the YAML file exists and is readable
if [[ ! -r "$games_yaml" ]]; then
    echo "Error: Unable to read the file '$games_yaml'"
    exit 1
fi

declare -A games_info

# Extract keys (game names)
mapfile -t keys < <(yq -r '.games | keys[]' "$games_yaml")

for key in "${keys[@]}"; do

    port=$(yq -r ".server.port" "/games/$key/config.fantasma.yml")

    if [[ -z "$port" ]]; then
        echo "Error: Missing port for $key"
        continue
    fi

    games_info["$key"]=$port

done

yq -r '{ejaw: .games | keys}' "$games_yaml" > /var/www/games.json

location_blocks=""
supervisor_blocks=""

for name in "${!games_info[@]}"; do
    port=${games_info[$name]}
    location_blocks+="\n location /api/games/$name/ { \n proxy_pass http://127.0.0.1:$port/api/games/; \n } \n"
    supervisor_blocks+="\n[program:$name]\ncommand=/games/$name/$name --port $port \ndirectory=/games/$name/ \nautostart=true \nautorestart=true \nenvironment=PORT=\"$port\",BASE_SLOT_FANTASMA=fantasma"
done

cat <<EOF > /etc/nginx/nginx.conf
worker_processes auto;

error_log /var/log/nginx/error.log;
pid /run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
        default_type application/octet-stream;

        log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                        '$status $body_bytes_sent "$http_referer" '
                        '"$http_user_agent" "$http_x_forwarded_for"';

        access_log /var/log/nginx/access.log main;

        sendfile on;
        keepalive_timeout 65;

    server {

        listen 80;
         location /api/games {
            default_type application/json;
            index games.json;
            alias /var/www/;
        }

        #LOCATION_BLOCKS#

    }
}
EOF
sed -i "s|#LOCATION_BLOCKS#|$location_blocks|" /etc/nginx/nginx.conf

cat <<EOF > /etc/supervisor/conf.d/supervisord.conf
[supervisord]
nodaemon=true

#SUPERVISOR_BLOCKS#

[program:nginx]
command=nginx -g 'daemon off;'
autostart=true
autorestart=true
EOF
sed -i "s|#SUPERVISOR_BLOCKS#|$supervisor_blocks|" /etc/supervisor/conf.d/supervisord.conf


/usr/bin/supervisord