package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"go.uber.org/zap"
)

type SpinBase struct {
	WagerVal       int64     `json:"wager"`
	Win            int64     `json:"award"`
	Stops          []int     `json:"stops"`
	Window         Window    `json:"window"`
	PayLinesToShow []PayLine `json:"pay_lines_to_show"`
	Gambles        []Gamble  `json:"gambles"`

	ReelsWithCrown []int       `json:"reels_with_crown"`
	Bonus          []SpinBonus `json:"bonus"`
}

type SpinBonus struct {
	Win            int64     `json:"award"`
	Stops          []int     `json:"stops"`
	Window         Window    `json:"window"`
	PayLinesToShow []PayLine `json:"pay_lines_to_show"`
	Gambles        []Gamble  `json:"gambles"`

	ReelsWithCrown   []int `json:"reels_with_crown"`
	NewReelTriggered []int `json:"new_reel_triggered"`
}

func (s *SpinBase) GambleAward() int64 {
	var award int64

	if len(s.Gambles) > 0 {
		award = s.Gambles[len(s.Gambles)-1].Win
	}

	return award
}

func (s *SpinBase) DeepCopy() engine.Spin {
	return s.deepCopy()
}

func (s *SpinBase) deepCopy() *SpinBase {
	spin := &SpinBase{
		WagerVal:       s.WagerVal,
		Win:            s.Win,
		Stops:          s.Stops,
		Window:         s.Window.deepCopy(),
		PayLinesToShow: make([]PayLine, len(s.PayLinesToShow)),
		Gambles:        make([]Gamble, len(s.Gambles)),
		ReelsWithCrown: make([]int, len(s.ReelsWithCrown)),
		Bonus:          make([]SpinBonus, len(s.Bonus)),
	}

	copy(spin.Bonus, s.Bonus)
	copy(spin.ReelsWithCrown, s.ReelsWithCrown)
	copy(spin.PayLinesToShow, s.PayLinesToShow)
	copy(spin.Gambles, s.Gambles)

	return spin
}

func (s *SpinBase) BaseAward() int64 {
	return s.Win
}

func (s *SpinBase) BonusAward() int64 {
	var award int64

	for _, sb := range s.Bonus {
		award += sb.Win
	}

	return award
}

func (s *SpinBase) Wager() int64 {
	return s.WagerVal
}

func (s *SpinBase) CanGamble(restoringIndexes engine.RestoringIndexes) bool {
	restoringIndexesTyped, ok := restoringIndexes.(*RestoringIndexes)

	if !ok {
		zap.S().Error("can not parse restoring indexes")

		return true
	}

	return !restoringIndexesTyped.IsGambleCollected
}

func (s *SpinBase) GambleQuantity() int {
	return len(s.Gambles)
}

func (s *SpinBase) BonusTriggered() bool {
	return len(s.Bonus) > 0
}

type PayLine struct {
	Symbol       string `json:"symbol"`
	Direction    string `json:"direction"`
	PayLineIndex int    `json:"index"`
	Indexes      []int  `json:"indexes"`
	Award        int64  `json:"award"`
}
