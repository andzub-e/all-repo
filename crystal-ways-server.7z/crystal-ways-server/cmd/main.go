package main

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/app"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/config"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/constants"
	"crystal-ways-server/engine"
	"fmt"
)

func main() {
	application, err := app.New("config.yml", engine.GameBoot)
	if err != nil {
		panic(err)
	}

	if err := application.RunOrSimulate(nil); err != nil {
		panic(err)
	}

	cfg := application.Ctn().Get(constants.ConfigName).(*config.Config).SimulatorConfig

	fmt.Println("Base: ", engine.BaseWin.Load())
	fmt.Println("Bonus: ", engine.BonusWin.Load())

	fmt.Println("NoWildsFromBaseGame: ", engine.NoWildsFromBaseGame.Load())

	fmt.Println("OneWildFromBaseGame: ", engine.OneWildFromBaseGame.Load())
	fmt.Println("OneWildWin: ", engine.OneWildWin.Load())

	fmt.Println("TwoWildsFromBaseGame: ", engine.TwoWildsFromBaseGame.Load())
	fmt.Println("TwoWildsWin: ", engine.TwoWildWin.Load())

	fmt.Println("ThreeWildsFromBaseGame: ", engine.ThreeWildsFromBaseGame.Load())
	fmt.Println("ThreeWildsWin: ", engine.ThreeWildWin.Load())

	fmt.Println("ZeroRestart: ", engine.ZeroRestart.Load())
	fmt.Println("OneRestartInReSpin: ", engine.OneRestartInReSpin.Load())
	fmt.Println("TwoRestartInReSpin: ", engine.TwoRestartInReSpin.Load())
	fmt.Println("ThreeRestartInReSpin: ", engine.ThreeRestartInReSpin.Load())

	spend := cfg.Spins * cfg.Wager

	fmt.Println("TotalNoWildWin: ", engine.TotalNoWildWin.Load())
	fmt.Println("TotalOneWildWin: ", engine.TotalOneWildWin.Load())
	fmt.Println("TotalTwoWildWin: ", engine.TotalTwoWildWin.Load())
	fmt.Println("TotalThreeWildWin: ", engine.TotalThreeWildWin.Load())

	fmt.Println("TotalNoWildWin rtp: ", rtp(engine.TotalNoWildWin.Load(), spend))
	fmt.Println("TotalOneWildWin rtp: ", rtp(engine.TotalOneWildWin.Load(), spend))
	fmt.Println("TotalTwoWildWin rtp: ", rtp(engine.TotalTwoWildWin.Load(), spend))
	fmt.Println("TotalThreeWildWin rtp: ", rtp(engine.TotalThreeWildWin.Load(), spend))
}

func rtp(win int64, spend int64) float64 {
	return float64(win) / float64(spend)
}
