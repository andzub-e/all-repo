package overlord

import (
	"context"
	"encoding/json"
	"go.uber.org/zap"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

type Client interface {
	InitUserState(ctx context.Context, game, operator string, lordParams interface{}) (state *InitUserStateOut, err error)
	GetStateBySessionToken(ctx context.Context, token string) (*InitUserStateOut, error)
	OpenBet(ctx context.Context, sessionToken, roundID, currency string, value int64) (*OpenBetResponse, error)
	OpenFreeBet(ctx context.Context, sessionToken, freeBetID, roundID string) (*OpenBetResponse, error)
	CloseBet(ctx context.Context, transactionID, currency string, value int64) (*CloseBetResponse, error)
	RollbackBet(ctx context.Context, transactionID, currency string) (*RollbackResponse, error)
	GetFreeSpins(ctx context.Context, token string) (*GetAvailableFreeBetsOut, error)
	GetCurrencies(ctx context.Context) ([]string, error)
}

type client struct {
	api OverlordClient
}

type Config struct {
	Host string
	Port string
}

type OpenBetResponse struct {
	TransactionID string
	Currency      string
	Balance       int64
}

type CloseBetResponse struct {
	Currency string
	Balance  int64
}

type RollbackResponse struct {
	Currency string
	Balance  int64
}

func newClient(host, port string) (OverlordClient, error) {
	addr := host + ":" + port
	conn, err := grpc.Dial(addr, grpc.WithTransportCredentials(insecure.NewCredentials()))

	if err != nil {
		return nil, err
	}

	return NewOverlordClient(conn), nil
}

func NewClient(cfg *Config) (Client, error) {
	var err error

	service := &client{}
	service.api, err = newClient(cfg.Host, cfg.Port)

	if err != nil {
		return service, err
	}

	return service, nil
}

func (o *client) GetCurrencies(ctx context.Context) ([]string, error) {
	res, err := o.api.GetAvailableCurrencies(ctx, &GetAvailableCurrenciesIn{})
	if err != nil {
		return nil, err
	}

	return res.Currencies, nil
}

func (o *client) GetStateBySessionToken(ctx context.Context, token string) (*InitUserStateOut, error) {
	zap.S().Info("repo: GetStateBySessionToken starting...")

	in := &GetStateBySessionTokenIn{SessionToken: token}

	state, err := o.api.GetStateBySessionToken(ctx, in)
	if err != nil {
		return state, mapError(err)
	}

	return state, nil
}

func (o *client) InitUserState(ctx context.Context,
	game, operator string, lordParams interface{}) (state *InitUserStateOut, err error) {
	zap.S().Info("repo: InitUserState starting...")

	// Create API request
	initUserStateIn := &InitUserStateIn{
		Operator: operator,
		Game:     game,
	}

	initUserStateIn.Params, err = json.Marshal(lordParams)
	if err != nil {
		zap.S().Error(err)

		return nil, ErrMarshaling
	}

	res, err := o.api.InitUserState(ctx, initUserStateIn)
	if err != nil {
		return nil, mapError(err)
	}

	return res, nil
}

func (o *client) OpenBet(ctx context.Context,
	sessionToken, roundID, currency string, value int64) (*OpenBetResponse, error) {
	p := &OpenBetIn{SessionToken: sessionToken, RoundId: roundID, Currency: currency, Value: value}

	bet, err := o.api.OpenBet(ctx, p)

	if err != nil {
		return nil, mapError(err)
	}

	y := &OpenBetResponse{TransactionID: bet.TransactionId, Currency: bet.Currency, Balance: bet.Balance}

	return y, nil
}

func (o *client) OpenFreeBet(ctx context.Context, sessionToken, freeBetID, roundID string) (*OpenBetResponse, error) {
	p := &OpenFreeBetIn{SessionToken: sessionToken, FreeBetId: freeBetID, RoundId: roundID}

	bet, err := o.api.OpenFreeBet(ctx, p)
	if err != nil {
		return nil, mapError(err)
	}

	y := &OpenBetResponse{TransactionID: bet.TransactionId, Currency: bet.Currency, Balance: bet.Balance}

	return y, nil
}

func (o *client) CloseBet(ctx context.Context, transactionID, currency string, value int64) (*CloseBetResponse, error) {
	p := &CloseBetIn{TransactionId: transactionID, Currency: currency, Value: value}
	bet, err := o.api.CloseBet(ctx, p)

	if err != nil {
		return nil, err
	}

	y := &CloseBetResponse{Currency: bet.Currency, Balance: bet.Balance}

	return y, nil
}

func (o *client) RollbackBet(ctx context.Context, transactionID, currency string) (*RollbackResponse, error) {
	r := &RollbackIn{TransactionId: transactionID, Currency: currency}
	bet, err := o.api.RollbackBet(ctx, r)

	if err != nil {
		return nil, err
	}

	y := &RollbackResponse{Currency: bet.Currency, Balance: bet.Balance}

	return y, nil
}

func (o *client) GetFreeSpins(ctx context.Context, token string) (*GetAvailableFreeBetsOut, error) {
	zap.S().Info("repo: GetFreeSpins starting...")

	in := &GetAvailableFreeBetsIn{SessionToken: token}

	freeBets, err := o.api.GetAvailableFreeBets(ctx, in)
	if err != nil {
		return freeBets, mapError(err)
	}

	return freeBets, err
}
