package redis

type Config struct {
	Host string
	Port string
	Pass string
}
