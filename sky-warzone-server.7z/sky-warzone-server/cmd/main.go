package main

import (
	"base-slot/internal/bot"
	"base-slot/internal/constants"
	"base-slot/internal/container"
	"base-slot/internal/http"
	"base-slot/internal/services"
	"base-slot/internal/validator"
	"base-slot/utils"
	"context"
	"github.com/gin-gonic/gin/binding"
	"go.uber.org/zap"
	"log"
	"sync"
	"time"
)

func main() {
	now := time.Now()
	ctx := context.Background()
	wg := &sync.WaitGroup{}
	app := container.Build(ctx, wg, false)

	var (
		logger      = app.Get(constants.LoggerName).(*zap.Logger)
		server      = app.Get(constants.ServerName).(*http.Server)
		validation  = app.Get(constants.ValidatorName).(*validator.Validator)
		distributor = app.Get(constants.DistributorName).(services.Distributor)
		control     = app.Get(constants.PlaneControlName).(services.PlaneControlService)
		prepare     = app.Get(constants.PrepareServiceName).(services.PrepareService)
		botSrv      = app.Get(constants.BotServiceName).(bot.Service)
	)

	logger.Info("Starting preparing...")

	err := prepare.CloseAllOpenWagers(ctx)
	if err != nil {
		log.Fatal(err)
	}

	logger.Info("Starting application...")

	binding.Validator = validation

	go server.Run()

	//goland:noinspection ALL
	go control.Start()
	go distributor.Start()
	go botSrv.Start()

	zap.S().Infof("Up and running (%s)", time.Since(now))
	zap.S().Infof("Got %s signal. Shutting down...", <-utils.WaitTermSignal())

	zap.S().Info("Shutdown flights...")
	control.StopFlightsAndWait() // wait to end round

	if err := server.Shutdown(ctx); err != nil {
		zap.S().Errorf("Error stopping server: %s", err)
	}

	wg.Wait()
	zap.S().Info("Service stopped.")
}
