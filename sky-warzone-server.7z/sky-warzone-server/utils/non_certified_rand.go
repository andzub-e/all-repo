package utils

import (
	cryptoRand "crypto/rand"
	"errors"
	"math/big"
)

func InRange(from, to int64) (int64, error) {
	if from > to {
		return 0, errors.New("from > to")
	}

	n, err := cryptoRand.Int(cryptoRand.Reader, big.NewInt(to-from))
	if err != nil {
		return 0, err
	}

	return n.Int64() + from, nil
}
