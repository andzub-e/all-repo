package tests

func panicIfNN(err ...error) {
	for _, e := range err {
		if e != nil {
			panic(e)
		}
	}
}
