package entities

import (
	"base-slot/pkg/overlord"
)

type GameState struct {
	UserID       string `json:"user_id"`
	Username     string `json:"username"`
	SessionToken string `json:"session_token"`
	Game         string `json:"game"`

	Currency     string  `json:"currency"`
	Balance      int64   `json:"balance"`
	WagerLevels  []int64 `json:"wager_levels"`
	DefaultWager int64   `json:"default_wager"`
}

func (gs *GameState) SetGeneratedSpin(spin Flight) *HistoryRecord {
	//newBalance := gs.Balance + spin.Award() + spin.BonusAward() - spin.Wager()
	hr := HistoryRecord{
		//	ID:           uuid.New(),
		//	Game:         gs.Game,
		//	UserID:       gs.UserID,
		//	Currency:     gs.Currency,
		//	StartBalance: gs.Balance,
		//	EndBalance:   newBalance,
		//	BaseAward:    spin.Award(),
		//	BonusAward:   spin.BonusAward(),
		//
		//	Spin: spin,
		//
		//	CreatedAt: time.Now(),
	}
	//
	//gs.Spin = spin
	//gs.Balance = newBalance

	return &hr
}

func GameStateFromLordState(state *overlord.InitUserStateOut) *GameState {
	return &GameState{
		UserID:       state.UserId,
		SessionToken: state.SessionToken,
		Game:         state.Game,
		Username:     state.Username,
		Currency:     state.Currency,
		Balance:      state.Balance,
		WagerLevels:  state.WagerLevels,
		DefaultWager: state.DefaultWager,
	}
}
