package entities

//type Round struct {
//}
