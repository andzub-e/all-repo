package container

import (
	"base-slot/internal/config"
	"base-slot/internal/constants"
	"base-slot/internal/engines/airport"
	"base-slot/internal/engines/coefficient"
	"base-slot/internal/engines/plane"
	"github.com/sarulabs/di"
)

func BuildEngine() []di.Def {
	return []di.Def{
		{
			Name: constants.PlaneGeneratorName,
			Build: func(ctn di.Container) (interface{}, error) {
				cfg := ctn.Get(constants.ConfigName).(*config.Config)
				coe := ctn.Get(constants.CoefficientFactoryName).(coefficient.Factory)

				return plane.NewGenerator(coe, *cfg.FlyConfig), nil
			},
		},
		{
			Name: constants.AirportName,
			Build: func(ctn di.Container) (interface{}, error) {
				pln := ctn.Get(constants.PlaneGeneratorName).(plane.Generator)

				return airport.NewAirPort(pln), nil
			},
		},
		{
			Name: constants.CoefficientFactoryName,
			Build: func(ctn di.Container) (interface{}, error) {
				return coefficient.NewMockCoefficientGenerator(), nil
			},
		},
	}
}
