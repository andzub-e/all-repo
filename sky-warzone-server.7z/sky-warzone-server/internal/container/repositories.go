package container

import (
	"base-slot/internal/constants"
	"base-slot/internal/repositories"
	"github.com/sarulabs/di"
	"gorm.io/gorm"
)

func BuildRepositories() []di.Def {
	return []di.Def{
		{
			Name: constants.HistoryRepositoryName,
			Build: func(ctn di.Container) (interface{}, error) {
				conn := ctn.Get(constants.PgSQLName).(*gorm.DB)
				return repositories.NewHistoryRepository(conn), nil
			},
		},
		{
			Name: constants.MetricsRepositoryName,
			Build: func(ctn di.Container) (interface{}, error) {
				conn := ctn.Get(constants.PgSQLName).(*gorm.DB)
				return repositories.NewMetricsPgSQLRepository(conn), nil
			},
		},
		//{
		//	Name: constants.RedisRepositoryName,
		//	Build: func(ctn di.Container) (interface{}, error) {
		//		rd := ctn.Get(constants.RedisName).(*redis.Client)
		//
		//		return repositories.NewRedisRound(rd), nil
		//	},
		//},
	}
}
