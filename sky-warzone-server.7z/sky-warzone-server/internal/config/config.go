package config

import (
	"base-slot/internal/bot"
	"base-slot/internal/constants"
	"base-slot/internal/engines/plane"
	"base-slot/internal/http"
	"base-slot/internal/websocket"
	"base-slot/pkg/overlord"
	"base-slot/pkg/pgsql"
	"base-slot/pkg/redis"
	"base-slot/pkg/rng"
	"github.com/spf13/viper"
	"sync"
)

var config *Config
var once sync.Once

type Config struct {
	PgSQLConfig     *pgsql.Config
	ServerConfig    *http.Config
	WebsocketConfig *websocket.Config
	OverlordConfig  *overlord.Config
	RNGConfig       *rng.Config
	ConstantsConfig *constants.Config
	RedisConfig     *redis.Config
	FlyConfig       *plane.Config
	BotConfig       *bot.Config
}

func New(isTest bool) (*Config, error) {
	once.Do(func() {
		config = &Config{}

		if isTest {
			viper.AddConfigPath("../")
		}

		viper.AddConfigPath(".")
		viper.SetConfigName("config")

		if err := viper.ReadInConfig(); err != nil {
			panic(err)
		}

		var (
			databaseConfig  = viper.Sub("database")
			serverConfig    = viper.Sub("server")
			websocketConfig = viper.Sub("websocket")
			overlordConfig  = viper.Sub("overlord")
			constantsConfig = viper.Sub("game")
			rngConfig       = viper.Sub("rng")
			redisConfig     = viper.Sub("redis")
			flyConfig       = viper.Sub("fly")
			botConfig       = viper.Sub("bot")
		)

		if err := databaseConfig.Unmarshal(&config.PgSQLConfig); err != nil {
			panic(err)
		}

		if err := serverConfig.Unmarshal(&config.ServerConfig); err != nil {
			panic(err)
		}

		if err := constantsConfig.Unmarshal(&config.ConstantsConfig); err != nil {
			panic(err)
		}

		if err := overlordConfig.Unmarshal(&config.OverlordConfig); err != nil {
			panic(err)
		}

		if err := rngConfig.Unmarshal(&config.RNGConfig); err != nil {
			panic(err)
		}

		if err := websocketConfig.Unmarshal(&config.WebsocketConfig); err != nil {
			panic(err)
		}

		if err := redisConfig.Unmarshal(&config.RedisConfig); err != nil {
			panic(err)
		}

		if err := flyConfig.Unmarshal(&config.FlyConfig); err != nil {
			panic(err)
		}

		if err := botConfig.Unmarshal(&config.BotConfig); err != nil {
			panic(err)
		}
	})

	return config, nil
}
