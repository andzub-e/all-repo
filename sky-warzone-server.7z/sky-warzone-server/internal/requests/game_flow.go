package requests

import "github.com/google/uuid"

type Auth struct {
	Operator string      `json:"operator" form:"operator" validate:"operator"`
	Game     string      `json:"game" form:"game" validate:"game"`
	Params   interface{} `json:"params" form:"params" validate:"required"`
}

type Wager struct {
	Wager              int64    `json:"wager" form:"wager" validate:"required"`
	FreeSpinID         string   `json:"free_spin_id"`
	AutoWinCoefficient *float64 `json:"auto_win_coefficient" validate:"coefficient"`
	Currency           string   `json:"currency"`
}

type Payout struct {
	RoundId uuid.UUID `json:"round_id" validate:"required"`
}

type History struct {
	SessionToken string `json:"session_token" form:"session_token" query:"session_token" validate:"required"`
	Page         *int   `json:"page" form:"page" query:"page" validate:"required,gt=0"`
	Count        *int   `json:"count" form:"count" query:"count" validate:"required,gt=0"`
}

type GetFreeSpinsRequest struct {
	SessionToken string `json:"session_token" form:"session_token" query:"session_token" validate:"required"`
}
