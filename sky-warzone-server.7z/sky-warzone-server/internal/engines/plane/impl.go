package plane

import (
	"base-slot/internal/engines/coefficient"
	"github.com/google/uuid"
	"sync"
	"time"
)

type Generator interface {
	NewPlane() (Plane, error)
}

func NewGenerator(cf coefficient.Factory, cnf Config) Generator {
	return &generator{cf: cf, cnf: cnf}
}

type generator struct {
	cf  coefficient.Factory
	cnf Config
}

func (g *generator) NewPlane() (Plane, error) {
	c, err := g.cf.GetCoefficient()
	if err != nil {
		return nil, err
	}

	p := &plane{
		roundId:    uuid.New(),
		stopCoef:   c,
		incSpeed:   g.cnf.IncrementSpeed,
		delayTime:  g.cnf.TimeForWager,
		actualCoef: 1,
	}

	p.wc.Add(1)

	return p, nil
}

//goland:noinspection SpellCheckingInspection
type plane struct {
	roundId    uuid.UUID
	started    bool
	stopped    bool
	actualCoef float64
	stopCoef   float64
	incSpeed   time.Duration
	delayTime  time.Duration

	ch []chan FlyEvent
	wc sync.WaitGroup

	chBusy bool

	sync.Mutex
}

func (f *plane) WaitCrash() {
	f.wc.Wait()
}

func (f *plane) sendToChannels(e FlyEvent) {
	for _, ch := range f.ch {
		ch <- e
	}
}

func (f *plane) GetEventChan() chan FlyEvent {
	f.Lock()
	defer f.Unlock()

	currChannel := make(chan FlyEvent)
	f.ch = append(f.ch, currChannel)

	return currChannel
}

func (f *plane) Start() error {
	f.Lock()

	if f.started {
		f.Unlock()
		return GameAlreadyStarted
	}
	f.Unlock()

	time.Sleep(time.Second) // delay before new round

	f.sendToChannels(FlyEvent{Event: EventNewRound})

	for i := f.delayTime; i > 0; i -= time.Second {
		f.sendToChannels(FlyEvent{Event: EventCountdown, Data: i})
		time.Sleep(time.Second)
	}

	f.Lock()
	f.started = true
	f.Unlock()

	f.sendToChannels(FlyEvent{Event: EventStarted})

	go func(f *plane) {
		for {
			time.Sleep(f.incSpeed)

			crashed := f.actualCoef >= f.stopCoef

			f.sendToChannels(FlyEvent{Event: EventCoefficient, Data: f.actualCoef})

			if crashed {
				f.Lock()
				f.stopped = true
				f.wc.Done()
				f.Unlock()

				f.sendToChannels(FlyEvent{Event: EventCrashed, Data: f.actualCoef})

				break
			}

			f.actualCoef += 0.01
		}
	}(f)

	return nil
}

func (f *plane) GetRoundId() uuid.UUID {
	return f.roundId
}

func (f *plane) CanWager() bool {
	f.Lock()
	defer f.Unlock()

	return !f.started && !f.stopped
}

func (f *plane) GetActualCoefficient() (float64, error) {
	f.Lock()
	defer f.Unlock()

	if !f.started {
		return 0, GameNotStartedYet
	}

	if f.stopped {
		return 0, GameAlreadyStopped
	}

	return f.actualCoef, nil
}
