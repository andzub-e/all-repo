package plane

import (
	"errors"
	"github.com/google/uuid"
)

type Plane interface {
	Start() error
	WaitCrash()
	GetRoundId() uuid.UUID
	CanWager() bool
	GetActualCoefficient() (float64, error)
	GetEventChan() chan FlyEvent
}

var (
	GameAlreadyStarted = errors.New("game already started")
	GameAlreadyStopped = errors.New("game already stopped")
	GameNotStartedYet  = errors.New("game not started yet")
)

type FlyEvent struct {
	Event event
	Data  any
}

type event string

const (
	EventCoefficient event = "coefficient"
	EventCrashed     event = "crashed"
	EventCountdown   event = "countdown"
	EventStarted     event = "started"
	EventNewRound    event = "new round"
)
