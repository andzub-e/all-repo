package coefficient

type Factory interface {
	GetCoefficient() (float64, error)
	GetCoefficientWithoutCheat() (float64, error)
	SetNextCoefficient(float64) error
}
