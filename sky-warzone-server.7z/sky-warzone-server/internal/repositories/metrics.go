package repositories

import (
	"base-slot/internal/entities"
	"context"
	"gorm.io/gorm"
	"time"
)

type MetricsRepository interface {
	TotalSpinCount(ctx context.Context, gameName string) (int64, error)
	UsersTurnover(ctx context.Context, gameName, userID string) (int64, error)
	Turnover(ctx context.Context, gameName string) (int64, error)
	BaseWinnings(ctx context.Context, gameName string) (int64, error)
	BonusWinnings(ctx context.Context, gameName string) (int64, error)
	UniqueUsers(ctx context.Context, gameName string) (int64, error)

	WithDailyMetric(day time.Time) MetricsRepository
	WithSinceMetric(since time.Time) MetricsRepository
	WithCurrency(currency string) MetricsRepository
}

type MetricsPgSQLRepository struct {
	conn *gorm.DB
}

func NewMetricsPgSQLRepository(conn *gorm.DB) MetricsRepository {
	return &MetricsPgSQLRepository{conn: conn}
}

func (r MetricsPgSQLRepository) WithDailyMetric(day time.Time) MetricsRepository {
	r.conn = r.withDailyRate(r.conn, day)

	return &r
}

func (r MetricsPgSQLRepository) WithSinceMetric(since time.Time) MetricsRepository {
	r.conn = r.conn.Where("crated_at > ?", since.Unix())

	return &r
}

func (r *MetricsPgSQLRepository) TotalSpinCount(ctx context.Context, gameName string) (count int64, err error) {
	err = r.conn.WithContext(ctx).
		Model(&entities.HistoryRecord{}).
		Where("game = ?", gameName).
		Count(&count).Error

	return count, err
}

func (r MetricsPgSQLRepository) WithCurrency(currency string) MetricsRepository {
	r.conn = r.conn.Where("currency = ?", currency)

	return &r
}

func (r *MetricsPgSQLRepository) UsersTurnover(ctx context.Context, gameName string, userID string) (turnover int64, err error) {
	err = r.conn.WithContext(ctx).
		Model(&entities.HistoryRecord{}).
		Where("game = ?", gameName).
		Where("user_id = ?", userID).
		Select("coalesce(sum(bet), 0)").
		Take(&turnover).Error

	return
}

func (r *MetricsPgSQLRepository) Turnover(ctx context.Context, gameName string) (turnover int64, err error) {
	err = r.conn.WithContext(ctx).
		Model(&entities.HistoryRecord{}).
		Where("game = ?", gameName).
		Select("coalesce(sum(bet), 0)").
		Take(&turnover).Error

	return
}

func (r *MetricsPgSQLRepository) BaseWinnings(ctx context.Context, gameName string) (winnings int64, err error) {
	err = r.conn.WithContext(ctx).
		Model(&entities.HistoryRecord{}).
		Where("game = ?", gameName).
		Select("coalesce(sum(base_pay), 0)").
		Take(&winnings).Error

	return
}

func (r *MetricsPgSQLRepository) BonusWinnings(ctx context.Context, gameName string) (winnings int64, err error) {
	err = r.conn.WithContext(ctx).
		Model(&entities.HistoryRecord{}).
		Where("game = ?", gameName).
		Select("coalesce(sum(bonus_pay), 0)").
		Take(&winnings).Error

	return
}

func (r *MetricsPgSQLRepository) UniqueUsers(ctx context.Context, gameName string) (count int64, err error) {
	err = r.conn.WithContext(ctx).
		Model(&entities.HistoryRecord{}).
		Where("game = ?", gameName).
		Group("user_id").
		Count(&count).Error

	return count, err
}

func (r *MetricsPgSQLRepository) withDailyRate(stmt *gorm.DB, date time.Time) *gorm.DB {
	searchDay := r.roundUpDateToDay(date)
	nextDay := searchDay.Add(time.Hour * 24)

	return stmt.Where("crated_at > ? and crated_at < ?", searchDay.Unix(), nextDay.Unix())
}

func (r *MetricsPgSQLRepository) roundUpDateToDay(date time.Time) time.Time {
	return time.Date(date.Year(), date.Month(), date.Day(), 0, 0, 0, 0, date.Location())
}
