package repositories

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/go-redis/redis/v8"
	"github.com/google/uuid"
	"sync"
)

type WagerRepository interface {
	GetOpenWagers(context.Context) ([]Wager, error)
	GetWagerById(context.Context, uuid.UUID) (Wager, error)
	DeleteWagerById(context.Context, uuid.UUID) error
	GetWagersWithCoefficient(context.Context, float64) ([]Wager, error)
	SaveRound(context.Context, Wager) error
	Clear(ctx context.Context) error
}

type Wager struct {
	ID            uuid.UUID `json:"id"`
	Amount        int64     `json:"amount"`
	Currency      string    `json:"currency"`
	TransactionId string    `json:"transaction_id"`
	WinAt         *float64  `json:"win_at"` // auto-win if coefficient is reached
	UserID        string    `json:"user_id"`
}

type redisRound struct {
	conn *redis.Client

	sync.Mutex
}

func (r *redisRound) Clear(ctx context.Context) error { // test only
	r.Lock()
	defer r.Unlock()

	return r.conn.FlushAll(ctx).Err()
}

func NewRedisRound(conn *redis.Client) WagerRepository {
	return &redisRound{conn: conn}
}

var (
	ErrorWagerIdCollision = errors.New("wager id collision")
	ErrorWrongType        = errors.New("wrong type (internal)")
	ErrorWagerNotFound    = errors.New("wager not found")
)

func (r *redisRound) GetOpenWagers(ctx context.Context) ([]Wager, error) {
	r.Lock()
	defer r.Unlock()

	keys, err := r.conn.Keys(ctx, "round_*").Result()
	if err != nil {
		return nil, err
	}

	if len(keys) == 0 {
		return []Wager{}, nil
	}

	values, err := r.conn.MGet(ctx, keys...).Result()
	if err != nil {
		return nil, err
	}

	wagers := make([]Wager, 0, len(keys))

	for _, s := range values {
		if s == redis.Nil {
			continue
		}

		wager, err := unmarshalWager(s)
		if err != nil {
			return nil, err
		}

		wagers = append(wagers, wager)
	}

	return wagers, nil
}

func (r *redisRound) GetWagerById(ctx context.Context, u uuid.UUID) (Wager, error) {
	r.Lock()
	defer r.Unlock()

	keys, err := r.conn.Keys(ctx, fmt.Sprintf("round_%s*", u)).Result()
	if err != nil {
		return Wager{}, err
	}

	switch len(keys) {
	case 0:
		return Wager{}, ErrorWagerNotFound
	case 1:
		result, err := r.conn.Get(ctx, keys[0]).Result()
		if err != nil {
			return Wager{}, err
		}

		return unmarshalWager(result)
	default:
		return Wager{}, ErrorWagerIdCollision
	}

}

func (r *redisRound) DeleteWagerById(ctx context.Context, u uuid.UUID) error {
	r.Lock()
	defer r.Unlock()

	keys, err := r.conn.Keys(ctx, fmt.Sprintf("round_%s*", u)).Result()
	if err != nil {
		return err
	}

	switch len(keys) {
	case 0:
		return ErrorWagerNotFound
	case 1:
		return r.conn.Del(ctx, keys[0]).Err()
	default:
		return ErrorWagerIdCollision
	}

}

func (r *redisRound) GetWagersWithCoefficient(ctx context.Context, coefficient float64) ([]Wager, error) {
	r.Lock()
	defer r.Unlock()

	key := fmt.Sprintf("round_*_fixed_%.2f", coefficient)

	keys, err := r.conn.Keys(ctx, key).Result()
	if err != nil {
		return nil, err
	}

	if len(keys) == 0 {
		return []Wager{}, nil
	}

	values, err := r.conn.MGet(ctx, keys...).Result()
	if err != nil {
		return nil, err
	}

	wagers := make([]Wager, 0, len(keys))

	for _, s := range values {
		if s == redis.Nil {
			continue
		}

		wager, err := unmarshalWager(s)
		if err != nil {
			return nil, err
		}

		wagers = append(wagers, wager)
	}

	return wagers, nil
}

func (r *redisRound) SaveRound(ctx context.Context, wager Wager) error {
	r.Lock()
	defer r.Unlock()

	var key string
	if wager.WinAt == nil {
		key = fmt.Sprintf("round_%s", wager.ID)
	} else {
		key = fmt.Sprintf("round_%s_fixed_%.2f", wager.ID, *wager.WinAt)
	}

	count, err := r.conn.Exists(ctx, key).Result()
	if err != nil {
		return err
	}

	if count > 0 {
		return ErrorWagerIdCollision
	}

	wagerJSON, _ := json.Marshal(wager)

	return r.conn.Set(ctx, key, wagerJSON, 0).Err()
}

func unmarshalWager(wgr any) (w Wager, e error) {
	switch wgr.(type) {
	case string:
		e = json.Unmarshal([]byte(wgr.(string)), &w)
	case []byte:
		e = json.Unmarshal(wgr.([]byte), &w)
	default:
		e = ErrorWrongType
	}

	return
}
