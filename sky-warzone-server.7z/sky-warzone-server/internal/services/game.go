package services

import (
	"base-slot/internal/entities"
	"base-slot/internal/errs"
	"base-slot/pkg/overlord"
	"context"
	"go.uber.org/zap"
)

type GameFlowService interface {
	InitGame(ctx context.Context, game, operator string, lordParams interface{}) (*entities.GameState, error)
	GameState(ctx context.Context, sessionToken string) (*entities.GameState, error)
	OpenWager(ctx context.Context, token, fsID, roundID string, wager int64) (OpenBet, error)
	CloseWager(ctx context.Context, transID, curr string, win int64, coefficient float64) (CloseBet, error)
	Rollback(ct context.Context, transactionID, currency string) (RollbackBet, error)
	GetFreeSpins(ctx context.Context, sessionToken string) ([]*entities.FreeSpin, error)
}

func NewGameFlowService(lord overlord.Client, historySrv *HistoryService) GameFlowService {
	return &gameFlowService{
		lord:       lord,
		historySrv: historySrv,
	}
}

type gameFlowService struct {
	lord       overlord.Client
	historySrv *HistoryService
}

func (s *gameFlowService) InitGame(ctx context.Context, game, operator string, lordParams interface{}) (*entities.GameState, error) {
	lordState, err := s.lord.InitUserState(ctx, game, operator, lordParams)
	if err != nil {
		return nil, errs.TranslateOverlordErr(err)
	}

	gs := entities.GameStateFromLordState(lordState)

	return gs, nil
}
func (s *gameFlowService) GameState(ctx context.Context, sessionToken string) (*entities.GameState, error) {
	lordState, err := s.lord.GetStateBySessionToken(ctx, sessionToken)
	if err != nil {
		return nil, errs.TranslateOverlordErr(err)
	}

	return entities.GameStateFromLordState(lordState), nil
}

func (s *gameFlowService) GetFreeSpins(ctx context.Context, sessionToken string) ([]*entities.FreeSpin, error) {
	overlordBets, err := s.lord.GetFreeSpins(ctx, sessionToken)
	if err != nil {
		zap.S().Error("lord: failed to get user free spins", err)

		return nil, errs.TranslateOverlordErr(err)
	}

	return entities.FreeSpinsFromLord(overlordBets.FreeBets), nil
}

func (s *gameFlowService) OpenWager(ctx context.Context, token, fsID, roundID string, wager int64) (OpenBet, error) {
	var b OpenBet

	gameState, err := s.GameState(ctx, token)
	if err != nil {
		return b, errs.TranslateOverlordErr(err)
	}

	var openBet *overlord.OpenBetResponse

	if fsID != "" {
		openBet, err = s.lord.OpenFreeBet(ctx, token, fsID, roundID)
	} else {
		openBet, err = s.lord.OpenBet(ctx, token, roundID, gameState.Currency, wager)
	}

	if err != nil {
		return b, errs.TranslateOverlordErr(err)
	}

	b.TransactionID = openBet.TransactionID
	b.Balance = openBet.Balance
	b.Currency = openBet.Currency

	return b, nil
}

func (s *gameFlowService) CloseWager(ct context.Context, transID, curr string, win int64, c float64) (CloseBet, error) {
	bet, err := s.lord.CloseBet(ct, transID, curr, win)
	if err != nil {
		return CloseBet{}, err
	}

	return CloseBet{
		Currency:    bet.Currency,
		Balance:     bet.Balance,
		Win:         win,
		Coefficient: c,
	}, nil
}

func (s *gameFlowService) Rollback(ct context.Context, transactionID, currency string) (RollbackBet, error) {
	bet, err := s.lord.RollbackBet(ct, transactionID, currency)
	if err != nil {
		return RollbackBet{}, err
	}

	return RollbackBet{
		Currency: bet.Currency,
		Balance:  bet.Balance,
	}, nil
}

type OpenBet struct {
	TransactionID string
	Currency      string
	Balance       int64
}

type CloseBet struct {
	Currency    string
	Balance     int64
	Win         int64
	Coefficient float64
}

type RollbackBet struct {
	Currency string
	Balance  int64
}
