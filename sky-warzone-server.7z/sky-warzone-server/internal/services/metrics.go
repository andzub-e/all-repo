package services

import (
	"base-slot/internal/repositories"
	"context"
	"time"
)

type MetricsService struct {
	repo repositories.MetricsRepository
}

func NewMetricsService(repo repositories.MetricsRepository) *MetricsService {
	return &MetricsService{repo: repo}
}

func (s MetricsService) WithDailyMetric(day time.Time) *MetricsService {
	s.repo = s.repo.WithDailyMetric(day)

	return &s
}

func (s MetricsService) WithCurrency(currency string) *MetricsService {
	s.repo = s.repo.WithCurrency(currency)

	return &s
}

func (s *MetricsService) UniqueActiveUsers(ctx context.Context, gameName string) (int64, error) {
	return s.repo.WithSinceMetric(time.Now().Add(-time.Hour*24*30)).UniqueUsers(ctx, gameName)
}

func (s *MetricsService) UsersTurnover(ctx context.Context, gameName, userID string) (int64, error) {
	return s.repo.UsersTurnover(ctx, gameName, userID)
}

func (s *MetricsService) TotalSpinCount(ctx context.Context, gameName string) (int64, error) {
	return s.repo.TotalSpinCount(ctx, gameName)
}

func (s *MetricsService) AverageBet(ctx context.Context, gameName string) (float64, error) {
	count, err := s.repo.TotalSpinCount(ctx, gameName)
	if err != nil {
		return 0, err
	}

	if count == 0 {
		return 0, nil
	}

	turnover, err := s.repo.Turnover(ctx, gameName)
	if err != nil {
		return 0, err
	}

	return float64(turnover) / float64(count), nil
}

func (s *MetricsService) UniqueUsers(ctx context.Context, gameName string) (int64, error) {
	return s.repo.UniqueUsers(ctx, gameName)
}

func (s *MetricsService) Revenue(ctx context.Context, gameName string) (int64, error) {
	baseWin, err := s.repo.BaseWinnings(ctx, gameName)
	if err != nil {
		return 0, err
	}

	bonusWin, err := s.repo.BonusWinnings(ctx, gameName)
	if err != nil {
		return 0, err
	}

	turnover, err := s.repo.Turnover(ctx, gameName)
	if err != nil {
		return 0, err
	}

	totalWin := baseWin + bonusWin

	return turnover - totalWin, nil
}

func (s *MetricsService) Margin(ctx context.Context, gameName string) (float64, error) {
	turnover, err := s.repo.Turnover(ctx, gameName)
	if err != nil {
		return 0, err
	}

	if turnover == 0 {
		return 0, nil
	}

	revenue, err := s.Revenue(ctx, gameName)
	if err != nil {
		return 0, err
	}

	return float64(revenue) / float64(turnover), nil
}

func (s *MetricsService) SpinsPerPlayer(ctx context.Context, gameName string) (float64, error) {
	totalUsers, err := s.UniqueUsers(ctx, gameName)
	if err != nil {
		return 0, err
	}

	if totalUsers == 0 {
		return 0, nil
	}

	spins, err := s.TotalSpinCount(ctx, gameName)
	if err != nil {
		return 0, err
	}

	return float64(spins) / float64(totalUsers), nil
}
