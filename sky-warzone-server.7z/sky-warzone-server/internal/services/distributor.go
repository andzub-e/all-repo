package services

import (
	"base-slot/internal/constants"
	"base-slot/internal/engines/airport"
	p "base-slot/internal/engines/plane"
	"base-slot/internal/repositories"
	"base-slot/internal/responses"
	"context"
	"fmt"
	"go.uber.org/zap"
	"log"
	"math"
)

type Distributor interface {
	Start()
}

type distributor struct {
	airport   airport.Airport
	connSrv   ConnectionService
	repoWager repositories.WagerRepository
	flow      GameFlowService
}

func NewDistributor(a airport.Airport, c ConnectionService, w repositories.WagerRepository, f GameFlowService) Distributor {
	return &distributor{airport: a, connSrv: c, repoWager: w, flow: f}
}

func (d *distributor) Start() {
	for {
		plane := d.airport.WaitThePlane()
		eventChan := plane.GetEventChan()

	events:
		for {
			event := <-eventChan

			switch event.Event {
			case p.EventCoefficient:
				coe := event.Data.(float64)

				d.connSrv.SendToAllAuthenticUsers(responses.SocketWrap{
					Code: constants.StatusSuccess,
					Type: responses.TypeCoefficient,
					Data: fmt.Sprintf("%.2f", event.Data),
				})

				ctx := context.Background() // TODO: need to discuss.

				wagersToClose, err := d.repoWager.GetWagersWithCoefficient(ctx, coe)
				if err != nil {
					log.Fatal(err)
				}

				for _, wager := range wagersToClose {

					win := int64(math.Round(float64(wager.Amount) * coe))

					w, err := d.flow.CloseWager(ctx, wager.TransactionId, wager.Currency, win, coe)
					if err != nil {
						zap.S().Warn(err)
						continue
					}

					//goland:noinspection ALL
					go d.connSrv.NotifyCloseBet(wager.UserID, w)

					if err = d.repoWager.DeleteWagerById(ctx, wager.ID); err != nil {
						zap.S().Warn(err)
						continue
					}

				}

			case p.EventCrashed:
				fmt.Printf("Crashed with coefficient: %.2f\n", event.Data)

				d.connSrv.SendToAllAuthenticUsers(responses.SocketWrap{
					Code: constants.StatusSuccess,
					Type: responses.TypeCrashed,
					Data: fmt.Sprintf("%.2f", event.Data),
				})

				break events
			case p.EventCountdown:
				d.connSrv.SendToAllAuthenticUsers(responses.SocketWrap{
					Code: constants.StatusSuccess,
					Type: responses.TypeCountdown,
					Data: fmt.Sprintf("%s", event.Data),
				})

			case p.EventStarted:
				d.connSrv.SendToAllAuthenticUsers(responses.SocketWrap{
					Code: constants.StatusSuccess,
					Type: responses.TypeStarted,
				})

			case p.EventNewRound:
				d.connSrv.SendToAllAuthenticUsers(responses.SocketWrap{
					Code: constants.StatusSuccess,
					Type: responses.TypeNewRound,
				})

			}

		}

	}
}
