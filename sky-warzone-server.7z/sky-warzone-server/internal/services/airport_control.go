package services

import (
	"base-slot/internal/engines/airport"
	"base-slot/internal/repositories"
	"context"
	"go.uber.org/zap"
	"log"
	"time"
)

// PlaneControlService handles open wagers after crash the plane.
type PlaneControlService interface {
	Start()
	StopFlightsAndWait()
}

type planeControlService struct {
	connSrv ConnectionService
	airEng  airport.Airport
	rndRepo repositories.WagerRepository
	flow    GameFlowService

	waiter  chan bool
	stopped bool
}

func (l *planeControlService) StopFlightsAndWait() {
	l.stopped = true

	// Wait to close all wagers
	<-l.waiter
}

func (l *planeControlService) Start() {
	l.stopped = false
	for {
		ctx := context.Background() // TODO: need to discuss with context.

		if err := l.airEng.StartOneFlight(); err != nil {
			log.Fatal(err)
		}

		plane := l.airEng.WaitThePlane()
		plane.WaitCrash()

		wagers, err := l.rndRepo.GetOpenWagers(ctx)
		if err != nil {
			log.Fatal(err)
		}

		for _, wager := range wagers {
			bet, err := l.flow.CloseWager(ctx, wager.TransactionId, wager.Currency, 0, 0)
			if err != nil {
				zap.S().Warn(err)
			}

			//goland:noinspection ALL
			go l.connSrv.NotifyCloseBet(wager.UserID, bet)

			if err = l.rndRepo.DeleteWagerById(ctx, wager.ID); err != nil {
				zap.S().Warn(err)
			}
		}

		if l.stopped {
			l.waiter <- true
			break
		}

		time.Sleep(time.Second * 2)
	}
}

func NewPlaneControlService(c ConnectionService, a airport.Airport, r repositories.WagerRepository, gf GameFlowService) PlaneControlService {
	return &planeControlService{connSrv: c, airEng: a, rndRepo: r, flow: gf, waiter: make(chan bool)}
}
