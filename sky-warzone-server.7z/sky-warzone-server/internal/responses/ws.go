package responses

import "github.com/google/uuid"

type SocketWrap struct {
	Code int          `json:"code"`
	Type ResponseType `json:"type"`

	Data any `json:"data,omitempty"`
}

type ResponseType string

const (
	TypeError       ResponseType = "error"
	TypeState       ResponseType = "state"
	TypeOpenWager   ResponseType = "open_wager"
	TypeCloseWager  ResponseType = "close_wager"
	TypeCoefficient ResponseType = "coefficient"
	TypeCrashed     ResponseType = "crashed"
	TypeCountdown   ResponseType = "countdown"
	TypeStarted     ResponseType = "started"
	TypeNewRound    ResponseType = "new round"
	TypeBotWager    ResponseType = "bot wager"
	TypeBotPayout   ResponseType = "bot payout"
	TypeBotLoose    ResponseType = "bot loose"
)

type OpenWager struct {
	RoundId uuid.UUID `json:"round_id"`
	Balance int64     `json:"balance"`
}

type CloseWager struct {
	WinCoefficient string `json:"win_coefficient"`
	Win            int64  `json:"win"`
	Currency       string `json:"currency"`
	Balance        int64  `json:"balance"`
}

type BotWager struct {
	Id    uuid.UUID `json:"id"`
	Name  string    `json:"name"`
	Wager uint64    `json:"wager"`
}

type BotPayout struct {
	Id             uuid.UUID `json:"id"`
	Wager          uint64    `json:"wager"`
	CoefficientWin string    `json:"coefficient_win"`
}

type BotLoose struct {
	Id    uuid.UUID `json:"id"`
	Wager uint64    `json:"wager"`
}
