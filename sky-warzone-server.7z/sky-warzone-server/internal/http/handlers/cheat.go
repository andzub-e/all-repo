package handlers

import (
	"base-slot/internal/engines/coefficient"
	"base-slot/internal/http"
	"base-slot/internal/requests"
	"github.com/gin-gonic/gin"
)

func NewCheatHandler(factory coefficient.Factory) http.Handler {
	return &cheatHandler{factory: factory}
}

type cheatHandler struct {
	factory coefficient.Factory
}

func (c *cheatHandler) Register(router *gin.RouterGroup) {
	cheat := router.Group("cheat")

	cheat.POST("set_next_coefficient", c.setCoefficient)
}

func (c *cheatHandler) setCoefficient(ctx *gin.Context) {
	var cheatRq requests.SetCoefficient
	if err := ctx.BindJSON(&cheatRq); err != nil {
		ctx.JSON(422, err.Error())
		return
	}

	err := c.factory.SetNextCoefficient(cheatRq.Coefficient)
	if err != nil {
		ctx.JSON(422, err.Error())
		return
	}

	ctx.Status(204)
}
