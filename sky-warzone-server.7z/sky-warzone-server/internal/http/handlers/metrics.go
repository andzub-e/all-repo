package handlers

import (
	"base-slot/internal/constants"
	"base-slot/internal/http"
	"base-slot/internal/services"
	"base-slot/pkg/overlord"
	"context"
	"github.com/gin-gonic/gin"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"go.uber.org/zap"
	"golang.org/x/exp/constraints"
	"strings"
	"time"
)

// GameMetric Y means - yesterday, LM means - last month
type GameMetric struct {
	GameName   string
	Currencies []string

	SpinTotalCount, TotalUserCount, ActiveUserCount, SpinsPerUser prometheus.Gauge
	SpinTotalCountY, TotalUserCountY, SpinsPerUserY               prometheus.Gauge
	SpinTotalCountLM, TotalUserCountLM, SpinsPerUserLM            prometheus.Gauge

	MetricsMap map[string]CurrencyDependentMetrics
}

type CurrencyDependentMetrics struct {
	AverageBet, Revenue, Margin       prometheus.Gauge
	AverageBetY, RevenueY, MarginY    prometheus.Gauge
	AverageBetLM, RevenueLM, MarginLM prometheus.Gauge
}

const (
	MetricBusinessNamespace = "business"
	MetricSpinCountName     = "spin_total_count"
	MetricSpinCountYName    = "yesterdays_spin_total_count"
	MetricSpinCountLMName   = "last_months_spin_total_count"
	MetricAverageBetName    = "average_bet"
	MetricAverageBetYName   = "yesterdays_average_bet"
	MetricAverageBetLMName  = "last_months_average_bet"
	MetricTotalUsersName    = "total_users_count"
	MetricTotalUsersYName   = "yesterdays_total_users_count"
	MetricTotalUsersLMName  = "last_months_total_users_count"
	MetricActiveUsersName   = "active_users_count"
	MetricRevenueName       = "revenue"
	MetricRevenueYName      = "yesterdays_revenue"
	MetricRevenueLMName     = "last_months_revenue"
	MetricMarginName        = "margin"
	MetricMarginYName       = "yesterdays_margin"
	MetricMarginLMName      = "last_months_margin"
	MetricSpinPerUserName   = "spins_per_user"
	MetricSpinPerUserYName  = "yesterdays_spins_per_user"
	MetricSpinPerUserLMName = "last_months_spins_per_user"
)

func NewGameMetric(gameName string, currencies []string) GameMetric {
	slug := strings.ReplaceAll(gameName, "-", "_")
	getMetricName := func(metric string) string {
		return slug + "_" + metric
	}

	getMetricNameWithCurrency := func(metric, currency string) string {
		return slug + "_" + metric + "_" + currency
	}

	metric := GameMetric{
		GameName:   gameName,
		Currencies: currencies,

		SpinTotalCount: prometheus.NewGauge(prometheus.GaugeOpts{
			Namespace: MetricBusinessNamespace,
			Name:      getMetricName(MetricSpinCountName),
			Help:      "This is a metric which shows total spin count",
		}),
		SpinTotalCountY: prometheus.NewGauge(prometheus.GaugeOpts{
			Namespace: MetricBusinessNamespace,
			Name:      getMetricName(MetricSpinCountYName),
			Help:      "This is a metric which shows total spin count",
		}),
		SpinTotalCountLM: prometheus.NewGauge(prometheus.GaugeOpts{
			Namespace: MetricBusinessNamespace,
			Name:      getMetricName(MetricSpinCountLMName),
			Help:      "This is a metric which shows total spin count",
		}),
		TotalUserCount: prometheus.NewGauge(prometheus.GaugeOpts{
			Namespace: MetricBusinessNamespace,
			Name:      getMetricName(MetricTotalUsersName),
			Help:      "This is a metric which shows total users count",
		}),
		TotalUserCountY: prometheus.NewGauge(prometheus.GaugeOpts{
			Namespace: MetricBusinessNamespace,
			Name:      getMetricName(MetricTotalUsersYName),
			Help:      "This is a metric which shows total users count",
		}),
		TotalUserCountLM: prometheus.NewGauge(prometheus.GaugeOpts{
			Namespace: MetricBusinessNamespace,
			Name:      getMetricName(MetricTotalUsersLMName),
			Help:      "This is a metric which shows total users count",
		}),
		ActiveUserCount: prometheus.NewGauge(prometheus.GaugeOpts{
			Namespace: MetricBusinessNamespace,
			Name:      getMetricName(MetricActiveUsersName),
			Help:      "This is a metric showing how many users have played in the last month",
		}),
		SpinsPerUser: prometheus.NewGauge(prometheus.GaugeOpts{
			Namespace: MetricBusinessNamespace,
			Name:      getMetricName(MetricSpinPerUserName),
			Help:      "This is a metric shows average spin rate",
		}),
		SpinsPerUserY: prometheus.NewGauge(prometheus.GaugeOpts{
			Namespace: MetricBusinessNamespace,
			Name:      getMetricName(MetricSpinPerUserYName),
			Help:      "This is a metric shows average spin rate",
		}),
		SpinsPerUserLM: prometheus.NewGauge(prometheus.GaugeOpts{
			Namespace: MetricBusinessNamespace,
			Name:      getMetricName(MetricSpinPerUserLMName),
			Help:      "This is a metric shows average spin rate",
		}),
	}

	metric.MetricsMap = map[string]CurrencyDependentMetrics{}

	for _, currency := range currencies {
		metric.MetricsMap[currency] = CurrencyDependentMetrics{
			AverageBet: prometheus.NewGauge(prometheus.GaugeOpts{
				Namespace: MetricBusinessNamespace,
				Name:      getMetricNameWithCurrency(MetricAverageBetName, currency),
				Help:      "This is a metric which shows average bet value",
			}),
			AverageBetY: prometheus.NewGauge(prometheus.GaugeOpts{
				Namespace: MetricBusinessNamespace,
				Name:      getMetricNameWithCurrency(MetricAverageBetYName, currency),
				Help:      "This is a metric which shows average bet value",
			}),
			AverageBetLM: prometheus.NewGauge(prometheus.GaugeOpts{
				Namespace: MetricBusinessNamespace,
				Name:      getMetricNameWithCurrency(MetricAverageBetLMName, currency),
				Help:      "This is a metric which shows average bet value",
			}),
			Revenue: prometheus.NewGauge(prometheus.GaugeOpts{
				Namespace: MetricBusinessNamespace,
				Name:      getMetricNameWithCurrency(MetricRevenueName, currency),
				Help:      "This is a metric shows game revenue",
			}),
			RevenueY: prometheus.NewGauge(prometheus.GaugeOpts{
				Namespace: MetricBusinessNamespace,
				Name:      getMetricNameWithCurrency(MetricRevenueYName, currency),
				Help:      "This is a metric shows game revenue",
			}),
			RevenueLM: prometheus.NewGauge(prometheus.GaugeOpts{
				Namespace: MetricBusinessNamespace,
				Name:      getMetricNameWithCurrency(MetricRevenueLMName, currency),
				Help:      "This is a metric shows game revenue",
			}),
			Margin: prometheus.NewGauge(prometheus.GaugeOpts{
				Namespace: MetricBusinessNamespace,
				Name:      getMetricNameWithCurrency(MetricMarginName, currency),
				Help:      "This is a metric shows game margin",
			}),
			MarginY: prometheus.NewGauge(prometheus.GaugeOpts{
				Namespace: MetricBusinessNamespace,
				Name:      getMetricNameWithCurrency(MetricMarginYName, currency),
				Help:      "This is a metric shows game margin",
			}),
			MarginLM: prometheus.NewGauge(prometheus.GaugeOpts{
				Namespace: MetricBusinessNamespace,
				Name:      getMetricNameWithCurrency(MetricMarginLMName, currency),
				Help:      "This is a metric shows game margin",
			}),
		}
	}

	return metric
}

var (
	games = []GameMetric{}
)

type metricsHandler struct {
	metricsSrv     *services.MetricsService
	overlordClient overlord.Client
}

func NewMetricsHandler(metricsSrv *services.MetricsService, overlordClient overlord.Client, conf *constants.Config) (http.Handler, error) {
	currencies, err := overlordClient.GetCurrencies(context.Background())

	if err != nil {
		return nil, err
	}

	for _, game := range conf.AvailableGames {
		games = append(games, NewGameMetric(game, currencies))
	}

	for _, game := range games {
		prometheus.MustRegister(game.SpinTotalCount)
		prometheus.MustRegister(game.SpinTotalCountY)
		prometheus.MustRegister(game.SpinTotalCountLM)

		prometheus.MustRegister(game.TotalUserCount)
		prometheus.MustRegister(game.TotalUserCountY)
		prometheus.MustRegister(game.TotalUserCountLM)
		prometheus.MustRegister(game.ActiveUserCount)

		prometheus.MustRegister(game.SpinsPerUser)
		prometheus.MustRegister(game.SpinsPerUserY)
		prometheus.MustRegister(game.SpinsPerUserLM)

		for _, currency := range currencies {
			prometheus.MustRegister(game.MetricsMap[currency].AverageBet)
			prometheus.MustRegister(game.MetricsMap[currency].AverageBetY)
			prometheus.MustRegister(game.MetricsMap[currency].AverageBetLM)
			prometheus.MustRegister(game.MetricsMap[currency].Revenue)
			prometheus.MustRegister(game.MetricsMap[currency].RevenueY)
			prometheus.MustRegister(game.MetricsMap[currency].RevenueLM)
			prometheus.MustRegister(game.MetricsMap[currency].Margin)
			prometheus.MustRegister(game.MetricsMap[currency].MarginY)
			prometheus.MustRegister(game.MetricsMap[currency].MarginLM)
		}
	}

	return &metricsHandler{
		metricsSrv:     metricsSrv,
		overlordClient: overlordClient,
	}, nil
}

func (m metricsHandler) Register(router *gin.RouterGroup) {
	metrics := router.Group("metrics")

	fn := promhttp.Handler()

	metrics.GET("/", func(ginCtx *gin.Context) {
		ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
		defer cancel()
		yesterday := time.Now().Add(-24 * time.Hour)
		monthBefore := time.Now().Add(-24 * 30 * time.Hour)

		for _, game := range games {
			updateMetric[int64](game.ActiveUserCount)(m.metricsSrv.UniqueActiveUsers(ctx, game.GameName))

			updateMetric[int64](game.SpinTotalCount)(m.metricsSrv.TotalSpinCount(ctx, game.GameName))
			updateMetric[int64](game.SpinTotalCountY)(m.metricsSrv.WithDailyMetric(yesterday).TotalSpinCount(ctx, game.GameName))
			updateMetric[int64](game.SpinTotalCountLM)(m.metricsSrv.WithDailyMetric(monthBefore).TotalSpinCount(ctx, game.GameName))

			updateMetric[int64](game.TotalUserCount)(m.metricsSrv.UniqueUsers(ctx, game.GameName))
			updateMetric[int64](game.TotalUserCountY)(m.metricsSrv.WithDailyMetric(yesterday).UniqueUsers(ctx, game.GameName))
			updateMetric[int64](game.TotalUserCountLM)(m.metricsSrv.WithDailyMetric(monthBefore).UniqueUsers(ctx, game.GameName))

			updateMetric[float64](game.SpinsPerUser)(m.metricsSrv.SpinsPerPlayer(ctx, game.GameName))
			updateMetric[float64](game.SpinsPerUserY)(m.metricsSrv.WithDailyMetric(yesterday).SpinsPerPlayer(ctx, game.GameName))
			updateMetric[float64](game.SpinsPerUserLM)(m.metricsSrv.WithDailyMetric(monthBefore).SpinsPerPlayer(ctx, game.GameName))

			for _, currency := range game.Currencies {
				updateMetric[int64](game.MetricsMap[currency].Revenue)(m.metricsSrv.
					WithCurrency(currency).Revenue(ctx, game.GameName))
				updateMetric[int64](game.MetricsMap[currency].RevenueY)(m.metricsSrv.
					WithCurrency(currency).WithDailyMetric(yesterday).Revenue(ctx, game.GameName))
				updateMetric[int64](game.MetricsMap[currency].RevenueLM)(m.metricsSrv.
					WithCurrency(currency).WithDailyMetric(monthBefore).Revenue(ctx, game.GameName))

				updateMetric[float64](game.MetricsMap[currency].AverageBet)(m.metricsSrv.
					WithCurrency(currency).AverageBet(ctx, game.GameName))
				updateMetric[float64](game.MetricsMap[currency].AverageBetY)(m.metricsSrv.
					WithCurrency(currency).WithDailyMetric(yesterday).AverageBet(ctx, game.GameName))
				updateMetric[float64](game.MetricsMap[currency].AverageBetLM)(m.metricsSrv.
					WithCurrency(currency).WithDailyMetric(monthBefore).AverageBet(ctx, game.GameName))

				updateMetric[float64](game.MetricsMap[currency].Margin)(m.metricsSrv.
					WithCurrency(currency).Margin(ctx, game.GameName))
				updateMetric[float64](game.MetricsMap[currency].MarginY)(m.metricsSrv.
					WithCurrency(currency).WithDailyMetric(yesterday).Margin(ctx, game.GameName))
				updateMetric[float64](game.MetricsMap[currency].MarginLM)(m.metricsSrv.
					WithCurrency(currency).WithDailyMetric(monthBefore).Margin(ctx, game.GameName))
			}
		}

		fn.ServeHTTP(ginCtx.Writer, ginCtx.Request)
	})
}

func updateMetric[T constraints.Integer | constraints.Float](metric prometheus.Gauge) func(val T, err error) {
	return func(val T, err error) {
		if err == nil {
			metric.Set(float64(val))
		} else {
			zap.S().Error(err)
		}
	}
}
