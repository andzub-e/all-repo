package handlers

import (
	"base-slot/internal/http"
	"base-slot/internal/websocket"
	"github.com/gin-gonic/gin"
)

type websocketHandler struct {
	websocketServer *websocket.Server
}

func (w websocketHandler) Register(router *gin.RouterGroup) {
	router.GET("ws", func(ctx *gin.Context) {
		err := w.websocketServer.ServeWS(ctx)
		if err != nil {
			http.ServerError(ctx, err, nil)
		}
	})
}

func NewWebsocketHandler(websocketServer *websocket.Server) http.Handler {
	return &websocketHandler{websocketServer: websocketServer}
}
