package handlers

import (
	"base-slot/internal/http"
	"github.com/gin-gonic/gin"
)

type simulationHandler struct {
}

func (w simulationHandler) Register(router *gin.RouterGroup) {
	sim := router.Group("simulator")

	sim.StaticFile("/", "simulation/index.html")
	sim.StaticFile("/main.js", "simulation/main.js")
	sim.StaticFile("/styles.css", "simulation/styles.css")

}

func NewSimulationHandler() http.Handler {
	return &simulationHandler{}
}
