package handlers

import (
	"base-slot/internal/errs"
	"base-slot/internal/http"
	"github.com/gin-gonic/gin"
)

var errorMap = map[error]func(ctx *gin.Context, data interface{}, meta map[string]interface{}){
	errs.ErrSessionTokenExpired:   http.SessionExpired,
	errs.ErrWrongSessionToken:     http.Unauthorized,
	errs.ErrHistoryRecordNotFound: http.Conflict,
	errs.ErrWrongFreeSpinID:       http.Conflict,
}

func handleServiceError(ctx *gin.Context, err error) {
	internalValidationError, ok := err.(errs.InternalValidationError)
	if ok {
		http.ValidationFailed(ctx, internalValidationError.Err)

		return
	}

	fn, ok := errorMap[err]
	if !ok {
		http.ServerError(ctx, err, nil)

		return
	}

	fn(ctx, err, nil)
}
