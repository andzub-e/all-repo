package wrap

import (
	"base-slot/internal/errs"
	"base-slot/internal/requests"
	"base-slot/internal/responses"
	ws "github.com/gorilla/websocket"
	"sync"
)

type MySocket interface {
	ReadMessage() (requests.SocketWrap, error)
	WriteMessage(wrap responses.SocketWrap) error
}

func NewMySocket(conn *ws.Conn) MySocket {
	return &mySocket{conn: conn, active: true}
}

type mySocket struct {
	conn        *ws.Conn
	writeLocker sync.Mutex
	active      bool
}

func (m *mySocket) ReadMessage() (w requests.SocketWrap, e error) {
	e = m.conn.ReadJSON(&w)
	return
}

func (m *mySocket) WriteMessage(wrap responses.SocketWrap) error {
	m.writeLocker.Lock()
	defer m.writeLocker.Unlock()

	if !m.active {
		return errs.ErrConnectionClosed
	}

	err := m.conn.WriteJSON(wrap)
	if err != nil {
		m.active = false
		_ = m.conn.Close()
		return errs.ErrConnectionClosed
	}

	return nil
}
