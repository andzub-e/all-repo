package constants

const (
	ConfigName          = "Config"
	LoggerName          = "Logger"
	PgSQLName           = "PgSQL"
	RedisName           = "Redis"
	OverlordName        = "Overlord"
	RNGName             = "RNG"
	ServerName          = "Server"
	WebsocketServerName = "WebsocketServer"
	ValidatorName       = "Validator"

	GameFlowHandlerName  = "GameFlowHandler"
	CheatHandlerName     = "CheatHandler"
	WebsocketHandlerName = "WebsocketHandler"
	SimulatorHandlerName = "SimulatorHandler"
	MetricsHandlerName   = "MetricsHandler"

	GameFlowServiceName   = "GameFlowService"
	PrepareServiceName    = "PrepareService"
	BotServiceName        = "BotService"
	HistoryServiceName    = "HistoryService"
	MetricsServiceName    = "MetricsService"
	ConnectionServiceName = "ConnectionService"
	PlaneControlName      = "PlaneControl"

	HistoryRepositoryName = "HistoryRepository"
	MetricsRepositoryName = "MetricsRepository"

	CoefficientFactoryName = "CoefficientFactory"
	PlaneGeneratorName     = "FlyFactory"
	AirportName            = "Airport"
	DistributorName        = "Distributor"

	WagerRepositoryName = "WagerRepository"
)
