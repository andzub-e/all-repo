package constants

const (
	StatusSuccess = iota + 1
	StatusBadRequest
	StatusActionNotFound
	StatusValidationFailed
	StatusInternalError
)
