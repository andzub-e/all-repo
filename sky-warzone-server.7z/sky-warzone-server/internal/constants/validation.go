package constants

const (
	GameRuleName     = "game"
	OperatorRuleName = "operator"
	CoefficientRule  = "coefficient"
)
