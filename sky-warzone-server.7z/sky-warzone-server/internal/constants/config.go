package constants

type Config struct {
	AvailableGames     []string
	AvailableOperators []string
	MinCoefficient     float64
}
