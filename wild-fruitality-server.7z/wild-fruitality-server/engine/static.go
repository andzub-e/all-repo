package engine

import "github.com/samber/lo"

const (
	scatterSymbol = "s"
	windSymbol    = "w"
	potSymbol     = "t"

	windowHeight          = 3
	windowWidth           = 5
	multiplicationDivider = 100

	HighRTPReelCode = 0
	LowRTPReelCode  = 1

	highRTPReelRate = 0.2933
)

var availableReelTypes = []int{HighRTPReelCode, LowRTPReelCode}
var availableReels = []*[][]string{&reelsHighRTP, &reelsLowRTP}

type Window [][]string

func (w *Window) compute(stops []int, reels [][]string) {
	*w = lo.Map(stops, func(stop int, index int) []string {
		reel := reels[index]
		reelLen := len(reel)

		windowLine := make([]string, windowHeight)
		for j := 0; j < windowHeight; j++ {
			windowLine[j] = reel[(stop+j)%reelLen]
		}

		return windowLine
	})
}

func (w Window) symbol(payIndex int) string {
	position, reel := payIndex/windowWidth, payIndex%windowWidth

	return w[reel][position]
}

func awardBySymbolAndCount(symbol string, count int, wager int64) int64 {
	mul := multipliers[symbol][count]

	return mul * wager / multiplicationDivider
}
