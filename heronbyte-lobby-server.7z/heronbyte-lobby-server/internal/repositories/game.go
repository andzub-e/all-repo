package repositories

import (
	"gorm.io/gorm"
	"lobby/internal/constants"
	"lobby/internal/entities"
)

type GameRepository interface {
	All(owner string) ([]*entities.Game, error)
}

type gameRepository struct {
	conn *gorm.DB
}

func NewGameRepository(conn *gorm.DB) GameRepository {
	return &gameRepository{
		conn: conn,
	}
}

func (r *gameRepository) All(owner string) (list []*entities.Game, err error) {
	conn := r.conn
	if owner != constants.EjawOrganization && owner != constants.HeronbyteOrganization {
		conn = conn.Where("owner = ?", owner)
	}

	if owner == constants.HeronbyteOrganization {
		conn = conn.Where("owner = ?", constants.EjawOrganization)
	}

	err = conn.Order("name").Find(&list).Error

	return
}
