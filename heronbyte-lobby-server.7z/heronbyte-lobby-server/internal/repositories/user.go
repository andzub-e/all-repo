package repositories

import (
	"context"
	"github.com/google/uuid"
	"gorm.io/gorm"
	"lobby/internal/entities"
)

type UserRepository interface {
	GetByID(ctx context.Context, id uuid.UUID) (*entities.User, error)
	Get(ctx context.Context, login string) (*entities.User, error)
	Create(ctx context.Context, user *entities.User) error
	Update(ctx context.Context, user *entities.User) error
}

type userRepository struct {
	conn *gorm.DB
}

func NewUserRepository(conn *gorm.DB) UserRepository {
	return &userRepository{conn: conn}
}

func (u *userRepository) GetByID(ctx context.Context, id uuid.UUID) (*entities.User, error) {
	user := &entities.User{}

	return user, u.conn.WithContext(ctx).Where("login = ?", id).First(&user).Error
}

func (u *userRepository) Get(ctx context.Context, login string) (*entities.User, error) {
	user := &entities.User{}

	return user, u.conn.WithContext(ctx).Where("login = ?", login).First(&user).Error
}

func (u *userRepository) Create(ctx context.Context, user *entities.User) error {
	return u.conn.WithContext(ctx).Updates(user).Error
}

func (u *userRepository) Update(ctx context.Context, user *entities.User) error {
	return u.conn.WithContext(ctx).Updates(user).Error
}
