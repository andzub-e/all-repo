package repositories

import (
	"gorm.io/gorm"
	"lobby/internal/constants"
	"lobby/internal/entities"
)

type LinkRepository interface {
	Create(link *entities.Link) error
	All(limit int, owner string) (list []*entities.Link, err error)
}

type linkRepository struct {
	conn *gorm.DB
}

func NewLinkRepository(conn *gorm.DB) LinkRepository {
	return &linkRepository{
		conn: conn,
	}
}

func (r *linkRepository) Create(link *entities.Link) error {
	return r.conn.Create(&link).Error
}

func (r *linkRepository) All(limit int, owner string) (list []*entities.Link, err error) {
	if owner != constants.EjawOrganization {
		return []*entities.Link{}, nil
	}

	err = r.conn.Order("created_at desc").Limit(limit).Find(&list).Error

	return
}
