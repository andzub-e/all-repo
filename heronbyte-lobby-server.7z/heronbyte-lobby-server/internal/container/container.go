package container

import (
	"context"
	"errors"
	"fmt"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
	"lobby/internal/config"
	"lobby/internal/constants"
	"lobby/internal/http"
	"lobby/internal/validator"
	"lobby/pkg/auth/jwt"
	"lobby/pkg/pgsql"
	"lobby/pkg/redis"
	"sync"
)

var container di.Container
var once sync.Once

func Build(ctx context.Context, wg *sync.WaitGroup) di.Container {
	once.Do(func() {
		builder, _ := di.NewBuilder()
		defs := []di.Def{
			{
				Name: constants.LoggerName,
				Build: func(ctn di.Container) (interface{}, error) {
					logger, err := zap.NewDevelopment()

					if err != nil {
						return nil, errors.New(fmt.Sprintf("can't initialize zap logger: %v", err))
					}

					zap.ReplaceGlobals(logger)
					return logger, nil
				},
			},
			{
				Name: constants.ConfigName,
				Build: func(ctn di.Container) (interface{}, error) {
					return config.New()
				},
			},
			{
				Name: constants.PgSQLName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return pgsql.NewPgsqlConnection(cfg.PgSQLConfig)
				},
			},
			{
				Name: constants.ServerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)
					handlers := []http.Handler{
						ctn.Get(constants.AuthHandlerName).(http.Handler),
						ctn.Get(constants.GameHandlerName).(http.Handler),
						ctn.Get(constants.LinkHandlerName).(http.Handler),
					}

					return http.New(ctx, wg, cfg.ServerConfig, handlers), nil
				},
			},
			{
				Name: constants.ValidatorName,
				Build: func(ctn di.Container) (interface{}, error) {
					return validator.New(), nil
				},
			},
			{
				Name: constants.RedisName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return redis.New(cfg.RedisConfig)
				},
			},
			{
				Name: constants.AuthorizerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return jwt.NewProvider(cfg.JWTConfig), nil
				},
			},
		}

		defs = append(defs, BuildRepositories()...)
		defs = append(defs, BuildServices()...)
		defs = append(defs, BuildHandlers()...)

		if err := builder.Add(defs...); err != nil {
			panic(err)
		}

		container = builder.Build()
	})

	return container
}
