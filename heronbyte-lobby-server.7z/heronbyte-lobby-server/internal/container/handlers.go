package container

import (
	"github.com/sarulabs/di"
	"lobby/internal/constants"
	"lobby/internal/http/handlers"
	"lobby/internal/services"
	"lobby/pkg/auth"
)

func BuildHandlers() []di.Def {
	return []di.Def{
		{
			Name: constants.LinkHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				svc := ctn.Get(constants.LinkServiceName).(services.LinkService)

				return handlers.NewLinkHandler(svc), nil
			},
		},
		{
			Name: constants.GameHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				svc := ctn.Get(constants.GameServiceName).(services.GameService)

				return handlers.NewGameHandler(svc), nil
			},
		},
		{
			Name: constants.AuthHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				authz := ctn.Get(constants.AuthorizerName).(auth.Authorizer)
				authenticationService := ctn.Get(constants.AuthenticationServiceName).(*services.AuthenticationService)
				cacheService := ctn.Get(constants.CacheServiceName).(*services.CacheService)

				return handlers.NewAuthHandler(authz, authenticationService, cacheService), nil
			},
		},
	}
}
