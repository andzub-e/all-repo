package container

import (
	"github.com/sarulabs/di"
	"lobby/internal/constants"
	"lobby/internal/repositories"
	"lobby/internal/services"
	"lobby/pkg/auth"
	"lobby/pkg/redis"
)

func BuildServices() []di.Def {
	return []di.Def{
		{
			Name: constants.LinkServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				repo := ctn.Get(constants.LinkRepositoryName).(repositories.LinkRepository)

				return services.NewLinkService(repo), nil
			},
		},
		{
			Name: constants.GameServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				repo := ctn.Get(constants.GameRepositoryName).(repositories.GameRepository)

				return services.NewGameService(repo), nil
			},
		},
		{
			Name: constants.UserServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				repo := ctn.Get(constants.UserRepositoryName).(repositories.UserRepository)

				return services.NewUserService(repo), nil
			},
		},
		{
			Name: constants.CacheServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				userService := ctn.Get(constants.UserServiceName).(*services.UserService)
				cache := ctn.Get(constants.RedisName).(*redis.Client)

				return services.NewCacheService(cache, userService), nil
			},
		},
		{
			Name: constants.AuthenticationServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				authz := ctn.Get(constants.AuthorizerName).(auth.Authorizer)
				userService := ctn.Get(constants.UserServiceName).(*services.UserService)
				cacheService := ctn.Get(constants.CacheServiceName).(*services.CacheService)
				tokenRepo := ctn.Get(constants.TokenRepositoryName).(repositories.TokenRepository)

				return services.NewAuthenticationService(userService, cacheService, tokenRepo, authz), nil
			},
		},
	}
}
