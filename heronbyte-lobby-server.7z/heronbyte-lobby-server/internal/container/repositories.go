package container

import (
	"github.com/sarulabs/di"
	"gorm.io/gorm"
	"lobby/internal/constants"
	"lobby/internal/repositories"
)

func BuildRepositories() []di.Def {
	return []di.Def{
		{
			Name: constants.LinkRepositoryName,
			Build: func(ctn di.Container) (interface{}, error) {
				conn := ctn.Get(constants.PgSQLName).(*gorm.DB)

				return repositories.NewLinkRepository(conn), nil
			},
		},
		{
			Name: constants.GameRepositoryName,
			Build: func(ctn di.Container) (interface{}, error) {
				conn := ctn.Get(constants.PgSQLName).(*gorm.DB)

				return repositories.NewGameRepository(conn), nil
			},
		},
		{
			Name: constants.UserRepositoryName,
			Build: func(ctn di.Container) (interface{}, error) {
				conn := ctn.Get(constants.PgSQLName).(*gorm.DB)

				return repositories.NewUserRepository(conn), nil
			},
		},
		{
			Name: constants.TokenRepositoryName,
			Build: func(ctn di.Container) (interface{}, error) {
				conn := ctn.Get(constants.PgSQLName).(*gorm.DB)

				return repositories.NewTokenRepository(conn), nil
			},
		},
	}
}
