package config

import (
	"github.com/spf13/viper"
	"lobby/internal/http"
	"lobby/pkg/auth/jwt"
	"lobby/pkg/pgsql"
	"lobby/pkg/redis"
	"sync"
)

var config *Config
var once sync.Once

type Config struct {
	PgSQLConfig  *pgsql.Config
	ServerConfig *http.Config
	RedisConfig  *redis.Config
	JWTConfig    *jwt.Config
}

func New() (*Config, error) {
	once.Do(func() {
		config = &Config{}

		viper.AddConfigPath(".")
		viper.SetConfigName("config")

		if err := viper.ReadInConfig(); err != nil {
			panic(err)
		}

		databaseConfig := viper.Sub("database")
		serverConfig := viper.Sub("server")
		redisConfig := viper.Sub("redis")
		jwtConfig := viper.Sub("jwt")

		if err := databaseConfig.Unmarshal(&config.PgSQLConfig); err != nil {
			panic(err)
		}

		if err := serverConfig.Unmarshal(&config.ServerConfig); err != nil {
			panic(err)
		}

		if err := redisConfig.Unmarshal(&config.RedisConfig); err != nil {
			panic(err)
		}

		if err := jwtConfig.Unmarshal(&config.JWTConfig); err != nil {
			panic(err)
		}
	})

	return config, nil
}
