package constants

const EjawOrganization = "ejaw"
const HeronbyteOrganization = "heronbyte"
