package constants

const (
	ConfigName     = "Config"
	LoggerName     = "Logger"
	PgSQLName      = "PgSQL"
	ServerName     = "Server"
	ValidatorName  = "Validator"
	AuthorizerName = "Authorizer"
	RedisName      = "Redis"

	LinkRepositoryName  = "LinkRepository"
	GameRepositoryName  = "GameRepository"
	UserRepositoryName  = "UserRepository"
	TokenRepositoryName = "TokenRepository"

	LinkServiceName           = "LinkService"
	GameServiceName           = "GameService"
	UserServiceName           = "UserService"
	AuthenticationServiceName = "AuthenticationService"
	CacheServiceName          = "CacheService"

	LinkHandlerName = "LinkHandler"
	GameHandlerName = "GameHandler"
	AuthHandlerName = "AuthHandler"
)
