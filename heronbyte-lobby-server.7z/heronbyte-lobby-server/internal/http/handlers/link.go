package handlers

import (
	"github.com/gin-gonic/gin"
	"lobby/internal/entities"
	"lobby/internal/http"
	"lobby/internal/http/request"
	"lobby/internal/http/response"
	"lobby/internal/services"
)

type linkHandler struct {
	linkService services.LinkService
}

func NewLinkHandler(linkService services.LinkService) http.Handler {
	return &linkHandler{
		linkService: linkService,
	}
}

func (h *linkHandler) Register(router *gin.RouterGroup) {
	router.GET("history", h.getLinkHistory)
	router.POST("history", h.addLinkHistory)
}

// @Summary Get history
// @Description Return history by limit, default 50
// @Tags history
// @Param limit query int false "history limit"
// @Produce json
// @Success 200 {object} []entities.Link
// @Failure 400
// @Failure 500
// @Router /history [get]
func (h *linkHandler) getLinkHistory(ctx *gin.Context) {
	user := ctx.Value("user").(*entities.User)

	history, err := h.linkService.All(50, user.Organization)

	if err != nil {
		response.BadRequest(ctx, err, nil)
		return
	}

	response.OK(ctx, history, nil)
}

func (h *linkHandler) addLinkHistory(ctx *gin.Context) {
	var req *request.CreateLinkRequest

	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.ValidationFailed(ctx, err)
		return
	}

	if err := h.linkService.Create(req.Url, req.Date); err != nil {
		response.BadRequest(ctx, err, nil)
		return
	}

	response.OK(ctx, nil, nil)
}
