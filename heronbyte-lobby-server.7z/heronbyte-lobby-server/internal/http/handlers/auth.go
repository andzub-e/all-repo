package handlers

import (
	"errors"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
	"lobby/internal/entities"
	"lobby/internal/http"
	"lobby/internal/http/middlewares"
	"lobby/internal/http/request"
	"lobby/internal/http/response"
	"lobby/internal/services"
	"lobby/pkg/auth"
)

type authHandler struct {
	authProvider        auth.Authorizer
	authenticateService *services.AuthenticationService
	cacheService        *services.CacheService
}

func NewAuthHandler(authProvider auth.Authorizer, authenticateService *services.AuthenticationService, cacheService *services.CacheService) http.Handler {
	return &authHandler{
		authProvider:        authProvider,
		authenticateService: authenticateService,
		cacheService:        cacheService,
	}
}

func (h *authHandler) Register(route *gin.RouterGroup) {
	route.POST("auth/login", h.login)

	route.Use(middlewares.Authenticate(h.authProvider, h.cacheService), middlewares.Authorize())
	route.POST("auth/refresh", h.refresh)
	route.POST("auth/logout", h.logout)
	route.GET("auth/user", h.user)

}

// @Summary Authenticate.
// @Tags meta
// @Consume application/json
// @Description Authenticate user.
// @Accept  json
// @Produce  json
// @Param login body string false "login"
// @Param password body string false "password"
// @Success 200  {object} auth.Auth
// @Router /api/auth/login [post].
func (h *authHandler) login(ctx *gin.Context) {
	req := &request.AuthenticateRequest{}
	if err := ctx.ShouldBindJSON(&req); err != nil {
		response.ValidationFailed(ctx, err)

		return
	}

	token, err := h.authenticateService.Authenticate(ctx, req.Login, req.Password)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) || errors.Is(err, services.ErrNotValidPassword) {
			response.Unauthorized(ctx, err, nil)

			return
		}

		response.ServerError(ctx, err, nil)

		return
	}

	response.OK(ctx, token, nil)
}

// @Summary Refresh tokens.
// @Tags meta
// @Consume application/json
// @Description Refresh tokens.
// @Accept  json
// @Produce  json
// @Security X-Auth
// @Param X-Auth header string true "Insert your refresh token"
// @Success 200  {object} auth.Auth
// @Router /api/auth/refresh [post].
func (h *authHandler) refresh(ctx *gin.Context) {
	token, err := h.authenticateService.Refresh(ctx, ctx.GetHeader("X-Auth"))
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) || errors.Is(err, services.ErrNotValidPassword) {
			response.Unauthorized(ctx, err, nil)

			return
		}

		response.ServerError(ctx, err, nil)

		return
	}

	response.OK(ctx, token, nil)
}

// @Summary Logout.
// @Tags meta
// @Consume application/json
// @Description Logout.
// @Accept  json
// @Produce  json
// @Security X-Auth
// @Param X-Auth header string true "Insert your access token"
// @Success 200  {object} nil
// @Router /api/auth/logout [post].
func (h *authHandler) logout(ctx *gin.Context) {
	user := ctx.Value("user").(*entities.User)

	if err := h.authenticateService.Logout(ctx, user, ctx.GetHeader("X-Auth")); err != nil {
		response.ServerError(ctx, err, nil)

		return
	}

	response.OK(ctx, nil, nil)
}

// @Summary User.
// @Tags meta
// @Consume application/json
// @Description User.
// @Accept  json
// @Produce  json
// @Security X-Auth
// @Param X-Auth header string true "Insert your access token"
// @Success 200  {object} response.User
// @Router /api/auth/user [get].
func (h *authHandler) user(ctx *gin.Context) {
	user := ctx.Value("user").(*entities.User)

	response.OK(ctx, response.User{Login: user.Login, Organization: user.Organization}, nil)
}
