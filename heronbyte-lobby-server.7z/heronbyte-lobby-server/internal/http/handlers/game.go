package handlers

import (
	"github.com/gin-gonic/gin"
	"lobby/internal/entities"
	"lobby/internal/http"
	"lobby/internal/http/response"
	"lobby/internal/services"
)

type gameHandler struct {
	gameService services.GameService
}

func NewGameHandler(gameService services.GameService) http.Handler {
	return &gameHandler{
		gameService: gameService,
	}
}

func (h *gameHandler) Register(router *gin.RouterGroup) {
	games := router.Group("games")
	games.GET("", h.getAllGames)
}

// @Summary Get all games
// @Tags games
// @Produce json
// @Success 200 {object} []entities.Game
// @Failure 400
// @Failure 500
// @Router /games [get]
func (h *gameHandler) getAllGames(ctx *gin.Context) {
	user := ctx.Value("user").(*entities.User)

	games, err := h.gameService.All(user.Organization)

	if err != nil {
		response.BadRequest(ctx, err, nil)
		return
	}

	response.OK(ctx, games, nil)
}
