package response

type User struct {
	Login        string `json:"login"`
	Organization string `json:"role"`
}
