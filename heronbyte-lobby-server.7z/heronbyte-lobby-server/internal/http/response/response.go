package response

import (
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"lobby/internal/validator"
	"net/http"
	"strconv"
	"strings"
)

type Response struct {
	Status  int         `json:"status"`
	Success bool        `json:"success"`
	Meta    interface{} `json:"meta"`
	Data    interface{} `json:"data"`
}

func new(status int, meta interface{}, data interface{}) *Response {
	success := false
	if status >= 200 && status <= 299 {
		success = true
	}

	response := &Response{
		Status:  status,
		Success: success,
		Meta:    meta,
		Data:    data,
	}

	if response.Data == nil {
		response.Data = http.StatusText(status)
	}

	if v, ok := data.(error); ok {
		response.Data = v.Error()
	}

	return response
}

func OK(ctx *gin.Context, data interface{}, meta interface{}) {
	r := new(http.StatusOK, meta, data)
	ctx.JSON(r.Status, r)
}

func BadRequest(ctx *gin.Context, data interface{}, meta interface{}) {
	zap.S().Error(data)
	r := new(http.StatusBadRequest, meta, data)
	ctx.Abort()
	ctx.JSON(r.Status, r)
}

func Unauthorized(ctx *gin.Context, data interface{}, meta interface{}) {
	zap.S().Error(data)
	r := new(http.StatusUnauthorized, meta, data)
	ctx.AbortWithStatusJSON(r.Status, r)
}

func Forbidden(ctx *gin.Context, data interface{}, meta interface{}) {
	zap.S().Error(data)
	r := new(http.StatusForbidden, meta, data)
	ctx.AbortWithStatusJSON(r.Status, r)
}

func NotFound(ctx *gin.Context, data interface{}, meta interface{}) {
	zap.S().Error(data)
	r := new(http.StatusNotFound, meta, data)
	ctx.AbortWithStatusJSON(r.Status, r)
}

func ServerError(ctx *gin.Context, data interface{}, meta interface{}) {
	zap.S().Error(data)
	r := new(http.StatusInternalServerError, meta, data)
	ctx.AbortWithStatusJSON(r.Status, r)
}

func ByCode(ctx *gin.Context, code int, data interface{}, meta interface{}) {
	zap.S().Info(data)
	zap.S().Info("code: " + strconv.Itoa(code))
	r := new(code, meta, data)
	ctx.AbortWithStatusJSON(r.Status, r)
}

func Conflict(ctx *gin.Context, data interface{}, meta interface{}) {
	zap.S().Error(data)
	r := new(http.StatusConflict, meta, data)
	ctx.AbortWithStatusJSON(r.Status, r)
}

func ValidationFailed(ctx *gin.Context, err error) {
	data := strings.Builder{}
	for _, e := range validator.CheckValidationErrors(err) {
		data.Write([]byte(e.Error()))
	}

	r := new(http.StatusUnprocessableEntity, nil, data.String())
	ctx.JSON(r.Status, r)
}
