package request

type AuthenticateRequest struct {
	Login    string `json:"login"`
	Password string `json:"password"`
}
