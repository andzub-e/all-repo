package request

import "github.com/google/uuid"

type CreateRoleRequest struct {
	Name        string `json:"name" validate:"required"`
	Description string `json:"description" validate:"required"`
	Slug        string `json:"slug" validate:"required"`
}

type AssignUserRoleRequest struct {
	UserUUID uuid.UUID `json:"user_uuid"`
	RoleUUID uuid.UUID `json:"role_uuid"`
}

type UserRoleRequest struct {
	Role string `json:"role" validate:"required"`
}

type UserPermissionsRequest struct {
	Permissions []string `json:"permissions" validate:"required,min=1"`
}

type RolePermissionsRequest struct {
	Permissions []string `json:"permissions" validate:"required,min=1"`
}
