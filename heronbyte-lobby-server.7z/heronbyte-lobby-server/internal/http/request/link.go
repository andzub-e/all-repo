package request

type CreateLinkRequest struct {
	Url  string `json:"url" validate:"required" form:"url"`
	Date string `json:"date" validate:"required" form:"date"`
}
