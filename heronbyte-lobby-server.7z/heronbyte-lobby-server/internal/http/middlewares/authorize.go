package middlewares

import (
	"github.com/gin-gonic/gin"
	"lobby/internal/entities"
	"lobby/internal/http/response"
)

func Authorize() gin.HandlerFunc {
	return func(ctx *gin.Context) {
		user, _ := ctx.Value("user").(*entities.User)
		if !user.Authorized(ctx.FullPath(), ctx.Request.Method) {
			response.Unauthorized(ctx, "You don't have permission for this action", nil)

			return
		}

		ctx.Next()
	}
}
