package middlewares

import (
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"lobby/internal/http/response"
	"lobby/internal/services"
	"lobby/pkg/auth"
)

func Authenticate(provider auth.Authorizer, sessionService *services.CacheService) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		uid, err := provider.Verify(ctx)
		if err != nil {
			response.Unauthorized(ctx, err, nil)

			return
		}

		user, err := sessionService.GetUser(ctx, uuid.MustParse(*uid))
		if err != nil {
			response.Unauthorized(ctx, err, nil)

			return
		}

		ctx.Set("user", user)
		ctx.Next()
	}
}
