package entities

import (
	"github.com/google/uuid"
	"time"
)

type Token struct {
	CreatedAt    time.Time
	UserID       uuid.UUID
	AccessToken  string
	RefreshToken string
	ExpiredAt    time.Time
}
