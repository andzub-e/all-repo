package entities

import (
	"encoding/json"
	"github.com/google/uuid"
	"time"
)

type User struct {
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
	DeletedAt time.Time `json:"-"`

	ID           uuid.UUID
	Login        string
	Password     string
	Organization string
}

func (u *User) MarshalBinary() (data []byte, err error) {
	return json.Marshal(u)
}

func (u *User) Unmarshal(data []byte) error {
	return json.Unmarshal(data, &u)
}

func (u *User) Authorized(endpoint, method string) bool {
	return true
}
