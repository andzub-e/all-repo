package entities

import (
	"github.com/lib/pq"
)

type Game struct {
	ID            string         `json:"id"`
	Name          string         `json:"name"`
	Jurisdictions pq.StringArray `json:"jurisdictions" gorm:"type:varchar[]"`
	Currencies    pq.StringArray `json:"currencies" gorm:"type:varchar[]"`
	Languages     pq.StringArray `json:"languages" gorm:"type:varchar[]"`
	UserLocale    pq.StringArray `json:"user_locale" gorm:"type:varchar[]"`
	DevUrl        string         `json:"dev_url"`
	StageUrl      string         `json:"stage_url"`
	DemoUrl       string         `json:"demo_url"`
	ProdUrl       string         `json:"prod_url"`

	Owner string `json:"owner"`
}
