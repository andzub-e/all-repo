package entities

import (
	"github.com/google/uuid"
	"time"
)

type Link struct {
	ID        uuid.UUID `json:"-"`
	URL       string    `json:"url"`
	Date      string    `json:"date"`
	CreatedAt time.Time `json:"-"`
}
