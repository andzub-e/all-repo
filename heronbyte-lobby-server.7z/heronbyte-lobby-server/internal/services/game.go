package services

import (
	"lobby/internal/entities"
	"lobby/internal/repositories"
)

type GameService interface {
	All(owner string) ([]*entities.Game, error)
}

type gameService struct {
	repo repositories.GameRepository
}

func NewGameService(repo repositories.GameRepository) GameService {
	return &gameService{
		repo: repo,
	}
}

func (s *gameService) All(owner string) ([]*entities.Game, error) {
	return s.repo.All(owner)
}
