package services

import (
	"github.com/google/uuid"
	"lobby/internal/entities"
	"lobby/internal/repositories"
	"time"
)

type LinkService interface {
	Create(link, date string) error
	All(limit int, owner string) ([]*entities.Link, error)
}

type linkService struct {
	repo repositories.LinkRepository
}

func NewLinkService(repo repositories.LinkRepository) LinkService {
	return &linkService{
		repo: repo,
	}
}

func (s *linkService) Create(link, date string) error {
	return s.repo.Create(&entities.Link{
		ID:        uuid.New(),
		URL:       link,
		Date:      date,
		CreatedAt: time.Now(),
	})
}

func (s *linkService) All(limit int, owner string) ([]*entities.Link, error) {
	return s.repo.All(limit, owner)
}
