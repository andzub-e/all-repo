package services

import (
	"context"
	"errors"
	"golang.org/x/crypto/bcrypt"
	"lobby/internal/entities"
	"lobby/internal/repositories"
	"lobby/pkg/auth"
)

var (
	ErrNotValidPassword = errors.New("not valid password")
)

type AuthenticationService struct {
	userService  *UserService
	cacheService *CacheService
	tokenRepo    repositories.TokenRepository
	authProvider auth.Authorizer
}

func NewAuthenticationService(userService *UserService, cacheService *CacheService, tokenRepo repositories.TokenRepository, authProvider auth.Authorizer) *AuthenticationService {
	return &AuthenticationService{
		userService:  userService,
		tokenRepo:    tokenRepo,
		cacheService: cacheService,
		authProvider: authProvider,
	}
}

func (s *AuthenticationService) Authenticate(ctx context.Context, login, password string) (*auth.Auth, error) {
	user, err := s.userService.Get(ctx, login)
	if err != nil {
		return nil, err
	}

	if err = bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password)); err != nil {
		return nil, ErrNotValidPassword
	}

	tokens, err := s.authProvider.Generate(auth.WithSubject(user.ID.String()))
	if err != nil {
		return nil, err
	}

	t := &entities.Token{
		UserID:       user.ID,
		AccessToken:  tokens.AccessToken,
		RefreshToken: tokens.RefreshToken,
		ExpiredAt:    tokens.ExpiredAt,
	}

	if err = s.tokenRepo.Create(ctx, t); err != nil {
		return nil, err
	}

	if err = s.cacheService.StoreUser(ctx, user); err != nil {
		return nil, err
	}

	return tokens, nil
}

func (s *AuthenticationService) Refresh(ctx context.Context, rt string) (*auth.Auth, error) {
	token, err := s.tokenRepo.GetByRefresh(ctx, rt)
	if err != nil {
		return nil, err
	}

	tokens, err := s.authProvider.Refresh(auth.WithRefreshToken(rt))
	if err != nil {
		return nil, err
	}

	if err = s.tokenRepo.DeleteByAccess(ctx, token.AccessToken); err != nil {
		return nil, err
	}

	t := &entities.Token{
		UserID:       token.UserID,
		AccessToken:  tokens.AccessToken,
		RefreshToken: tokens.RefreshToken,
		ExpiredAt:    tokens.ExpiredAt,
	}

	if err = s.tokenRepo.Create(ctx, t); err != nil {
		return nil, err
	}

	return tokens, nil
}

func (s *AuthenticationService) Logout(ctx context.Context, user *entities.User, token string) (err error) {
	if err = s.tokenRepo.DeleteByAccess(ctx, token); err != nil {
		return
	}

	if err = s.cacheService.DeleteUser(ctx, user); err != nil {
		return
	}

	return
}
