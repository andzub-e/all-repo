package services

import (
	"context"
	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
	"lobby/internal/entities"
	"lobby/internal/repositories"
	"time"
)

type UserService struct {
	userRepo repositories.UserRepository
}

func NewUserService(userRepo repositories.UserRepository) *UserService {
	return &UserService{
		userRepo: userRepo,
	}
}

func (s *UserService) Create(ctx context.Context, login, password, organization string, creator entities.User) error {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), 15)
	if err != nil {
		return err
	}

	user := &entities.User{
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),

		Login:        login,
		Password:     string(hashedPassword),
		Organization: organization,
	}

	return s.userRepo.Create(ctx, user)
}

func (s *UserService) Get(ctx context.Context, login string) (*entities.User, error) {
	return s.userRepo.Get(ctx, login)
}

func (s *UserService) GetByID(ctx context.Context, id uuid.UUID) (*entities.User, error) {
	return s.userRepo.GetByID(ctx, id)
}
