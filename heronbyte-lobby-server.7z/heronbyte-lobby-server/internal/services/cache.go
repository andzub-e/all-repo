package services

import (
	"context"
	"errors"
	"fmt"
	r "github.com/go-redis/redis/v8"
	"github.com/google/uuid"
	"lobby/internal/entities"
	"lobby/pkg/redis"
	"time"
)

const (
	UsersCacheLifetime  = 720 * time.Hour
	UsersCacheKeyPrefix = "users"
)

type CacheService struct {
	userService *UserService
	cache       *redis.Client
}

func NewCacheService(cache *redis.Client, userService *UserService) *CacheService {
	return &CacheService{
		cache:       cache,
		userService: userService,
	}
}

func (s *CacheService) GetUser(ctx context.Context, id uuid.UUID) (*entities.User, error) {
	user := &entities.User{}
	bts, err := s.cache.Get(ctx, s.prepareKey(UsersCacheKeyPrefix, id.String()))
	if err == nil {
		if err = user.Unmarshal(bts); err != nil {
			return nil, err
		}

		return user, nil
	}

	if !errors.Is(err, r.Nil) {
		return nil, err
	}

	user, err = s.userService.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}

	if err = s.cache.Set(ctx, s.prepareKey(UsersCacheKeyPrefix, id.String()), user, UsersCacheLifetime); err != nil {
		return nil, err
	}

	return user, nil
}

func (s *CacheService) StoreUser(ctx context.Context, user *entities.User) error {
	return s.cache.Set(ctx, s.prepareKey(UsersCacheKeyPrefix, user.ID.String()), user, UsersCacheLifetime)
}

func (s *CacheService) DeleteUser(ctx context.Context, user *entities.User) error {
	return s.cache.Del(ctx, s.prepareKey(UsersCacheKeyPrefix, user.ID.String()))
}

func (s *CacheService) prepareKey(prefix, key string) string {
	return fmt.Sprintf("%s:%s", prefix, key)
}
