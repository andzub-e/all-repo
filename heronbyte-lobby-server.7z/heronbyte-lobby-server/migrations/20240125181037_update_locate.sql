-- +goose Up
-- +goose StatementBegin
UPDATE games
SET user_locale = array_remove(user_locale, 'ua_UK ru_RU');

UPDATE games
SET user_locale = array_append(user_locale, 'uk_UA');
UPDATE games
SET user_locale = array_append(user_locale, 'ru_RU');

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
