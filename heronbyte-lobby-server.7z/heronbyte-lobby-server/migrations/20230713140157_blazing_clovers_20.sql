-- +goose Up
-- +goose StatementBegin

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('19b38c62-882f-4648-b03c-1c82f2fd17bf', 'Blazing Clovers 20 94', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/blazing-clovers-20-94/', 'https://stage.bf.heronbyte.com/blazing-clovers-20-94/', 'https://demo.bf.heronbyte.com/blazing-clovers-20-94/', 'https://prod.bf.heronbyte.com/blazing-clovers-20-94/', 'bf');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('e013f98c-c319-44c8-a0a8-d18b2ef66038', 'Blazing Clovers 20 96', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/blazing-clovers-20-96/', 'https://stage.bf.heronbyte.com/blazing-clovers-20-96/', 'https://demo.bf.heronbyte.com/blazing-clovers-20-96/', 'https://prod.bf.heronbyte.com/blazing-clovers-20-96/', 'bf');

SELECT 'up SQL query';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
