-- +goose Up
-- +goose StatementBegin
insert into users (created_at, updated_at, id, login, password, organization)
values (now(), now(), '6413c5fe-2ab1-45c4-94d9-83b1395ee97e', 'heronbyte', '$2a$10$dqBESGb2kRCG2Wvcd1wHoOfPl3wbqsXTvvC8xfmzAG1LU0Yn9HaCO', 'heronbyte');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
