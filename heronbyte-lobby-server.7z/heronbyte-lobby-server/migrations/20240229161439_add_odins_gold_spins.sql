-- +goose Up
-- +goose StatementBegin
INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale,
                   dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('a5caf4f9-8bb0-4667-86ac-241b94783457',
        'Odins Gold Spins',
        '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, uk_UA, ru_RU, pl_PL, hu_HU}',
        'https://dev-games.heronbyte.com/odins-gold-spins/',
        'https://stage-games.heronbyte.com/odins-gold-spins/',
        '',
        'https://prod-games.heronbyte.com/odins-gold-spins/',
        'ejaw');

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DELETE
FROM games
WHERE id in ('a5caf4f9-8bb0-4667-86ac-241b94783457');
-- +goose StatementEnd
