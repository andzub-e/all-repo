-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';

update games set dev_url = 'https://dev.daplay.io/lucky-skulls-bonanza/',
                 stage_url = 'https://stage.daplay.io/lucky-skulls-bonanza/',
                 demo_url = 'https://demo.daplay.io/lucky-skulls-bonanza/',
                 prod_url = 'https://prod.daplay.io/lucky-skulls-bonanza/'
where id = '62997828-30fe-4218-9310-738aa7c7eb3a';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
