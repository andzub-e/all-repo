-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS games
(
    id            uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    name          VARCHAR   NOT NULL,
    jurisdictions VARCHAR[] NOT NULL,
    currencies    VARCHAR[] NOT NULL,
    languages     VARCHAR[] NOT NULL,
    user_locale   VARCHAR[] NOT NULL,
    dev_url       VARCHAR   NOT NULL,
    stage_url     VARCHAR   NOT NULL
);

CREATE TABLE IF NOT EXISTS links
(
    id         VARCHAR(36) PRIMARY KEY,
    url        VARCHAR(255)                          NOT NULL,
    date       VARCHAR(255)                          NOT NULL,
    created_at timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL
);

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url)
VALUES ('8949a4b9-2f87-43ed-a346-6aaab7757b35', 'Asgard Party', '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}',
        '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/asgardparty', 'https://stage.heronbyte.com/asgardparty');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url)
VALUES ('b3c2fd15-a6bb-4803-823c-858b7a0a4e65', 'Stones of Magic', '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}',
        '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/stonesofmagic', 'https://stage.heronbyte.com/stonesofmagic');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url)
VALUES ('f347fc09-60ec-4a5e-98ba-94e8b9c569a1', 'Rob-O-Tics', '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}',
        '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/robotics', 'https://stage.heronbyte.com/robotics');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url)
VALUES ('5d314d3c-514b-4470-baed-d2e86754c437', 'Dicey Hustle', '{"UA", "RU"}',
        '{"RUB", "USD", "EUR", "KZT", "UAH", "AZN", "UZS", "XTS"}',
        '{RU, UA}',
        '{"da_DK", "de_AT", "de_CH", "de_DE", "el_GR", "en_CA", "en_GB", "en_IE", "en_US", "es_ES", "fi_FI", "fr_BE", "fr_CA", "fr_CH", "fr_FR", "it_CH", "it_IT", "ja_JP", "ko_KR", "nl_BE", "nl_NL", "no_NO", "no_NO_B", "pt_PT", "sv_SE", "tr_TR", "zh_TW"}',
        'https://dev.heronbyte.com/diceyhustle', 'https://stage.heronbyte.com/diceyhustle');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
DROP TABLE IF EXISTS games;
DROP TABLE IF EXISTS links;
-- +goose StatementEnd
