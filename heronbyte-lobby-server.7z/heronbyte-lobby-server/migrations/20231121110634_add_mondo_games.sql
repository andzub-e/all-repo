-- +goose Up
-- +goose StatementBegin
INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('06b45d72-064c-4676-a147-debe55943b3e',
        'Egyptians Book',
        '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/egyptians-book/',
        'https://stage.heronbyte.com/egyptians-book/',
        'https://prod.heronbyte.com/egyptians-book/',
        'https://prod.heronbyte.com/egyptians-book/',
        'mondo_games');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('c4c9be00-977f-4754-8300-1655ba4af9c4',
        'Olympus Quest',
        '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/olympus-quest/',
        'https://stage.heronbyte.com/olympus-quest/',
        'https://prod.heronbyte.com/olympus-quest/',
        'https://prod.heronbyte.com/olympus-quest/',
        'mondo_games');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('cdb3d3be-2dfc-4a7b-b6e1-7d149db3338b',
        'Toreadors Fortune',
        '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/toreadors-fortune/',
        'https://stage.heronbyte.com/toreadors-fortune/',
        'https://prod.heronbyte.com/toreadors-fortune/',
        'https://prod.heronbyte.com/toreadors-fortune/',
        'mondo_games');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DELETE
FROM games
WHERE id in ('06b45d72-064c-4676-a147-debe55943b3e',
             'c4c9be00-977f-4754-8300-1655ba4af9c4',
             'cdb3d3be-2dfc-4a7b-b6e1-7d149db3338b')
-- +goose StatementEnd
