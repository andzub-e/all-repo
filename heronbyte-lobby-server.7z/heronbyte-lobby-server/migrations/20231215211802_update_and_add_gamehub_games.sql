-- +goose Up
-- +goose StatementBegin

UPDATE games
SET
    name = 'Lucky Skulls Bonanza',
    stage_url = 'https://stage-games.daplay.io/lucky-skulls-bonanza/'
WHERE id = '62997828-30fe-4218-9310-738aa7c7eb3a';

UPDATE games
SET stage_url = 'https://stage-games.daplay.io/wild-fruitality/'
WHERE id = 'd750a342-ea3c-4157-a9ad-50d8f9b14031';

UPDATE games
SET stage_url = 'https://stage-games.daplay.io/cleos-riches-flexiways/'
WHERE id = 'c15496ad-ac59-4cba-a2e3-56712af0aee7';

UPDATE games
SET stage_url = 'https://stage-games.daplay.io/fortune-777-respin/'
WHERE id = '2ba51cb1-0378-4230-b89c-c9423bb4d951';

UPDATE games
SET stage_url = 'https://stage-games.daplay.io/sweet-mystery-flexiways/'
WHERE id = '9609aadc-489a-44b3-84a0-433daef773b2';

UPDATE games
SET stage_url = 'https://stage-games.daplay.io/wild-dragon-respin/'
WHERE id = 'c8ea4f7d-1c6e-4ed2-8e01-dd5aba4e130f';

UPDATE games
SET stage_url = 'https://stage-games.daplay.io/quest-of-ra/'
WHERE id = '936b971e-5761-4e8a-ae88-541dd7ff111b';

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale,
                   dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('965a9a6a-0bab-4214-a95d-3ca78b1d8ec7',
        'Irish Riches Bonanza',
        '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev-games.daplay.io/irish-riches-bonanza/',
        'https://stage-games.daplay.io/irish-riches-bonanza/',
        '',
        'https://prod-games.daplay.io/irish-riches-bonanza/',
        'game_hub');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale,
                   dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('a12a930f-a35e-421a-a151-d68d0667cd5c',
        'Coral Reef Flexiways',
        '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev-games.daplay.io/coral-reef-flexiways/',
        'https://stage-games.daplay.io/coral-reef-flexiways/',
        '',
        'https://prod-games.daplay.io/coral-reef-flexiways/',
        'game_hub');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DELETE
FROM games
WHERE id in ('965a9a6a-0bab-4214-a95d-3ca78b1d8ec7',
             'a12a930f-a35e-421a-a151-d68d0667cd5c');
-- +goose StatementEnd
