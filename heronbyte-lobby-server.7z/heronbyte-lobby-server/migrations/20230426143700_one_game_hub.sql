-- +goose Up
-- +goose StatementBegin
insert into users (created_at, updated_at, id, login, password, organization)
values (now(), now(), 'e7efa397-27c1-4c0e-8550-9f3aaffe5db6', '1GameHUB', '$2a$10$lO0zCFMAHzCxqcnm1N8lVOeyN4nkrzi/LG8SrVRJ8kS60anr4okD2', 'heronbyte');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
