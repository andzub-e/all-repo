-- +goose Up
-- +goose StatementBegin
INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('cb9e4bda-def0-470b-a9a9-f6cbfe368cff', 'Wild West John', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA,RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/wild-west-john/', 'https://stage.bf.heronbyte.com/wild-west-john/', 'https://demo.bf.heronbyte.com/wild-west-john/', 'https://prod.bf.heronbyte.com/wild-west-john/', 'bf');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
