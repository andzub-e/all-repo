-- +goose Up
-- +goose StatementBegin
UPDATE games
SET dev_url = 'https://dev-cryptolut.heronbyte.com/burning-wins-3/'
WHERE id = 'b3326714-895b-415f-956f-049d27f9bab8';

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
