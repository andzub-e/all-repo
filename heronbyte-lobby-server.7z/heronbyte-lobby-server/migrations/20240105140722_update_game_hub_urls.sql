-- +goose Up
-- +goose StatementBegin
update games
set dev_url   = replace(dev_url, 'dev.daplay.io', 'dev-games.daplay.io'),
    stage_url = replace(stage_url, 'stage.daplay.io', 'stage-games.daplay.io'),
    prod_url  = replace(prod_url, 'prod.daplay.io', 'prod-games.daplay.io')
where owner = 'game_hub';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
