-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
alter table games add column demo_url varchar default '';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
alter table games drop column demo_url;
-- +goose StatementEnd
