-- +goose Up
-- +goose StatementBegin
INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale,
                   dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('d4b6488a-f9b4-41a7-83e6-811301bb0a0e',
        'Magic Moonlight',
        '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK, ru_RU, pl_PL, hu_HU}',
        'https://dev-games.heronbyte.com/magic-moonlight/',
        'https://stage-games.heronbyte.com/magic-moonlight/',
        '',
        'https://prod-games.heronbyte.com/magic-moonlight/',
        'mondo_games');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale,
                   dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('4bc6d348-bb22-4dd1-8dc6-83aa27df22dc',
        'Crystal Ways',
        '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK, ru_RU, pl_PL, hu_HU}',
        'https://dev-games.heronbyte.com/crystal-ways/',
        'https://stage-games.heronbyte.com/crystal-ways/',
        '',
        'https://prod-games.heronbyte.com/crystal-ways/',
        'mondo_games');

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DELETE
FROM games
WHERE id in ('d4b6488a-f9b4-41a7-83e6-811301bb0a0e',
             '4bc6d348-bb22-4dd1-8dc6-83aa27df22dc');
-- +goose StatementEnd
