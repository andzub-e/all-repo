-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('e477a20e-b93b-48d4-9fc2-cf51732ffb4b', 'Test Symbols Project', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.heronbyte.com/test-symbols-project/', 'https://stage.heronbyte.com/test-symbols-project/', 'https://demo.heronbyte.com/test-symbols-project/', 'https://prod.heronbyte.com/test-symbols-project/', 'ejaw');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
