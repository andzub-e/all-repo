-- +goose Up
-- +goose StatementBegin
UPDATE games
SET owner = 'game_hub'
WHERE id = 'e618eb90-085b-4464-9b02-afea37358173'
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin

-- +goose StatementEnd
