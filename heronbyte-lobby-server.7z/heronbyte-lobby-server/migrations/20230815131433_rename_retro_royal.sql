-- +goose Up
-- +goose StatementBegin
update games
set name      = 'Retro Royale',
    dev_url   = 'https://dev.heronbyte.com/retro-royale/',
    stage_url = 'https://stage.heronbyte.com/retro-royale/',
    demo_url  = 'https://demo.heronbyte.com/retro-royale/',
    prod_url  = 'https://games.heronbyte.com/retro-royale/'
where id = 'fc52f197-4aec-431c-9029-2218f26d8125';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
