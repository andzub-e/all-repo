-- +goose Up
-- +goose StatementBegin
INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale,
                   dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('057cc590-c14b-4a9b-a4e3-82465ed8ea6f',
        'Pirates Paradise',
        '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, uk_UA, ru_RU, pl_PL, hu_HU}',
        'https://dev-games.heronbyte.com/pirates-paradise/',
        'https://stage-games.heronbyte.com/pirates-paradise/',
        '',
        'https://prod-games.heronbyte.com/pirates-paradise/',
        'ejaw'),
       ('d2e71b1c-1896-423e-8a09-1a70c21097bb',
        'Hula Luau Gold',
        '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, uk_UA, ru_RU, pl_PL, hu_HU}',
        'https://dev-games.heronbyte.com/hula-luau-gold/',
        'https://stage-games.heronbyte.com/hula-luau-gold/',
        '',
        'https://prod-games.heronbyte.com/hula-luau-gold/',
        'ejaw');

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DELETE
FROM games
WHERE id in ('057cc590-c14b-4a9b-a4e3-82465ed8ea6f',
            'd2e71b1c-1896-423e-8a09-1a70c21097bb');
-- +goose StatementEnd
