-- +goose Up
-- +goose StatementBegin
DELETE
FROM games
WHERE id IN ('83c80da8-a221-11ed-a8fc-0242ac120002',
            'e477a20e-b93b-48d4-9fc2-cf51732ffb4b',
            'e7e0214b-a322-4942-8f34-2b3ff2eeac59');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin

-- +goose StatementEnd
