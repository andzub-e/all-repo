-- +goose Up
-- +goose StatementBegin

ALTER TABLE games ADD COLUMN  prod_url VARCHAR(255) DEFAULT '';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE games DROP COLUMN  prod_url;
-- +goose StatementEnd
