-- +goose Up
-- +goose StatementBegin
UPDATE games
SET
    dev_url = 'https://dev.heronbyte.com/blockchain-plinko/',
    stage_url = 'https://stage.heronbyte.com/blockchain-plinko/',
    demo_url = 'https://prod.heronbyte.com/blockchain-plinko/',
    prod_url = 'https://prod.heronbyte.com/blockchain-plinko/'
WHERE id = 'e7e0214b-a322-4942-8f34-2b3ff2eeac59';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
