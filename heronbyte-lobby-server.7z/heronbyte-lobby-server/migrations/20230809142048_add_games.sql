-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';
INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('fc52f197-4aec-431c-9029-2218f26d8125', 'Rerto Royal', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.heronbyte.com/retro-royal/', 'https://stage.heronbyte.com/retro-royal/', 'https://demo.heronbyte.com/retro-royal/', 'https://prod.heronbyte.com/retro-royal/', 'ejaw');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('62997828-30fe-4218-9310-738aa7c7eb3a', 'Sweet Bonanza', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.heronbyte.com/sweet-bonanza/', 'https://stage.heronbyte.com/sweet-bonanza/', 'https://demo.heronbyte.com/sweet-bonanza/', 'https://prod.heronbyte.com/sweet-bonanza/', 'game_hub');

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
