-- +goose Up
-- +goose StatementBegin
update games
set name      = 'Wild Fruitality',
    dev_url   = 'https://dev.heronbyte.com/wild-fruitality/',
    stage_url = 'https://stage.heronbyte.com/wild-fruitality/',
    demo_url  = 'https://demo.heronbyte.com/wild-fruitality/',
    prod_url  = 'https://games.heronbyte.com/wild-fruitality/'
where id = 'fc52f197-4aec-431c-9029-2218f26d8125';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
