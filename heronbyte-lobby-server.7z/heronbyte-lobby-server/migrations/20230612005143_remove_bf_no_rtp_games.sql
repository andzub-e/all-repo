-- +goose Up
-- +goose StatementBegin
delete from games where id in (
    'b6b880c6-a221-11ed-a8fc-0242ac120002',
    'a6b45a9c-a221-11ed-a8fc-0242ac120002',
    'ab2b6fca-a221-11ed-a8fc-0242ac120002',
    'e0584944-7040-45b9-8f4f-eb400e20cd33',
    '7d190d1d-7e53-4aca-a994-1a247c5c58d7',
    'cb9e4bda-def0-470b-a9a9-f6cbfe368cff'
    );
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
