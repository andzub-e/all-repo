-- +goose Up
-- +goose StatementBegin
UPDATE games
SET name = 'Vampire Vault Hold n Win',
    dev_url  = 'https://dev-games.daplay.io/vampire-vault-hold-n-win/',
    stage_url= 'https://stage-games.daplay.io/vampire-vault-hold-n-win/',
    prod_url = 'https://prod-games.daplay.io/vampire-vault-hold-n-win/'
WHERE id = '726e4a5c-8761-4d5b-84d3-afa9de37b791'
-- +goose StatementEnd

-- +goose Down