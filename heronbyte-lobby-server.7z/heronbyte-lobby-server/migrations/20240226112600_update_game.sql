-- +goose Up
-- +goose StatementBegin
UPDATE games
SET dev_url  = 'https://dev-games.heronbyte.com/inferno-riches/',
    stage_url= 'https://stage-games.heronbyte.com/inferno-riches/',
    prod_url = 'https://prod-games.heronbyte.com/inferno-riches/'
WHERE id = 'e618eb90-085b-4464-9b02-afea37358173'
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin

-- +goose StatementEnd
