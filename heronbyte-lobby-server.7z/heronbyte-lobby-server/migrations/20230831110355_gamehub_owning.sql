-- +goose Up
-- +goose StatementBegin
update users set organization = 'game_hub' where id = 'e7efa397-27c1-4c0e-8550-9f3aaffe5db6';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
