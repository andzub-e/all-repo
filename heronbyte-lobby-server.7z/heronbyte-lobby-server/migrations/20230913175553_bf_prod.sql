-- +goose Up
-- +goose StatementBegin
update games set prod_url = REPLACE(prod_url, 'prod.bf.heronbyte.com', 'hb-games.pro') where owner = 'bf';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
