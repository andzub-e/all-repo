-- +goose Up
-- +goose StatementBegin
insert into users (created_at, updated_at, id, login, password, organization)
values (now(), now(), '8d67f067-5234-4413-8902-3f576add93f7', 'BGaming', '$2a$10$4Ayo9RG3VenB5xs/fzCgPONTXN4oWvBEXApU.g4rLFCla2/KoU5DC', 'heronbyte');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
