-- +goose Up
-- +goose StatementBegin
DELETE FROM games;

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('5d314d3c-514b-4470-baed-d2e86754c437', 'Asgard Party', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/asgardparty/', 'https://stage.heronbyte.com/asgardparty/', 'https://demo.heronbyte.com/asgardparty/', 'https://prod.heronbyte.com/asgardparty/', 'ejaw');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('7a1fa9fa-a221-11ed-a8fc-0242ac120002', 'Stones of Magic', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/stonesofmagic/', 'https://stage.heronbyte.com/stonesofmagic/', 'https://demo.heronbyte.com/stonesofmagic/', 'https://prod.heronbyte.com/stonesofmagic/', 'ejaw');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('7e544f1c-a221-11ed-a8fc-0242ac120002', 'Ego Draconis', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/ego-draconis/', 'https://stage.heronbyte.com/ego-draconis/', 'https://demo.heronbyte.com/ego-draconis/', 'https://prod.heronbyte.com/ego-draconis/', 'ejaw');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('83c80da8-a221-11ed-a8fc-0242ac120002', 'Rob-o-tics', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/robotics/', 'https://stage.heronbyte.com/robotics/', 'https://demo.heronbyte.com/robotics/', 'https://prod.heronbyte.com/robotics', 'ejaw');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('88b1953c-a221-11ed-a8fc-0242ac120002', 'Spells Streak', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/spells-streak/', 'https://stage.heronbyte.com/spells-streak/', 'https://demo.heronbyte.com/spells-streak/', 'https://prod.heronbyte.com/spells-streak/', 'ejaw');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('8d50ad58-a221-11ed-a8fc-0242ac120002', 'Cyber Town', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/cyber-town/', 'https://stage.heronbyte.com/cyber-town/', 'https://demo.heronbyte.com/cyber-town/', 'https://prod.heronbyte.com/cyber-town/', 'ejaw');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('92fc4032-a221-11ed-a8fc-0242ac120002', 'Secret Totem', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/secrettotems/', 'https://stage.heronbyte.com/secrettotems/', 'https://demo.heronbyte.com/secrettotems/', 'https://prod.heronbyte.com/secrettotems/', 'ejaw');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('9775d0c4-a221-11ed-a8fc-0242ac120002', 'Precious Bugs', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/preciousbugs/', 'https://stage.heronbyte.com/preciousbugs/', 'https://demo.heronbyte.com/preciousbugs/', 'https://prod.heronbyte.com/preciousbugs/', 'ejaw');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('9d1e6d06-a221-11ed-a8fc-0242ac120002', 'Aviator', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/aviator/', 'https://stage.heronbyte.com/aviator/', 'https://demo.heronbyte.com/aviator/', 'https://prod.heronbyte.com/aviator/', 'ejaw');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('a29a1bfe-a221-11ed-a8fc-0242ac120002', 'Plinko', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/plinko/', 'https://stage.heronbyte.com/plinko/', 'https://demo.heronbyte.com/plinko/', 'https://prod.heronbyte.com/plinko/', 'ejaw');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('a6b45a9c-a221-11ed-a8fc-0242ac120002', 'Smashing Hot', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.bf.heronbyte.com/smashing-hot/', 'https://stage.bf.heronbyte.com/smashing-hot/', 'https://demo.bf.heronbyte.com/smashing-hot/', 'https://prod.bf.heronbyte.com/smashing-hot/', 'bf');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('ab2b6fca-a221-11ed-a8fc-0242ac120002', 'Smashing Hot 20', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.bf.heronbyte.com/smashing-hot-20/', 'https://stage.bf.heronbyte.com/smashing-hot-20/', 'https://demo.bf.heronbyte.com/smashing-hot-20/', 'https://prod.bf.heronbyte.com/smashing-hot-20/', 'bf');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('b6b880c6-a221-11ed-a8fc-0242ac120002', 'Book of Ming', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.bf.heronbyte.com/book-of-dynasty/', 'https://stage.bf.heronbyte.com/book-of-dynasty/', 'https://demo.bf.heronbyte.com/book-of-dynasty/', 'https://prod.bf.heronbyte.com/book-of-dynasty/', 'bf');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('bd09da38-a221-11ed-a8fc-0242ac120002', 'Book of Jones', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/book-of-jones/', 'https://stage.heronbyte.com/book-of-jones/', 'https://demo.heronbyte.com/book-of-jones/', 'https://prod.heronbyte.com/book-of-jones/', 'lemon');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('c2629a60-a221-11ed-a8fc-0242ac120002', 'Burning 20 Wins', '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.heronbyte.com/burning-20-wins/', 'https://stage.heronbyte.com/burning-20-wins/', 'https://demo.heronbyte.com/burning-20-wins/', 'https://prod.heronbyte.com/burning-20-wins/', 'lemon');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
