-- +goose Up
-- +goose StatementBegin
INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('1f7033e9-2fc1-426b-8d45-36940fedc894', 'Smashing Hot 94', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/smashing-hot-94/', 'https://stage.bf.heronbyte.com/smashing-hot-94/', 'https://demo.bf.heronbyte.com/smashing-hot-94/', 'https://prod.bf.heronbyte.com/smashing-hot-94/', 'bf');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('337f323a-c992-4a12-bd48-f3b2f5b236c6', 'Smashing Hot 96', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/smashing-hot-96/', 'https://stage.bf.heronbyte.com/smashing-hot-96/', 'https://demo.bf.heronbyte.com/smashing-hot-96/', 'https://prod.bf.heronbyte.com/smashing-hot-96/', 'bf');


INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('7811e829-550e-4524-b124-bb68ec5d3579', 'Smashing Hot 20 94', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/smashing-hot-20-94/', 'https://stage.bf.heronbyte.com/smashing-hot-20-94/', 'https://demo.bf.heronbyte.com/smashing-hot-20-94/', 'https://prod.bf.heronbyte.com/smashing-hot-20-94/', 'bf');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('b794f433-3b92-4e50-b6db-bce523080d10', 'Smashing Hot 20 96', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/smashing-hot-20-96/', 'https://stage.bf.heronbyte.com/smashing-hot-20-96/', 'https://demo.bf.heronbyte.com/smashing-hot-20-96/', 'https://prod.bf.heronbyte.com/smashing-hot-20-96/', 'bf');



INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('378907b3-d47a-4f33-9e61-8c0a463d981c', 'Book Of Dynasty 94', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/book-of-dynasty-94/', 'https://stage.bf.heronbyte.com/book-of-dynasty-94/', 'https://demo.bf.heronbyte.com/book-of-dynasty-94/', 'https://prod.bf.heronbyte.com/book-of-dynasty-94/', 'bf');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('ff163581-d2eb-469e-b2be-b26889f8779c', 'Book Of Dynasty 96', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/book-of-dynasty-96/', 'https://stage.bf.heronbyte.com/book-of-dynasty-96/', 'https://demo.bf.heronbyte.com/book-of-dynasty-96/', 'https://prod.bf.heronbyte.com/book-of-dynasty-96/', 'bf');


INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('43e00396-7e8f-4972-9189-a486db79e19d', 'Book Of Sacred 94', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/book-of-sacred-94/', 'https://stage.bf.heronbyte.com/book-of-sacred-94/', 'https://demo.bf.heronbyte.com/book-of-sacred-94/', 'https://prod.bf.heronbyte.com/book-of-sacred-94/', 'bf');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('2dfb3a95-208f-4e6d-93e7-9d7675cacab3', 'Book Of Sacred 96', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/book-of-sacred-96/', 'https://stage.bf.heronbyte.com/book-of-sacred-96/', 'https://demo.bf.heronbyte.com/book-of-sacred-96/', 'https://prod.bf.heronbyte.com/book-of-sacred-96/', 'bf');


INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('8b6a6873-5085-4b80-bb32-6c2e6e618d5d', 'Wild West John 93', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/wild-west-john-93/', 'https://stage.bf.heronbyte.com/wild-west-john-93/', 'https://demo.bf.heronbyte.com/wild-west-john-93/', 'https://prod.bf.heronbyte.com/wild-west-john-93/', 'bf');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('56637c47-6f46-4b06-8d66-a0d47d9d1175', 'Wild West John 95', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/wild-west-john-95/', 'https://stage.bf.heronbyte.com/wild-west-john-95/', 'https://demo.bf.heronbyte.com/wild-west-john-95/', 'https://prod.bf.heronbyte.com/wild-west-john-95/', 'bf');



INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('96522462-f635-4e24-b0cc-b7a2e65d4df9', 'Blazing Clovers 94', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/blazing-clovers-94/', 'https://stage.bf.heronbyte.com/blazing-clovers-94/', 'https://demo.bf.heronbyte.com/blazing-clovers-94/', 'https://prod.bf.heronbyte.com/blazing-clovers-94/', 'bf');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url, owner)
VALUES ('ea924517-2b5c-4a46-96b7-1bc8a51435c3', 'Blazing Clovers 96', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.bf.heronbyte.com/blazing-clovers-96/', 'https://stage.bf.heronbyte.com/blazing-clovers-96/', 'https://demo.bf.heronbyte.com/blazing-clovers-96/', 'https://prod.bf.heronbyte.com/blazing-clovers-96/', 'bf');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
