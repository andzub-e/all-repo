-- +goose Up
-- +goose StatementBegin
SELECT 'up SQL query';

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url,
                   owner)
VALUES ('c15496ad-ac59-4cba-a2e3-56712af0aee7',
        'Cleos Riches Flexiways',
        '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.daplay.io/cleos-riches-flexiways/',
        'https://stage.daplay.io/cleos-riches-flexiways/',
        'https://demo.daplay.io/cleos-riches-flexiways/',
        'https://prod.daplay.io/cleos-riches-flexiways/',
        'game_hub');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url,
                   owner)
VALUES ('2ba51cb1-0378-4230-b89c-c9423bb4d951',
        'Fortune 777 Respin',
        '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.daplay.io/fortune-777-respin/',
        'https://stage.daplay.io/fortune-777-respin/',
        'https://demo.daplay.io/fortune-777-respin/',
        'https://prod.daplay.io/fortune-777-respin/',
        'game_hub');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url,
                   owner)
VALUES ('9609aadc-489a-44b3-84a0-433daef773b2',
        'Sweet Mystery Flexiways',
        '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.daplay.io/sweet-mystery-flexiways/',
        'https://stage.daplay.io/sweet-mystery-flexiways/',
        'https://demo.daplay.io/sweet-mystery-flexiways/',
        'https://prod.daplay.io/sweet-mystery-flexiways/',
        'game_hub');

INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url,
                   owner)
VALUES ('c8ea4f7d-1c6e-4ed2-8e01-dd5aba4e130f',
        'Wild Dragon Respin',
        '{"UA", "RU"}',
        '{USD, EUR, KZT, RUB, UAH, AZN, UZS, XTS, CAD, USDT, INR}',
        '{UA, RU}',
        '{en_US, en_CA, en_GB, en_IE, da_DK, de_AT, de_CH, de_DE, el_GR, es_ES, fi_FI, fr_BE, fr_CA, fr_CH, fr_FR, it_CH, it_IT, ja_JP, ko_KR, nl_BE, nl_NL, no_NO, no_NO_B, pt_PT, sv_SE, tr_TR, zh_TW, ua_UK ru_RU, pl_PL, hu_HU}',
        'https://dev.daplay.io/wild-dragon-respin/',
        'https://stage.daplay.io/wild-dragon-respin/',
        'https://demo.daplay.io/wild-dragon-respin/',
        'https://prod.daplay.io/wild-dragon-respin/',
        'game_hub');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';

DELETE
FROM games
WHERE id in ('c8ea4f7d-1c6e-4ed2-8e01-dd5aba4e130f',
             '9609aadc-489a-44b3-84a0-433daef773b2',
             '2ba51cb1-0378-4230-b89c-c9423bb4d951',
             'c15496ad-ac59-4cba-a2e3-56712af0aee7')
-- +goose StatementEnd