-- +goose Up
-- +goose StatementBegin
alter table games add column owner varchar(40) default 'ejaw';

create table if not exists users
(
    created_at   timestamptz default now(),
    updated_at   timestamptz,
    deleted_at   timestamptz,

    id           uuid primary key,
    login        varchar(40) unique,
    password     varchar,
    organization varchar(40)
);

create table if not exists tokens
(
    created_at    timestamptz default now(),
    user_id       uuid references users (id) on delete cascade,
    access_token  text        not null,
    refresh_token text        not null,
    expired_at    timestamptz not null,
    primary key (user_id, access_token, refresh_token)
);

create index if not exists idx_access_token on tokens using hash (access_token);
create index if not exists idx_refresh_token on tokens using hash (refresh_token);

insert into users (created_at, updated_at, id, login, password, organization)
values (now(), now(), '51e8e8d8-8b70-11ed-a1eb-0242ac120002', 'ejaw', '$2a$15$USRHW/9ic379Y7RfjEkIWuoCD6eMy/Ro/oaH8TsZmV6f9eZA2GavW', 'ejaw');
insert into users (created_at, updated_at, id, login, password, organization)
values (now(), now(), '9424618c-8b7f-11ed-a1eb-0242ac120002', 'lemon-casino', '$2a$15$3bTt73M/yb3bjrRz877ta.GlKTpiZPOwjsDW57pi4iNznuNtkafWC', 'lemon');
insert into users (created_at, updated_at, id, login, password, organization)
values (now(), now(), 'b5469e8e-8b7f-11ed-a1eb-0242ac120002', 'bf-games', '$2a$15$OyBcAAmerMfkhVjiWg5x3e9XH7Ecp/ahYA0JRcaoN0bOd/BL0Jp4S', 'bf');

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
drop table if exists users;
drop index if exists idx_access_token;
drop index if exists idx_refresh_token;
drop table if exists tokens;
-- +goose StatementEnd
