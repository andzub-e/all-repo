-- +goose Up
-- +goose StatementBegin
update games
set name      = 'Retro Royale',
    dev_url   = 'https://dev.heronbyte.com/retro-royale/',
    stage_url = 'https://stage.heronbyte.com/retro-royale/',
    demo_url  = 'https://demo.heronbyte.com/retro-royale/',
    prod_url  = 'https://games.heronbyte.com/retro-royale/'
where id = 'fc52f197-4aec-431c-9029-2218f26d8125';


INSERT INTO games (id, name, jurisdictions, currencies, languages, user_locale, dev_url, stage_url, demo_url, prod_url,
                   owner)
VALUES ('d750a342-ea3c-4157-a9ad-50d8f9b14031', 'Wild Fruitality', '{"UA", "RU"}',
        '{USD,EUR,KZT,RUB,UAH,AZN,UZS,XTS,CAD,USDT,INR,HUF,NZD,NOK,PLN,ZAR,BRL,PEN,CLP,MXN}',
        '{UA, RU}',
        '{en_US,en_CA,en_GB,en_IE,da_DK,de_AT,de_CH,de_DE,el_GR,es_ES,fi_FI,fr_BE,fr_CA,fr_CH,fr_FR,it_CH,it_IT,ja_JP,ko_KR,nl_BE,nl_NL,no_NO,no_NO_B,pt_PT,sv_SE,tr_TR,zh_TW,ua_UK,ru_RU,pl_PL,hu_HU}',
        'https://dev.heronbyte.com/wild-fruitality/',
        'https://stage.heronbyte.com/wild-fruitality/',
        'https://demo.heronbyte.com/wild-fruitality/',
        'https://games.heronbyte.com/wild-fruitality/', 'game_hub');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
