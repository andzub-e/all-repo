-- +goose Up
-- +goose StatementBegin
update games
set dev_url   = replace(dev_url, 'dev.heronbyte.com', 'dev-games.heronbyte.com'),
    stage_url = replace(stage_url, 'stage.heronbyte.com', 'stage-games.heronbyte.com'),
    prod_url  = replace(prod_url, 'prod.heronbyte.com', 'prod-games.heronbyte.com')
where owner in ('mondo_games', 'ejaw');
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
SELECT 'down SQL query';
-- +goose StatementEnd
