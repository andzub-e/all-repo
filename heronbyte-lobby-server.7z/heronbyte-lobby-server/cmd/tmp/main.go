package main

import (
	"fmt"
	"golang.org/x/crypto/bcrypt"
)

var password = []byte("")

func main() {
	b, err := bcrypt.GenerateFromPassword(password, 0)
	if err != nil {
		panic(err)
	}

	fmt.Println(string(b))

	err = bcrypt.CompareHashAndPassword(b, password)
	fmt.Println(err)
}
