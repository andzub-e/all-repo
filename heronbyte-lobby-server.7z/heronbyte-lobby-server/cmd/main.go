package main

import (
	"context"
	"github.com/gin-gonic/gin/binding"
	"go.uber.org/zap"
	"lobby/internal/constants"
	"lobby/internal/container"
	"lobby/internal/http"
	"lobby/internal/validator"
	"lobby/utils"
	"sync"
	"time"
)

func main() {
	now := time.Now()
	ctx := context.Background()
	wg := &sync.WaitGroup{}
	app := container.Build(ctx, wg)

	logger := app.Get("Logger").(*zap.Logger)
	logger.Info("Starting application...")
	server := app.Get(constants.ServerName).(*http.Server)

	binding.Validator = app.Get(constants.ValidatorName).(*validator.Validator)

	go server.Run()

	zap.S().Infof("Up and running (%s)", time.Since(now))
	zap.S().Infof("Got %s signal. Shutting down...", <-utils.WaitTermSignal())

	if err := server.Shutdown(ctx); err != nil {
		zap.S().Errorf("Error stopping server: %s", err)
	}

	wg.Wait()
	zap.S().Info("Service stopped.")
}
