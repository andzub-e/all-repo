import * as i18n from "./i18n";
import * as popup from "./popup";
import * as PFR from "./PFR";
import { events } from "./events";
import * as net from "./net";
import { regulatoryRequirements } from "./rr";
import { Currencies, LocaleTypes, urlDecoder } from "./urlDecoder";
import * as fmt from "./fmt";
import { LIB_VERSION } from "./version";
import { check_free_spins_with_integrator_bet } from "./PFR";

console.info(`Ejaw Client Library Loaded. Version: ${LIB_VERSION}`);

export const enum Games {
    test = "test",
}

interface Config {
    lang: string;
    locale: LocaleTypes;
    currency: Currencies;
}

const config: Config = {
    lang: "EN",
    locale: LocaleTypes.default,
    currency: Currencies.default,
};

const urlD = new urlDecoder();

/** Ejaw Client Library */
export const ECL = {
    /** Localisation (internationalization) manager */
    i18n,
    /** Popup manager */
    popup,
    /** Promotional Free Rounds manager */
    PFR,
    /** Networking manager */
    net,
    /** Events manager */
    events,
    /** Session config */
    config,
    /** URL decoder */
    urlD,
    /** Values formatter */
    fmt,
    /** Regulatory requirements */
    rr: new regulatoryRequirements(urlD.getJurisdiction()),
    /** Game name - must set during init */
    game: "test",
    /** backend address */
    API_ADDRESS: "",
    /** Init library */
    async init(game: string, API_ADDRESS: string, legacyPFR = false) {
        this.game = game;
        this.API_ADDRESS = API_ADDRESS;

        this.config = {
            lang: ECL.urlD.getLang(),
            locale: ECL.urlD.getLocale(),
            currency: ECL.urlD.getCurrencyKey(),
        };

        i18n.init_dictionary(this.config.lang);

        urlD.init(game);

        const state = await net.custom_fetch({
            method: "POST",
            uri: `${API_ADDRESS}core/state`,
            body: JSON.stringify({
                session_id: urlD.getSessionID(),
                integrator: urlD.getOperator(),
                game: urlD.getGameId(),
                params: urlD.getOperatorParams(),
            }),
            timeout: 30000,
        });

        if (state.data.currency) this.config.currency = state.data.currency;

        if (legacyPFR) {
            PFR.check_free_spins(this.config.locale, this.config.currency, API_ADDRESS, state.data.session_token, urlD.getOperator());
        } else {
            PFR.check_free_spins_with_integrator_bet(
                this.config.locale,
                this.config.currency,
                API_ADDRESS,
                state.data.session_token,
                urlD.getOperator(),
            );
        }

        state.data["params"] = urlD.getOperatorParams();

        return state.data;
    },
};
