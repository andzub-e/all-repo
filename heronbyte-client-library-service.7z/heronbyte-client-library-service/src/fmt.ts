import { ECL } from "./index";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let formatter: any = undefined;

/**
 * Formats money using currency and locale
 * @param amount money amount in cents
 * @returns formatted amount with currency symbol
 */
export function money(amount: number) {
    const noFormat = ["usdt"]; // валюты которых нет в Intl.NumberFormat`е, выдаст ошибку если отправить

    if (!formatter) {
        const locale = ECL.config.locale.replace("_", "-");

        if (noFormat.includes(ECL.config.currency.toLowerCase())) {
            const mainFMT = new Intl.NumberFormat(locale, {
                minimumFractionDigits: 2, // минимум 2 символа после запятой
                maximumFractionDigits: 2, // максимум символа после запятой
            });

            formatter = {
                main: mainFMT, // замыкаем форматер в ключе объекта чтоб не создавать новый каждый раз
                format: function (amount: number) {
                    return formatter.main.format(amount) + " " + ECL.config.currency.toUpperCase(); // добавляем валюту в конец цифры
                },
            };
        } else {
            formatter = new Intl.NumberFormat(locale, {
                style: "currency",
                currency: ECL.config.currency,
                minimumFractionDigits: 2, // минимум 2 символа после запятой
                maximumFractionDigits: 2, // максимум символа после запятой
            });
        }
    }

    return formatter.format(amount / 1000);
}

/**
 * Formats money using locale
 * @param amount money amount in cents
 * @returns formatted amount without currency symbol
 */
export function coins(amount: number) {
    return (amount / 1000).toLocaleString(ECL.config.locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/**
 * Formats date using locale
 * @param date default date format
 * @returns formatted date
 */
export function date(date: Date) {
    return date.toLocaleDateString(ECL.config.locale);
}

/**
 * Formats time using locale
 * @param date default date format
 * @returns formatted time
 */
export function time(date: Date) {
    return date.toLocaleTimeString(ECL.config.locale);
}

/**
 * Formats date and time using locale
 * @param date default date format
 * @returns formatted date and time
 */
export function datetime(date: Date) {
    return date.toLocaleString(ECL.config.locale);
}
