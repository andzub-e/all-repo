import { get_query_param } from "./util";

const QUERY_PARAM_NAMES = {
    sessionid: "ticket",
    userlocale: "userlocale",
    user_locale: "user_locale",
    lang: "lang",
    jurisdiction: "jurisdiction",
    currency: "currency",
    lobbyurl: "lobbyurl",
    integrator: "integrator",
    params: "params",
    showcheats: "showcheats",
    low_balance: "low_balance",
};

const CURRENCY_SYMBOLS = {
    EUR: "€",
    USD: "$",
    GBP: "£",
    UAH: "₴",
    RUB: "₽",
    XTS: "XTS",
};

export const enum Currencies {
    "default" = "XTS",
    "EUR" = "EUR",
    "USD" = "USD",
    "GBP" = "GBP",
    "UAH" = "UAH",
    "RUB" = "RUB",
    "XTS" = "XTS",
}

export const enum JurisdictionTypes {
    "default" = "US",
    "US" = "US",
}

export const enum LocaleTypes {
    "default" = "en-US",
    "da-DK" = "da-DK",
    "de-AT" = "de-AT",
    "de-CH" = "de-CH",
    "de-DE" = "de-DE",
    "el-GR" = "el-GR",
    "en-CA" = "en-CA",
    "en-GB" = "en-GB",
    "en-IE" = "en-IE",
    "en-US" = "en-US",
    "es-ES" = "es-ES",
    "fi-FI" = "fi-FI",
    "fr-BE" = "fr-BE",
    "fr-CA" = "fr-CA",
    "fr-CH" = "fr-CH",
    "fr-FR" = "fr-FR",
    "it-CH" = "it-CH",
    "it-IT" = "it-IT",
    "ja-JP" = "ja-JP",
    "ko-KR" = "ko-KR",
    "nl-BE" = "nl-BE",
    "nl-NL" = "nl-NL",
    "no-NO" = "no-NO",
    "pt-PT" = "pt-PT",
    "sv-SE" = "sv-SE",
    "tr-TR" = "tr-TR",
    "zh-TW" = "zh-TW",
}

const LocaleToLocaleType = {
    default: "en-US",
    da: "da-DK",
    de: "de-DE",
    el: "el-GR",
    en: "en-US",
    es: "es-ES",
    fi: "fi-FI",
    fr: "fr-FR",
    it: "it-IT",
    ja: "ja-JP",
    ko: "ko-KR",
    nl: "nl-NL",
    no: "no-NO",
    pt: "pt-PT",
    sv: "sv-SE",
    tr: "tr-TR",
    zh: "zh-TW",
};

const enum Integrators {
    default = "mock",
    mock = "mock",
    pokerdom = "pokerdom",
    infin = "infingame",
}

interface IntegratorParams {
    currency: Currencies;
    integrator: Integrators;
    game: string;
    low_balance?: true;
    lobbyurl?: string;
    [key: string]: string | true | undefined;
}

const sessionidNames = {
    default: "ticket",
    mock: "ticket",
    pokerdom: "token",
    infingame: "ticket",
};

export class urlDecoder {
    sessionID: string;
    userlocale: LocaleTypes;
    //@TODO add enum of langs
    lang: string;
    jurisdiction: JurisdictionTypes;
    currencyKey: Currencies;
    //@TODO add enum of currency symbols
    currencySymbol: string | null;
    lobbyurl: string | null;
    integrator: Integrators;
    showCheats: boolean;
    integratorParams?: IntegratorParams;
    game?: string;
    low_balance: boolean;

    constructor() {
        this.integrator = this.decodeOperator();
        this.sessionID = this.decodeSessionID();
        this.userlocale = this.decodeLocale();
        this.lang = this.decodeLang();
        this.jurisdiction = this.decodeJurisdiction();
        this.currencyKey = this.decodeCurrencyKey();
        this.currencySymbol = this.setCurrencySymbol();
        this.lobbyurl = this.decodeLobbyUrl();
        this.showCheats = this.decodeShowCheats();
        this.low_balance = this.decode_low_balance();
    }

    init(game: string) {
        this.game = game;
        this.integratorParams = this.decodeOperatorParams(game);
    }

    decodeOperator() {
        const url = new URL(window.location.href);
        const gameName = url.searchParams.get("gameName");
        if (gameName) return Integrators.infin;

        return (get_query_param(QUERY_PARAM_NAMES.integrator) as Integrators) || Integrators.default;
    }

    decodeSessionID() {
        return get_query_param(sessionidNames[this.integrator]) || (get_query_param(sessionidNames.default) as string);
    }

    decodeLocale() {
        const locale =
            (get_query_param(QUERY_PARAM_NAMES.userlocale) as LocaleTypes) ||
            (get_query_param(QUERY_PARAM_NAMES.user_locale) as LocaleTypes) ||
            (get_query_param(QUERY_PARAM_NAMES.lang) as LocaleTypes) ||
            LocaleTypes.default;

        const buff = locale.split("-");
        if (buff.length === 1) {
            return (LocaleToLocaleType[buff[0] as keyof typeof LocaleToLocaleType] as LocaleTypes) || locale;
        } else {
            return locale;
        }
    }

    decodeLang() {
        return this.userlocale;
    }

    decodeJurisdiction() {
        return (get_query_param(QUERY_PARAM_NAMES.jurisdiction) as JurisdictionTypes) || JurisdictionTypes.default;
    }

    decodeCurrencyKey(): Currencies {
        return (get_query_param(QUERY_PARAM_NAMES.currency) as Currencies) || Currencies.default;
    }

    /** deprecated */
    setCurrencySymbol() {
        if (CURRENCY_SYMBOLS.hasOwnProperty(this.currencyKey)) {
            return CURRENCY_SYMBOLS[this.currencyKey];
        }

        return null;
    }

    getCurrencySymbol() {
        if (CURRENCY_SYMBOLS.hasOwnProperty(this.currencyKey)) {
            return CURRENCY_SYMBOLS[this.currencyKey];
        }

        return null;
    }

    decodeLobbyUrl() {
        return get_query_param(QUERY_PARAM_NAMES.lobbyurl) || null;
    }

    decodeShowCheats() {
        if (get_query_param(QUERY_PARAM_NAMES.showcheats)) {
            return true;
        } else {
            return false;
        }
    }

    decode_low_balance() {
        if (get_query_param(QUERY_PARAM_NAMES.low_balance) === "TRUE") {
            return true;
        } else {
            return false;
        }
    }

    formatParams(key: string, value: string) {
        let newKey = key;
        let newValue = value;

        switch (key) {
            case "user":
                newKey = "user_id";
                break;
            case "game":
                newKey = "game_id";
                break;
            case "gameName":
                newKey = "game_id";
                break;
            case "return_url":
                newKey = "lobbyurl";
                break;
            case "exit_url":
                newKey = "lobbyurl";
                break;
            case "lang":
                newKey = "userlocale";
                newValue = LocaleToLocaleType[value as keyof typeof LocaleToLocaleType] || `${value}-${value.toUpperCase()}`;
                break;
            default:
                break;
        }

        return { newKey, newValue };
    }

    decodeOperatorParams(game: string) {
        const params: IntegratorParams = {
            currency: Currencies.default,
            integrator: Integrators.default,
            game: game,
        };

        const url = new URL(window.location.href);

        console.log(url);
        const searchParams = new URLSearchParams(url.searchParams.toString());

        const formatParams = this.formatParams;

        console.groupCollapsed("Search params");
        searchParams.forEach(function (value, key) {
            const { newKey, newValue } = formatParams(key, value);
            params[newKey] = newValue;

            if (key === "game") params["operatorGameKey"] = value;
            if (key === "gameName") params["integrator"] = Integrators.infin;

            console.log(key, "-->", newKey + ",", value, "-->", newValue);
        });
        console.groupEnd();

        if (this.low_balance) {
            params.low_balance = true;
        }

        if (!this.lobbyurl && params.lobbyurl) {
            this.lobbyurl = params.lobbyurl;
        }

        return params;
    }

    // getters
    getSessionID() {
        return this.sessionID;
    }

    getLocale() {
        return this.userlocale;
    }

    getLang(full = false) {
        return full ? this.lang : this.lang.split("-")[0];
    }

    getJurisdiction() {
        return this.jurisdiction;
    }

    getCurrency() {
        return this.currencySymbol || this.currencyKey;
    }

    getCurrencyKey() {
        return this.currencyKey;
    }

    getOperator() {
        return this.integrator;
    }

    getOperatorParams() {
        return this.integratorParams;
    }

    getShowCheats() {
        return this.showCheats;
    }

    enableAutoSpin() {
        return true;
    }

    enableTurboSpin() {
        return true;
    }

    enableSlamStop() {
        return true;
    }

    // minimumTimeBetweenWagers() {

    // }

    getLobbyURL() {
        return this.lobbyurl ? decodeURIComponent(this.lobbyurl) : this.lobbyurl;
    }

    getGameId() {
        return this.game;
    }

    showClose() {
        if (this.lobbyurl) {
            return true;
        }

        return false;
    }
}
