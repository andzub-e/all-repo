declare module "*.txt" {
    const content: string;
    export = content;
}

declare module "*.css" {
    const content: string;
    export = content;
}

declare module "*.png" {
    const content: string;
    export = content;
}

declare module "*.ttf" {
    const content: string;
    export = content;
}

declare module "*.html" {
    const value: string;
    export default value;
}
