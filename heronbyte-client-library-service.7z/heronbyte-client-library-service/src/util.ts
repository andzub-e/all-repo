export function get_query_param(item: string) {
    const svalue = window.location.search.match(new RegExp("[?&]" + item + "=([^&]*)(&?)", "i"));
    return svalue ? svalue[1] : svalue;
}
