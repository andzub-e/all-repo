export class regulatoryRequirements {
    jurisdiction: string;

    constructor(jurisdiction: string) {
        this.jurisdiction = jurisdiction;
    }

    /**
     * returns the minimum time (in ms) between wagers required by the current jurisdiction (0 === no delay required)
     */
    getMinimumTimeBetweenWagers() {
        // DE=Germany
        // DK=Denmark
        // ES=Spain
        // GB=United Kingdom
        // SE=Sweden
        // CO=Columbia
        // GR=Greece
        const mtbw = {
            DE: 5000,
            DK: 3000,
            ES: 3000,
            GB: 3000,
            SE: 3000,
            CO: 3000,
            GR: 3000,
        };
        //@ts-ignore
        return mtbw[this.jurisdiction] || 0;
    }
    /**
     * returns true if you're allowed to enable this feature on the current jurisdiction
     */
    enableTurboSpin() {
        return this.getMinimumTimeBetweenWagers() === 0;
    }

    /**
     * returns true if you're allowed to enable this feature on the current jurisdiction
     */
    enableSlamStop() {
        return this.getMinimumTimeBetweenWagers() === 0;
    }
    /**
     * returns true if you're allowed to enable this feature on the current jurisdiction
     */
    enableAutoSpin() {
        // Germany and Netherlands requires the auto spin to be disabled
        // note: GB allows it, but has special requirements for it
        const restricted = ["DE", "NL"];
        return !restricted.includes(this.jurisdiction);
    }
}
