import Inter_Medium from "./assets/Inter-Medium.ttf";
import Inter_Black from "./assets/Inter-Black.ttf";
import { Localize } from "./i18n";

const style_elem = document.createElement("style");

const template = `
<div class="wrapper">
    <div class="wrapper_popup">
        <div class="popup">
            <div class="popup_title">
                <h1 class="title" id="title"></h1>
            </div>
            <div class="popup_content">
                <div class ="content" id="content"></div>
            </div>
            <div class="popup_btn" id="btns">
                <div class="btn_1-conteiner">
                    <button class="btn" id="btn-1"></button>
                </div>
                <div class="btn_3-conteiner" >
                    <button class="btn" id="btn-3"></button>
                </div>
                <div class="btn_2-conteiner">
                    <button class="btn" id="btn-2"></button>
                </div>
            </div>
        </div>
    </div>
</div>
`;

style_elem.innerHTML = `
@font-face {
    font-family: 'Inter Black';
    src: url('./Inter-Black.ttf') format('truetype');
}

@font-face {
    font-family: 'Inter Medium';
    src: url('./Inter-Medium.ttf') format('truetype');
}

.wrapper {
    position: absolute;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    font-family: "Inter Medium";
    background-color: rgba(0, 0, 0, 0.4);
    backdrop-filter: blur(4px);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    user-select: none;
}

.wrapper_popup{
    display: block;
    padding: 10px 10px 10px 10px;
    min-width: 340px;
}

.popup {
    max-width: 589px;
    min-width: 346px;
    padding: 30px 10px 30px 10px;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    text-align: center;
    align-items: center;
    border-radius: 30px;
    backdrop-filter: blur(5px);
    background-color: rgba(0,125,183,0.6);
}

.popup_title {
    line-height: 2rem;
    display: flex;
    justify-content: center;
    max-width: 80%;
}

.title {
    font-size: 30px;
    color: #ffffff;
    text-align: center;
    box-sizing: border-box;
    font-family: Inter Black;
}

.popup_content  {
    line-height: 18px;
    display: flex;
    justify-content: center;
    max-width: 80%;
    box-sizing: border-box;
}

.content{
    margin-bottom: 2rem;
    line-height: 18px;
    width: 100%;
    box-sizing: border-box;
    font-family: Inter Medium;
    font-size: 20px;
    color: #ffffff;
    font-weight: 500;
}

.popup_btn{
    display: flex;
    width: 80%;
    justify-content: space-around;
    align-items: center;

}

#btn-3{
    width: 110px;
    height: 110px;
    border-style: solid;
    border-width: 6px;
    border-color: rgb(0, 0, 0, 0.35);
    border-radius: 50%;
    background-color: #ffffff;
    color: #002846;
    font-family: Inter Black;
}

.btn {
    cursor: pointer;
    min-height: 57px;
    height: 100%;
    width: 155px;
    border-style: solid;
    border-width: 4px;
    border-color: rgb(0, 0, 0, 0.35);
    border-radius: 15px;
    padding: 0;
    background-color: #ffffff;
    font-size: medium;
    word-break: break-word;
    color: #002846;
    font-family: Inter Black;
    display: flex;
    justify-content: center;
    align-items: center;
}

.btn:hover  {
    border-color: rgb(255, 255, 255);
    background-color: rgb(0, 145, 255);
    color: #ffffff;
}

#btn-3:hover{
    border-color: rgb(255, 255, 255);
    background-color: rgb(0, 145, 255);
    color: #ffffff;
}

@media screen and (max-width: 756px) {
    .popup_btn{
        flex-wrap: wrap;
        width: 92%;
    }

    .btn_1-conteiner{
      order: 1;
    }

    .btn_2-conteiner{
        order: 2;
    }

    .btn_3-conteiner{
        width: 100%;
        display: flex;
        justify-content: center;
        margin: 0 auto;
        order: 3;
    }
}
`;

style_elem.appendChild(
    document.createTextNode(
        `@font-face {
            font-family: "Inter Medium";
            src: url("${Inter_Medium}") format("truetype");
        }`,
    ),
);

style_elem.appendChild(
    document.createTextNode(
        `@font-face {
            font-family: "Inter Black";
            src: url("${Inter_Black}") format("truetype");
        }`,
    ),
);

const main = document.createElement("div");
main.innerHTML = template;
document.body.appendChild(main);

const div = document.createElement("div");
div.innerHTML = ".";
div.style.fontFamily = "Inter Medium";
div.style.position = "absolute";
div.style.opacity = "0";
div.style.margin = "0";
div.style.padding = "0";
document.body.appendChild(div);

const div2 = document.createElement("div");
div2.innerHTML = ".";
div2.style.fontFamily = "Inter Black";
div2.style.position = "absolute";
div2.style.opacity = "0";
div2.style.margin = "0";
div2.style.padding = "0";
document.body.appendChild(div2);

document.head.appendChild(style_elem);

const left = document.getElementById("btn-1")!;
const right = document.getElementById("btn-2")!;
const middle = document.getElementById("btn-3")!;
const title = document.getElementById("title")!;
const content = document.getElementById("content")!;
const popup = document.getElementsByClassName("wrapper")[0]! as any;

export interface Content {
    title: string;
    message: string;
}

export interface Button {
    label: string;
    callback: () => void;
}
export interface Buttons {
    middle?: Button;
    left?: Button;
    right?: Button;
}
/**
 * Shows the popup
 * @param info title and message of popup @see Content
 * @param buttons buttons of popup with label and callback @see Buttons
 */
export function show(info: Content, buttons: Buttons) {
    popup.style.display = "flex";
    title.innerHTML = info.title || "";
    content.innerHTML = info.message || "";

    if (buttons.middle) {
        if (buttons.left && buttons.right) {
            right.style.display = "flex";
            left.style.display = "flex";
            middle.style.display = "flex";

            right.innerHTML = buttons.left.label;
            right.onpointerdown = buttons.left.callback;
            left.innerHTML = buttons.right.label;
            left.onpointerdown = buttons.right.callback;
            middle.innerHTML = buttons.middle.label;
            middle.onpointerdown = buttons.middle.callback;
        } else {
            right.style.display = "none";
            left.style.display = "none";
            middle.style.display = "flex";

            middle.innerHTML = buttons.middle.label;
            middle.onpointerdown = buttons.middle.callback;
        }
    } else {
        middle.style.display = "none";

        if (buttons.left) {
            left.style.display = "flex";
            left.innerHTML = buttons.left.label;
            left.onpointerdown = buttons.left.callback;
        }

        if (buttons.right) {
            right.style.display = "flex";
            right.innerHTML = buttons.right.label;
            right.onpointerdown = buttons.right.callback;
        }
    }
}

/** Hide the popup */
export function hide() {
    popup.style.display = "none";
}

export function autoplay_msg(type: "INCREASE" | "DECREASE" | "ANY_WIN" | "SINGLE_WIN" | "BONUS", callback?: () => void) {
    let body = `${Localize("autoplay_stop")} `;

    switch (type) {
        case "INCREASE": {
            body += Localize("max_cash_increase");
            break;
        }
        case "DECREASE": {
            body += Localize("max_cash_decrease");
            break;
        }
        case "SINGLE_WIN": {
            body += Localize("single_win");
            break;
        }
        case "ANY_WIN": {
            body += Localize("any_win");
            break;
        }
        case "BONUS": {
            body += Localize("bonus_reached");
            break;
        }
        default: {
            throw "Shouldn't be here!";
        }
    }

    show(
        { title: Localize("autoplay"), message: body },
        {
            middle: {
                label: Localize("ok"),
                callback: () => {
                    hide();

                    if (callback) {
                        callback();
                    }
                },
            },
        },
    );
}

hide();
