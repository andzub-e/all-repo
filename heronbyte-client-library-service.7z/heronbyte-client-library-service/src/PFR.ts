import { events } from "./events";
import { money } from "./fmt";
import { custom_fetch } from "./net";
import { Currencies } from "./urlDecoder";
import { hide, show } from "./popup";
import { Localize } from "./i18n";

export interface FreeSpin {
    currency: Currencies;
    expire_date: string;
    game: string;
    id: string;
    value: number;
}

interface FreeSpinRes {
    data: {
        freespins: FreeSpin[];
    };
    meta: any;
    status: number;
    success: boolean;
}
interface FreeSpinWithIntegratorBetRes {
    data: {
        freespins: { [key: string]: FreeSpin[] };
    };
    meta: any;
    status: number;
    success: boolean;
}

export let is_free_spinning = false;
let free_spins: FreeSpin[] = [];
let last_free_spin_bet = 1000;
let winnings = 0;
let API_ADDRESS = "";
// let USER_LOCALE = "en-US";
// let CURRENCY = "USD";
let SESSION_TOKEN = "";
let _FREE_BET_INTEGRATOR = "";

const style = document.createElement("style");
style.innerHTML = `
.pfr_counter span {
    font-family: Inter Medium;
    color: white;
    margin: 10px;
}

.pfr_counter {
    position: absolute;
    top: 20px;
    right: 20px;
    width: 100px;
    height: 100px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border-radius: 15px;
    backdrop-filter: blur(5px);
    background-color: rgba(0,125,183,0.6);
}`;
document.head.appendChild(style);

const pfr_counter_div = document.createElement("div");
pfr_counter_div.className = "pfr_counter";

const fs_left_amount = document.createElement("span");
pfr_counter_div.appendChild(fs_left_amount);

const fs_left_label = document.createElement("span");
pfr_counter_div.appendChild(fs_left_label);
fs_left_label.className = "align_center";

function init_PFR() {
    show(
        { title: `${Localize("congratulations")}!`, message: `${Localize("you_have")}\n${free_spins.length} ${Localize("free_spins")}!` },
        {
            left: {
                label: Localize("later"),
                callback: hide,
            },
            middle: {
                label: Localize("play_now"),
                callback: onPlayNow,
            },
            right: {
                label: Localize("decline"),
                callback: onDecline,
            },
        },
    );
}

function onPlayNow() {
    is_free_spinning = true;
    hide();
    document.body.appendChild(pfr_counter_div);
    fs_left_label.innerHTML = Localize("free_games").toString();
    fs_left_amount.innerHTML = free_spins.length.toString();
    last_free_spin_bet = free_spins[0]?.value || last_free_spin_bet;
    document.dispatchEvent(new Event(events.FREESPINS_ACCEPTED_EVENT));
}

function onDecline() {
    show(
        { title: Localize("decline_offer"), message: Localize("are_you_sure") },
        {
            left: {
                label: Localize("yes"),
                callback: () => {
                    hide();
                    if (_FREE_BET_INTEGRATOR && _FREE_BET_INTEGRATOR.length > 0) {
                        fetch(
                            `${API_ADDRESS}core/free_spins/cancel_with_integrator_bet?session_token=${SESSION_TOKEN}&integrator_bet_id=${_FREE_BET_INTEGRATOR}`,
                        );
                    } else {
                    fetch(`${API_ADDRESS}core/free_spins/cancel?session_token=${SESSION_TOKEN}`);
                    }
                },
            },
            right: {
                label: Localize("no"),
                callback: init_PFR,
            },
        },
    );
}

export async function check_free_spins(
    _USER_LOCALE: string,
    _CURRENCY: string,
    _API_ADDRESS: string,
    _SESSION_TOKEN: string,
    INTEGRATOR?: string,
    NOT_SHOW_MODAL?: boolean,
) {
    API_ADDRESS = _API_ADDRESS;
    // USER_LOCALE = _USER_LOCALE;
    // CURRENCY = _CURRENCY;
    SESSION_TOKEN = _SESSION_TOKEN;

    const res: FreeSpinRes = await custom_fetch({
        method: "GET",
        uri: `${API_ADDRESS}core/free_spins/get?session_token=${SESSION_TOKEN}${INTEGRATOR ? `&integrator=${INTEGRATOR}` : ""}`,
        timeout: 30000,
    });

    const free_spins_temp = res.data.freespins;

    if (free_spins_temp.length > 0) {
        free_spins = free_spins_temp;
        if (!NOT_SHOW_MODAL) {
            init_PFR();
        } else {
            update_free_spins();
        }
    }
}


export async function check_free_spins_with_integrator_bet(
    _USER_LOCALE: string,
    _CURRENCY: string,
    _API_ADDRESS: string,
    _SESSION_TOKEN: string,
    INTEGRATOR?: string,
    NOT_SHOW_MODAL?: boolean,
) {
    API_ADDRESS = _API_ADDRESS;
    // USER_LOCALE = _USER_LOCALE;
    // CURRENCY = _CURRENCY;
    SESSION_TOKEN = _SESSION_TOKEN;

    const res: FreeSpinWithIntegratorBetRes = await custom_fetch({
        method: "GET",
        uri: `${API_ADDRESS}core/free_spins/get_with_integrator_bet?session_token=${SESSION_TOKEN}${
            INTEGRATOR ? `&integrator=${INTEGRATOR}` : ""
        }`,
        timeout: 30000,
    });

    const firstKey = Object.keys(res.data.freespins)[0];
    let free_spins_temp: FreeSpin[] = res.data.freespins[firstKey] || [];

    if (Object.keys(res.data.freespins).length > 1) {
        const entries = Array.from(Object.entries(res.data.freespins));

        let nearestKey: string | null = null;
        let nearestDateDifference: number = Number.MAX_VALUE;

        entries.forEach(([key, objects]) => {
            objects.forEach(obj => {
                const today = new Date();
                const expireDate = new Date(obj.expire_date);
                const difference = Math.abs(expireDate.getTime() - today.getTime());

                if (difference < nearestDateDifference) {
                    nearestDateDifference = difference;
                    nearestKey = key;
                }
            });
        });
        if (nearestKey !== null) {
            _FREE_BET_INTEGRATOR = nearestKey;
            free_spins_temp = res.data.freespins[nearestKey] || free_spins_temp;
        }
    }

    if (free_spins_temp != null && free_spins_temp.length > 0) {
        free_spins = free_spins_temp;
        if (!NOT_SHOW_MODAL) {
            init_PFR();
        } else {
            update_free_spins();
        }
    }
}


function update_free_spins() {
    fs_left_amount.innerHTML = free_spins.length.toString();
    last_free_spin_bet = free_spins[0]?.value || last_free_spin_bet;
}


export function pop_free_spin() {
    const free_spin = free_spins.pop();
    fs_left_amount.innerHTML = free_spins.length.toString();

    return free_spin;
}

export function free_spins_left() {
    return free_spins.length;
}

export function update_winnings(win_amount: number) {
    winnings += win_amount;
}

export function check_free_spins_ended() {
    if (free_spins.length === 0) {
        is_free_spinning = false;
        document.body.removeChild(pfr_counter_div);

        show(
            { title: Localize("free_game_complete"), message: `${Localize("you_win")}\n${money(winnings)}` },
            {
                middle: {
                    label: Localize("back_to_game"),
                    callback: () => {
                        hide();
                        document.dispatchEvent(new Event(events.FREESPINS_COMPLETED_EVENT));
                    },
                },
            },
        );
    }
}

export function free_spins_bet() {
    last_free_spin_bet = free_spins[0]?.value || last_free_spin_bet;

    return last_free_spin_bet;
}
