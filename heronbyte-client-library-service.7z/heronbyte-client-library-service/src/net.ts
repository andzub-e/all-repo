/* eslint-disable linebreak-style */
import { events } from "./events";
import { Localize } from "./i18n";
import { hide, show } from "./popup";

type ErrorTypes =
    //no money
    | "INSUFFICIENT_FUNDS"
    //response took too long
    | "NETWORK_ERROR"
    //server returned error
    | "UNKNOWN_ERROR"
    //internet connection restored
    | "ONLINE"
    //session_id (session_token) not found
    | "UNAUTHORIZED"
    //wrong free spin id
    | "CONFLICT"
    //validation error
    | "UNPROCESSABLE"
    //server returned error
    | "MULTIPLE_WINDOW"
    // blocked user
    | "USER_BLOCKED"
    // integrator is dead
    | "INTEGRATOR_IS_DEAD";

interface FetchParams {
    uri: string;
    method: "GET" | "POST";
    body?: string;
    timeout?: number;
    onError?: (error: ErrorTypes) => void;
}

export let online = true;

export async function custom_fetch(params: FetchParams) {
    const req = fetch(params.uri, {
        method: params.method,
        mode: "cors",
        cache: "no-store",
        credentials: "omit",
        headers: params.body
            ? {
                  "Content-Type": "application/json",
              }
            : undefined,
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: params.body,
    });

    const error = (type: ErrorTypes) => {
        document.dispatchEvent(new Event(events.STOP_AUTOSPINS));



        (params.onError || show_error)(type);
    };

    if (params.timeout !== undefined) {
        const timer = setTimeout(() => {
            error("NETWORK_ERROR");
        }, params.timeout);

        req.then(() => {
            clearTimeout(timer);
        });
    }

    try {
        const res = await req;

        if (res.status == 401) {
            error("UNAUTHORIZED");
            res.text().then(text => console.error("raw server data:", text));
            return res;
        }

        if (res.status == 402) {
            error("INSUFFICIENT_FUNDS");
            res.text().then(text => console.error("raw server data:", text));
            return res;
        }

        if (res.status == 403) {
            error("USER_BLOCKED");
            res.text().then(text => console.error("raw server data:", text));
            return res;
        }

        if (res.status == 409) {
            error("CONFLICT");
            res.text().then(text => console.error("raw server data:", text));
            return res;
        }

        if (res.status == 419) {
            error("MULTIPLE_WINDOW");
            res.text().then(text => console.error("raw server data:", text));
            return res;
        }

        if (res.status == 422) {
            error("UNPROCESSABLE");
            res.text().then(text => console.error("raw server data:", text));
            return res;
        }

        if (res.status == 503) {
            error("INTEGRATOR_IS_DEAD");
            res.text().then(text => console.error("raw server data:", text));
            return res;
        }

        if (res.status >= 400) {
            error("UNKNOWN_ERROR");
            res.text().then(text => console.error("raw server data:", text));
            return res;
        }

        try {
            const body = await res.json();

            if (body.error) {
                error(body.error);
            }

            return body;
        } catch (err) {
            // probably body is missing, maybe it's intended...
            console.warn(err);
            return res;
        }
    } catch (err) {
        if (window.navigator.onLine == true) {
            error("UNKNOWN_ERROR");
        } else {
            error("NETWORK_ERROR");
        }
        console.error(err);
        return req;
    }
}

export function show_error(error: ErrorTypes) {
    let header = "";
    let content = "";
    let is_fatal = false;

    switch (error) {
        case "NETWORK_ERROR": {
            header = Localize("error_network");
            content = Localize("lost_internet");
            is_fatal = true;
            break;
        }
        case "ONLINE": {
            header = Localize("connection_restored");
            content = Localize("connection_restored_message");
            break;
        }
        case "UNAUTHORIZED": {
            header = Localize("unauthorized");
            content = Localize("session_not_found");
            is_fatal = true;
            break;
        }
        case "CONFLICT": {
            header = Localize("error");
            content = Localize("conflict");
            is_fatal = true;
            break;
        }
        case "UNPROCESSABLE": {
            header = Localize("unprocessable");
            content = Localize("error_validation");
            is_fatal = true;
            break;
        }
        case "INSUFFICIENT_FUNDS": {
            header = Localize("error_if");
            content = Localize("no_money");
            break;
        }
        case "USER_BLOCKED": {
            header = Localize("error_unknown");
            content = Localize("smth_wrong");
            break;
        }
        case "INTEGRATOR_IS_DEAD": {
            header = Localize("error_unknown");
            content = Localize("smth_wrong");
            break;
        }
        case "MULTIPLE_WINDOW": {
            header = Localize("error");
            content = Localize("multi_open");
            is_fatal = true;
            break;
        }
        default: {
            header = Localize("error_unknown");
            content = Localize("smth_wrong");
            is_fatal = true;
        }
    }

    show(
        { title: header, message: content },
        {
            middle: {
                label: Localize("ok"),
                callback: is_fatal
                    ? () => {
                          window.location.reload();
                      }
                    : hide,
            },
        },
    );
}

window.onoffline = () => {
    online = false;
    show_error("NETWORK_ERROR");
};

window.ononline = () => {
    if (!online) {
        online = true;
        show_error("ONLINE");
    }
};
