package engine

import (
	"encoding/json"
	"fmt"
	"sort"

	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/constants"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"github.com/samber/lo"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
)

func GameBoot(ctn di.Container, config *engine.Config) *engine.Bootstrap {
	rand := ctn.Get(constants.RNGName).(rng.Client)
	factory := NewSpinFactory(rand)

	if config.RTP == rtp94 || config.RTP == rtp96 {
		rtp = config.RTP
	} else {
		panic(fmt.Sprintf("can't specify RTP: %v", config.RTP))
	}

	if config.BuildVersion == pl5 || config.BuildVersion == pl20 || config.BuildVersion == pl40 {
		pl = config.BuildVersion
	} else {
		panic(fmt.Sprintf("can't specify build version: %v", config.BuildVersion))
	}

	highRTPReelRate = HighRTPReelRates[pl][rtp]

	//if pl == pl5 {
	//	payLines = payLines5
	//	multipliers = multipliers5
	//	reelsHighRTP = reelsHighRTP5
	//	reelsLowRTP = reelsLowRTP5
	//	currentWindowHeight = windowHeight3
	//}
	//if pl == pl20 {
	//	payLines = payLines20
	//	multipliers = multipliers20
	//	reelsHighRTP = reelsHighRTP20
	//	reelsLowRTP = reelsLowRTP20
	//	currentWindowHeight = windowHeight3
	//}

	if pl == pl40 {
		payLines = payLines40
		multipliers = multipliers40
		reelsHighRTP = reelsHighRTP40
		reelsLowRTP = reelsLowRTP40
		currentWindowHeight = windowHeight4
	}

	zap.S().Infof("rtp: %v, pl: %v", rtp, pl)

	boot := &engine.Bootstrap{
		SpinFactory: factory,

		HTTPTransport:      true,
		WebsocketTransport: true,

		GambleAnyWinFeature: true,
		FreeSpinsFeature:    true,

		GambleAnyWinMaxTimes: 4,
		GambleAnyWinMaxWager: 125 * 100 * 1000, // 12 500 $

		GameMaxWager: 40000,

		HistoryHandlingType: engine.SequentialRestoring,
	}

	if !config.TurnOnGambleIfAdmissible {
		boot.GambleAnyWinFeature = false
	}

	return boot
}

func NewSpinFactory(rand rng.Client) *SpinFactory {
	return &SpinFactory{rand: rand}
}

type SpinFactory struct {
	rand rng.Client
}

func (s *SpinFactory) Generate(ctx engine.Context, wager int64, parameters interface{}) (engine.Spin, engine.RestoringIndexes, error) {
	c := Cheats{}

	if ctx.Cheats != nil {
		if err := c.Eval(ctx.Cheats); err != nil {
			return nil, nil, err
		}
	}

	var reels [][]string
	var reelType int

	if c.ReelsType != nil && lo.Contains(availableReelTypes, *c.ReelsType) {
		reelType = *c.ReelsType
	} else {
		rnd, err := s.rand.RandFloat()
		if err != nil {
			return nil, nil, err
		}

		reelType = LowRTPReelCode
		if rnd < highRTPReelRate {
			reelType = HighRTPReelCode
		}
	}

	reels = *availableReels[reelType]

	stops, err := s.getStops(ctx, reels)
	if err != nil {
		return nil, nil, err
	}

	window, payLinesToShow, award, isExpendedWild := s.compute(stops, wager, reels)

	if payLinesToShow == nil {
		payLinesToShow = make([]PayLine, 0, 1)
	}

	return &Spin{
			WagerVal:       wager,
			Win:            award,
			Stops:          stops,
			Window:         window,
			PayLinesToShow: payLinesToShow,
			IsExpendedWild: isExpendedWild,
			ReelsType:      reelType},
		&RestoringIndexes{},
		nil
}

func (s *SpinFactory) GambleAnyWin(ctx engine.Context, parameters interface{}) (engine.Spin, error) {
	if ctx.LastSpin.BaseAward() == 0 {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin, ok := ctx.LastSpin.(*Spin)
	if !ok {
		return nil, errs.ErrBadDataGiven
	}

	typedSpin = typedSpin.deepCopy()

	payload, err := parseParams(parameters)

	if payload.Color != GambleRed && payload.Color != GambleBlue {
		return nil, errs.ErrBadDataGiven
	}

	if err != nil {
		return nil, err
	}

	res, err := s.rand.Rand(2)
	if err != nil {
		return nil, err
	}

	g := Gamble{ExpectColor: payload.Color, WagerVal: typedSpin.BaseAward()}

	c := Cheats{}
	if ctx.Cheats != nil {
		if err := c.Eval(ctx.Cheats); err != nil {
			return nil, err
		}
	}

	if c.GambleColor == GambleRed || c.GambleColor == GambleBlue {
		g.RealColor = c.GambleColor
	} else if res == 1 {
		g.RealColor = GambleRed
	} else {
		g.RealColor = GambleBlue
	}

	g.compute()

	typedSpin.Gambles = append(typedSpin.Gambles, g)

	return typedSpin, nil
}

func (s *SpinFactory) KeepGenerate(ctx engine.Context, parameters interface{}) (engine.Spin, bool, error) {
	return ctx.LastSpin, false, nil
}

func (s SpinFactory) UnmarshalJSONSpin(bytes []byte) (engine.Spin, error) {
	spin := Spin{}
	err := json.Unmarshal(bytes, &spin)

	return &spin, err
}

func (s SpinFactory) UnmarshalJSONRestoringIndexes(bytes []byte) (engine.RestoringIndexes, error) {
	restoringIndexes := RestoringIndexes{}
	err := json.Unmarshal(bytes, &restoringIndexes)

	return &restoringIndexes, err
}

func (s *SpinFactory) getStops(ctx engine.Context, reels [][]string) ([]int, error) {
	if ctx.Cheats != nil {
		c := Cheats{}
		if err := c.Eval(ctx.Cheats); err != nil {
			return nil, err
		}

		if len(c.Stops) != len(reels) {
			return nil, errs.ErrBadDataGiven
		}

		for i := range c.Stops {
			if c.Stops[i] > len(reels[i]) {
				return nil, errs.ErrBadDataGiven
			}
		}

		return c.Stops, nil
	}

	req := lo.Map(reels, func(item []string, index int) uint64 {
		return uint64(len(item))
	})

	res, err := s.rand.RandSlice(req)
	if err != nil {
		return nil, err
	}

	return lo.Map(res, func(item uint64, index int) int {
		return int(item)
	}), nil
}

func (s *SpinFactory) compute(stops []int, wager int64, reels [][]string) (window Window, payLinesToShow []PayLine, award int64, expendedWilds []int) {
	window.compute(stops, reels)

	award, payLinesToShow = s.computeBasicWindow(wager, window)

	scatterPayLine, ok := s.computeSpecialSym(wager, window, scatterSymbol)
	if ok {
		payLinesToShow = append(payLinesToShow, scatterPayLine)
		award += scatterPayLine.Award
	}

	potPayLine, ok := s.computeSpecialSym(wager, window, potSymbol)
	if ok {
		payLinesToShow = append(payLinesToShow, potPayLine)
		award += potPayLine.Award
	}

	for _, payLine := range payLinesToShow {
		if len(payLine.IsUsedExpandedWild) != 0 {
			expendedWilds = append(expendedWilds, payLine.IsUsedExpandedWild...)

			break
		}
	}

	expendedWilds = lo.Uniq(expendedWilds)
	sort.Ints(expendedWilds)

	return window, payLinesToShow, award, expendedWilds
}

func (s *SpinFactory) computeBasicWindow(wager int64, window Window) (award int64, payLinesToShow []PayLine) {
	reelsWithWild := s.computeWildReels(window)

	for payLineIndex, payLine := range payLines {
		symbol := ""
		usedExpandedWild := []int{}
		lineCounter := 0
		payLineIndexes := []int{}

		for reelIndex, payIndex := range payLine {
			if symbol == "" {
				if window.symbol(payIndex) == scatterSymbol || window.symbol(payIndex) == potSymbol {
					break
				}

				if reelsWithWild[reelIndex] {
					usedExpandedWild = append(usedExpandedWild, reelIndex)
				} else {
					symbol = window.symbol(payIndex)
				}

				payLineIndexes = append(payLineIndexes, payIndex)

				lineCounter++
			} else {
				if reelsWithWild[reelIndex] {
					usedExpandedWild = append(usedExpandedWild, reelIndex)
				}

				if symbol == window.symbol(payIndex) || reelsWithWild[reelIndex] {
					payLineIndexes = append(payLineIndexes, payIndex)

					lineCounter++
				} else {
					break
				}
			}
		}

		if addAward := awardBySymbolAndCount(symbol, lineCounter, wager); addAward > 0 {
			award += addAward

			usedExpandedWild = lo.Uniq(usedExpandedWild)
			sort.Ints(usedExpandedWild)

			payLinesToShow = append(payLinesToShow, PayLine{
				Indexes:            payLineIndexes,
				Award:              addAward,
				Symbol:             symbol,
				PayLineIndex:       payLineIndex,
				IsUsedExpandedWild: usedExpandedWild})
		}
	}

	return award, payLinesToShow
}

func (s *SpinFactory) computeWildReels(window Window) []bool {
	buf := make([]bool, len(window))

	for i := 0; i < len(window); i++ {
		reel := window[i]
		isWildReel := false

		for j := 0; j < len(reel); j++ {
			if reel[j] == windSymbol {
				isWildReel = true

				break
			}
		}

		buf[i] = isWildReel
	}

	return buf
}

func (s *SpinFactory) computeSpecialSym(wager int64, window Window, specialSymbol string) (PayLine, bool) {
	scatterIndexes := []int{}
	scatterCounter := 0

	for i, reel := range window {
		for j, symbol := range reel {
			if symbol == specialSymbol {
				scatterIndexes = append(scatterIndexes, j*windowWidth+i)
				scatterCounter++

				break
			}
		}
	}

	if award := awardBySymbolAndCount(specialSymbol, scatterCounter, wager); award > 0 {
		return PayLine{Indexes: scatterIndexes, Award: award, Symbol: specialSymbol, PayLineIndex: -1}, true
	}

	return PayLine{}, false
}
