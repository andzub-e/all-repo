package redis

import (
	"context"
	"github.com/go-redis/redis/v8"
)

func New(cfg *Config) (client *redis.Client, err error) {
	client = redis.NewClient(&redis.Options{
		Addr:     cfg.Host + ":" + cfg.Port,
		Password: cfg.Pass,
	})

	if _, err = client.Ping(context.Background()).Result(); err != nil {
		return nil, err
	}

	return client, nil
}
