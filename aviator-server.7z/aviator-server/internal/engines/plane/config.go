package plane

import "time"

type Config struct {
	IncrementSpeed time.Duration // time of increment to 0.01 coefficient
	TimeForWager   time.Duration // time for delay takeoff
}
