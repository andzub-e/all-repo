package airport

import (
	"base-slot/internal/engines/plane"
	"base-slot/internal/errs"
	"base-slot/utils"
	"errors"
	"log"
	"sync"
)

type Airport interface {
	GetCurrentPlane() (plane.Plane, error)
	WaitThePlane() plane.Plane
	StartOneFlight() error
}

func NewAirPort(gen plane.Generator) Airport {
	a := &airport{
		generator: gen,
		RWMutex:   &sync.RWMutex{},
		waitPlane: utils.WaitGroupWith(1),
		waitAllow: utils.WaitGroupWith(1),
	}
	go a.start()
	return a
}

type airport struct {
	plane  plane.Plane
	active bool

	waitPlane *sync.WaitGroup
	waitAllow *sync.WaitGroup

	generator plane.Generator

	*sync.RWMutex
}

func (a *airport) start() {
	for {
		a.waitAllow.Wait()
		a.waitAllow.Add(1)

		p, err := a.generator.NewPlane()
		if err != nil {
			log.Fatal(err)
		}

		a.Lock()
		a.plane = p
		a.waitPlane.Done()
		a.Unlock()

		if err := p.Start(); err != nil {
			panic(err)
		}

		p.WaitCrash()

		a.Lock()
		a.active = false
		a.waitPlane.Add(1)
		a.Unlock()

	}
}

func (a *airport) GetCurrentPlane() (plane.Plane, error) {
	a.RLock()
	defer a.RUnlock()

	if a.plane == nil {
		return nil, errs.ErrHaveNotActivePlanes
	}

	return a.plane, nil
}

func (a *airport) WaitThePlane() plane.Plane {
	a.waitPlane.Wait()

	return a.plane
}

func (a *airport) StartOneFlight() error {
	a.Lock()
	defer a.Unlock()

	if a.active {
		return errors.New("airport already started")
	}

	a.active = true
	a.waitAllow.Done()

	return nil
}
