package coefficient

import (
	"base-slot/internal/errs"
	rand2 "math/rand"
	"sync"
	"time"
)

/* TODO: FOR TEST ONLY. NOT FOR PRODUCTION! */

func NewMockCoefficientGenerator() Factory {
	return &localCoefficientGenerator{m: &sync.Mutex{}}
}

type localCoefficientGenerator struct {
	nextCoef *float64
	m        *sync.Mutex
}

func (l *localCoefficientGenerator) SetNextCoefficient(f float64) error {
	l.m.Lock()
	defer l.m.Unlock()

	if f < 1 {
		return errs.ErrWrongCheatCoefficient
	}

	l.nextCoef = &f
	return nil
}

func (l *localCoefficientGenerator) GetCoefficient() (float64, error) {
	l.m.Lock()
	defer l.m.Unlock()

	if l.nextCoef != nil {
		coef := *l.nextCoef
		l.nextCoef = nil
		return coef, nil
	}

	b := rand2.New(rand2.NewSource(time.Now().UnixNano()))

	return (b.Float64() * 5) + 1, nil
}

func (l *localCoefficientGenerator) GetCoefficientWithoutCheat() (float64, error) {
	l.m.Lock()
	defer l.m.Unlock()

	b := rand2.New(rand2.NewSource(time.Now().UnixNano()))

	return (b.Float64() * 5) + 1, nil
}
