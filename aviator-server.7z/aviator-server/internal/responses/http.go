package responses

import "base-slot/internal/entities"

type GetFreeSpinsResponse struct {
	FreeSpins []*entities.FreeSpin `json:"free_spins"`
}
