package websocket

import (
	"base-slot/internal/services"
	"base-slot/internal/validator"
	"base-slot/internal/wrap"
	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
	"net/http"
)

var upg = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin: func(r *http.Request) bool {
		return true
	},
}

type Server struct {
	conf    *Config
	vld     *validator.Validator
	connSrv services.ConnectionService
}

func NewServer(conf *Config, vld *validator.Validator, connSrv services.ConnectionService) *Server {
	return &Server{
		conf:    conf,
		vld:     vld,
		connSrv: connSrv,
	}
}

func (s *Server) ServeWS(ctx *gin.Context) error {
	conn, err := upg.Upgrade(ctx.Writer, ctx.Request, nil)
	if err != nil {
		return err
	}

	s.connSrv.Connect(wrap.NewMySocket(conn))

	return nil
}
