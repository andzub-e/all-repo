package errs

import "base-slot/pkg/overlord"

var translateMap = map[error]error{
	overlord.ErrMarshaling:          ErrBadDataGiven,
	overlord.ErrBalanceTooLow:       ErrNotEnoughMoney,
	overlord.ErrWrongSessionToken:   ErrWrongSessionToken,
	overlord.ErrWrongFreeSpinID:     ErrWrongFreeSpinID,
	overlord.ErrSessionTokenExpired: ErrSessionTokenExpired,
}

func TranslateOverlordErr(err error) error {
	validationErr, ok := err.(overlord.ValidationError)
	if ok {
		return InternalValidationError{Err: validationErr}
	}

	res, ok := translateMap[err]
	if !ok {
		return err
	}

	return res
}
