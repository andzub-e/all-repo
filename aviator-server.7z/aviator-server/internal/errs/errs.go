package errs

import "errors"

type InternalValidationError struct {
	Err error
}

func (err InternalValidationError) Error() string {
	return err.Err.Error()
}

func NewInternalValidationError(err error) InternalValidationError {
	return InternalValidationError{Err: err}
}

var (
	ErrUserNotAuthorized       = errors.New("user not authorized")
	ErrNotEnoughMoney          = errors.New("not enough money")
	ErrWrongSessionToken       = errors.New("wrong session token")
	ErrSessionTokenExpired     = errors.New("session token expired")
	ErrWrongFreeSpinID         = errors.New("wrong free spin id")
	ErrBadDataGiven            = errors.New("bad data given")
	ErrWrongBalanceComputation = errors.New("wrong balance computation")
	ErrHistoryRecordNotFound   = errors.New("history record not found")
	ErrConnectionAlreadyExist  = errors.New("connection already exist")
	ErrUserNotConnected        = errors.New("user not connected")
	ErrWrongCurrency           = errors.New("wrong currency")
	ErrWrongCheatCoefficient   = errors.New("wrong cheat coefficient")
	ErrWrongUserFromRound      = errors.New("round from another user")
	ErrHaveNotActivePlanes     = errors.New("have not active planes")
	ErrConnectionClosed        = errors.New("connection closed")
)
