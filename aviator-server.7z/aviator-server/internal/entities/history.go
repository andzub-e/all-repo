package entities

import (
	"github.com/google/uuid"
	"time"
)

const HistoryRecordTable = "history_records"

type HistoryRecord struct {
	ID     uuid.UUID `json:"id"`
	Game   string    `json:"game"`
	UserID string    `json:"user_id"`

	Currency     string    `json:"currency"`
	StartBalance int64     `json:"start_balance"`
	EndBalance   int64     `json:"end_balance"`
	Wager        int64     `json:"wager"`
	BaseAward    int64     `json:"base_award"`
	BonusAward   int64     `json:"bonus_award"`
	CreatedAt    time.Time `json:"created_at"`

	Spin Flight `json:"spin" gorm:"serializer:json"`
}

type Flight struct {
	Wager int64
}

type HistoryPagination struct {
	Records []*HistoryRecord `json:"records"`
	Page    int              `json:"page"`
	Count   int              `json:"count"`
	Total   int              `json:"total"`
}
