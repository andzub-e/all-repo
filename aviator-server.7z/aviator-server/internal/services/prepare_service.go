package services

import (
	"base-slot/internal/repositories"
	"context"
	"go.uber.org/zap"
)

type PrepareService interface {
	CloseAllOpenWagers(context.Context) error
}

func NewPrepareService(repo repositories.WagerRepository, flow GameFlowService) PrepareService {
	return &prepareService{repo: repo, flow: flow}
}

type prepareService struct {
	repo repositories.WagerRepository
	flow GameFlowService
}

func (p *prepareService) CloseAllOpenWagers(ctx context.Context) error {
	wagers, err := p.repo.GetOpenWagers(ctx)
	if err != nil {
		return err
	}

	for _, wager := range wagers {
		zap.S().Info("Closing " + wager.ID.String())
		_, err := p.flow.Rollback(ctx, wager.TransactionId, wager.Currency)
		if err != nil {
			return err
		}

		if err = p.repo.DeleteWagerById(ctx, wager.ID); err != nil {
			return err
		}
	}
	return nil
}
