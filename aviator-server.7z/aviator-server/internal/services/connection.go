package services

import (
	"base-slot/internal/constants"
	"base-slot/internal/engines/airport"
	"base-slot/internal/entities"
	"base-slot/internal/errs"
	"base-slot/internal/repositories"
	"base-slot/internal/requests"
	"base-slot/internal/responses"
	"base-slot/internal/wrap"
	"base-slot/utils"
	"context"
	"errors"
	"github.com/google/uuid"
	"log"
	"math"
	"sync"
	"time"
)

type ConnectionService interface {
	Connect(wrap.MySocket)
	SendToUser(string, responses.SocketWrap) error
	NotifyCloseBet(string, CloseBet) error
	SendToAllAuthenticUsers(rq responses.SocketWrap)
}

func NewConnectionService(gfs GameFlowService, r repositories.WagerRepository, ap airport.Airport) ConnectionService {
	return &connectionServiceImpl{gfs: gfs, repo: r, pool: &sync.Map{}, ap: ap}
}

type connectionServiceImpl struct {
	gfs  GameFlowService
	pool *sync.Map
	repo repositories.WagerRepository
	ap   airport.Airport
}

func (c *connectionServiceImpl) NotifyCloseBet(userID string, bet CloseBet) error {
	return c.SendToUser(userID, responses.SocketWrap{
		Code: constants.StatusSuccess,
		Type: responses.TypeCloseWager,
		Data: responses.CloseWager{
			WinCoefficient: utils.CoefficientToString(bet.Coefficient),
			Win:            bet.Win,
			Currency:       bet.Currency,
			Balance:        bet.Balance,
		},
	})

}

func (c *connectionServiceImpl) Connect(conn wrap.MySocket) {
	go c.handle(conn)
}

func (c *connectionServiceImpl) SendToUser(userID string, rq responses.SocketWrap) error {
	var userFound bool

	c.pool.Range(func(key, value any) bool {
		if value.(*entities.GameState).UserID == userID {
			conn := key.(wrap.MySocket)
			err := conn.WriteMessage(rq)
			if err != nil {
				c.disconnect(conn)
			} else {
				userFound = true
			}
		}

		return true
	})

	if userFound {
		return nil
	} else {
		return errs.ErrUserNotConnected
	}
}

func (c *connectionServiceImpl) SendToAllAuthenticUsers(rq responses.SocketWrap) {
	c.pool.Range(func(conn, _ any) bool {
		w := conn.(wrap.MySocket)

		go func(conn wrap.MySocket) {
			err := conn.WriteMessage(rq)
			if err != nil {
				c.disconnect(conn)
			}
		}(w)

		return true
	})

}

func (c *connectionServiceImpl) disconnect(conn wrap.MySocket) {
	u, ok := c.pool.LoadAndDelete(conn)
	if ok {
		log.Printf("disconnected user: %s\n", u.(*entities.GameState).UserID)
	}
}

func (c *connectionServiceImpl) handle(conn wrap.MySocket) {

	for {
		rq, err := conn.ReadMessage()
		if err != nil {
			c.disconnect(conn)

			break
		}

		go func(rq requests.SocketWrap) {

			ctx, cancel := context.WithTimeout(context.Background(), time.Second*10) // TODO: set timeout;
			defer cancel()

			var err error

			if rq.Auth != nil {
				err = c.auth(ctx, conn, rq.Auth)
				goto handleErr
			}

			if rq.Wager != nil {
				err = c.wager(ctx, conn, rq.Wager)
				goto handleErr
			}

			if rq.Payout != nil {
				err = c.payout(ctx, conn, rq.Payout)
				goto handleErr
			}

		handleErr:
			if err == errs.ErrConnectionClosed {
				c.disconnect(conn)
				return
			} else if err != nil {
				err = conn.WriteMessage(responses.SocketWrap{
					Code: constants.StatusBadRequest,
					Type: responses.TypeError,
					Data: err.Error(),
				})
				goto handleErr
			}

		}(rq)
	}

}

func (c *connectionServiceImpl) wager(ctx context.Context, conn wrap.MySocket, rq *requests.Wager) error {
	stateObj, exist := c.pool.Load(conn)
	if !exist {
		return errs.ErrUserNotAuthorized
	}

	plane, err := c.ap.GetCurrentPlane()
	if err != nil {
		return err
	}

	if !plane.CanWager() {
		return errors.New("you can't wager now")
	}

	state := stateObj.(*entities.GameState)

	if state.Currency != rq.Currency {
		return errs.ErrWrongCurrency
	}

	wg := repositories.Wager{
		ID:       uuid.New(),
		Amount:   rq.Wager,
		Currency: rq.Currency,
		WinAt:    rq.AutoWinCoefficient,
		UserID:   state.UserID,
	}

	w, err := c.gfs.OpenWager(ctx, state.SessionToken, rq.FreeSpinID, wg.ID.String(), rq.Wager)
	if err != nil {
		return err
	}

	wg.TransactionId = w.TransactionID

	err = c.repo.SaveRound(ctx, wg)
	if err != nil {
		return err
	}

	err = conn.WriteMessage(responses.SocketWrap{
		Code: constants.StatusSuccess,
		Type: responses.TypeOpenWager,
		Data: responses.OpenWager{RoundId: wg.ID, Balance: w.Balance},
	})

	return err
}

func (c *connectionServiceImpl) payout(ctx context.Context, conn wrap.MySocket, rq *requests.Payout) error {
	stateObj, exist := c.pool.Load(conn)
	if !exist {
		return errs.ErrUserNotAuthorized
	}

	state := stateObj.(*entities.GameState)

	repoWager, err := c.repo.GetWagerById(ctx, rq.RoundId)
	if err != nil {
		return err
	}

	if state.UserID != repoWager.UserID {
		return errs.ErrWrongUserFromRound
	}

	plane, err := c.ap.GetCurrentPlane()
	if err != nil {
		err = conn.WriteMessage(responses.SocketWrap{
			Code: constants.StatusBadRequest,
			Type: responses.TypeError,
			Data: err.Error(),
		})

		if err != nil {
			return err
		}
	}

	coe, err := plane.GetActualCoefficient()
	if err != nil {
		err := conn.WriteMessage(responses.SocketWrap{
			Code: constants.StatusBadRequest,
			Type: responses.TypeError,
			Data: err.Error(),
		})

		if err != nil {
			return err
		}
	}

	win := int64(math.Round(float64(repoWager.Amount) * coe))

	w, err := c.gfs.CloseWager(ctx, repoWager.TransactionId, repoWager.Currency, win, coe)
	if err != nil {
		return err
	}

	err = c.repo.DeleteWagerById(ctx, repoWager.ID)
	if err != nil {
		return err
	}

	return c.NotifyCloseBet(repoWager.UserID, w)
}

func (c *connectionServiceImpl) auth(ctx context.Context, conn wrap.MySocket, rq *requests.Auth) error {
	_, exist := c.pool.Load(conn)
	if exist {
		return errs.ErrConnectionAlreadyExist
	}

	game, err := c.gfs.InitGame(ctx, rq.Game, rq.Operator, rq.Params)

	if err != nil {
		err = conn.WriteMessage(responses.SocketWrap{
			Code: constants.StatusBadRequest,
			Type: responses.TypeError,
			Data: err.Error(),
		})

		if err != nil {
			c.disconnect(conn)
		}

		return err
	}

	err = conn.WriteMessage(responses.SocketWrap{Code: constants.StatusSuccess, Type: responses.TypeState, Data: game})
	if err != nil {
		c.disconnect(conn)

		return err
	}

	log.Printf("connected user: %s\n", game.UserID)

	c.pool.Store(conn, game)

	return nil
}
