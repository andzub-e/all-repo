package services

import (
	"base-slot/internal/entities"
	"base-slot/internal/repositories"
	"context"
)

type HistoryService struct {
	repo *repositories.HistoryRepository
}

func NewHistoryService(repo *repositories.HistoryRepository) *HistoryService {
	return &HistoryService{repo: repo}
}

func (s *HistoryService) Pagination(ctx context.Context, userID, game string, count, page int) (entities.HistoryPagination, error) {
	return s.repo.Pagination(ctx, userID, game, count, page)
}

func (s *HistoryService) Create(ctx context.Context, record *entities.HistoryRecord) error {
	return s.repo.Create(ctx, record)
}

func (s *HistoryService) LastRecord(ctx context.Context, userID, game string) (*entities.HistoryRecord, error) {
	return s.repo.LastRecord(ctx, userID, game)
}
