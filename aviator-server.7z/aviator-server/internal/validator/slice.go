package validator

import (
	"fmt"
	"strings"
)

type sliceValidateError []error

func (err sliceValidateError) Error() string {
	builder := strings.Builder{}

	for i, e := range err {
		if e != nil {
			builder.WriteString(fmt.Sprintf("[%d]: %s\n", i, e.Error()))
		}
	}

	return strings.TrimRight(builder.String(), "\n")
}
