package requests

type SetCoefficient struct {
	Coefficient float64 `json:"coefficient"`
}
