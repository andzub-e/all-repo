package requests

type SocketWrap struct {
	Auth   *Auth   `json:"auth"`
	Wager  *Wager  `json:"wager"`
	Payout *Payout `json:"payout"`
}
