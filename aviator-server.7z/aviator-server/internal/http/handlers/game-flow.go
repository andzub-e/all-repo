package handlers

import (
	"base-slot/internal/http"
	"base-slot/internal/requests"
	"base-slot/internal/services"
	"context"
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

type gameFlowHandler struct {
	gameFlowSrv services.GameFlowService
	historySrv  *services.HistoryService
}

func NewGameFlowHandler(gameFlowSrv services.GameFlowService, historySrv *services.HistoryService) http.Handler {
	return &gameFlowHandler{gameFlowSrv: gameFlowSrv, historySrv: historySrv}
}

func (h *gameFlowHandler) Register(router *gin.RouterGroup) {
	core := router.Group("core")

	core.GET("spins_history", h.history)
}

func (h *gameFlowHandler) history(ctx *gin.Context) {
	params := &requests.History{}
	if err := ctx.ShouldBindQuery(params); err != nil {
		zap.S().Error("history", err)
		http.ValidationFailed(ctx, err)

		return
	}

	gameState, err := h.gameFlowSrv.GameState(context.Background(), params.SessionToken)
	if err != nil {
		handleServiceError(ctx, err)

		return
	}

	pagination, err := h.historySrv.Pagination(ctx, gameState.UserID, gameState.Game, *params.Count, *params.Page)
	if err != nil {
		handleServiceError(ctx, err)

		return
	}

	http.OK(ctx, pagination, nil)
}
