package container

import (
	"base-slot/internal/bot"
	"base-slot/internal/config"
	"base-slot/internal/constants"
	"base-slot/internal/engines/airport"
	"base-slot/internal/engines/coefficient"
	"base-slot/internal/http"
	"base-slot/internal/repositories"
	"base-slot/internal/services"
	"base-slot/internal/validator"
	"base-slot/internal/websocket"
	"base-slot/pkg/overlord"
	"base-slot/pkg/pgsql"
	"base-slot/pkg/redis"
	"base-slot/pkg/rng"
	redis2 "github.com/go-redis/redis/v8"

	"context"
	"errors"
	"fmt"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
	"sync"
)

var container di.Container
var once sync.Once

func Build(ctx context.Context, wg *sync.WaitGroup, isTest bool) di.Container {
	once.Do(func() {
		builder, _ := di.NewBuilder()
		defs := []di.Def{
			{
				Name: constants.LoggerName,
				Build: func(ctn di.Container) (interface{}, error) {
					logger, err := zap.NewDevelopment()

					if err != nil {
						return nil, errors.New(fmt.Sprintf("can't initialize zap logger: %v", err))
					}

					zap.ReplaceGlobals(logger)
					return logger, nil
				},
			},
			{
				Name: constants.ConfigName,
				Build: func(ctn di.Container) (interface{}, error) {
					return config.New(isTest)
				},
			},
			{
				Name: constants.PgSQLName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return pgsql.NewPgsqlConnection(cfg.PgSQLConfig)
				},
			},
			{
				Name: constants.OverlordName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return overlord.NewClient(cfg.OverlordConfig)
				},
			},
			{
				Name: constants.RNGName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return rng.New(cfg.RNGConfig)
				},
			},
			{
				Name: constants.ValidatorName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return validator.New(cfg.ConstantsConfig)
				},
			},
			{
				Name: constants.WebsocketServerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)
					connSrv := ctn.Get(constants.ConnectionServiceName).(services.ConnectionService)
					vldEng := ctn.Get(constants.ValidatorName).(*validator.Validator)

					return websocket.NewServer(cfg.WebsocketConfig, vldEng, connSrv), nil
				},
			},
			{
				Name: constants.ConnectionServiceName,
				Build: func(ctn di.Container) (interface{}, error) {
					gameFlow := ctn.Get(constants.GameFlowServiceName).(services.GameFlowService)
					roundRepo := ctn.Get(constants.WagerRepositoryName).(repositories.WagerRepository)
					airportSrv := ctn.Get(constants.AirportName).(airport.Airport)

					return services.NewConnectionService(gameFlow, roundRepo, airportSrv), nil
				},
			},
			{
				Name: constants.ServerName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)
					var publicHandlers = []http.Handler{
						ctn.Get(constants.GameFlowHandlerName).(http.Handler),
						ctn.Get(constants.CheatHandlerName).(http.Handler),
						ctn.Get(constants.WebsocketHandlerName).(http.Handler),
						ctn.Get(constants.SimulatorHandlerName).(http.Handler),
						ctn.Get(constants.MetricsHandlerName).(http.Handler),
					}
					var privateHandlers []http.Handler

					return http.New(ctx, wg, cfg.ServerConfig, publicHandlers, privateHandlers), nil
				},
			},
			{
				Name: constants.RedisName,
				Build: func(ctn di.Container) (interface{}, error) {
					cfg := ctn.Get(constants.ConfigName).(*config.Config)

					return redis.New(cfg.RedisConfig)
				},
			},
			{
				Name: constants.WagerRepositoryName,
				Build: func(ctn di.Container) (interface{}, error) {
					cli := ctn.Get(constants.RedisName).(*redis2.Client)
					return repositories.NewRedisRound(cli), nil
				},
			},
			{
				Name: constants.GameFlowServiceName,
				Build: func(ctn di.Container) (interface{}, error) {
					hst := ctn.Get(constants.HistoryServiceName).(*services.HistoryService)
					lord := ctn.Get(constants.OverlordName).(overlord.Client)

					return services.NewGameFlowService(lord, hst), nil
				},
			},
			{
				Name: constants.PrepareServiceName,
				Build: func(ctn di.Container) (interface{}, error) {
					wgr := ctn.Get(constants.WagerRepositoryName).(repositories.WagerRepository)
					gfs := ctn.Get(constants.GameFlowServiceName).(services.GameFlowService)

					return services.NewPrepareService(wgr, gfs), nil
				},
			},
			{
				Name: constants.BotServiceName,
				Build: func(ctn di.Container) (interface{}, error) {
					air := ctn.Get(constants.AirportName).(airport.Airport)
					con := ctn.Get(constants.ConnectionServiceName).(services.ConnectionService)
					coe := ctn.Get(constants.CoefficientFactoryName).(coefficient.Factory)
					cnf := ctn.Get(constants.ConfigName).(*config.Config)

					return bot.NewService(air, con, coe, *cnf.BotConfig, *cnf.FlyConfig), nil
				},
			},
		}

		defs = append(defs, BuildServices()...)
		defs = append(defs, BuildRepositories()...)
		defs = append(defs, BuildHandlers()...)
		defs = append(defs, BuildEngine()...)

		if err := builder.Add(defs...); err != nil {
			panic(err)
		}

		container = builder.Build()
	})

	return container
}
