package container

import (
	"base-slot/internal/config"
	"base-slot/internal/constants"
	"base-slot/internal/engines/coefficient"
	"base-slot/internal/http/handlers"
	"base-slot/internal/services"
	"base-slot/internal/websocket"
	"base-slot/pkg/overlord"
	"github.com/sarulabs/di"
)

func BuildHandlers() []di.Def {
	return []di.Def{
		{
			Name: constants.GameFlowHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				gameFlowSrv := ctn.Get(constants.GameFlowServiceName).(services.GameFlowService)
				historySrv := ctn.Get(constants.HistoryServiceName).(*services.HistoryService)

				return handlers.NewGameFlowHandler(gameFlowSrv, historySrv), nil
			},
		},
		{
			Name: constants.CheatHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				ftc := ctn.Get(constants.CoefficientFactoryName).(coefficient.Factory)

				return handlers.NewCheatHandler(ftc), nil
			},
		},
		{
			Name: constants.WebsocketHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				websocketServer := ctn.Get(constants.WebsocketServerName).(*websocket.Server)

				return handlers.NewWebsocketHandler(websocketServer), nil
			},
		},
		{
			Name: constants.SimulatorHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				return handlers.NewSimulationHandler(), nil
			},
		},
		{
			Name: constants.MetricsHandlerName,
			Build: func(ctn di.Container) (interface{}, error) {
				conf := ctn.Get(constants.ConfigName).(*config.Config)
				metricsSrv := ctn.Get(constants.MetricsServiceName).(*services.MetricsService)
				overlordClient := ctn.Get(constants.OverlordName).(overlord.Client)

				return handlers.NewMetricsHandler(metricsSrv, overlordClient, conf.ConstantsConfig)
			},
		},
	}
}
