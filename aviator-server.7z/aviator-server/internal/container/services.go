package container

import (
	"base-slot/internal/constants"
	"base-slot/internal/engines/airport"
	"base-slot/internal/repositories"
	"base-slot/internal/services"
	"github.com/sarulabs/di"
)

func BuildServices() []di.Def {
	return []di.Def{
		{
			Name: constants.HistoryServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				repo := ctn.Get(constants.HistoryRepositoryName).(*repositories.HistoryRepository)

				return services.NewHistoryService(repo), nil
			},
		},
		{
			Name: constants.MetricsServiceName,
			Build: func(ctn di.Container) (interface{}, error) {
				repo := ctn.Get(constants.MetricsRepositoryName).(repositories.MetricsRepository)

				return services.NewMetricsService(repo), nil
			},
		},
		{
			Name: constants.DistributorName,
			Build: func(ctn di.Container) (interface{}, error) {
				air := ctn.Get(constants.AirportName).(airport.Airport)
				con := ctn.Get(constants.ConnectionServiceName).(services.ConnectionService)
				wgr := ctn.Get(constants.WagerRepositoryName).(repositories.WagerRepository)
				gfs := ctn.Get(constants.GameFlowServiceName).(services.GameFlowService)

				return services.NewDistributor(air, con, wgr, gfs), nil
			},
		}, {
			Name: constants.PlaneControlName,
			Build: func(ctn di.Container) (interface{}, error) {
				air := ctn.Get(constants.AirportName).(airport.Airport)
				con := ctn.Get(constants.ConnectionServiceName).(services.ConnectionService)
				rnd := ctn.Get(constants.WagerRepositoryName).(repositories.WagerRepository)
				flw := ctn.Get(constants.GameFlowServiceName).(services.GameFlowService)

				return services.NewPlaneControlService(con, air, rnd, flw), nil
			},
		},
	}
}
