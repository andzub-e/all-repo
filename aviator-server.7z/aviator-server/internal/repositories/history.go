package repositories

import (
	"base-slot/internal/entities"
	"base-slot/internal/errs"
	"context"
	"gorm.io/gorm"
)

type HistoryRepository struct {
	conn *gorm.DB
}

func NewHistoryRepository(conn *gorm.DB) *HistoryRepository {
	return &HistoryRepository{conn: conn}
}

func (r *HistoryRepository) Create(ctx context.Context, record *entities.HistoryRecord) error {
	return r.conn.WithContext(ctx).Create(record).Error
}

func (r *HistoryRepository) Pagination(ctx context.Context, userID, game string, count, page int) (p entities.HistoryPagination, err error) {
	tx := r.conn.WithContext(ctx).
		Order("created_at desc").
		Where("user_id = ? and game = ?", userID, game).
		Table(entities.HistoryRecordTable)

	var counter int64
	if err = tx.Count(&counter).Error; err != nil {
		return p, err
	}

	err = tx.Limit(count).
		Offset(count * (page - 1)).
		Find(&p.Records).Error

	if err != nil {
		return p, err
	}

	p.Total = int(counter)
	p.Count = count
	p.Page = page

	return p, nil
}

func (r *HistoryRepository) LastRecord(ctx context.Context, userID, game string) (*entities.HistoryRecord, error) {
	record := &entities.HistoryRecord{}
	err := r.conn.WithContext(ctx).
		Order("created_at desc").
		Where("user_id = ? and game = ?", userID, game).
		First(record).
		Error

	if err == gorm.ErrRecordNotFound {
		return nil, errs.ErrHistoryRecordNotFound
	}
	if err != nil {
		return nil, err
	}

	return record, nil
}

func (r *HistoryRepository) Update(ctx context.Context, record *entities.HistoryRecord) error {
	return r.conn.WithContext(ctx).Updates(record).Error
}
