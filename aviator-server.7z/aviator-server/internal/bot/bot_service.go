package bot

import (
	"base-slot/internal/constants"
	"base-slot/internal/engines/airport"
	"base-slot/internal/engines/coefficient"
	plane2 "base-slot/internal/engines/plane"
	"base-slot/internal/responses"
	"base-slot/internal/services"
	"base-slot/utils"
	"github.com/google/uuid"
	"go.uber.org/zap"
	"sync"
	"time"
)

type Service interface {
	Start()
}

func NewService(a airport.Airport, b services.ConnectionService, r coefficient.Factory, c Config,
	c2 plane2.Config) Service {

	return &botService{airport: a, conn: b, rng: r, plCnf: c2, btCnf: c}
}

type botService struct {
	airport airport.Airport
	conn    services.ConnectionService
	rng     coefficient.Factory
	plCnf   plane2.Config
	btCnf   Config
	storage sync.Map
}

func (b *botService) Start() {
	for {
		plane := b.airport.WaitThePlane()
		eventChan := plane.GetEventChan()

	events:
		for event := range eventChan {
			switch event.Event {
			case plane2.EventNewRound:
				botsAmount, err := utils.InRange(b.btCnf.Amount[0], b.btCnf.Amount[1])
				if err != nil {
					zap.S().Warn(err)
					continue
				}

				for i := int64(0); i < botsAmount; i++ {

					go func() {
						delay, err := utils.InRange(0, b.plCnf.TimeForWager.Nanoseconds())
						if err != nil {
							zap.S().Warn(err)
							return
						}

						time.Sleep(time.Duration(delay))

						coe, err := b.rng.GetCoefficientWithoutCheat()
						if err != nil {
							zap.S().Warn(err)
							return
						}

						wager, err := utils.InRange(b.btCnf.Wagers[0], b.btCnf.Wagers[1])
						if err != nil {
							zap.S().Warn(err)
							return
						}

						nameID, err := utils.InRange(0, int64(len(b.btCnf.Names)))
						if err != nil {
							zap.S().Warn(err)
							return
						}

						if !plane.CanWager() {
							return
						}

						botIns := &bot{
							id:     uuid.New(),
							wager:  uint64(wager),
							payout: utils.CoefficientToString(coe),
							name:   b.btCnf.Names[nameID],
						}

						b.storage.Store(botIns, true)

						b.conn.SendToAllAuthenticUsers(responses.SocketWrap{
							Code: constants.StatusSuccess,
							Type: responses.TypeBotWager,
							Data: responses.BotWager{Id: botIns.id, Wager: botIns.wager, Name: botIns.name},
						})

						zap.S().Infof("%+v", *botIns)

					}()

				}

			case plane2.EventCoefficient:
				coeNow := event.Data.(float64)
				coeNowStr := utils.CoefficientToString(coeNow)

				b.storage.Range(func(k, _ any) bool {
					botIns := k.(*bot)
					if botIns.payout == coeNowStr {
						// bot won
						b.conn.SendToAllAuthenticUsers(responses.SocketWrap{
							Code: constants.StatusSuccess,
							Type: responses.TypeBotPayout,
							Data: responses.BotPayout{Id: botIns.id, Wager: botIns.wager, CoefficientWin: coeNowStr},
						})
						b.storage.Delete(k)
					}
					return true
				})

			case plane2.EventCrashed:

				b.storage.Range(func(k, _ any) bool {
					botIns := k.(*bot)

					b.conn.SendToAllAuthenticUsers(responses.SocketWrap{
						Code: constants.StatusSuccess,
						Type: responses.TypeBotLoose,
						Data: responses.BotLoose{Id: botIns.id, Wager: botIns.wager},
					})

					b.storage.Delete(k)

					return true
				})

				close(eventChan)
				break events

			}

		}
	}
}

type bot struct {
	id     uuid.UUID
	name   string
	wager  uint64
	payout string // coefficient in string
}
