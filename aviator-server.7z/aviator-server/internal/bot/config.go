package bot

type Config struct {
	Wagers [2]int64
	Amount [2]int64 // from .. to
	Names  []string
}
