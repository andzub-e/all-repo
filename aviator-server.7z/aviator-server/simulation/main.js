let socket_protocol = location.protocol === 'https:' ? 'wss:' : 'ws:'

let socket_url = socket_protocol + '//' + location.host + '/ws'

let ws = new WebSocket(socket_url);

ws.onopen = () => {
    // noinspection JSUnresolvedFunction
    let s = JSON.stringify({
        auth: {
            operator: "mock",
            game: "cyber-town",
            params: {
                currency: "XTS",
                operator: "mock",
                game: "cyber-town",
                user_id: gen_uuid(),
                jurisdiction: "UA",
                userlocale: "da-DK"
            }
        }
    });

    ws.send(s)
}

let $center_text = $('.center-text');
let $balance = $('.balance');
let $wager_btn = $('.wager');
let $wager_inp = $('.wager_in');
let $coef_inp = $('.coef_in');
let $bots = $('#bots')

let currency = null
let default_wager = null

ws.onmessage = msg => {
    let data = JSON.parse(msg.data)

    if (data.type === "close_wager" && data.data.win > 0) {
        $wager_btn.data('round_id', null).text("Done!").prop('disabled', true)
        Swal.fire('WIN!', `You won ${data.data.win} ${data.data.currency.toUpperCase()}`, 'success')
    }

    data.type === "error" && Swal.fire('Error', data.data, 'error')

    if (data.type === "state") {
        currency = data.data.currency
        default_wager = data.data.default_wager
        $balance.text(`${data.data.balance} ${currency.toUpperCase()}`)
        $wager_inp.val(default_wager)
    }

    if (data.type === 'open_wager' || data.type === 'close_wager') {
        $balance.text(`${data.data.balance} ${currency.toUpperCase()}`)
    }

    if (data.type === 'open_wager') {
        $wager_btn.data('round_id', data.data.round_id).text('WAIT..').prop('disabled', !0)
    }

    if (data.type === 'started') {
        let round_id = $wager_btn.data('round_id');

        $wager_btn.prop('disabled', !round_id)

        $wager_btn.text(round_id ? 'Payout' : 'Pls wait next round')
    }

    data.type === "coefficient" && $center_text.css('color', '#5600ff').text('x' + data.data)


    if (data.type === "crashed") {
        $wager_btn.data('round_id', null).text('WAIT..')
        $center_text.css('color', 'red')
    }

    if (data.type === "countdown") {
        $center_text.css('color', 'green').text(`Left ${data.data}`)


        let round_id = $wager_btn.data('round_id');

        !round_id && $wager_btn.prop('disabled', false).text('WAGER')
    }

    if (data.type === "new round") {
        $bots.empty()
    }

    if (data.type === "bot wager") {
        $bots.append(`
            <tr id="${data.data.id}"> 
                <td>${data.data.name}</td>
                <td>${data.data.wager * default_wager} ${currency}</td>
                <td></td> 
            </tr>`)
    }

    if (data.type === "bot payout") {
        let won = (data.data.coefficient_win * data.data.wager * default_wager).toFixed(0) + " " + currency;
        $('#' + data.data.id).addClass('won').children().eq(2).text(won)
    }

    if (data.type === "bot loose") {
        $('#' + data.data.id).addClass('loose')
    }

}

$wager_btn.click(() => {

    let round_id = $wager_btn.data('round_id');

    if (round_id) {
        let s = JSON.stringify({payout: {round_id}});
        $wager_btn.data('round_id', null).text("Done!").prop('disabled', true)
        ws.send(s)
    } else {
        let auto_win_coefficient = undefined
        if ($coef_inp.val()) auto_win_coefficient = $coef_inp.val() * 1
        let wager = $wager_inp.val() * 1;
        let s = JSON.stringify({wager: {wager, currency, auto_win_coefficient}});
        ws.send(s)
    }


})

$('#cheat button').click(function () {
    let coefficient = $('#cheat input').val() * 1;
    $.ajax({
        type: "POST",
        url: '/cheat/set_next_coefficient',
        data: JSON.stringify({coefficient}),
        success: () => Swal.fire('Success', '', 'success'),
        error: e => Swal.fire('Error', e.responseText, 'error'),
        contentType: "application/json",
    });
})

function gen_uuid() {
    return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
        (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
    );
}

