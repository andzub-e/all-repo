package tests

import (
	"base-slot/internal/constants"
	"base-slot/internal/container"
	"base-slot/internal/repositories"
	"context"
	"github.com/google/uuid"
	"reflect"
	"testing"
)

func TestRedisRepo(t *testing.T) {
	//goland:noinspection SpellCheckingInspection
	var (
		ctx   = context.Background()
		app   = container.Build(ctx, nil, true)
		round = app.Get(constants.WagerRepositoryName).(repositories.WagerRepository)

		coefficient      = 45.2
		countWithCoef    = 5
		countWithoutCoef = 7
	)

	//goland:noinspection GoBoolExpressions
	if countWithCoef <= 0 || countWithoutCoef <= 0 {
		panic("wrong input params")
	}

	panicIfNN(round.Clear(ctx))
	defer func() {
		panicIfNN(round.Clear(ctx))
	}()

	// Insert necessary data.
	{
		for i := 0; i < countWithoutCoef; i++ {
			err := round.SaveRound(ctx, repositories.Wager{
				ID:            uuid.New(),
				Amount:        100,
				Currency:      "USD",
				TransactionId: uuid.NewString(),
				WinAt:         nil,
			})
			panicIfNN(err)
		}

		for i := 0; i < countWithCoef; i++ {
			err := round.SaveRound(ctx, repositories.Wager{
				ID:            uuid.New(),
				Amount:        100,
				Currency:      "USD",
				TransactionId: uuid.NewString(),
				WinAt:         &coefficient,
			})
			panicIfNN(err)
		}
	}

	// Test for GetWagersWithCoefficient.
	{
		wagers, err := round.GetWagersWithCoefficient(ctx, coefficient)
		panicIfNN(err)

		if len(wagers) != countWithCoef {
			t.Errorf("wagers need: %d. wagers have: %d", countWithCoef, len(wagers))
		}
	}

	// Test for GetWagersWithCoefficient.
	{
		wagers, err := round.GetWagersWithCoefficient(ctx, coefficient+1)
		panicIfNN(err)

		if len(wagers) != 0 {
			t.Errorf("wagers need: 0. wagers have: %d", len(wagers))
		}
	}

	// Test for GetWagersWithCoefficient.
	{
		wagers, err := round.GetWagersWithCoefficient(ctx, coefficient-1)
		panicIfNN(err)

		if len(wagers) != 0 {
			t.Errorf("wagers need: 0. wagers have: %d", len(wagers))
		}
	}

	// Test for GetOpenWagers and GetWagerById.
	{
		wagers, err := round.GetOpenWagers(ctx)
		panicIfNN(err)

		if len(wagers) != countWithoutCoef+countWithCoef {
			t.Errorf("wagers need: %d. wagers have: %d", countWithoutCoef+countWithCoef, len(wagers))
		}

		for _, wager := range wagers {
			wager2, err := round.GetWagerById(ctx, wager.ID)
			panicIfNN(err)

			if !reflect.DeepEqual(wager, wager2) {
				t.Errorf("wagers not equal: %+v and %+v", wager, wager2)
			}
		}
	}

	// Test for GetOpenWagers and DeleteWagerById.
	{
		wagers, err := round.GetOpenWagers(ctx)
		panicIfNN(err)

		if len(wagers) != countWithoutCoef+countWithCoef {
			t.Errorf("wagers need: %d. wagers have: %d\n", countWithoutCoef+countWithCoef, len(wagers))
		}

		need := len(wagers)
		for _, wager := range wagers {
			err := round.DeleteWagerById(ctx, wager.ID)
			panicIfNN(err)
			need--

			wagers, err = round.GetOpenWagers(ctx)
			panicIfNN(err)

			if len(wagers) != need {
				t.Errorf("wagers need: %d. wagers have: %d\n", need, len(wagers))
			}
		}
	}

}
