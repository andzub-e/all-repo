package utils

import "sync"

func WaitGroupWith(delta int) *sync.WaitGroup {
	wg := &sync.WaitGroup{}
	wg.Add(delta)
	return wg
}
