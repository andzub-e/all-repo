package utils

import "fmt"

func CoefficientToString(f float64) string {
	return fmt.Sprintf("%.2f", f)
}
