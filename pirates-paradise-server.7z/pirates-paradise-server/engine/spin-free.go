package engine

type FreeGame struct {
	Win   int64      `json:"award"`
	Spins []FreeSpin `json:"free_spins"`
}

type FreeSpin struct {
	Stops              []int  `json:"stops"`
	Award              int64  `json:"award"`
	Window             Window `json:"window"`
	FreeSpinsLeft      int    `json:"bonus_spins_left"`
	FreeSpinsTriggered int    `json:"bonus_spins_triggered"`

	BonusSymbols   []int64   `json:"bonus_symbols"`
	PayLinesToShow []PayLine `json:"pay_lines_to_show"`

	BonusSpin *BonusGame `json:"bonus_spin"`
}

func (f *FreeGame) Award() int64 {
	if f == nil {
		return 0
	}

	return f.Win
}
