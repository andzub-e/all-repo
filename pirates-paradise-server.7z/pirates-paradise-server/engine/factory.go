package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	kernelUtils "bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine/utils"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/errs"
	"bitbucket.org/electronicjaw/base-slot-server/pkg/rng"
	"bitbucket.org/electronicjaw/base-slot-server/utils"
	"encoding/json"
	"github.com/samber/lo"
	"github.com/sarulabs/di"
	"go.uber.org/zap"
	"pirates-paradise/engine/volatility/high"
	"strconv"

	low "pirates-paradise/engine/volatility/low"
	meduim "pirates-paradise/engine/volatility/medium"
)

type Config struct {
	LowRTP, HighRTP          float64
	AvailableReels           [][][]int
	BonusSymbolChooser       *utils.Chooser[int64, int]
	BigSymbolChooser         *utils.Chooser[int, int]
	BonusSymbolsTableChooser map[int]*utils.Chooser[int, int]
}

func newVolatilityConfig(
	rand rng.Client,
	lowRtp, highRtp float64, availableReels [][][]int,
	bonusSymbolWeight map[int64]int, bigSymbolWeight map[int]int,
	bonusSymbolsTable map[int]map[int]int,
) *Config {
	bonusSymbolsChooser, err := utils.NewChooserFromMap(rand, bonusSymbolWeight)
	if err != nil {
		zap.S().Panic(err)
		panic(err)
	}

	bigSymbolChooser, err := utils.NewChooserFromMap(rand, bigSymbolWeight)
	if err != nil {
		zap.S().Panic(err)
		panic(err)
	}

	bonusSymbolsTableChooser := make(map[int]*utils.Chooser[int, int])
	for i, data := range bonusSymbolsTable {
		bonusSymbolsTableChooser[i], err = utils.NewChooserFromMap(rand, data)
		if err != nil {
			zap.S().Panic(err)
			panic(err)
		}
	}

	return &Config{
		LowRTP:                   lowRtp,
		HighRTP:                  highRtp,
		AvailableReels:           availableReels,
		BonusSymbolChooser:       bonusSymbolsChooser,
		BigSymbolChooser:         bigSymbolChooser,
		BonusSymbolsTableChooser: bonusSymbolsTableChooser,
	}
}

func GameBoot(ctn di.Container, config *engine.Config) *engine.Bootstrap {
	rand := kernelUtils.GetRNG(ctn, config)

	volatilityConfigMap := map[string]*Config{
		"low":    newVolatilityConfig(rand, low.LowRTP, low.HighRTP, low.AvailableReels, low.BonusSymbolWeight, low.BigSymbolWeight, low.BonusSymbolsTable),
		"medium": newVolatilityConfig(rand, meduim.LowRTP, meduim.HighRTP, meduim.AvailableReels, meduim.BonusSymbolWeight, meduim.BigSymbolWeight, meduim.BonusSymbolsTable),
		"high":   newVolatilityConfig(rand, high.LowRTP, high.HighRTP, high.AvailableReels, high.BonusSymbolWeight, high.BigSymbolWeight, high.BonusSymbolsTable),
	}

	if !lo.Contains(lo.Keys(volatilityConfigMap), config.Volatility) {
		config.Volatility = "medium" // FIXME: remove default value when slot-helm will be ready
	}

	rtp, err := strconv.ParseFloat(config.RTP, 64)
	if err != nil {
		zap.S().Panic(err)
		panic(err)
	}

	zap.S().Info("RTP: ", rtp)
	zap.S().Info("Volatility: ", config.Volatility)

	lowRTP := volatilityConfigMap[config.Volatility].LowRTP
	highRTP := volatilityConfigMap[config.Volatility].HighRTP

	highRTPProb = (lowRTP - rtp) / (lowRTP - highRTP)

	factory := NewSpinFactory(rand, volatilityConfigMap, config.Volatility)

	return &engine.Bootstrap{
		SpinFactory:        factory,
		HTTPTransport:      true,
		WebsocketTransport: true,

		FreeSpinsFeature: true,

		HistoryHandlingType: engine.SequentialRestoring,
	}
}

type SpinFactory struct {
	rand              rng.Client
	volatilityCfgMap  map[string]*Config
	defaultVolatility string
}

func NewSpinFactory(
	rand rng.Client,
	volatilityCfgMap map[string]*Config,
	defaultVolatility string,
) *SpinFactory {
	return &SpinFactory{
		rand:              rand,
		volatilityCfgMap:  volatilityCfgMap,
		defaultVolatility: defaultVolatility,
	}
}

func (s *SpinFactory) Cfg(key *string) *Config {
	if key != nil {
		return s.volatilityCfgMap[*key]
	}

	return s.volatilityCfgMap[s.defaultVolatility]
}

func (s *SpinFactory) Generate(ctx engine.Context, wager int64, _ interface{}) (engine.Spin, engine.RestoringIndexes, error) {
	cheats, err := getCheatsFromCtx(ctx)
	if err != nil {
		return nil, nil, err
	}

	var (
		vol *string
		rtp *int64
	)

	if ctx.UserParams != nil {
		vol = ctx.UserParams.Volatility
		rtp = ctx.UserParams.RTP
	}

	zap.S().Info("Generate...", rtp)
	if rtp != nil {
		zap.S().Info("RTP: ", *rtp)
	}
	if vol != nil {
		zap.S().Info("Volatility: ", *vol)
	}

	reelType, err := s.choseReels(rtp, vol, cheats)
	if err != nil {
		return nil, nil, err
	}

	stops, err := s.getStops(cheats, reelType, vol)
	if err != nil {
		return nil, nil, err
	}

	ag, err := NewAwardGetter(wager)
	if err != nil {
		return nil, nil, err
	}

	spin, err := s.computeBaseWindow(ag, stops, reelType, vol)
	if err != nil {
		return nil, nil, err
	}

	//WinsMap.Inc(spin.BaseAward() + spin.BonusAward())

	return spin, &RestoringIndexes{}, nil
}

func (s *SpinFactory) GambleAnyWin(_ engine.Context, _ interface{}) (engine.Spin, error) {
	return nil, nil
}

func (s *SpinFactory) KeepGenerate(_ engine.Context, _ interface{}) (engine.Spin, bool, error) {
	return nil, false, nil
}

func (s *SpinFactory) UnmarshalJSONSpin(bytes []byte) (engine.Spin, error) {
	spin := SpinBase{}
	err := json.Unmarshal(bytes, &spin)

	return &spin, err
}

func (s *SpinFactory) UnmarshalJSONRestoringIndexes(bytes []byte) (engine.RestoringIndexes, error) {
	restoringIndexes := RestoringIndexes{}
	err := json.Unmarshal(bytes, &restoringIndexes)

	return &restoringIndexes, err
}

func (s *SpinFactory) choseReels(rtp *int64, vol *string, cheats *Cheats) (int, error) {
	if cheats.reelTypeOneOf(reelSetLowRTPCode, reelSetHighRTPCode) {
		return cheats.ReelType, nil
	}

	r, err := s.rand.RandFloat()
	if err != nil {
		return -1, err
	}

	if rtp == nil {
		if r > highRTPProb {
			return reelSetLowRTPCode, nil
		}

		return reelSetHighRTPCode, nil
	}

	temp := float64(*rtp)

	lowRTP := s.Cfg(vol).LowRTP
	highRTP := s.Cfg(vol).HighRTP

	if temp < lowRTP {
		return reelSetLowRTPCode, nil
	}
	if temp > highRTP {
		return reelSetHighRTPCode, nil
	}

	prob := (lowRTP - temp) / (lowRTP - highRTP)

	if r > prob {
		return reelSetLowRTPCode, nil
	}

	return reelSetHighRTPCode, nil
}

func (s *SpinFactory) getStops(cheats *Cheats, reelCode int, vol *string) ([]int, error) {
	reel := s.Cfg(vol).AvailableReels[reelCode]

	if cheats != nil {
		if len(cheats.Stops) != len(reel) {
			return nil, errs.ErrBadDataGiven
		}

		for i := range cheats.Stops {
			if cheats.Stops[i] > len(reel[i]) {
				return nil, errs.ErrBadDataGiven
			}
		}

		return cheats.Stops, nil
	}

	req := lo.Map(reel, func(item []int, index int) uint64 {
		return uint64(len(item))
	})

	res, err := s.rand.RandSlice(req)
	if err != nil {
		return nil, err
	}

	return lo.Map(res, func(item uint64, index int) int {
		return int(item)
	}), nil
}
