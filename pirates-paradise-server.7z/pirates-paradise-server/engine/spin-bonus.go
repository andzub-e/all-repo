package engine

// BonusGame is an extension for every spin doesn't depend on if it is base or free
type BonusGame struct {
	Win   int64       `json:"award"`
	Spins []BonusSpin `json:"spins"`
}

type BonusSpin struct {
	Win            bool      `json:"award"`
	BonusSpinsLeft int       `json:"bonus_spins_left"`
	Window         [][]int64 `json:"window"`
}

func (b *BonusGame) Award() int64 {
	if b == nil {
		return 0
	}

	return b.Win
}
