package engine

import (
	"github.com/samber/lo"
)

type Window [][]int

func (w *Window) GetSymbol(_, payItem int) int {
	return w.symbol(payItem)
}

func (w *Window) GetByIndexes(reelIndex, symbolIndex int) (int, int) {
	return symbolIndex*windowWidth + reelIndex, (*w)[reelIndex][symbolIndex]
}

func (w *Window) GetHeight() int {
	return windowHeight
}

func (w *Window) GetWidth() int {
	return windowWidth
}

func (w *Window) symbol(payIndex int) int {
	position, reel := payIndex/windowWidth, payIndex%windowWidth

	return (*w)[reel][position]
}

// to think if we can calc scatters and bonuses on the generate stage
func (w *Window) computeBaseGame(stops []int, reels [][]int) (scatterQty, bonusQty int) {
	*w = lo.Map(stops, func(stop int, index int) []int {
		reel := reels[index]
		reelLen := len(reel)

		windowLine := make([]int, windowHeight)
		for i := 0; i < windowHeight; i++ {
			rIndex := mod(stop+i, reelLen)
			symbol := reel[rIndex]

			scatterQty += addScatterQty(symbol, 1)
			bonusQty += addBonusQty(symbol, 1)

			windowLine[i] = symbol
		}

		return windowLine
	})

	return
}

// stop only for first and last reel, 3 reels in the middle have same symbols (bigSymbol)
// 3 5 5 5 6
// 4 5 5 5 3
// 6 5 5 5 1
func (w *Window) computeFreeGame(stops []int, bigSymbol int, reels [][]int) (scatterQty, bonusFirstQty, bonusLastQty int) {
	*w = make([][]int, windowWidth)

	index := 0
	for i := 0; i < windowWidth; i++ {
		windowLine := make([]int, windowHeight)

		if i == 0 || i == windowWidth-1 {
			reel := reels[index]
			reelLen := len(reel)

			for j := 0; j < windowHeight; j++ {
				symbol := reel[mod(stops[index]+j, reelLen)]

				scatterQty += addScatterQty(symbol, 1)

				if addBonusQty(symbol, 1) == 1 {
					if index == 0 {
						bonusFirstQty++
					} else {
						bonusLastQty++
					}
				}

				windowLine[j] = symbol
			}

			(*w)[i] = windowLine

			index++

			continue
		}

		for j := 0; j < windowHeight; j++ {
			windowLine[j] = bigSymbol
		}

		(*w)[i] = windowLine
	}

	return scatterQty, bonusFirstQty, bonusLastQty
}

func (w *Window) scatterIndexes() []int {
	indexes := make([]int, 0, 3)

	for i, reel := range *w {
		for j, symbol := range reel {
			if symbol == scatterSymbol {
				indexes = append(indexes, j*windowWidth+i)
			}
		}
	}

	return indexes
}

func addScatterQty(symbol, qty int) int {
	if symbol == scatterSymbol {
		return qty
	}

	return 0
}

func addBonusQty(symbol, qty int) int {
	if symbol == bonusSymbol {
		return qty
	}

	return 0
}

func mod(a, b int) int {
	return (a%b + b) % b
}
