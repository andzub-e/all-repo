package engine

const (
	windowHeight = 3
	windowWidth  = 5

	reelSetHighRTPCode = 0
	reelSetLowRTPCode  = 1
	reelSetBonusCode   = 2

	needScattersToTriggerFreeSpins   = 3
	needScattersToReTriggerFreeSpins = 3
	freeGameSpins                    = 5
	freeGameSpinsReTrigger           = 3

	needBonusesToTriggerBonusSpins = 6
	bonusGameSpins                 = 3

	megaMultiplier = 1000

	multiplicationDivider = 10

	bigSymbolQty = 9
)

var highRTPProb float64

var (
	wildSymbol    = 1
	bonusSymbol   = 10
	scatterSymbol = 11
)

var multipliers = map[int]map[int]int64{
	1:  {3: 10, 4: 100, 5: 200},
	2:  {3: 10, 4: 100, 5: 200},
	3:  {3: 8, 4: 60, 5: 160},
	4:  {3: 6, 4: 40, 5: 120},
	5:  {3: 4, 4: 20, 5: 80},
	6:  {3: 4, 4: 8, 5: 20},
	7:  {3: 2, 4: 8, 5: 20},
	8:  {3: 2, 4: 8, 5: 20},
	9:  {3: 2, 4: 8, 5: 20},
	10: {},
	11: {3: 10},
}

var payLines = [][]int{
	{5, 6, 7, 8, 9},
	{0, 1, 2, 3, 4},
	{10, 11, 12, 13, 14},
	{0, 6, 12, 8, 4},
	{10, 6, 2, 8, 14},
	{5, 1, 2, 3, 9},
	{5, 11, 12, 13, 9},
	{0, 1, 7, 13, 14},
	{10, 11, 7, 3, 4},
	{5, 11, 7, 3, 9},
	{5, 1, 7, 13, 9},
	{0, 6, 7, 8, 4},
	{10, 6, 7, 8, 14},
	{0, 6, 2, 8, 4},
	{10, 6, 12, 8, 14},
	{5, 6, 2, 8, 9},
	{5, 6, 12, 8, 9},
	{0, 1, 12, 3, 4},
	{10, 11, 2, 13, 14},
	{0, 11, 12, 13, 4},
	{10, 1, 2, 3, 14},
	{5, 11, 2, 13, 9},
	{5, 1, 12, 3, 9},
	{0, 11, 2, 13, 4},
	{10, 1, 12, 3, 14},
}
