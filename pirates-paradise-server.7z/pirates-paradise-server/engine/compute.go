package engine

import (
	"fmt"
)

func (s *SpinFactory) computeBaseWindow(ag AwardGetter, stops []int, reelType int, vol *string) (*SpinBase, error) {
	var (
		reels     = s.Cfg(vol).AvailableReels[reelType]
		window    Window
		bonusGame *BonusGame
		freeGame  *FreeGame
		err       error
	)

	scatterQty, bonusQty := window.computeBaseGame(stops, reels)

	bonusSymbols, err := s.createBonusSymbols(bonusQty, ag.wager(), vol)
	if err != nil {
		return nil, err
	}

	payLinesToShow, award := calcWin(ag, window)

	if scatterQty >= needScattersToTriggerFreeSpins {
		scatterAward := ag.wager()

		payLinesToShow = append(payLinesToShow, PayLine{
			Symbol:  scatterSymbol,
			Indexes: window.scatterIndexes(),
			Award:   scatterAward,
		})

		award += scatterAward

		freeGame, err = s.computeFreeWindow(ag, window, vol)
		if err != nil {
			return nil, err
		}

		// FreeSpinsDuration += int64(len(freeGame.Spins))
		// FreeSpinsCount++
	}

	if bonusQty >= needBonusesToTriggerBonusSpins {
		bonusGame, err = s.computeBonusWindow(window, bonusSymbols, ag.wager(), vol)
		if err != nil {
			return nil, err
		}

		// BonusGameAward += bonusGame.Award()

		// BonusGameCountFromBaseGame++
	}

	// BaseGameAward += award

	return &SpinBase{
		WagerVal:       ag.wager(),
		Win:            award,
		Stops:          stops,
		Window:         window,
		BonusSymbols:   bonusSymbols,
		PayLinesToShow: payLinesToShow,
		ReelType:       reelType,

		FreeGame:  freeGame,
		BonusGame: bonusGame,
	}, nil
}

func (s *SpinFactory) computeFreeWindow(ag AwardGetter, window Window, vol *string) (*FreeGame, error) {
	var (
		freeGame   = new(FreeGame)
		extraSpins = 0
	)

	for spins := freeGameSpins; spins > 0 || extraSpins > 0; spins-- {
		var bonusGame *BonusGame
		var bonusQty int

		stops, err := s.getStops(nil, reelSetBonusCode, vol)
		if err != nil {
			return nil, err
		}

		bigSymbol, err := s.Cfg(vol).BigSymbolChooser.Pick()
		if err != nil {
			return nil, err
		}

		reels := s.Cfg(vol).AvailableReels[reelSetBonusCode]

		scatterQty, bonusFirstQty, bonusLastQty := window.computeFreeGame(stops, bigSymbol, reels)

		bonusQty = bonusFirstQty + bonusLastQty

		if bigSymbol == bonusSymbol {
			bonusQty += bigSymbolQty
		}
		if bigSymbol == scatterSymbol {
			scatterQty += 1
		}

		bonusSymbols, err := s.computeBonusSymbolForFreeGame(bigSymbol, ag.wager(), bonusFirstQty, bonusLastQty, vol)
		if err != nil {
			return nil, err
		}

		payLinesToShow, spinAward := calcWin(ag, window)

		if extraSpins > 0 {
			spins += extraSpins
			extraSpins = 0
		}

		if scatterQty >= needScattersToReTriggerFreeSpins {
			scatterAward := ag.wager()

			payLinesToShow = append(payLinesToShow, PayLine{
				Symbol:  scatterSymbol,
				Indexes: window.scatterIndexes(),
				Award:   scatterAward,
			})

			spinAward += scatterAward

			extraSpins = freeGameSpinsReTrigger
		}

		// FreeSpinsGameAward += spinAward

		if bonusQty >= needBonusesToTriggerBonusSpins {
			bonusGame, err = s.computeBonusWindow(window, bonusSymbols, ag.wager(), vol)
			if err != nil {
				return nil, err
			}

			// BonusGameAward += bonusGame.Award()

			// BonusGameCountFromFreeSpins++

			spinAward += bonusGame.Award()
		}

		freeGame.Spins = append(freeGame.Spins, FreeSpin{
			Stops:              stops,
			Award:              spinAward,
			Window:             window,
			FreeSpinsLeft:      spins,
			FreeSpinsTriggered: extraSpins,
			PayLinesToShow:     payLinesToShow,

			BonusSymbols: bonusSymbols,
			BonusSpin:    bonusGame,
		})

		freeGame.Win += spinAward
	}

	return freeGame, nil
}

func (s *SpinFactory) computeBonusWindow(window Window, bonusSymbols []int64, wager int64, vol *string) (*BonusGame, error) {
	var (
		bonusGame   = new(BonusGame)
		windowBonus WindowBonus
	)

	entryIndexesMap := windowBonus.compute(window, bonusSymbols)

	for spins := bonusGameSpins; spins > 0; {
		if len(entryIndexesMap) == 0 {
			bonusGame.Win = windowBonus.awardWithMegaJackpot(wager)

			return bonusGame, nil
		}

		btc, ok := s.Cfg(vol).BonusSymbolsTableChooser[len(entryIndexesMap)]
		if !ok {
			return nil, fmt.Errorf("can't find bonus table for %d symbols", len(entryIndexesMap))
		}

		newSymbolsQty, err := btc.Pick()
		if err != nil {
			return nil, err
		}

		newSymbols := make([]int64, newSymbolsQty)
		for i := 0; i < newSymbolsQty; i++ {
			value, err := s.Cfg(vol).BonusSymbolChooser.Pick()
			if err != nil {
				return nil, err
			}

			newSymbols[i] = value * wager
		}

		newIndexes := make([]int, 0, newSymbolsQty)

		for index := range entryIndexesMap {
			if len(newIndexes) == newSymbolsQty {
				break
			}

			newIndexes = append(newIndexes, index)
			delete(entryIndexesMap, index)
		}

		windowBonus.spin(newSymbols, newIndexes)

		if newSymbolsQty > 0 {
			spins = bonusGameSpins
		} else {
			spins--
		}

		bonusGame.Spins = append(bonusGame.Spins, BonusSpin{
			Win:            newSymbolsQty > 0,
			BonusSpinsLeft: spins,
			Window:         windowBonus.window(),
		})
	}

	bonusGame.Win = windowBonus.award()

	return bonusGame, nil
}

func calcWin(ag AwardGetter, window Window) (payLinesToShow []PayLine, totalAward int64) {
	for i := range payLines {
		firstSymbol := window.symbol(payLines[i][0])
		if firstSymbol == scatterSymbol {
			continue
		}

		wildReplaced := false
		wildCount := 0
		count := 1

		for ; count < len(payLines[i]); count++ {
			expectedSymbol := window.symbol(payLines[i][count])

			if expectedSymbol == scatterSymbol {
				break
			}

			if !wildReplaced && firstSymbol == wildSymbol && firstSymbol != expectedSymbol {
				firstSymbol = expectedSymbol
				wildReplaced = true
				wildCount = count

			} else if expectedSymbol != firstSymbol && expectedSymbol != wildSymbol {
				break
			}
		}

		award := ag.GetAward(firstSymbol, count)

		if wildReplaced {
			wildAward := ag.GetAward(wildSymbol, wildCount)
			if wildAward > award {
				award = wildAward
				firstSymbol = wildSymbol
				count = wildCount
			}
		}

		if award == 0 {
			continue
		}

		payLinesToShow = append(payLinesToShow, PayLine{
			Symbol:  firstSymbol,
			Indexes: payLines[i][:count],
			Award:   award,
		})

		totalAward += award
	}

	return payLinesToShow, totalAward
}

func (s *SpinFactory) createBonusSymbols(length int, wager int64, vol *string) ([]int64, error) {
	symbols := make([]int64, length)

	for i := 0; i < length; i++ {
		value, err := s.Cfg(vol).BonusSymbolChooser.Pick()
		if err != nil {
			return nil, err
		}

		symbols[i] = value * wager
	}

	return symbols, nil
}

func (s *SpinFactory) computeBonusSymbolForFreeGame(bigSymbol int, wager int64, firstQty, lastQty int, vol *string) ([]int64, error) {
	var symbols []int64
	if bigSymbol == bonusSymbol {
		symbols = make([]int64, 0, firstQty+lastQty+bigSymbolQty)
	} else {
		symbols = make([]int64, 0, firstQty+lastQty)
	}

	if firstQty > 0 {
		for i := 0; i < firstQty; i++ {
			value, err := s.Cfg(vol).BonusSymbolChooser.Pick()
			if err != nil {
				return nil, err
			}

			symbols = append(symbols, value*wager)
		}
	}

	if bigSymbol == bonusSymbol {
		value, err := s.Cfg(vol).BonusSymbolChooser.Pick()
		if err != nil {
			return nil, err
		}

		for i := 0; i < bigSymbolQty; i++ {
			symbols = append(symbols, value*wager)
		}
	}

	if lastQty > 0 {
		for i := 0; i < lastQty; i++ {
			value, err := s.Cfg(vol).BonusSymbolChooser.Pick()
			if err != nil {
				return nil, err
			}

			symbols = append(symbols, value*wager)
		}
	}

	return symbols, nil
}
