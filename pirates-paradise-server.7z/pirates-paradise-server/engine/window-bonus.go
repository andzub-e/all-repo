package engine

type WindowBonus struct {
	w   [][]int64
	win int64
}

func (w *WindowBonus) compute(window [][]int, bonusSymbols []int64) map[int]struct{} {
	entryIndexes := map[int]struct{}{}

	w.w = make([][]int64, windowWidth)

	// i - bonusSymbols index
	// j - index of not bonus symbols from 1 to 9
	i := 0
	for rI, reel := range window {
		w.w[rI] = make([]int64, windowHeight)

		for sI, symbol := range reel {
			if symbol == bonusSymbol {
				w.w[rI][sI] = bonusSymbols[i]
				w.win += bonusSymbols[i]
				i++

				continue
			}

			w.w[rI][sI] = 0

			entryIndexes[sI*windowWidth+rI] = struct{}{}
		}
	}

	return entryIndexes
}

func (w *WindowBonus) spin(newValue []int64, newIndexes []int) {
	for i, index := range newIndexes {
		sIndex := index / windowWidth
		rIndex := index % windowWidth

		w.w[rIndex][sIndex] = newValue[i]
		w.win += newValue[i]
	}
}

func (w *WindowBonus) window() [][]int64 {
	copied := make([][]int64, len(w.w))

	for i := range w.w {
		copied[i] = make([]int64, len(w.w[i]))

		copy(copied[i], w.w[i])
	}

	return copied
}

func (w *WindowBonus) award() (award int64) {
	return w.win
}

func (w *WindowBonus) awardWithMegaJackpot(wager int64) int64 {
	return w.award() + megaMultiplier*wager
}
