package engine

import "sync"

var (
	BaseGameAward      int64 = 0
	BonusGameAward     int64 = 0
	FreeSpinsGameAward int64 = 0

	FreeSpinsCount              int64 = 0
	BonusGameCountFromBaseGame  int64 = 0
	BonusGameCountFromFreeSpins int64 = 0

	FreeSpinsDuration int64 = 0
)

var WinsMap = NewSafeMap()

type SafeMap struct {
	mu   sync.Mutex // Guards access to the internal map
	data map[int64]uint64
}

func NewSafeMap() *SafeMap {
	return &SafeMap{
		data: make(map[int64]uint64),
	}
}

func (sm *SafeMap) Inc(key int64) {
	sm.mu.Lock()
	defer sm.mu.Unlock()
	sm.data[key]++
}

func (sm *SafeMap) Map() map[int64]uint64 {
	sm.mu.Lock()
	defer sm.mu.Unlock()
	return sm.data
}
