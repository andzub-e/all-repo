package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
)

type SpinBase struct {
	WagerVal       int64     `json:"wager"`
	Win            int64     `json:"award"`
	Stops          []int     `json:"stops"`
	Window         Window    `json:"window"`
	BonusSymbols   []int64   `json:"bonus_symbols"`
	PayLinesToShow []PayLine `json:"pay_lines_to_show"`
	ReelType       int       `json:"reel_type"`

	FreeGame  *FreeGame  `json:"free_game"`
	BonusGame *BonusGame `json:"bonus_game"`
}

type PayLine struct {
	Symbol  int   `json:"symbol"`
	Indexes []int `json:"indexes"`
	Award   int64 `json:"award"`
}

func (s *SpinBase) BaseAward() int64 {
	return s.Win
}

func (s *SpinBase) BonusAward() (award int64) {
	if s.BonusGame != nil {
		award += s.BonusGame.Award()
	}

	if s.FreeGame != nil {
		award += s.FreeGame.Award()
	}

	return award
}

func (s *SpinBase) GambleAward() int64 {
	return 0
}

func (s *SpinBase) Wager() int64 {
	return s.WagerVal
}

func (s *SpinBase) GambleQuantity() int {
	return 0
}

func (s *SpinBase) CanGamble(_ engine.RestoringIndexes) bool {
	return false
}

func (s *SpinBase) BonusTriggered() bool {
	return s.FreeGame != nil
}

func (s *SpinBase) DeepCopy() engine.Spin {
	spin := &SpinBase{
		WagerVal: s.WagerVal,
		Win:      s.Win,
		ReelType: s.ReelType,
		// TODO: need to add deep copy for FreeGame and BonusGame
		FreeGame:  s.FreeGame,
		BonusGame: s.BonusGame,

		Stops:          make([]int, len(s.Stops)),
		BonusSymbols:   make([]int64, len(s.BonusSymbols)),
		Window:         make([][]int, len(s.Window)),
		PayLinesToShow: make([]PayLine, len(s.PayLinesToShow)),
	}

	copy(spin.Stops, s.Stops)
	copy(spin.BonusSymbols, s.BonusSymbols)
	copy(spin.Window, s.Window)
	copy(spin.PayLinesToShow, s.PayLinesToShow)

	return spin
}
