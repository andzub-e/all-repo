package engine

import (
	"fmt"
	"testing"
)

func Test_calcWin(t *testing.T) {
	type args struct {
		ag     AwardGetter
		window Window
	}
	tests := []struct {
		name      string
		args      args
		wantAward int64
	}{
		{
			name: "1",
			args: args{
				ag: AwardGetter{Wager: 25},
				window: [][]int{
					{5, 8, 1},
					{1, 1, 1},
					{1, 1, 1},
					{1, 1, 1},
					{9, 5, 3},
				},
			},
			wantAward: 3630,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			payLines, gotAward := calcWin(tt.args.ag, tt.args.window)

			for _, payLine := range payLines {
				fmt.Printf("Symbol %d: [ ", payLine.Symbol)
				for _, index := range payLine.Indexes {
					fmt.Printf("%d ", tt.args.window.symbol(index))
				}
				fmt.Printf("] Win: %d\n", payLine.Award)
			}

			if gotAward != tt.wantAward {
				t.Errorf("calcWin() gotAward = %v, want %v", gotAward, tt.wantAward)
			}
		})
	}
}

/*
Expected output:
Line 1: 8,1,1,1,5   Win: 20
Line 2: 5,1,1,1,9   Win: 50
Line 3: 1,1,1,1,3   Win: 400
Line 4: 5,1,1,1,9   Win: 50
Line 5: 1,1,1,1,3   Win: 400
Line 6: 8,1,1,1,5   Win: 20
Line 7: 8,1,1,1,5   Win: 20
Line 8: 5,1,1,1,3   Win: 50
Line 9: 1,1,1,1,9   Win: 250
Line 10: 8,1,1,1,5   Win: 20
Line 11: 8,1,1,1,5   Win: 20
Line 12: 5,1,1,1,9   Win: 50
Line 13: 1,1,1,1,3   Win: 400
Line 14: 5,1,1,1,9   Win: 50
Line 15: 1,1,1,1,3   Win: 400
Line 16: 8,1,1,1,5   Win: 20
Line 17: 8,1,1,1,5   Win: 20
Line 18: 5,1,1,1,9   Win: 50
Line 19: 1,1,1,1,3   Win: 400
Line 20: 5,1,1,1,9   Win: 50
Line 21: 1,1,1,1,3   Win: 400
Line 22: 8,1,1,1,5   Win: 20
Line 23: 8,1,1,1,5   Win: 20
Line 24: 5,1,1,1,9   Win: 50
Line 25: 1,1,1,1,3   Win: 400
Total win: 3630
*/
