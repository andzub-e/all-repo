package engine

import "fmt"

type AwardGetter struct {
	Wager int64
}

func NewAwardGetter(wager int64) (AwardGetter, error) {
	if wager < 0 {
		return AwardGetter{}, fmt.Errorf("negative wager: %v", wager)
	}

	return AwardGetter{Wager: wager}, nil
}

func (a AwardGetter) GetAward(symbol, size int) int64 {
	mul := multipliers[symbol][size]

	return mul * a.Wager / multiplicationDivider
}

func (a AwardGetter) wager() int64 {
	return a.Wager
}
