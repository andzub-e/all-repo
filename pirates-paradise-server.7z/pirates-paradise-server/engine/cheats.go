package engine

import (
	"bitbucket.org/electronicjaw/base-slot-server/pkg/kernel/engine"
	"encoding/json"
)

type Cheats struct {
	ReelType int   `json:"reel_type"`
	Stops    []int `json:"stops"`
}

func (c *Cheats) Eval(payload interface{}) error {
	b, err := json.Marshal(payload)
	if err != nil {
		return err
	}

	return json.Unmarshal(b, c)
}

func (c *Cheats) reelTypeOneOf(types ...int) bool {
	if c == nil {
		return false
	}

	for i := range types {
		if c.ReelType == types[i] {
			return true
		}
	}

	return false
}

func getCheatsFromCtx(ctx engine.Context) (*Cheats, error) {
	var cheats *Cheats

	if ctx.Cheats != nil {
		cheats = new(Cheats)

		if err := cheats.Eval(ctx.Cheats); err != nil {
			return nil, err
		}
	}

	return cheats, nil
}
